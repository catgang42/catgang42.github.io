#!/bin/sh
java -Xmx512M -Xms512M -jar eaglercraft_bukkit.jar
