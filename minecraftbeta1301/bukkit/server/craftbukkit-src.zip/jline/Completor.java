// 
// Decompiled by Procyon v0.5.36
// 

package jline;

import java.util.List;

public interface Completor
{
    int complete(final String p0, final int p1, final List p2);
}
