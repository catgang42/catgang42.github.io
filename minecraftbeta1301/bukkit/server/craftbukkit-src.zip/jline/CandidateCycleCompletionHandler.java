// 
// Decompiled by Procyon v0.5.36
// 

package jline;

import java.io.IOException;
import java.util.List;

public class CandidateCycleCompletionHandler implements CompletionHandler
{
    public boolean complete(final ConsoleReader reader, final List candidates, final int position) throws IOException {
        throw new IllegalStateException("CandidateCycleCompletionHandler unimplemented");
    }
}
