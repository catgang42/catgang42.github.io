// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Arrays;

public class LongHashset<V> extends LongHash<V>
{
    long[][][] values;
    int count;
    
    public LongHashset() {
        this.values = new long[256][][];
        this.count = 0;
    }
    
    public boolean isEmpty() {
        return this.count == 0;
    }
    
    public void add(final int msw, final int lsw) {
        this.add(LongHash.toLong(msw, lsw));
    }
    
    public void add(final long key) {
        final int mainIdx = (int)(key & 0xFFL);
        final int outerIdx = (int)(key >> 32 & 0xFFL);
        long[][] outer = this.values[mainIdx];
        if (outer == null) {
            outer = (this.values[mainIdx] = new long[256][]);
        }
        long[] inner = outer[outerIdx];
        if (inner == null) {
            inner = (outer[outerIdx] = new long[] { 0L });
            inner[0] = key;
            ++this.count;
        }
        else {
            int i;
            for (i = 0; i < inner.length; ++i) {
                if (inner[i] == key) {
                    return;
                }
            }
            inner = (outer[outerIdx] = Arrays.copyOf(inner, i + 1));
            inner[i] = key;
            ++this.count;
        }
    }
    
    @Override
    public boolean containsKey(final long key) {
        final int mainIdx = (int)(key & 0xFFL);
        final int outerIdx = (int)(key >> 32 & 0xFFL);
        final long[][] outer = this.values[mainIdx];
        if (outer == null) {
            return false;
        }
        final long[] inner = outer[outerIdx];
        if (inner == null) {
            return false;
        }
        for (final long entry : inner) {
            if (entry == key) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void remove(final long key) {
        final long[][] outer = this.values[(int)(key & 0xFFL)];
        if (outer == null) {
            return;
        }
        final long[] inner = outer[(int)(key >> 32 & 0xFFL)];
        if (inner == null) {
            return;
        }
        for (int max = inner.length - 1, i = 0; i <= max; ++i) {
            if (inner[i] == key) {
                --this.count;
                if (i != max) {
                    inner[i] = inner[max];
                }
                outer[(int)(key >> 32 & 0xFFL)] = (long[])((max == 0) ? null : Arrays.copyOf(inner, max));
                return;
            }
        }
    }
    
    public long popFirst() {
        for (final long[][] outer : this.values) {
            if (outer != null) {
                for (int i = 0; i < outer.length; ++i) {
                    final long[] inner = outer[i];
                    if (inner != null && inner.length != 0) {
                        --this.count;
                        final long ret = inner[inner.length - 1];
                        outer[i] = Arrays.copyOf(inner, inner.length - 1);
                        return ret;
                    }
                }
            }
        }
        return 0L;
    }
    
    public long[] keys() {
        int index = 0;
        final long[] ret = new long[this.count];
        for (final long[][] outer : this.values) {
            if (outer != null) {
                for (final long[] inner : outer) {
                    if (inner != null) {
                        for (final long entry : inner) {
                            ret[index++] = entry;
                        }
                    }
                }
            }
        }
        return ret;
    }
}
