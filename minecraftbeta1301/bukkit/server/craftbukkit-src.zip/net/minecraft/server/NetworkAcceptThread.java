// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.net.InetAddress;
import java.net.Socket;
import java.io.IOException;
import java.util.HashMap;

class NetworkAcceptThread extends Thread
{
    final /* synthetic */ MinecraftServer a;
    final /* synthetic */ NetworkListenThread b;
    
    NetworkAcceptThread(final NetworkListenThread b, final String name, final MinecraftServer a) {
        this.b = b;
        this.a = a;
        super(name);
    }
    
    @Override
    public void run() {
        final HashMap<Object, Long> hashMap = new HashMap<Object, Long>();
        while (this.b.b) {
            try {
                final Socket accept = this.b.d.accept();
                if (accept == null) {
                    continue;
                }
                final InetAddress inetAddress = accept.getInetAddress();
                if (hashMap.containsKey(inetAddress) && !"127.0.0.1".equals(inetAddress.getHostAddress()) && System.currentTimeMillis() - hashMap.get(inetAddress) < 5000L) {
                    hashMap.put(inetAddress, System.currentTimeMillis());
                    accept.close();
                }
                else {
                    hashMap.put(inetAddress, System.currentTimeMillis());
                    this.b.a(new NetLoginHandler(this.a, accept, "Connection #" + this.b.f++));
                }
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}
