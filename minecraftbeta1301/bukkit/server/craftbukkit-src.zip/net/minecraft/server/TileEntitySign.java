// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class TileEntitySign extends TileEntity
{
    public String[] a;
    public int b;
    
    public TileEntitySign() {
        this.a = new String[] { "", "", "", "" };
        this.b = -1;
    }
    
    @Override
    public void b(final NBTTagCompound nbtTagCompound) {
        super.b(nbtTagCompound);
        nbtTagCompound.a("Text1", this.a[0]);
        nbtTagCompound.a("Text2", this.a[1]);
        nbtTagCompound.a("Text3", this.a[2]);
        nbtTagCompound.a("Text4", this.a[3]);
    }
    
    @Override
    public void a(final NBTTagCompound nbtTagCompound) {
        super.a(nbtTagCompound);
        for (int i = 0; i < 4; ++i) {
            this.a[i] = nbtTagCompound.i("Text" + (i + 1));
            if (this.a[i].length() > 15) {
                this.a[i] = this.a[i].substring(0, 15);
            }
        }
    }
    
    @Override
    public Packet e() {
        final String[] array = new String[4];
        for (int i = 0; i < 4; ++i) {
            array[i] = this.a[i];
        }
        return new Packet130UpdateSign(this.e, this.f, this.g, array);
    }
}
