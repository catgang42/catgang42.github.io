// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.Server;
import org.bukkit.craftbukkit.CraftChunk;
import org.bukkit.event.world.ChunkUnloadEvent;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.Event;
import java.util.ArrayList;
import java.util.List;

public class ChunkProviderServer implements IChunkProvider
{
    public LongHashset a;
    private Chunk b;
    private IChunkProvider c;
    private IChunkLoader d;
    public LongHashtable<Chunk> e;
    public List f;
    public WorldServer g;
    
    public ChunkProviderServer(final WorldServer worldserver, final IChunkLoader ichunkloader, final IChunkProvider ichunkprovider) {
        this.a = new LongHashset();
        this.e = new LongHashtable<Chunk>();
        this.f = new ArrayList();
        this.b = new EmptyChunk(worldserver, new byte[32768], 0, 0);
        this.g = worldserver;
        this.d = ichunkloader;
        this.c = ichunkprovider;
    }
    
    public boolean a(final int i, final int j) {
        return this.e.containsKey(i, j);
    }
    
    public void c(final int i, final int j) {
        final ChunkCoordinates chunkcoordinates = this.g.l();
        final int k = i * 16 + 8 - chunkcoordinates.a;
        final int l = j * 16 + 8 - chunkcoordinates.c;
        final short short1 = 128;
        if (k < -short1 || k > short1 || l < -short1 || l > short1) {
            this.a.add(i, j);
        }
    }
    
    public Chunk d(final int i, final int j) {
        this.a.remove(i, j);
        Chunk chunk = this.e.get(i, j);
        if (chunk == null) {
            chunk = this.e(i, j);
            if (chunk == null) {
                if (this.c == null) {
                    chunk = this.b;
                }
                else {
                    chunk = this.c.b(i, j);
                }
            }
            this.e.put(i, j, chunk);
            this.f.add(chunk);
            if (chunk != null) {
                chunk.c();
                chunk.d();
            }
            final CraftServer server = this.g.getServer();
            if (server != null) {
                server.getPluginManager().callEvent(new ChunkLoadEvent(Event.Type.CHUNK_LOADED, chunk.bukkitChunk));
            }
            if (!chunk.n && this.a(i + 1, j + 1) && this.a(i, j + 1) && this.a(i + 1, j)) {
                this.a(this, i, j);
            }
            if (this.a(i - 1, j) && !this.b(i - 1, j).n && this.a(i - 1, j + 1) && this.a(i, j + 1) && this.a(i - 1, j)) {
                this.a(this, i - 1, j);
            }
            if (this.a(i, j - 1) && !this.b(i, j - 1).n && this.a(i + 1, j - 1) && this.a(i, j - 1) && this.a(i + 1, j)) {
                this.a(this, i, j - 1);
            }
            if (this.a(i - 1, j - 1) && !this.b(i - 1, j - 1).n && this.a(i - 1, j - 1) && this.a(i, j - 1) && this.a(i - 1, j)) {
                this.a(this, i - 1, j - 1);
            }
        }
        return chunk;
    }
    
    public Chunk b(final int i, final int j) {
        Chunk chunk = this.e.get(i, j);
        chunk = ((chunk == null) ? (this.g.r ? this.d(i, j) : this.b) : chunk);
        if (chunk == this.b) {
            return chunk;
        }
        if (i != chunk.j || j != chunk.k) {
            MinecraftServer.a.info("Chunk (" + chunk.j + ", " + chunk.k + ") stored at  (" + i + ", " + j + ")");
            MinecraftServer.a.info(chunk.getClass().getName());
            final Throwable x = new Throwable();
            x.fillInStackTrace();
            x.printStackTrace();
        }
        return chunk;
    }
    
    public Chunk e(final int i, final int j) {
        if (this.d == null) {
            return null;
        }
        try {
            final Chunk chunk = this.d.a(this.g, i, j);
            if (chunk != null) {
                chunk.r = this.g.k();
            }
            return chunk;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return null;
        }
    }
    
    public void a(final Chunk chunk) {
        if (this.d != null) {
            try {
                this.d.b(this.g, chunk);
            }
            catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }
    
    public void b(final Chunk chunk) {
        if (this.d != null) {
            try {
                chunk.r = this.g.k();
                this.d.a(this.g, chunk);
            }
            catch (Exception ioexception) {
                ioexception.printStackTrace();
            }
        }
    }
    
    public void a(final IChunkProvider ichunkprovider, final int i, final int j) {
        final Chunk chunk = this.b(i, j);
        if (!chunk.n) {
            chunk.n = true;
            if (this.c != null) {
                this.c.a(ichunkprovider, i, j);
                chunk.f();
            }
        }
    }
    
    public boolean a(final boolean flag, final IProgressUpdate iprogressupdate) {
        int i = 0;
        for (int j = 0; j < this.f.size(); ++j) {
            final Chunk chunk = this.f.get(j);
            if (flag && !chunk.p) {
                this.a(chunk);
            }
            if (chunk.a(flag)) {
                this.b(chunk);
                chunk.o = false;
                if (++i == 24 && !flag) {
                    return false;
                }
            }
        }
        if (flag) {
            if (this.d == null) {
                return true;
            }
            this.d.b();
        }
        return true;
    }
    
    public boolean a() {
        if (!this.g.w) {
            final Server server = this.g.getServer();
            while (!this.a.isEmpty()) {
                final long chunkcoordinates = this.a.popFirst();
                final Chunk chunk = this.e.get(chunkcoordinates);
                if (chunk == null) {
                    continue;
                }
                final ChunkUnloadEvent event = new ChunkUnloadEvent(Event.Type.CHUNK_UNLOADED, chunk.bukkitChunk);
                server.getPluginManager().callEvent(event);
                if (event.isCancelled()) {
                    continue;
                }
                this.g.getWorld().preserveChunk((CraftChunk)chunk.bukkitChunk);
                chunk.e();
                this.b(chunk);
                this.a(chunk);
                this.e.remove(chunkcoordinates);
                this.f.remove(chunk);
            }
            if (this.d != null) {
                this.d.a();
            }
        }
        return this.c.a();
    }
    
    public boolean b() {
        return !this.g.w;
    }
}
