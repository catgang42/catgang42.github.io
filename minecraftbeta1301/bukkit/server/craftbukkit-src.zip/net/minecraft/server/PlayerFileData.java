// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public interface PlayerFileData
{
    void a(final EntityHuman p0);
    
    void b(final EntityHuman p0);
}
