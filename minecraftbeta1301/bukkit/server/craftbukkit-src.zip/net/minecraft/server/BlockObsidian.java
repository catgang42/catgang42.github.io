// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockObsidian extends BlockStone
{
    public BlockObsidian(final int n, final int n2) {
        super(n, n2);
    }
    
    @Override
    public int a(final Random random) {
        return 1;
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Block.OBSIDIAN.id;
    }
}
