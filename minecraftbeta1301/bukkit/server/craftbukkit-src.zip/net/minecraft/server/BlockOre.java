// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockOre extends Block
{
    public BlockOre(final int n, final int n2) {
        super(n, n2, Material.STONE);
    }
    
    @Override
    public int a(final int n, final Random random) {
        if (this.id == Block.COAL_ORE.id) {
            return Item.COAL.id;
        }
        if (this.id == Block.DIAMOND_ORE.id) {
            return Item.DIAMOND.id;
        }
        if (this.id == Block.LAPIS_ORE.id) {
            return Item.INK_SACK.id;
        }
        return this.id;
    }
    
    @Override
    public int a(final Random random) {
        if (this.id == Block.LAPIS_ORE.id) {
            return 4 + random.nextInt(5);
        }
        return 1;
    }
    
    @Override
    protected int b(final int n) {
        if (this.id == Block.LAPIS_ORE.id) {
            return 4;
        }
        return 0;
    }
}
