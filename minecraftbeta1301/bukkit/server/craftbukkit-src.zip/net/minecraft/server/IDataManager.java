// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.List;

public interface IDataManager
{
    WorldData c();
    
    void b();
    
    IChunkLoader a(final WorldProvider p0);
    
    void a(final WorldData p0, final List p1);
    
    void a(final WorldData p0);
    
    PlayerFileData d();
    
    void e();
}
