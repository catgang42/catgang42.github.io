// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockMobSpawner extends BlockContainer
{
    protected BlockMobSpawner(final int n, final int n2) {
        super(n, n2, Material.STONE);
    }
    
    @Override
    protected TileEntity a_() {
        return new TileEntityMobSpawner();
    }
    
    @Override
    public int a(final int n, final Random random) {
        return 0;
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
    
    @Override
    public boolean a() {
        return false;
    }
}
