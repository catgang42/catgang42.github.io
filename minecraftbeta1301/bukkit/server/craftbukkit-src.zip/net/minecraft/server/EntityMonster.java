// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityTargetEvent;

public class EntityMonster extends EntityCreature implements IMonster
{
    protected int c;
    
    public EntityMonster(final World world) {
        super(world);
        this.c = 2;
        this.health = 20;
    }
    
    @Override
    public void q() {
        final float f = this.c(1.0f);
        if (f > 0.5f) {
            this.at += 2;
        }
        super.q();
    }
    
    @Override
    public void f_() {
        super.f_();
        if (this.world.j == 0) {
            this.C();
        }
    }
    
    @Override
    protected Entity l() {
        final EntityHuman entityhuman = this.world.a(this, 16.0);
        return (entityhuman != null && this.e(entityhuman)) ? entityhuman : null;
    }
    
    @Override
    public boolean a(final Entity entity, final int i) {
        if (!super.a(entity, i)) {
            return false;
        }
        if (this.passenger != entity && this.vehicle != entity) {
            if (entity != this) {
                final CraftServer server = ((WorldServer)this.world).getServer();
                org.bukkit.entity.Entity bukkitTarget = null;
                if (entity != null) {
                    bukkitTarget = entity.getBukkitEntity();
                }
                final EntityTargetEvent event = new EntityTargetEvent(this.getBukkitEntity(), bukkitTarget, EntityTargetEvent.TargetReason.TARGET_ATTACKED_ENTITY);
                server.getPluginManager().callEvent(event);
                if (!event.isCancelled()) {
                    if (event.getTarget() == null) {
                        this.d = null;
                    }
                    else {
                        this.d = ((CraftEntity)event.getTarget()).getHandle();
                    }
                }
            }
            return true;
        }
        return true;
    }
    
    @Override
    protected void a(final Entity entity, final float f) {
        if (f < 1.5 && entity.boundingBox.e > this.boundingBox.b && entity.boundingBox.b < this.boundingBox.e) {
            this.attackTicks = 20;
            if (entity instanceof EntityLiving && !(entity instanceof EntityHuman)) {
                final CraftServer server = ((WorldServer)this.world).getServer();
                final org.bukkit.entity.Entity damager = this.getBukkitEntity();
                final org.bukkit.entity.Entity damagee = (entity == null) ? null : entity.getBukkitEntity();
                final EntityDamageEvent.DamageCause damageType = EntityDamageEvent.DamageCause.ENTITY_ATTACK;
                final EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(damager, damagee, damageType, this.c);
                server.getPluginManager().callEvent(event);
                if (!event.isCancelled()) {
                    entity.a(this, event.getDamage());
                }
                return;
            }
            entity.a(this, this.c);
        }
    }
    
    @Override
    protected float a(final int i, final int j, final int k) {
        return 0.5f - this.world.l(i, j, k);
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
    }
    
    @Override
    public boolean b() {
        final int i = MathHelper.b(this.locX);
        final int j = MathHelper.b(this.boundingBox.b);
        final int k = MathHelper.b(this.locZ);
        if (this.world.a(EnumSkyBlock.SKY, i, j, k) > this.random.nextInt(32)) {
            return false;
        }
        final int l = this.world.j(i, j, k);
        return l <= this.random.nextInt(8) && super.b();
    }
}
