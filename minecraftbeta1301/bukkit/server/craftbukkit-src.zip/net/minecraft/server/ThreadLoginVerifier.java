// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

class ThreadLoginVerifier extends Thread
{
    final /* synthetic */ Packet1Login a;
    final /* synthetic */ NetLoginHandler b;
    
    ThreadLoginVerifier(final NetLoginHandler b, final Packet1Login a) {
        this.b = b;
        this.a = a;
    }
    
    @Override
    public void run() {
        try {
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(new URL("http://www.minecraft.net/game/checkserver.jsp?user=" + this.a.b + "&serverId=" + NetLoginHandler.a(this.b)).openStream()));
            final String line = bufferedReader.readLine();
            bufferedReader.close();
            if (line.equals("YES")) {
                NetLoginHandler.a(this.b, this.a);
            }
            else {
                this.b.a("Failed to verify username!");
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
