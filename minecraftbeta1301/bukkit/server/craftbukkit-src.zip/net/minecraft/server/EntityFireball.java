// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import java.util.List;
import org.bukkit.event.entity.ExplosionPrimedEvent;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageByProjectileEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class EntityFireball extends Entity
{
    private int e;
    private int f;
    private int g;
    private int h;
    private boolean i;
    public int a;
    private EntityLiving j;
    private int k;
    private int l;
    public double b;
    public double c;
    public double d;
    
    public EntityFireball(final World world) {
        super(world);
        this.e = -1;
        this.f = -1;
        this.g = -1;
        this.h = 0;
        this.i = false;
        this.a = 0;
        this.l = 0;
        this.a(1.0f, 1.0f);
    }
    
    @Override
    protected void a() {
    }
    
    public EntityFireball(final World world, final EntityLiving entityliving, double d0, double d1, double d2) {
        super(world);
        this.e = -1;
        this.f = -1;
        this.g = -1;
        this.h = 0;
        this.i = false;
        this.a = 0;
        this.l = 0;
        this.j = entityliving;
        this.a(1.0f, 1.0f);
        this.c(entityliving.locX, entityliving.locY, entityliving.locZ, entityliving.yaw, entityliving.pitch);
        this.a(this.locX, this.locY, this.locZ);
        this.height = 0.0f;
        final double motX = 0.0;
        this.motZ = motX;
        this.motY = motX;
        this.motX = motX;
        d0 += this.random.nextGaussian() * 0.4;
        d1 += this.random.nextGaussian() * 0.4;
        d2 += this.random.nextGaussian() * 0.4;
        final double d3 = MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2);
        this.b = d0 / d3 * 0.1;
        this.c = d1 / d3 * 0.1;
        this.d = d2 / d3 * 0.1;
    }
    
    @Override
    public void f_() {
        super.f_();
        this.fireTicks = 10;
        if (this.a > 0) {
            --this.a;
        }
        if (this.i) {
            final int i = this.world.getTypeId(this.e, this.f, this.g);
            if (i == this.h) {
                ++this.k;
                if (this.k == 1200) {
                    this.C();
                }
                return;
            }
            this.i = false;
            this.motX *= this.random.nextFloat() * 0.2f;
            this.motY *= this.random.nextFloat() * 0.2f;
            this.motZ *= this.random.nextFloat() * 0.2f;
            this.k = 0;
            this.l = 0;
        }
        else {
            ++this.l;
        }
        Vec3D vec3d = Vec3D.b(this.locX, this.locY, this.locZ);
        Vec3D vec3d2 = Vec3D.b(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
        MovingObjectPosition movingobjectposition = this.world.a(vec3d, vec3d2);
        vec3d = Vec3D.b(this.locX, this.locY, this.locZ);
        vec3d2 = Vec3D.b(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
        if (movingobjectposition != null) {
            vec3d2 = Vec3D.b(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
        }
        Entity entity = null;
        final List list = this.world.b(this, this.boundingBox.a(this.motX, this.motY, this.motZ).b(1.0, 1.0, 1.0));
        double d0 = 0.0;
        for (int j = 0; j < list.size(); ++j) {
            final Entity entity2 = list.get(j);
            if (entity2.d_() && (entity2 != this.j || this.l >= 25)) {
                final float f = 0.3f;
                final AxisAlignedBB axisalignedbb = entity2.boundingBox.b(f, f, f);
                final MovingObjectPosition movingobjectposition2 = axisalignedbb.a(vec3d, vec3d2);
                if (movingobjectposition2 != null) {
                    final double d2 = vec3d.a(movingobjectposition2.f);
                    if (d2 < d0 || d0 == 0.0) {
                        entity = entity2;
                        d0 = d2;
                    }
                }
            }
        }
        if (entity != null) {
            movingobjectposition = new MovingObjectPosition(entity);
        }
        if (movingobjectposition != null) {
            if (movingobjectposition.g != null) {
                boolean stick;
                if (movingobjectposition.g instanceof EntityLiving) {
                    final CraftServer server = ((WorldServer)this.world).getServer();
                    final org.bukkit.entity.Entity shooter = (this.j == null) ? null : this.j.getBukkitEntity();
                    final org.bukkit.entity.Entity damagee = movingobjectposition.g.getBukkitEntity();
                    final org.bukkit.entity.Entity projectile = this.getBukkitEntity();
                    final EntityDamageEvent.DamageCause damageCause = EntityDamageEvent.DamageCause.ENTITY_ATTACK;
                    final int damage = 0;
                    final EntityDamageByProjectileEvent event = new EntityDamageByProjectileEvent(shooter, damagee, projectile, damageCause, damage);
                    server.getPluginManager().callEvent(event);
                    if (!event.isCancelled()) {
                        stick = movingobjectposition.g.a(this.j, event.getDamage());
                    }
                    else {
                        stick = !event.getBounce();
                    }
                }
                else {
                    stick = movingobjectposition.g.a(this.j, 0);
                }
                if (stick) {}
            }
            final CraftServer server2 = ((WorldServer)this.world).getServer();
            final Event.Type eventType = Event.Type.EXPLOSION_PRIMED;
            final ExplosionPrimedEvent event2 = new ExplosionPrimedEvent(eventType, CraftEntity.getEntity(server2, this), 1.0f, false);
            server2.getPluginManager().callEvent(event2);
            if (!event2.isCancelled()) {
                this.world.a(null, this.locX, this.locY, this.locZ, event2.getRadius(), event2.getFire());
                this.C();
            }
        }
        this.locX += this.motX;
        this.locY += this.motY;
        this.locZ += this.motZ;
        final float f2 = MathHelper.a(this.motX * this.motX + this.motZ * this.motZ);
        this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0 / 3.1415927410125732);
        this.pitch = (float)(Math.atan2(this.motY, f2) * 180.0 / 3.1415927410125732);
        while (this.pitch - this.lastPitch < -180.0f) {
            this.lastPitch -= 360.0f;
        }
        while (this.pitch - this.lastPitch >= 180.0f) {
            this.lastPitch += 360.0f;
        }
        while (this.yaw - this.lastYaw < -180.0f) {
            this.lastYaw -= 360.0f;
        }
        while (this.yaw - this.lastYaw >= 180.0f) {
            this.lastYaw += 360.0f;
        }
        this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2f;
        this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2f;
        float f3 = 0.95f;
        if (this.g_()) {
            for (int k = 0; k < 4; ++k) {
                final float f4 = 0.25f;
                this.world.a("bubble", this.locX - this.motX * f4, this.locY - this.motY * f4, this.locZ - this.motZ * f4, this.motX, this.motY, this.motZ);
            }
            f3 = 0.8f;
        }
        this.motX += this.b;
        this.motY += this.c;
        this.motZ += this.d;
        this.motX *= f3;
        this.motY *= f3;
        this.motZ *= f3;
        this.world.a("smoke", this.locX, this.locY + 0.5, this.locZ, 0.0, 0.0, 0.0);
        this.a(this.locX, this.locY, this.locZ);
    }
    
    public void a(final NBTTagCompound nbttagcompound) {
        nbttagcompound.a("xTile", (short)this.e);
        nbttagcompound.a("yTile", (short)this.f);
        nbttagcompound.a("zTile", (short)this.g);
        nbttagcompound.a("inTile", (byte)this.h);
        nbttagcompound.a("shake", (byte)this.a);
        nbttagcompound.a("inGround", (byte)(this.i ? 1 : 0));
    }
    
    public void b(final NBTTagCompound nbttagcompound) {
        this.e = nbttagcompound.d("xTile");
        this.f = nbttagcompound.d("yTile");
        this.g = nbttagcompound.d("zTile");
        this.h = (nbttagcompound.c("inTile") & 0xFF);
        this.a = (nbttagcompound.c("shake") & 0xFF);
        this.i = (nbttagcompound.c("inGround") == 1);
    }
    
    @Override
    public boolean d_() {
        return true;
    }
    
    @Override
    public boolean a(final Entity entity, final int i) {
        this.R();
        if (entity != null) {
            final Vec3D vec3d = entity.N();
            if (vec3d != null) {
                this.motX = vec3d.a;
                this.motY = vec3d.b;
                this.motZ = vec3d.c;
                this.b = this.motX * 0.1;
                this.c = this.motY * 0.1;
                this.d = this.motZ * 0.1;
            }
            return true;
        }
        return false;
    }
}
