// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public final class ItemStack
{
    public int count;
    public int b;
    public int id;
    public int damage;
    
    public ItemStack(final Block block) {
        this(block, 1);
    }
    
    public ItemStack(final Block block, final int i) {
        this(block.id, i, 0);
    }
    
    public ItemStack(final Block block, final int i, final int j) {
        this(block.id, i, j);
    }
    
    public ItemStack(final Item item) {
        this(item.id, 1, 0);
    }
    
    public ItemStack(final Item item, final int i) {
        this(item.id, i, 0);
    }
    
    public ItemStack(final Item item, final int i, final int j) {
        this(item.id, i, j);
    }
    
    public ItemStack(final int i, final int j, final int k) {
        this.count = 0;
        this.id = i;
        this.count = j;
        this.damage = k;
    }
    
    public ItemStack(final NBTTagCompound nbttagcompound) {
        this.count = 0;
        this.b(nbttagcompound);
    }
    
    public ItemStack a(final int i) {
        this.count -= i;
        return new ItemStack(this.id, i, this.damage);
    }
    
    public Item a() {
        return Item.byId[this.id];
    }
    
    public boolean a(final EntityHuman entityhuman, final World world, final int i, final int j, final int k, final int l) {
        return this.a().a(this, entityhuman, world, i, j, k, l);
    }
    
    public float a(final Block block) {
        return this.a().a(this, block);
    }
    
    public ItemStack a(final World world, final EntityHuman entityhuman) {
        return this.a().a(this, world, entityhuman);
    }
    
    public NBTTagCompound a(final NBTTagCompound nbttagcompound) {
        nbttagcompound.a("id", (short)this.id);
        nbttagcompound.a("Count", (byte)this.count);
        nbttagcompound.a("Damage", (short)this.damage);
        return nbttagcompound;
    }
    
    public void b(final NBTTagCompound nbttagcompound) {
        this.id = nbttagcompound.d("id");
        this.count = nbttagcompound.c("Count");
        this.damage = nbttagcompound.d("Damage");
    }
    
    public int b() {
        return this.a().b();
    }
    
    public boolean c() {
        return this.b() > 1 && (!this.d() || !this.f());
    }
    
    public boolean d() {
        return Item.byId[this.id].d() > 0;
    }
    
    public boolean e() {
        return Item.byId[this.id].c();
    }
    
    public boolean f() {
        return this.d() && this.damage > 0;
    }
    
    public int g() {
        return this.damage;
    }
    
    public int h() {
        return this.damage;
    }
    
    public int i() {
        return Item.byId[this.id].d();
    }
    
    public void b(final int i) {
        if (this.d()) {
            this.damage += i;
            if (this.damage > this.i()) {
                --this.count;
                if (this.count < 0) {
                    this.count = 0;
                }
                this.damage = 0;
            }
        }
    }
    
    public void a(final EntityLiving entityliving) {
        Item.byId[this.id].a(this, entityliving);
    }
    
    public void a(final int i, final int j, final int k, final int l) {
        Item.byId[this.id].a(this, i, j, k, l);
    }
    
    public int a(final Entity entity) {
        return Item.byId[this.id].a(entity);
    }
    
    public boolean b(final Block block) {
        return Item.byId[this.id].a(block);
    }
    
    public void a(final EntityHuman entityhuman) {
    }
    
    public void b(final EntityLiving entityliving) {
        Item.byId[this.id].b(this, entityliving);
    }
    
    public ItemStack j() {
        return new ItemStack(this.id, this.count, this.damage);
    }
    
    public static boolean a(final ItemStack itemstack, final ItemStack itemstack1) {
        return (itemstack == null && itemstack1 == null) || (itemstack != null && itemstack1 != null && itemstack.c(itemstack1));
    }
    
    private boolean c(final ItemStack itemstack) {
        return this.count == itemstack.count && this.id == itemstack.id && this.damage == itemstack.damage;
    }
    
    public boolean a(final ItemStack itemstack) {
        return this.id == itemstack.id && this.damage == itemstack.damage;
    }
    
    public static ItemStack b(final ItemStack itemstack) {
        return (itemstack == null) ? null : itemstack.j();
    }
    
    @Override
    public String toString() {
        return this.count + "x" + Item.byId[this.id].a() + "@" + this.damage;
    }
}
