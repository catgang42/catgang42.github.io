// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.entity.Player;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.Server;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockIgniteEvent;
import java.util.Random;

public class BlockStationary extends BlockFluids
{
    protected BlockStationary(final int i, final Material material) {
        super(i, material);
        this.a(false);
        if (material == Material.LAVA) {
            this.a(true);
        }
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        super.a(world, i, j, k, l);
        if (world.getTypeId(i, j, k) == this.id) {
            this.i(world, i, j, k);
        }
    }
    
    private void i(final World world, final int i, final int j, final int k) {
        final int l = world.getData(i, j, k);
        world.h = true;
        world.setTypeIdAndData(i, j, k, this.id - 1, l);
        world.b(i, j, k, i, j, k);
        world.c(i, j, k, this.id - 1, this.b());
        world.h = false;
    }
    
    @Override
    public void a(final World world, int i, int j, int k, final Random random) {
        if (this.material == Material.LAVA) {
            final int l = random.nextInt(3);
            final Server server = ((WorldServer)world).getServer();
            final CraftWorld cworld = ((WorldServer)world).getWorld();
            final BlockIgniteEvent.IgniteCause igniteCause = BlockIgniteEvent.IgniteCause.LAVA;
            final Player thePlayer = null;
            for (int i2 = 0; i2 < l; ++i2) {
                i += random.nextInt(3) - 1;
                ++j;
                k += random.nextInt(3) - 1;
                final int j2 = world.getTypeId(i, j, k);
                if (j2 == 0) {
                    if (this.j(world, i - 1, j, k) || this.j(world, i + 1, j, k) || this.j(world, i, j, k - 1) || this.j(world, i, j, k + 1) || this.j(world, i, j - 1, k) || this.j(world, i, j + 1, k)) {
                        final org.bukkit.block.Block theBlock = cworld.getBlockAt(i, j, k);
                        if (theBlock.getTypeId() != Block.FIRE.id) {
                            final BlockIgniteEvent event = new BlockIgniteEvent(theBlock, igniteCause, thePlayer);
                            server.getPluginManager().callEvent(event);
                            if (event.isCancelled()) {
                                continue;
                            }
                        }
                        world.e(i, j, k, Block.FIRE.id);
                        return;
                    }
                }
                else if (Block.byId[j2].material.isSolid()) {
                    return;
                }
            }
        }
    }
    
    private boolean j(final World world, final int i, final int j, final int k) {
        return world.getMaterial(i, j, k).isBurnable();
    }
}
