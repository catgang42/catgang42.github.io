// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BiomeForest extends BiomeBase
{
    @Override
    public WorldGenerator a(final Random random) {
        if (random.nextInt(5) == 0) {
            return new WorldGenForest();
        }
        if (random.nextInt(3) == 0) {
            return new WorldGenBigTree();
        }
        return new WorldGenTrees();
    }
}
