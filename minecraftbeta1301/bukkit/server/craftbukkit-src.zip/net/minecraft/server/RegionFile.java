// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.OutputStream;
import java.util.zip.DeflaterOutputStream;
import java.io.DataOutputStream;
import java.util.zip.InflaterInputStream;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.io.RandomAccessFile;
import java.io.File;

public class RegionFile
{
    private static final byte[] a;
    private final File b;
    private RandomAccessFile c;
    private final int[] d;
    private final int[] e;
    private ArrayList f;
    private int g;
    private long h;
    
    public RegionFile(final File file) {
        this.h = 0L;
        this.d = new int[1024];
        this.e = new int[1024];
        this.b = file;
        this.b("REGION LOAD " + this.b);
        this.g = 0;
        try {
            if (file.exists()) {
                this.h = file.lastModified();
            }
            this.c = new RandomAccessFile(file, "rw");
            if (this.c.length() < 4096L) {
                for (int i = 0; i < 1024; ++i) {
                    this.c.writeInt(0);
                }
                for (int j = 0; j < 1024; ++j) {
                    this.c.writeInt(0);
                }
                this.g += 8192;
            }
            if ((this.c.length() & 0xFFFL) != 0x0L) {
                for (int n = 0; n < (this.c.length() & 0xFFFL); ++n) {
                    this.c.write(0);
                }
            }
            final int initialCapacity = (int)this.c.length() / 4096;
            this.f = new ArrayList(initialCapacity);
            for (int k = 0; k < initialCapacity; ++k) {
                this.f.add(true);
            }
            this.f.set(0, false);
            this.f.set(1, false);
            this.c.seek(0L);
            for (int l = 0; l < 1024; ++l) {
                final int int1 = this.c.readInt();
                this.d[l] = int1;
                if (int1 != 0 && (int1 >> 8) + (int1 & 0xFF) <= this.f.size()) {
                    for (int n2 = 0; n2 < (int1 & 0xFF); ++n2) {
                        this.f.set((int1 >> 8) + n2, false);
                    }
                }
            }
            for (int n3 = 0; n3 < 1024; ++n3) {
                this.e[n3] = this.c.readInt();
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public synchronized int a() {
        final int g = this.g;
        this.g = 0;
        return g;
    }
    
    private void a(final String s) {
    }
    
    private void b(final String str) {
        this.a(str + "\n");
    }
    
    private void a(final String str, final int i, final int j, final String str2) {
        this.a("REGION " + str + " " + this.b.getName() + "[" + i + "," + j + "] = " + str2);
    }
    
    private void a(final String str, final int i, final int j, final int k, final String str2) {
        this.a("REGION " + str + " " + this.b.getName() + "[" + i + "," + j + "] " + k + "B = " + str2);
    }
    
    private void b(final String s, final int n, final int n2, final String str) {
        this.a(s, n, n2, str + "\n");
    }
    
    public synchronized DataInputStream a(final int n, final int n2) {
        if (this.d(n, n2)) {
            this.b("READ", n, n2, "out of bounds");
            return null;
        }
        try {
            final int e = this.e(n, n2);
            if (e == 0) {
                return null;
            }
            final int n3 = e >> 8;
            final int i = e & 0xFF;
            if (n3 + i > this.f.size()) {
                this.b("READ", n, n2, "invalid sector");
                return null;
            }
            this.c.seek(n3 * 4096);
            final int int1 = this.c.readInt();
            if (int1 > 4096 * i) {
                this.b("READ", n, n2, "invalid length: " + int1 + " > 4096 * " + i);
                return null;
            }
            final byte byte1 = this.c.readByte();
            if (byte1 == 1) {
                final byte[] array = new byte[int1 - 1];
                this.c.read(array);
                return new DataInputStream(new GZIPInputStream(new ByteArrayInputStream(array)));
            }
            if (byte1 == 2) {
                final byte[] array2 = new byte[int1 - 1];
                this.c.read(array2);
                return new DataInputStream(new InflaterInputStream(new ByteArrayInputStream(array2)));
            }
            this.b("READ", n, n2, "unknown version " + byte1);
            return null;
        }
        catch (IOException ex) {
            this.b("READ", n, n2, "exception");
            return null;
        }
    }
    
    public DataOutputStream b(final int n, final int n2) {
        if (this.d(n, n2)) {
            return null;
        }
        return new DataOutputStream(new DeflaterOutputStream(new ChunkBuffer(this, n, n2)));
    }
    
    protected synchronized void a(final int n, final int n2, final byte[] array, final int n3) {
        try {
            final int e = this.e(n, n2);
            final int n4 = e >> 8;
            final int n5 = e & 0xFF;
            final int n6 = (n3 + 5) / 4096 + 1;
            if (n6 >= 256) {
                return;
            }
            if (n4 != 0 && n5 == n6) {
                this.a("SAVE", n, n2, n3, "rewrite");
                this.a(n4, array, n3);
            }
            else {
                for (int i = 0; i < n5; ++i) {
                    this.f.set(n4 + i, true);
                }
                int index = this.f.indexOf(true);
                int n7 = 0;
                if (index != -1) {
                    for (int j = index; j < this.f.size(); ++j) {
                        if (n7 != 0) {
                            if (this.f.get(j)) {
                                ++n7;
                            }
                            else {
                                n7 = 0;
                            }
                        }
                        else if (this.f.get(j)) {
                            index = j;
                            n7 = 1;
                        }
                        if (n7 >= n6) {
                            break;
                        }
                    }
                }
                if (n7 >= n6) {
                    this.a("SAVE", n, n2, n3, "reuse");
                    final int n8 = index;
                    this.a(n, n2, n8 << 8 | n6);
                    for (int k = 0; k < n6; ++k) {
                        this.f.set(n8 + k, false);
                    }
                    this.a(n8, array, n3);
                }
                else {
                    this.a("SAVE", n, n2, n3, "grow");
                    this.c.seek(this.c.length());
                    final int size = this.f.size();
                    for (int l = 0; l < n6; ++l) {
                        this.c.write(RegionFile.a);
                        this.f.add(false);
                    }
                    this.g += 4096 * n6;
                    this.a(size, array, n3);
                    this.a(n, n2, size << 8 | n6);
                }
            }
            this.b(n, n2, (int)(System.currentTimeMillis() / 1000L));
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    private void a(final int i, final byte[] b, final int len) {
        this.b(" " + i);
        this.c.seek(i * 4096);
        this.c.writeInt(len + 1);
        this.c.writeByte(2);
        this.c.write(b, 0, len);
    }
    
    private boolean d(final int n, final int n2) {
        return n < 0 || n >= 32 || n2 < 0 || n2 >= 32;
    }
    
    private int e(final int n, final int n2) {
        return this.d[n + n2 * 32];
    }
    
    public boolean c(final int n, final int n2) {
        return this.e(n, n2) != 0;
    }
    
    private void a(final int n, final int n2, final int v) {
        this.d[n + n2 * 32] = v;
        this.c.seek((n + n2 * 32) * 4);
        this.c.writeInt(v);
    }
    
    private void b(final int n, final int n2, final int v) {
        this.e[n + n2 * 32] = v;
        this.c.seek(4096 + (n + n2 * 32) * 4);
        this.c.writeInt(v);
    }
    
    public void b() {
        this.c.close();
    }
    
    static {
        a = new byte[4096];
    }
}
