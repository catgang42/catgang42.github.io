// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.List;

public interface ICrafting
{
    void a(final Container p0, final List p1);
    
    void a(final Container p0, final int p1, final ItemStack p2);
    
    void a(final Container p0, final int p1, final int p2);
}
