// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.List;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.block.BlockInteractEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.event.Event;
import java.util.Random;

public class BlockPressurePlate extends Block
{
    private EnumMobType a;
    
    protected BlockPressurePlate(final int i, final int j, final EnumMobType enummobtype) {
        super(i, j, Material.STONE);
        this.a = enummobtype;
        this.a(true);
        final float f = 0.0625f;
        this.a(f, 0.0f, f, 1.0f - f, 0.03125f, 1.0f - f);
    }
    
    @Override
    public int b() {
        return 20;
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k) {
        return world.d(i, j - 1, k);
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        boolean flag = false;
        if (!world.d(i, j - 1, k)) {
            flag = true;
        }
        if (flag) {
            this.b_(world, i, j, k, world.getData(i, j, k));
            world.e(i, j, k, 0);
        }
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (!world.isStatic && world.getData(i, j, k) != 0) {
            this.g(world, i, j, k);
        }
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Entity entity) {
        if (!world.isStatic && world.getData(i, j, k) != 1) {
            if (entity instanceof EntityLiving) {
                final CraftServer server = ((WorldServer)world).getServer();
                final CraftWorld craftWorld = ((WorldServer)world).getWorld();
                final Event.Type eventType = Event.Type.BLOCK_INTERACT;
                final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
                final LivingEntity who = (entity == null) ? null : ((LivingEntity)entity.getBukkitEntity());
                final BlockInteractEvent event = new BlockInteractEvent(eventType, block, who);
                server.getPluginManager().callEvent(event);
                if (event.isCancelled()) {
                    return;
                }
            }
            this.g(world, i, j, k);
        }
    }
    
    private void g(final World world, final int i, final int j, final int k) {
        final boolean flag = world.getData(i, j, k) == 1;
        boolean flag2 = false;
        final float f = 0.125f;
        List list = null;
        if (this.a == EnumMobType.EVERYTHING) {
            list = world.b(null, AxisAlignedBB.b(i + f, j, k + f, i + 1 - f, j + 0.25, k + 1 - f));
        }
        if (this.a == EnumMobType.MOBS) {
            list = world.a(EntityLiving.class, AxisAlignedBB.b(i + f, j, k + f, i + 1 - f, j + 0.25, k + 1 - f));
        }
        if (this.a == EnumMobType.PLAYERS) {
            list = world.a(EntityHuman.class, AxisAlignedBB.b(i + f, j, k + f, i + 1 - f, j + 0.25, k + 1 - f));
        }
        if (list.size() > 0) {
            flag2 = true;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer server = ((WorldServer)world).getServer();
        final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
        final BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, flag ? 1 : 0, flag2 ? 1 : 0);
        server.getPluginManager().callEvent(eventRedstone);
        flag2 = (eventRedstone.getNewCurrent() > 0);
        if (flag2 && !flag) {
            world.c(i, j, k, 1);
            world.h(i, j, k, this.id);
            world.h(i, j - 1, k, this.id);
            world.b(i, j, k, i, j, k);
            world.a(i + 0.5, j + 0.1, k + 0.5, "random.click", 0.3f, 0.6f);
        }
        if (!flag2 && flag) {
            world.c(i, j, k, 0);
            world.h(i, j, k, this.id);
            world.h(i, j - 1, k, this.id);
            world.b(i, j, k, i, j, k);
            world.a(i + 0.5, j + 0.1, k + 0.5, "random.click", 0.3f, 0.5f);
        }
        if (flag2) {
            world.c(i, j, k, this.id, this.b());
        }
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k) {
        final int l = world.getData(i, j, k);
        if (l > 0) {
            world.h(i, j, k, this.id);
            world.h(i, j - 1, k, this.id);
        }
        super.b(world, i, j, k);
    }
    
    @Override
    public void a(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final boolean flag = iblockaccess.getData(i, j, k) == 1;
        final float f = 0.0625f;
        if (flag) {
            this.a(f, 0.0f, f, 1.0f - f, 0.03125f, 1.0f - f);
        }
        else {
            this.a(f, 0.0f, f, 1.0f - f, 0.0625f, 1.0f - f);
        }
    }
    
    @Override
    public boolean b(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return iblockaccess.getData(i, j, k) > 0;
    }
    
    @Override
    public boolean c(final World world, final int i, final int j, final int k, final int l) {
        return world.getData(i, j, k) != 0 && l == 1;
    }
    
    @Override
    public boolean c() {
        return true;
    }
}
