// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class WorldGenReed extends WorldGenerator
{
    @Override
    public boolean a(final World world, final Random random, final int n, final int j, final int n2) {
        for (int i = 0; i < 20; ++i) {
            final int n3 = n + random.nextInt(4) - random.nextInt(4);
            final int n4 = n2 + random.nextInt(4) - random.nextInt(4);
            if (world.isEmpty(n3, j, n4) && (world.getMaterial(n3 - 1, j - 1, n4) == Material.WATER || world.getMaterial(n3 + 1, j - 1, n4) == Material.WATER || world.getMaterial(n3, j - 1, n4 - 1) == Material.WATER || world.getMaterial(n3, j - 1, n4 + 1) == Material.WATER)) {
                for (int n5 = 2 + random.nextInt(random.nextInt(3) + 1), k = 0; k < n5; ++k) {
                    if (Block.SUGAR_CANE_BLOCK.f(world, n3, j + k, n4)) {
                        world.setTypeId(n3, j + k, n4, Block.SUGAR_CANE_BLOCK.id);
                    }
                }
            }
        }
        return true;
    }
}
