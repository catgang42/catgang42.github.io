// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.List;
import java.util.ArrayList;

public class EntityPainting extends Entity
{
    private int f;
    public int a;
    public int b;
    public int c;
    public int d;
    public EnumArt e;
    
    public EntityPainting(final World world) {
        super(world);
        this.f = 0;
        this.a = 0;
        this.height = 0.0f;
        this.a(0.5f, 0.5f);
    }
    
    public EntityPainting(final World world, final int b, final int c, final int d, final int n) {
        this(world);
        this.b = b;
        this.c = c;
        this.d = d;
        final ArrayList<Object> list = new ArrayList<Object>();
        for (final EnumArt e : EnumArt.values()) {
            this.e = e;
            this.b(n);
            if (this.h()) {
                list.add(e);
            }
        }
        if (list.size() > 0) {
            this.e = (EnumArt)list.get(this.random.nextInt(list.size()));
        }
        this.b(n);
    }
    
    @Override
    protected void a() {
    }
    
    public void b(final int a) {
        this.a = a;
        final float n = (float)(a * 90);
        this.yaw = n;
        this.lastYaw = n;
        float n2 = (float)this.e.A;
        final float n3 = (float)this.e.B;
        float n4 = (float)this.e.A;
        if (a == 0 || a == 2) {
            n4 = 0.5f;
        }
        else {
            n2 = 0.5f;
        }
        final float n5 = n2 / 32.0f;
        final float n6 = n3 / 32.0f;
        final float n7 = n4 / 32.0f;
        float n8 = this.b + 0.5f;
        final float n9 = this.c + 0.5f;
        float n10 = this.d + 0.5f;
        final float n11 = 0.5625f;
        if (a == 0) {
            n10 -= n11;
        }
        if (a == 1) {
            n8 -= n11;
        }
        if (a == 2) {
            n10 += n11;
        }
        if (a == 3) {
            n8 += n11;
        }
        if (a == 0) {
            n8 -= this.c(this.e.A);
        }
        if (a == 1) {
            n10 += this.c(this.e.A);
        }
        if (a == 2) {
            n8 += this.c(this.e.A);
        }
        if (a == 3) {
            n10 -= this.c(this.e.A);
        }
        final float n12 = n9 + this.c(this.e.B);
        this.a(n8, n12, (double)n10);
        final float n13 = -0.00625f;
        this.boundingBox.c(n8 - n5 - n13, n12 - n6 - n13, n10 - n7 - n13, n8 + n5 + n13, n12 + n6 + n13, n10 + n7 + n13);
    }
    
    private float c(final int n) {
        if (n == 32) {
            return 0.5f;
        }
        if (n == 64) {
            return 0.5f;
        }
        return 0.0f;
    }
    
    @Override
    public void f_() {
        if (this.f++ == 100 && !this.world.isStatic) {
            this.f = 0;
            if (!this.h()) {
                this.C();
                this.world.a(new EntityItem(this.world, this.locX, this.locY, this.locZ, new ItemStack(Item.PAINTING)));
            }
        }
    }
    
    public boolean h() {
        if (this.world.a(this, this.boundingBox).size() > 0) {
            return false;
        }
        final int n = this.e.A / 16;
        final int n2 = this.e.B / 16;
        int n3 = this.b;
        final int c = this.c;
        int n4 = this.d;
        if (this.a == 0) {
            n3 = MathHelper.b(this.locX - this.e.A / 32.0f);
        }
        if (this.a == 1) {
            n4 = MathHelper.b(this.locZ - this.e.A / 32.0f);
        }
        if (this.a == 2) {
            n3 = MathHelper.b(this.locX - this.e.A / 32.0f);
        }
        if (this.a == 3) {
            n4 = MathHelper.b(this.locZ - this.e.A / 32.0f);
        }
        final int b = MathHelper.b(this.locY - this.e.B / 32.0f);
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n2; ++j) {
                Material material;
                if (this.a == 0 || this.a == 2) {
                    material = this.world.getMaterial(n3 + i, b + j, this.d);
                }
                else {
                    material = this.world.getMaterial(this.b, b + j, n4 + i);
                }
                if (!material.isBuildable()) {
                    return false;
                }
            }
        }
        final List b2 = this.world.b(this, this.boundingBox);
        for (int k = 0; k < b2.size(); ++k) {
            if (b2.get(k) instanceof EntityPainting) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public boolean d_() {
        return true;
    }
    
    @Override
    public boolean a(final Entity entity, final int n) {
        if (!this.dead && !this.world.isStatic) {
            this.C();
            this.R();
            this.world.a(new EntityItem(this.world, this.locX, this.locY, this.locZ, new ItemStack(Item.PAINTING)));
        }
        return true;
    }
    
    public void a(final NBTTagCompound nbtTagCompound) {
        nbtTagCompound.a("Dir", (byte)this.a);
        nbtTagCompound.a("Motive", this.e.z);
        nbtTagCompound.a("TileX", this.b);
        nbtTagCompound.a("TileY", this.c);
        nbtTagCompound.a("TileZ", this.d);
    }
    
    public void b(final NBTTagCompound nbtTagCompound) {
        this.a = nbtTagCompound.c("Dir");
        this.b = nbtTagCompound.e("TileX");
        this.c = nbtTagCompound.e("TileY");
        this.d = nbtTagCompound.e("TileZ");
        final String i = nbtTagCompound.i("Motive");
        for (final EnumArt e : EnumArt.values()) {
            if (e.z.equals(i)) {
                this.e = e;
            }
        }
        if (this.e == null) {
            this.e = EnumArt.KEBAB;
        }
        this.b(this.a);
    }
}
