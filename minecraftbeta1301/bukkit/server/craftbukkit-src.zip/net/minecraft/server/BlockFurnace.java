// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockInteractEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.event.Event;
import java.util.Random;

public class BlockFurnace extends BlockContainer
{
    private final boolean a;
    
    protected BlockFurnace(final int i, final boolean flag) {
        super(i, Material.STONE);
        this.a = flag;
        this.textureId = 45;
    }
    
    @Override
    public int a(final int i, final Random random) {
        return Block.FURNACE.id;
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
        super.e(world, i, j, k);
        this.g(world, i, j, k);
    }
    
    private void g(final World world, final int i, final int j, final int k) {
        final int l = world.getTypeId(i, j, k - 1);
        final int i2 = world.getTypeId(i, j, k + 1);
        final int j2 = world.getTypeId(i - 1, j, k);
        final int k2 = world.getTypeId(i + 1, j, k);
        byte b0 = 3;
        if (Block.o[l] && !Block.o[i2]) {
            b0 = 3;
        }
        if (Block.o[i2] && !Block.o[l]) {
            b0 = 2;
        }
        if (Block.o[j2] && !Block.o[k2]) {
            b0 = 5;
        }
        if (Block.o[k2] && !Block.o[j2]) {
            b0 = 4;
        }
        world.c(i, j, k, b0);
    }
    
    @Override
    public int a(final int i) {
        return (i == 1) ? (this.textureId + 17) : ((i == 0) ? (this.textureId + 17) : ((i == 3) ? (this.textureId - 1) : this.textureId));
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        if (world.isStatic) {
            return true;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer server = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.BLOCK_INTERACT;
        final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
        final LivingEntity who = (entityhuman == null) ? null : ((LivingEntity)entityhuman.getBukkitEntity());
        final BlockInteractEvent event = new BlockInteractEvent(eventType, block, who);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        final TileEntityFurnace tileentityfurnace = (TileEntityFurnace)world.getTileEntity(i, j, k);
        entityhuman.a(tileentityfurnace);
        return true;
    }
    
    public static void a(final boolean flag, final World world, final int i, final int j, final int k) {
        final int l = world.getData(i, j, k);
        final TileEntity tileentity = world.getTileEntity(i, j, k);
        if (flag) {
            world.e(i, j, k, Block.BURNING_FURNACE.id);
        }
        else {
            world.e(i, j, k, Block.FURNACE.id);
        }
        world.c(i, j, k, l);
        world.setTileEntity(i, j, k, tileentity);
    }
    
    @Override
    protected TileEntity a_() {
        return new TileEntityFurnace();
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final EntityLiving entityliving) {
        final int l = MathHelper.b(entityliving.yaw * 4.0f / 360.0f + 0.5) & 0x3;
        if (l == 0) {
            world.c(i, j, k, 2);
        }
        if (l == 1) {
            world.c(i, j, k, 5);
        }
        if (l == 2) {
            world.c(i, j, k, 3);
        }
        if (l == 3) {
            world.c(i, j, k, 4);
        }
    }
}
