// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleEntityCollisionEvent;
import java.util.List;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.vehicle.VehicleMoveEvent;
import org.bukkit.event.vehicle.VehicleEvent;
import org.bukkit.Location;
import org.bukkit.event.vehicle.VehicleDamageEvent;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.vehicle.VehicleCreateEvent;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.Event;

public class EntityMinecart extends Entity implements IInventory
{
    private ItemStack[] h;
    public int a;
    public int b;
    public int c;
    private boolean i;
    public int d;
    public int e;
    public double f;
    public double g;
    private static final int[][][] j;
    private int k;
    private double l;
    private double m;
    private double n;
    private double o;
    private double p;
    public boolean slowWhenEmpty;
    public double derailedX;
    public double derailedY;
    public double derailedZ;
    public double flyingX;
    public double flyingY;
    public double flyingZ;
    public double maxSpeed;
    
    public ItemStack[] getContents() {
        return this.h;
    }
    
    public EntityMinecart(final World world) {
        super(world);
        this.slowWhenEmpty = true;
        this.derailedX = 0.5;
        this.derailedY = 0.5;
        this.derailedZ = 0.5;
        this.flyingX = 0.95;
        this.flyingY = 0.95;
        this.flyingZ = 0.95;
        this.maxSpeed = 0.4;
        this.h = new ItemStack[27];
        this.a = 0;
        this.b = 0;
        this.c = 1;
        this.i = false;
        this.aC = true;
        this.a(0.98f, 0.7f);
        this.height = this.width / 2.0f;
        this.bg = false;
        final CraftServer server = ((WorldServer)this.world).getServer();
        final Event.Type eventType = Event.Type.VEHICLE_CREATE;
        final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
        final VehicleCreateEvent event = new VehicleCreateEvent(eventType, vehicle);
        server.getPluginManager().callEvent(event);
    }
    
    @Override
    protected void a() {
    }
    
    @Override
    public AxisAlignedBB a_(final Entity entity) {
        return entity.boundingBox;
    }
    
    @Override
    public AxisAlignedBB d() {
        return null;
    }
    
    @Override
    public boolean e_() {
        return true;
    }
    
    public EntityMinecart(final World world, final double d0, final double d1, final double d2, final int i) {
        this(world);
        this.a(d0, d1 + this.height, d2);
        this.motX = 0.0;
        this.motY = 0.0;
        this.motZ = 0.0;
        this.lastX = d0;
        this.lastY = d1;
        this.lastZ = d2;
        this.d = i;
    }
    
    @Override
    public double k() {
        return this.width * 0.0 - 0.30000001192092896;
    }
    
    @Override
    public boolean a(final Entity entity, int i) {
        if (this.world.isStatic || this.dead) {
            return true;
        }
        final Event.Type eventType = Event.Type.VEHICLE_DAMAGE;
        final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
        final org.bukkit.entity.Entity passenger = (entity == null) ? null : entity.getBukkitEntity();
        final int damage = i;
        final VehicleDamageEvent event = new VehicleDamageEvent(eventType, vehicle, passenger, damage);
        ((WorldServer)this.world).getServer().getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        i = event.getDamage();
        this.c = -this.c;
        this.b = 10;
        this.R();
        this.a += i * 10;
        if (this.a > 40) {
            this.a(Item.MINECART.id, 1, 0.0f);
            if (this.d == 1) {
                this.a(Block.CHEST.id, 1, 0.0f);
            }
            else if (this.d == 2) {
                this.a(Block.FURNACE.id, 1, 0.0f);
            }
            this.C();
        }
        return true;
    }
    
    @Override
    public boolean d_() {
        return !this.dead;
    }
    
    @Override
    public void C() {
        for (int i = 0; i < this.m_(); ++i) {
            final ItemStack itemstack = this.c_(i);
            if (itemstack != null) {
                final float f = this.random.nextFloat() * 0.8f + 0.1f;
                final float f2 = this.random.nextFloat() * 0.8f + 0.1f;
                final float f3 = this.random.nextFloat() * 0.8f + 0.1f;
                while (itemstack.count > 0) {
                    int j = this.random.nextInt(21) + 10;
                    if (j > itemstack.count) {
                        j = itemstack.count;
                    }
                    final ItemStack itemStack = itemstack;
                    itemStack.count -= j;
                    final EntityItem entityitem = new EntityItem(this.world, this.locX + f, this.locY + f2, this.locZ + f3, new ItemStack(itemstack.id, j, itemstack.h()));
                    final float f4 = 0.05f;
                    entityitem.motX = (float)this.random.nextGaussian() * f4;
                    entityitem.motY = (float)this.random.nextGaussian() * f4 + 0.2f;
                    entityitem.motZ = (float)this.random.nextGaussian() * f4;
                    this.world.a(entityitem);
                }
            }
        }
        super.C();
    }
    
    @Override
    public void f_() {
        final double prevX = this.locX;
        final double prevY = this.locY;
        final double prevZ = this.locZ;
        final float prevYaw = this.yaw;
        final float prevPitch = this.pitch;
        if (this.b > 0) {
            --this.b;
        }
        if (this.a > 0) {
            --this.a;
        }
        if (this.world.isStatic && this.k > 0) {
            if (this.k > 0) {
                final double d1 = this.locX + (this.l - this.locX) / this.k;
                final double d2 = this.locY + (this.m - this.locY) / this.k;
                final double d3 = this.locZ + (this.n - this.locZ) / this.k;
                double d4;
                for (d4 = this.o - this.yaw; d4 < -180.0; d4 += 360.0) {}
                while (d4 >= 180.0) {
                    d4 -= 360.0;
                }
                this.yaw += (float)(d4 / this.k);
                this.pitch += (float)((this.p - this.pitch) / this.k);
                --this.k;
                this.a(d1, d2, d3);
                this.c(this.yaw, this.pitch);
            }
            else {
                this.a(this.locX, this.locY, this.locZ);
                this.c(this.yaw, this.pitch);
            }
        }
        else {
            this.lastX = this.locX;
            this.lastY = this.locY;
            this.lastZ = this.locZ;
            this.motY -= 0.03999999910593033;
            final int i = MathHelper.b(this.locX);
            int j = MathHelper.b(this.locY);
            final int k = MathHelper.b(this.locZ);
            if (this.world.getTypeId(i, j - 1, k) == Block.RAILS.id) {
                --j;
            }
            final double d5 = this.maxSpeed;
            boolean flag = false;
            final double d4 = 0.0078125;
            if (this.world.getTypeId(i, j, k) == Block.RAILS.id) {
                final Vec3D vec3d = this.g(this.locX, this.locY, this.locZ);
                final int l = this.world.getData(i, j, k);
                this.locY = j;
                if (l >= 2 && l <= 5) {
                    this.locY = j + 1;
                }
                if (l == 2) {
                    this.motX -= d4;
                }
                if (l == 3) {
                    this.motX += d4;
                }
                if (l == 4) {
                    this.motZ += d4;
                }
                if (l == 5) {
                    this.motZ -= d4;
                }
                final int[][] aint = EntityMinecart.j[l];
                double d6 = aint[1][0] - aint[0][0];
                double d7 = aint[1][2] - aint[0][2];
                final double d8 = Math.sqrt(d6 * d6 + d7 * d7);
                final double d9 = this.motX * d6 + this.motZ * d7;
                if (d9 < 0.0) {
                    d6 = -d6;
                    d7 = -d7;
                }
                double d10 = Math.sqrt(this.motX * this.motX + this.motZ * this.motZ);
                this.motX = d10 * d6 / d8;
                this.motZ = d10 * d7 / d8;
                double d11 = 0.0;
                final double d12 = i + 0.5 + aint[0][0] * 0.5;
                final double d13 = k + 0.5 + aint[0][2] * 0.5;
                final double d14 = i + 0.5 + aint[1][0] * 0.5;
                final double d15 = k + 0.5 + aint[1][2] * 0.5;
                d6 = d14 - d12;
                d7 = d15 - d13;
                if (d6 == 0.0) {
                    this.locX = i + 0.5;
                    d11 = this.locZ - k;
                }
                else if (d7 == 0.0) {
                    this.locZ = k + 0.5;
                    d11 = this.locX - i;
                }
                else {
                    final double d16 = this.locX - d12;
                    final double d17 = this.locZ - d13;
                    final double d18 = d11 = (d16 * d6 + d17 * d7) * 2.0;
                }
                this.locX = d12 + d6 * d11;
                this.locZ = d13 + d7 * d11;
                this.a(this.locX, this.locY + this.height, this.locZ);
                double d16 = this.motX;
                double d17 = this.motZ;
                if (this.passenger != null) {
                    d16 *= 0.75;
                    d17 *= 0.75;
                }
                if (d16 < -d5) {
                    d16 = -d5;
                }
                if (d16 > d5) {
                    d16 = d5;
                }
                if (d17 < -d5) {
                    d17 = -d5;
                }
                if (d17 > d5) {
                    d17 = d5;
                }
                this.c(d16, 0.0, d17);
                if (aint[0][1] != 0 && MathHelper.b(this.locX) - i == aint[0][0] && MathHelper.b(this.locZ) - k == aint[0][2]) {
                    this.a(this.locX, this.locY + aint[0][1], this.locZ);
                }
                else if (aint[1][1] != 0 && MathHelper.b(this.locX) - i == aint[1][0] && MathHelper.b(this.locZ) - k == aint[1][2]) {
                    this.a(this.locX, this.locY + aint[1][1], this.locZ);
                }
                if (this.passenger != null || !this.slowWhenEmpty) {
                    this.motX *= 0.996999979019165;
                    this.motY *= 0.0;
                    this.motZ *= 0.996999979019165;
                }
                else {
                    if (this.d == 2) {
                        final double d18 = MathHelper.a(this.f * this.f + this.g * this.g);
                        if (d18 > 0.01) {
                            flag = true;
                            this.f /= d18;
                            this.g /= d18;
                            final double d19 = 0.04;
                            this.motX *= 0.800000011920929;
                            this.motY *= 0.0;
                            this.motZ *= 0.800000011920929;
                            this.motX += this.f * d19;
                            this.motZ += this.g * d19;
                        }
                        else {
                            this.motX *= 0.8999999761581421;
                            this.motY *= 0.0;
                            this.motZ *= 0.8999999761581421;
                        }
                    }
                    this.motX *= 0.9599999785423279;
                    this.motY *= 0.0;
                    this.motZ *= 0.9599999785423279;
                }
                final Vec3D vec3d2 = this.g(this.locX, this.locY, this.locZ);
                if (vec3d2 != null && vec3d != null) {
                    final double d20 = (vec3d.b - vec3d2.b) * 0.05;
                    d10 = Math.sqrt(this.motX * this.motX + this.motZ * this.motZ);
                    if (d10 > 0.0) {
                        this.motX = this.motX / d10 * (d10 + d20);
                        this.motZ = this.motZ / d10 * (d10 + d20);
                    }
                    this.a(this.locX, vec3d2.b, this.locZ);
                }
                final int i2 = MathHelper.b(this.locX);
                final int j2 = MathHelper.b(this.locZ);
                if (i2 != i || j2 != k) {
                    d10 = Math.sqrt(this.motX * this.motX + this.motZ * this.motZ);
                    this.motX = d10 * (i2 - i);
                    this.motZ = d10 * (j2 - k);
                }
                if (this.d == 2) {
                    final double d21 = MathHelper.a(this.f * this.f + this.g * this.g);
                    if (d21 > 0.01 && this.motX * this.motX + this.motZ * this.motZ > 0.001) {
                        this.f /= d21;
                        this.g /= d21;
                        if (this.f * this.motX + this.g * this.motZ < 0.0) {
                            this.f = 0.0;
                            this.g = 0.0;
                        }
                        else {
                            this.f = this.motX;
                            this.g = this.motZ;
                        }
                    }
                }
            }
            else {
                if (this.motX < -d5) {
                    this.motX = -d5;
                }
                if (this.motX > d5) {
                    this.motX = d5;
                }
                if (this.motZ < -d5) {
                    this.motZ = -d5;
                }
                if (this.motZ > d5) {
                    this.motZ = d5;
                }
                if (this.onGround) {
                    this.motX *= this.derailedX;
                    this.motY *= this.derailedY;
                    this.motZ *= this.derailedZ;
                }
                this.c(this.motX, this.motY, this.motZ);
                if (!this.onGround) {
                    this.motX *= this.flyingX;
                    this.motY *= this.flyingY;
                    this.motZ *= this.flyingZ;
                }
            }
            this.pitch = 0.0f;
            final double d22 = this.lastX - this.locX;
            final double d23 = this.lastZ - this.locZ;
            if (d22 * d22 + d23 * d23 > 0.001) {
                this.yaw = (float)(Math.atan2(d23, d22) * 180.0 / 3.141592653589793);
                if (this.i) {
                    this.yaw += 180.0f;
                }
            }
            double d24;
            for (d24 = this.yaw - this.lastYaw; d24 >= 180.0; d24 -= 360.0) {}
            while (d24 < -180.0) {
                d24 += 360.0;
            }
            if (d24 < -170.0 || d24 >= 170.0) {
                this.yaw += 180.0f;
                this.i = !this.i;
            }
            this.c(this.yaw, this.pitch);
            final CraftServer server = ((WorldServer)this.world).getServer();
            final CraftWorld world = ((WorldServer)this.world).getWorld();
            final Location from = new Location(world, prevX, prevY, prevZ, prevYaw, prevPitch);
            final Location to = new Location(world, this.locX, this.locY, this.locZ, this.yaw, this.pitch);
            final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
            server.getPluginManager().callEvent(new VehicleEvent(Event.Type.VEHICLE_UPDATE, vehicle));
            if (!from.equals(to)) {
                final VehicleMoveEvent event = new VehicleMoveEvent(Event.Type.VEHICLE_MOVE, vehicle, from, to);
                server.getPluginManager().callEvent(event);
            }
            final List list = this.world.b(this, this.boundingBox.b(0.20000000298023224, 0.0, 0.20000000298023224));
            if (list != null && list.size() > 0) {
                for (int k2 = 0; k2 < list.size(); ++k2) {
                    final Entity entity = list.get(k2);
                    if (entity != this.passenger && entity.e_() && entity instanceof EntityMinecart) {
                        entity.h(this);
                    }
                }
            }
            if (this.passenger != null && this.passenger.dead) {
                this.passenger = null;
            }
            if (flag && this.random.nextInt(4) == 0) {
                --this.e;
                if (this.e < 0) {
                    final double n = 0.0;
                    this.g = n;
                    this.f = n;
                }
                this.world.a("largesmoke", this.locX, this.locY + 0.8, this.locZ, 0.0, 0.0, 0.0);
            }
        }
    }
    
    public Vec3D g(double d0, double d1, double d2) {
        final int i = MathHelper.b(d0);
        int j = MathHelper.b(d1);
        final int k = MathHelper.b(d2);
        if (this.world.getTypeId(i, j - 1, k) == Block.RAILS.id) {
            --j;
        }
        if (this.world.getTypeId(i, j, k) == Block.RAILS.id) {
            final int l = this.world.getData(i, j, k);
            d1 = j;
            if (l >= 2 && l <= 5) {
                d1 = j + 1;
            }
            final int[][] aint = EntityMinecart.j[l];
            double d3 = 0.0;
            final double d4 = i + 0.5 + aint[0][0] * 0.5;
            final double d5 = j + 0.5 + aint[0][1] * 0.5;
            final double d6 = k + 0.5 + aint[0][2] * 0.5;
            final double d7 = i + 0.5 + aint[1][0] * 0.5;
            final double d8 = j + 0.5 + aint[1][1] * 0.5;
            final double d9 = k + 0.5 + aint[1][2] * 0.5;
            final double d10 = d7 - d4;
            final double d11 = (d8 - d5) * 2.0;
            final double d12 = d9 - d6;
            if (d10 == 0.0) {
                d0 = i + 0.5;
                d3 = d2 - k;
            }
            else if (d12 == 0.0) {
                d2 = k + 0.5;
                d3 = d0 - i;
            }
            else {
                final double d13 = d0 - d4;
                final double d14 = d2 - d6;
                final double d15 = d3 = (d13 * d10 + d14 * d12) * 2.0;
            }
            d0 = d4 + d10 * d3;
            d1 = d5 + d11 * d3;
            d2 = d6 + d12 * d3;
            if (d11 < 0.0) {
                ++d1;
            }
            if (d11 > 0.0) {
                d1 += 0.5;
            }
            return Vec3D.b(d0, d1, d2);
        }
        return null;
    }
    
    @Override
    protected void a(final NBTTagCompound nbttagcompound) {
        nbttagcompound.a("Type", this.d);
        if (this.d == 2) {
            nbttagcompound.a("PushX", this.f);
            nbttagcompound.a("PushZ", this.g);
            nbttagcompound.a("Fuel", (short)this.e);
        }
        else if (this.d == 1) {
            final NBTTagList nbttaglist = new NBTTagList();
            for (int i = 0; i < this.h.length; ++i) {
                if (this.h[i] != null) {
                    final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                    nbttagcompound2.a("Slot", (byte)i);
                    this.h[i].a(nbttagcompound2);
                    nbttaglist.a(nbttagcompound2);
                }
            }
            nbttagcompound.a("Items", nbttaglist);
        }
    }
    
    @Override
    protected void b(final NBTTagCompound nbttagcompound) {
        this.d = nbttagcompound.e("Type");
        if (this.d == 2) {
            this.f = nbttagcompound.h("PushX");
            this.g = nbttagcompound.h("PushZ");
            this.e = nbttagcompound.d("Fuel");
        }
        else if (this.d == 1) {
            final NBTTagList nbttaglist = nbttagcompound.l("Items");
            this.h = new ItemStack[this.m_()];
            for (int i = 0; i < nbttaglist.c(); ++i) {
                final NBTTagCompound nbttagcompound2 = (NBTTagCompound)nbttaglist.a(i);
                final int j = nbttagcompound2.c("Slot") & 0xFF;
                if (j >= 0 && j < this.h.length) {
                    this.h[j] = new ItemStack(nbttagcompound2);
                }
            }
        }
    }
    
    @Override
    public void h(final Entity entity) {
        if (!this.world.isStatic && entity != this.passenger) {
            final CraftServer server = ((WorldServer)this.world).getServer();
            Event.Type eventType = Event.Type.VEHICLE_COLLISION_ENTITY;
            final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
            final org.bukkit.entity.Entity hitEntity = (entity == null) ? null : entity.getBukkitEntity();
            final VehicleEntityCollisionEvent collsionEvent = new VehicleEntityCollisionEvent(eventType, vehicle, hitEntity);
            server.getPluginManager().callEvent(collsionEvent);
            if (collsionEvent.isCancelled()) {
                return;
            }
            if (entity instanceof EntityLiving && !(entity instanceof EntityHuman) && this.d == 0 && this.motX * this.motX + this.motZ * this.motZ > 0.01 && this.passenger == null && entity.vehicle == null && !collsionEvent.isPickupCancelled()) {
                eventType = Event.Type.VEHICLE_ENTER;
                final VehicleEnterEvent enterEvent = new VehicleEnterEvent(eventType, vehicle, hitEntity);
                server.getPluginManager().callEvent(enterEvent);
                if (!enterEvent.isCancelled()) {
                    entity.b(this);
                }
            }
            double d0 = entity.locX - this.locX;
            double d2 = entity.locZ - this.locZ;
            double d3 = d0 * d0 + d2 * d2;
            if (d3 >= 9.999999747378752E-5 && !collsionEvent.isCollisionCancelled()) {
                d3 = MathHelper.a(d3);
                d0 /= d3;
                d2 /= d3;
                double d4 = 1.0 / d3;
                if (d4 > 1.0) {
                    d4 = 1.0;
                }
                d0 *= d4;
                d2 *= d4;
                d0 *= 0.10000000149011612;
                d2 *= 0.10000000149011612;
                d0 *= 1.0f - this.bo;
                d2 *= 1.0f - this.bo;
                d0 *= 0.5;
                d2 *= 0.5;
                if (entity instanceof EntityMinecart) {
                    double d5 = entity.motX + this.motX;
                    double d6 = entity.motZ + this.motZ;
                    if (((EntityMinecart)entity).d == 2 && this.d != 2) {
                        this.motX *= 0.20000000298023224;
                        this.motZ *= 0.20000000298023224;
                        this.f(entity.motX - d0, 0.0, entity.motZ - d2);
                        entity.motX *= 0.699999988079071;
                        entity.motZ *= 0.699999988079071;
                    }
                    else if (((EntityMinecart)entity).d != 2 && this.d == 2) {
                        entity.motX *= 0.20000000298023224;
                        entity.motZ *= 0.20000000298023224;
                        entity.f(this.motX + d0, 0.0, this.motZ + d2);
                        this.motX *= 0.699999988079071;
                        this.motZ *= 0.699999988079071;
                    }
                    else {
                        d5 /= 2.0;
                        d6 /= 2.0;
                        this.motX *= 0.20000000298023224;
                        this.motZ *= 0.20000000298023224;
                        this.f(d5 - d0, 0.0, d6 - d2);
                        entity.motX *= 0.20000000298023224;
                        entity.motZ *= 0.20000000298023224;
                        entity.f(d5 + d0, 0.0, d6 + d2);
                    }
                }
                else {
                    this.f(-d0, 0.0, -d2);
                    entity.f(d0 / 4.0, 0.0, d2 / 4.0);
                }
            }
        }
    }
    
    public int m_() {
        return 27;
    }
    
    public ItemStack c_(final int i) {
        return this.h[i];
    }
    
    public ItemStack a(final int i, final int j) {
        if (this.h[i] == null) {
            return null;
        }
        if (this.h[i].count <= j) {
            final ItemStack itemstack = this.h[i];
            this.h[i] = null;
            return itemstack;
        }
        final ItemStack itemstack = this.h[i].a(j);
        if (this.h[i].count == 0) {
            this.h[i] = null;
        }
        return itemstack;
    }
    
    public void a(final int i, final ItemStack itemstack) {
        this.h[i] = itemstack;
        if (itemstack != null && itemstack.count > this.n_()) {
            itemstack.count = this.n_();
        }
    }
    
    public String c() {
        return "Minecart";
    }
    
    public int n_() {
        return 64;
    }
    
    public void h() {
    }
    
    @Override
    public boolean a(final EntityHuman entityhuman) {
        if (this.d == 0) {
            if (this.passenger != null && this.passenger instanceof EntityHuman && this.passenger != entityhuman) {
                return true;
            }
            if (!this.world.isStatic) {
                final CraftServer server = ((WorldServer)this.world).getServer();
                final Event.Type eventType = Event.Type.VEHICLE_ENTER;
                final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
                final org.bukkit.entity.Entity player = (entityhuman == null) ? null : entityhuman.getBukkitEntity();
                final VehicleEnterEvent event = new VehicleEnterEvent(eventType, vehicle, player);
                server.getPluginManager().callEvent(event);
                if (event.isCancelled()) {
                    return true;
                }
                entityhuman.b(this);
            }
        }
        else if (this.d == 1) {
            if (!this.world.isStatic) {
                entityhuman.a((IInventory)this);
            }
        }
        else if (this.d == 2) {
            final ItemStack itemstack = entityhuman.inventory.b();
            if (itemstack != null && itemstack.id == Item.COAL.id) {
                final ItemStack itemStack = itemstack;
                if (--itemStack.count == 0) {
                    entityhuman.inventory.a(entityhuman.inventory.c, null);
                }
                this.e += 1200;
            }
            this.f = this.locX - entityhuman.locX;
            this.g = this.locZ - entityhuman.locZ;
        }
        return true;
    }
    
    public boolean a_(final EntityHuman entityhuman) {
        return !this.dead && entityhuman.g(this) <= 64.0;
    }
    
    static {
        j = new int[][][] { { { 0, 0, -1 }, { 0, 0, 1 } }, { { -1, 0, 0 }, { 1, 0, 0 } }, { { -1, -1, 0 }, { 1, 0, 0 } }, { { -1, 0, 0 }, { 1, -1, 0 } }, { { 0, 0, -1 }, { 0, -1, 1 } }, { { 0, -1, -1 }, { 0, 0, 1 } }, { { 0, 0, 1 }, { 1, 0, 0 } }, { { 0, 0, 1 }, { -1, 0, 0 } }, { { 0, 0, -1 }, { -1, 0, 0 } }, { { 0, 0, -1 }, { 1, 0, 0 } } };
    }
}
