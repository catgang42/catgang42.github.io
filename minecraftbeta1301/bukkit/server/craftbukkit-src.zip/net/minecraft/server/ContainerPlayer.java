// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ContainerPlayer extends Container
{
    public InventoryCrafting a;
    public IInventory b;
    public boolean c;
    
    public ContainerPlayer(final InventoryPlayer inventoryPlayer) {
        this(inventoryPlayer, true);
    }
    
    public ContainerPlayer(final InventoryPlayer inventoryPlayer, final boolean c) {
        this.a = new InventoryCrafting(this, 2, 2);
        this.b = new InventoryCraftResult();
        this.c = false;
        this.c = c;
        this.a(new SlotResult(this.a, this.b, 0, 144, 36));
        for (int i = 0; i < 2; ++i) {
            for (int j = 0; j < 2; ++j) {
                this.a(new Slot(this.a, j + i * 2, 88 + j * 18, 26 + i * 18));
            }
        }
        for (int k = 0; k < 4; ++k) {
            this.a(new SlotArmor(this, inventoryPlayer, inventoryPlayer.m_() - 1 - k, 8, 8 + k * 18, k));
        }
        for (int l = 0; l < 3; ++l) {
            for (int n = 0; n < 9; ++n) {
                this.a(new Slot(inventoryPlayer, n + (l + 1) * 9, 8 + n * 18, 84 + l * 18));
            }
        }
        for (int m = 0; m < 9; ++m) {
            this.a(new Slot(inventoryPlayer, m, 8 + m * 18, 142));
        }
        this.a(this.a);
    }
    
    @Override
    public void a(final IInventory inventory) {
        this.b.a(0, CraftingManager.a().a(this.a));
    }
    
    @Override
    public void a(final EntityHuman entityHuman) {
        super.a(entityHuman);
        for (int i = 0; i < 4; ++i) {
            final ItemStack c_ = this.a.c_(i);
            if (c_ != null) {
                entityHuman.b(c_);
                this.a.a(i, null);
            }
        }
    }
    
    @Override
    public boolean b(final EntityHuman entityHuman) {
        return true;
    }
}
