// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.event.block.SignChangeEvent;
import java.util.List;
import java.util.ArrayList;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.command.CommandException;
import java.util.logging.Level;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.TextWrapper;
import org.bukkit.event.player.PlayerChatEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.block.BlockRightClickEvent;
import org.bukkit.event.player.PlayerItemEvent;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.block.BlockDamageLevel;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.Location;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.Event;
import org.bukkit.craftbukkit.entity.CraftPlayer;
import java.util.HashMap;
import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.CraftServer;
import java.util.Map;
import java.util.logging.Logger;

public class NetServerHandler extends NetHandler implements ICommandListener
{
    public static Logger a;
    public NetworkManager b;
    public boolean c;
    private MinecraftServer d;
    public EntityPlayer e;
    private int f;
    private int g;
    private boolean h;
    private double i;
    private double j;
    private double k;
    private boolean l;
    private Map m;
    private final CraftServer server;
    private int lastX;
    private int lastY;
    private int lastZ;
    private double lastPosX;
    private double lastPosY;
    private double lastPosZ;
    private CraftBlock lastRightClicked;
    private BlockFace lastRightClickedFace;
    private int lastMaterial;
    
    public NetServerHandler(final MinecraftServer minecraftserver, final NetworkManager networkmanager, final EntityPlayer entityplayer) {
        this.c = false;
        this.l = true;
        this.m = new HashMap();
        this.lastPosX = Double.MIN_VALUE;
        this.lastPosY = Double.MIN_VALUE;
        this.lastPosZ = Double.MIN_VALUE;
        this.d = minecraftserver;
        (this.b = networkmanager).a(this);
        this.e = entityplayer;
        entityplayer.a = this;
        this.server = minecraftserver.server;
    }
    
    public CraftPlayer getPlayer() {
        return (this.e == null) ? null : ((CraftPlayer)this.e.getBukkitEntity());
    }
    
    public void a() {
        this.h = false;
        this.b.a();
        if (this.f - this.g > 20) {
            this.b(new Packet0KeepAlive());
        }
    }
    
    public void a(final String s) {
        final String leaveMessage = "§e" + this.e.name + " left the game.";
        final PlayerKickEvent event = new PlayerKickEvent(Event.Type.PLAYER_KICK, this.server.getPlayer(this.e), s, leaveMessage);
        this.server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return;
        }
        this.b.a(new Packet255KickDisconnect(event.getReason()));
        this.b.c();
        this.d.f.a(new Packet3Chat(event.getLeaveMessage()));
        this.d.f.c(this.e);
        this.c = true;
    }
    
    @Override
    public void a(final Packet27 packet27) {
        this.e.a(packet27.c(), packet27.e(), packet27.g(), packet27.h(), packet27.d(), packet27.f());
    }
    
    @Override
    public void a(final Packet10Flying packet10flying) {
        this.h = true;
        if (!this.l) {
            final double d0 = packet10flying.b - this.j;
            if (packet10flying.a == this.i && d0 * d0 < 0.01 && packet10flying.c == this.k) {
                this.l = true;
            }
        }
        final Player player = this.getPlayer();
        Location from = new Location(player.getWorld(), this.i, this.j, this.k, this.e.yaw, this.e.pitch);
        Location to = player.getLocation();
        final double delta = Math.pow(this.lastPosX - this.i, 2.0) + Math.pow(this.lastPosY - this.j, 2.0) + Math.pow(this.lastPosZ - this.k, 2.0);
        if (delta > 0.00390625) {
            final PlayerMoveEvent event = new PlayerMoveEvent(Event.Type.PLAYER_MOVE, player, from, to);
            this.server.getPluginManager().callEvent(event);
            from = event.getFrom();
            to = (event.isCancelled() ? from : event.getTo());
            this.e.locX = to.getX();
            this.e.locY = to.getY();
            this.e.locZ = to.getZ();
            this.e.yaw = to.getYaw();
            this.e.pitch = to.getPitch();
            this.lastPosX = this.e.locX;
            this.lastPosY = this.e.locY;
            this.lastPosZ = this.e.locZ;
        }
        if (this.l) {
            if (this.e.vehicle != null) {
                float f = this.e.yaw;
                float f2 = this.e.pitch;
                this.e.vehicle.h_();
                final double d2 = this.e.locX;
                final double d3 = this.e.locY;
                final double d4 = this.e.locZ;
                double d5 = 0.0;
                double d6 = 0.0;
                if (packet10flying.i) {
                    f = packet10flying.e;
                    f2 = packet10flying.f;
                }
                if (packet10flying.h && packet10flying.b == -999.0 && packet10flying.d == -999.0) {
                    d5 = packet10flying.a;
                    d6 = packet10flying.c;
                }
                this.e.onGround = packet10flying.g;
                this.e.a(true);
                this.e.c(d5, 0.0, d6);
                this.e.b(d2, d3, d4, f, f2);
                this.e.motX = d5;
                this.e.motZ = d6;
                if (this.e.vehicle != null) {
                    ((WorldServer)this.e.world).b(this.e.vehicle, true);
                }
                if (this.e.vehicle != null) {
                    this.e.vehicle.h_();
                }
                this.d.f.b(this.e);
                this.i = this.e.locX;
                this.j = this.e.locY;
                this.k = this.e.locZ;
                this.e.world.f(this.e);
                return;
            }
            final double d0 = this.e.locY;
            this.i = this.e.locX;
            this.j = this.e.locY;
            this.k = this.e.locZ;
            double d2 = this.e.locX;
            double d3 = this.e.locY;
            double d4 = this.e.locZ;
            float f3 = this.e.yaw;
            float f4 = this.e.pitch;
            if (packet10flying.h && packet10flying.b == -999.0 && packet10flying.d == -999.0) {
                packet10flying.h = false;
            }
            if (packet10flying.h) {
                d2 = packet10flying.a;
                d3 = packet10flying.b;
                d4 = packet10flying.c;
                final double d6 = packet10flying.d - packet10flying.b;
                if (d6 > 1.65 || d6 < 0.1) {
                    this.a("Illegal stance");
                    NetServerHandler.a.warning(this.e.name + " had an illegal stance: " + d6);
                }
            }
            if (packet10flying.i) {
                f3 = packet10flying.e;
                f4 = packet10flying.f;
            }
            this.e.a(true);
            this.e.bl = 0.0f;
            this.e.b(this.i, this.j, this.k, f3, f4);
            double d6 = d2 - this.e.locX;
            double d7 = d3 - this.e.locY;
            double d8 = d4 - this.e.locZ;
            final float f5 = 0.0625f;
            final boolean flag = this.e.world.a(this.e, this.e.boundingBox.b().e(f5, f5, f5)).size() == 0;
            this.e.c(d6, d7, d8);
            d6 = d2 - this.e.locX;
            d7 = d3 - this.e.locY;
            if (d7 > -0.5 || d7 < 0.5) {
                d7 = 0.0;
            }
            d8 = d4 - this.e.locZ;
            final double d9 = d6 * d6 + d7 * d7 + d8 * d8;
            boolean flag2 = false;
            if (d9 > 0.0625 && !this.e.E()) {
                flag2 = true;
                NetServerHandler.a.warning(this.e.name + " moved wrongly!");
                System.out.println("Got position " + d2 + ", " + d3 + ", " + d4);
                System.out.println("Expected " + this.e.locX + ", " + this.e.locY + ", " + this.e.locZ);
            }
            this.e.b(d2, d3, d4, f3, f4);
            final boolean flag3 = this.e.world.a(this.e, this.e.boundingBox.b().e(f5, f5, f5)).size() == 0;
            if (flag && (flag2 || !flag3) && !this.e.E()) {
                this.a(this.i, this.j, this.k, f3, f4);
                return;
            }
            this.e.onGround = packet10flying.g;
            this.d.f.b(this.e);
            this.e.b(this.e.locY - d0, packet10flying.g);
        }
    }
    
    public void a(double d0, double d1, double d2, float f, float f1) {
        final Player player = this.getPlayer();
        Location from = player.getLocation();
        Location to = new Location(player.getWorld(), d0, d1, d2, f, f1);
        final PlayerMoveEvent event = new PlayerMoveEvent(Event.Type.PLAYER_TELEPORT, player, from, to);
        this.server.getPluginManager().callEvent(event);
        from = event.getFrom();
        to = (event.isCancelled() ? from : event.getTo());
        d0 = to.getX();
        d1 = to.getY();
        d2 = to.getZ();
        f = to.getYaw();
        f1 = to.getPitch();
        this.l = false;
        this.i = d0;
        this.j = d1;
        this.k = d2;
        this.e.b(d0, d1, d2, f, f1);
        this.e.a.b(new Packet13PlayerLookMove(d0, d1 + 1.6200000047683716, d1, d2, f, f1, false));
    }
    
    @Override
    public void a(final Packet14BlockDig packet14blockdig) {
        if (packet14blockdig.e == 4) {
            this.e.y();
        }
        else {
            final WorldServer worldServer = (WorldServer)this.e.world;
            final boolean h = this.d.f.h(this.e.name);
            worldServer.v = h;
            final boolean flag = h;
            boolean flag2 = false;
            if (packet14blockdig.e == 0) {
                flag2 = true;
            }
            if (packet14blockdig.e == 2) {
                flag2 = true;
            }
            final int i = packet14blockdig.a;
            final int j = packet14blockdig.b;
            final int k = packet14blockdig.c;
            if (flag2) {
                final double d0 = this.e.locX - (i + 0.5);
                final double d2 = this.e.locY - (j + 0.5);
                final double d3 = this.e.locZ - (k + 0.5);
                final double d4 = d0 * d0 + d2 * d2 + d3 * d3;
                if (d4 > 36.0) {
                    return;
                }
            }
            final ChunkCoordinates chunkcoordinates = this.e.world.l();
            final int l = (int)MathHelper.e((float)(i - chunkcoordinates.a));
            int i2 = (int)MathHelper.e((float)(k - chunkcoordinates.c));
            if (l > i2) {
                i2 = l;
            }
            final CraftPlayer player = this.getPlayer();
            CraftBlock block = (CraftBlock)player.getWorld().getBlockAt(i, j, k);
            final int blockId = block.getTypeId();
            float damage = 0.0f;
            if (Block.byId[blockId] != null) {
                damage = Block.byId[blockId].a(player.getHandle());
            }
            if (packet14blockdig.e == 0) {
                if (i2 > this.d.spawnProtection || flag) {
                    BlockDamageEvent event;
                    if (damage >= 1.0f) {
                        if ((blockId == Block.REDSTONE_WIRE.id && block.getRawData() > 0) || blockId == Block.REDSTONE_TORCH_ON.id) {
                            this.server.getPluginManager().callEvent(new BlockRedstoneEvent(block, (blockId == Block.REDSTONE_WIRE.id) ? block.getRawData() : 15, 0));
                        }
                        event = new BlockDamageEvent(Event.Type.BLOCK_DAMAGED, block, BlockDamageLevel.BROKEN, player);
                    }
                    else {
                        event = new BlockDamageEvent(Event.Type.BLOCK_DAMAGED, block, BlockDamageLevel.STARTED, player);
                    }
                    this.server.getPluginManager().callEvent(event);
                    if (!event.isCancelled()) {
                        this.e.c.a(i, j, k);
                    }
                    else {
                        MinecraftServer.a.info("A plugin cancelled the block start break event");
                    }
                }
            }
            else if (packet14blockdig.e == 2) {
                block = (CraftBlock)player.getWorld().getBlockAt(this.lastX, this.lastY, this.lastZ);
                final BlockDamageEvent event = new BlockDamageEvent(Event.Type.BLOCK_DAMAGED, block, BlockDamageLevel.STOPPED, player);
                this.server.getPluginManager().callEvent(event);
                if (!event.isCancelled()) {
                    this.e.c.b(i, j, k);
                }
                else {
                    MinecraftServer.a.info("A plugin cancelled the block stop break event");
                }
            }
            else if (packet14blockdig.e == 3) {
                final double d5 = this.e.locX - (i + 0.5);
                final double d6 = this.e.locY - (j + 0.5);
                final double d7 = this.e.locZ - (k + 0.5);
                final double d8 = d5 * d5 + d6 * d6 + d7 * d7;
                if (d8 < 256.0) {
                    this.e.a.b(new Packet53BlockChange(i, j, k, this.e.world));
                }
            }
            this.lastX = i;
            this.lastY = j;
            this.lastZ = k;
            ((WorldServer)this.e.world).v = false;
        }
    }
    
    @Override
    public void a(final Packet15Place packet15place) {
        final net.minecraft.server.ItemStack itemstack = this.e.inventory.b();
        final WorldServer worldServer = (WorldServer)this.e.world;
        final boolean h = this.d.f.h(this.e.name);
        worldServer.v = h;
        final boolean flag = h;
        CraftBlock blockClicked = null;
        BlockFace blockFace = BlockFace.SELF;
        if (packet15place.d == 255) {
            if ((packet15place.e != null && packet15place.e.id == this.lastMaterial) || this.lastMaterial == 0) {
                blockClicked = this.lastRightClicked;
                blockFace = this.lastRightClickedFace;
            }
            this.lastRightClicked = null;
            this.lastRightClickedFace = null;
            this.lastMaterial = 0;
        }
        else {
            blockClicked = (CraftBlock)((WorldServer)this.e.world).getWorld().getBlockAt(packet15place.a, packet15place.b, packet15place.c);
            blockFace = CraftBlock.notchToBlockFace(packet15place.d);
            this.lastRightClicked = blockClicked;
            this.lastMaterial = ((packet15place.e == null) ? 0 : packet15place.e.id);
            this.lastRightClickedFace = blockFace;
        }
        boolean always = false;
        if (packet15place.d == 255) {
            if (itemstack == null) {
                return;
            }
            final Event.Type eventType = Event.Type.PLAYER_ITEM;
            final Player who = (this.e == null) ? null : ((Player)this.e.getBukkitEntity());
            final ItemStack itemInHand = new CraftItemStack(itemstack);
            final PlayerItemEvent event = new PlayerItemEvent(eventType, who, itemInHand, blockClicked, blockFace);
            switch (itemInHand.getType()) {
                case SIGN:
                case BUCKET:
                case WATER_BUCKET:
                case LAVA_BUCKET: {
                    break;
                }
                default: {
                    this.server.getPluginManager().callEvent(event);
                    break;
                }
            }
            if (!event.isCancelled()) {
                final int itemstackAmount = itemstack.count;
                this.e.c.a(this.e, this.e.world, itemstack);
                always = (itemstack.count != itemstackAmount);
            }
        }
        else {
            int i = packet15place.a;
            int j = packet15place.b;
            int k = packet15place.c;
            final int l = packet15place.d;
            final ChunkCoordinates chunkcoordinates = this.e.world.l();
            final int i2 = (int)MathHelper.e((float)(i - chunkcoordinates.a));
            int j2 = (int)MathHelper.e((float)(k - chunkcoordinates.c));
            if (i2 > j2) {
                j2 = i2;
            }
            final CraftItemStack craftItem = new CraftItemStack(itemstack);
            final Player player = this.getPlayer();
            final BlockRightClickEvent event2 = new BlockRightClickEvent(Event.Type.BLOCK_RIGHTCLICKED, blockClicked, blockFace, craftItem, player);
            this.server.getPluginManager().callEvent(event2);
            this.e.c.a(this.e, this.e.world, itemstack, i, j, k, l);
            this.e.a.b(new Packet53BlockChange(i, j, k, this.e.world));
            if (l == 0) {
                --j;
            }
            if (l == 1) {
                ++j;
            }
            if (l == 2) {
                --k;
            }
            if (l == 3) {
                ++k;
            }
            if (l == 4) {
                --i;
            }
            if (l == 5) {
                ++i;
            }
            this.e.a.b(new Packet53BlockChange(i, j, k, this.e.world));
        }
        if (itemstack != null && itemstack.count == 0) {
            this.e.inventory.a[this.e.inventory.c] = null;
        }
        this.e.h = true;
        this.e.inventory.a[this.e.inventory.c] = net.minecraft.server.ItemStack.b(this.e.inventory.a[this.e.inventory.c]);
        final Slot slot = this.e.activeContainer.a(this.e.inventory, this.e.inventory.c);
        this.e.activeContainer.a();
        this.e.h = false;
        if (!net.minecraft.server.ItemStack.a(this.e.inventory.b(), packet15place.e) || always) {
            this.b(new Packet103SetSlot(this.e.activeContainer.f, slot.a, this.e.inventory.b()));
        }
        ((WorldServer)this.e.world).v = false;
    }
    
    @Override
    public void a(final String s, final Object[] aobject) {
        NetServerHandler.a.info(this.e.name + " lost connection: " + s);
        this.d.f.a(new Packet3Chat("§e" + this.e.name + " left the game."));
        this.d.f.c(this.e);
        this.c = true;
    }
    
    @Override
    public void a(final Packet packet) {
        NetServerHandler.a.warning(this.getClass() + " wasn't prepared to deal with a " + packet.getClass());
        this.a("Protocol error, unexpected packet");
    }
    
    public void b(final Packet packet) {
        this.b.a(packet);
        this.g = this.f;
    }
    
    @Override
    public void a(final Packet16BlockItemSwitch packet16blockitemswitch) {
        final PlayerItemHeldEvent event = new PlayerItemHeldEvent(Event.Type.PLAYER_ITEM_HELD, this.getPlayer(), this.e.inventory.c, packet16blockitemswitch.a);
        this.server.getPluginManager().callEvent(event);
        this.e.inventory.c = packet16blockitemswitch.a;
    }
    
    @Override
    public void a(final Packet3Chat packet3chat) {
        String s = packet3chat.a;
        if (s.length() > 100) {
            this.a("Chat message too long");
        }
        else {
            s = s.trim();
            for (int i = 0; i < s.length(); ++i) {
                if (FontAllowedCharacters.a.indexOf(s.charAt(i)) < 0) {
                    this.a("Illegal characters in chat");
                    return;
                }
            }
            this.chat(s);
        }
    }
    
    public boolean chat(String msg) {
        if (msg.startsWith("/")) {
            this.c(msg);
            return true;
        }
        final Player player = this.getPlayer();
        final PlayerChatEvent event = new PlayerChatEvent(Event.Type.PLAYER_CHAT, player, msg);
        this.server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        msg = String.format(event.getFormat(), event.getPlayer().getDisplayName(), event.getMessage());
        NetServerHandler.a.info(msg);
        for (final String line : TextWrapper.wrapText(msg)) {
            this.d.f.a(new Packet3Chat(line));
        }
        return false;
    }
    
    private void c(String s) {
        CraftPlayer player = this.getPlayer();
        PlayerChatEvent event = new PlayerChatEvent(Event.Type.PLAYER_COMMAND_PREPROCESS, player, s);
        this.server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return;
        }
        boolean targetPluginFound = false;
        try {
            targetPluginFound = this.server.dispatchCommand(player, s.substring(1));
        }
        catch (CommandException ex) {
            player.sendMessage(ChatColor.RED + "An internal error occured while attempting to perform this command");
            Logger.getLogger(NetServerHandler.class.getName()).log(Level.SEVERE, null, ex);
            return;
        }
        if (targetPluginFound) {
            return;
        }
        event = new PlayerChatEvent(Event.Type.PLAYER_COMMAND, player, s);
        this.server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return;
        }
        s = event.getMessage();
        player = (CraftPlayer)event.getPlayer();
        final EntityPlayer e = player.getHandle();
        if (s.toLowerCase().startsWith("/me ")) {
            s = "* " + this.e.name + " " + s.substring(s.indexOf(" ")).trim();
            NetServerHandler.a.info(s);
            this.d.f.a(new Packet3Chat(s));
        }
        else if (s.toLowerCase().startsWith("/kill")) {
            this.e.a(null, 1000);
        }
        else if (s.toLowerCase().startsWith("/tell ")) {
            final String[] astring = s.split(" ");
            if (astring.length >= 3) {
                s = s.substring(s.indexOf(" ")).trim();
                s = s.substring(s.indexOf(" ")).trim();
                s = "§7" + this.e.name + " whispers " + s;
                NetServerHandler.a.info(s + " to " + astring[1]);
                if (!this.d.f.a(astring[1], new Packet3Chat(s))) {
                    this.b(new Packet3Chat("§cThere's no player by that name online."));
                }
            }
        }
        else if (this.d.f.h(this.e.name)) {
            final String s2 = s.substring(1);
            NetServerHandler.a.info(this.e.name + " issued server command: " + s2);
            this.d.a(s2, this);
        }
        else {
            final String s2 = s.substring(1);
            NetServerHandler.a.info(this.e.name + " tried command: " + s2);
        }
    }
    
    @Override
    public void a(final Packet18ArmAnimation packet18armanimation) {
        if (packet18armanimation.b == 1) {
            final Player player = this.getPlayer();
            final PlayerAnimationEvent event = new PlayerAnimationEvent(Event.Type.PLAYER_ANIMATION, player);
            this.server.getPluginManager().callEvent(event);
            this.e.r();
        }
    }
    
    @Override
    public void a(final Packet19EntityAction packet19entityaction) {
        if (packet19entityaction.b == 1 || packet19entityaction.b == 2) {
            final Player player = this.getPlayer();
            final PlayerToggleSneakEvent event = new PlayerToggleSneakEvent(Event.Type.PLAYER_TOGGLE_SNEAK, player);
            this.server.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                return;
            }
        }
        if (packet19entityaction.b == 1) {
            this.e.b(true);
        }
        else if (packet19entityaction.b == 2) {
            this.e.b(false);
        }
        else if (packet19entityaction.b == 3) {
            this.e.a(false, true);
            this.l = false;
        }
    }
    
    @Override
    public void a(final Packet255KickDisconnect packet255kickdisconnect) {
        this.b.a("disconnect.quitting", new Object[0]);
    }
    
    public int b() {
        return this.b.d();
    }
    
    public void b(final String s) {
        this.b(new Packet3Chat("§7" + s));
    }
    
    public String c() {
        return this.e.name;
    }
    
    @Override
    public void a(final Packet7UseEntity packet7useentity) {
        final Entity entity = ((WorldServer)this.e.world).a(packet7useentity.b);
        if (entity != null && this.e.e(entity) && this.e.f(entity) < 4.0f) {
            if (packet7useentity.c == 0) {
                this.e.c(entity);
            }
            else if (packet7useentity.c == 1) {
                this.e.d(entity);
            }
        }
    }
    
    @Override
    public void a(final Packet9Respawn packet9respawn) {
        if (this.e.health <= 0) {
            this.e = this.d.f.d(this.e);
            final CraftPlayer player = this.getPlayer();
            player.setHandle(this.e);
        }
    }
    
    @Override
    public void a(final Packet101CloseWindow packet101closewindow) {
        this.e.v();
    }
    
    @Override
    public void a(final Packet102WindowClick packet102windowclick) {
        if (this.e.activeContainer.f == packet102windowclick.a && this.e.activeContainer.c(this.e)) {
            final net.minecraft.server.ItemStack itemstack = this.e.activeContainer.a(packet102windowclick.b, packet102windowclick.c, this.e);
            if (net.minecraft.server.ItemStack.a(packet102windowclick.e, itemstack)) {
                this.e.a.b(new Packet106Transaction(packet102windowclick.a, packet102windowclick.d, true));
                this.e.h = true;
                this.e.activeContainer.a();
                this.e.u();
                this.e.h = false;
            }
            else {
                this.m.put(this.e.activeContainer.f, packet102windowclick.d);
                this.e.a.b(new Packet106Transaction(packet102windowclick.a, packet102windowclick.d, false));
                this.e.activeContainer.a(this.e, false);
                final ArrayList arraylist = new ArrayList();
                for (int i = 0; i < this.e.activeContainer.e.size(); ++i) {
                    arraylist.add(this.e.activeContainer.e.get(i).b());
                }
                this.e.a(this.e.activeContainer, arraylist);
            }
        }
    }
    
    @Override
    public void a(final Packet106Transaction packet106transaction) {
        final Short oshort = this.m.get(this.e.activeContainer.f);
        if (oshort != null && packet106transaction.b == oshort && this.e.activeContainer.f == packet106transaction.a && !this.e.activeContainer.c(this.e)) {
            this.e.activeContainer.a(this.e, true);
        }
    }
    
    @Override
    public void a(final Packet130UpdateSign packet130updatesign) {
        if (this.e.world.f(packet130updatesign.a, packet130updatesign.b, packet130updatesign.c)) {
            final TileEntity tileentity = this.e.world.getTileEntity(packet130updatesign.a, packet130updatesign.b, packet130updatesign.c);
            for (int i = 0; i < 4; ++i) {
                boolean flag = true;
                if (packet130updatesign.d[i].length() > 15) {
                    flag = false;
                }
                else {
                    for (int j = 0; j < packet130updatesign.d[i].length(); ++j) {
                        if (FontAllowedCharacters.a.indexOf(packet130updatesign.d[i].charAt(j)) < 0) {
                            flag = false;
                        }
                    }
                }
                if (!flag) {
                    packet130updatesign.d[i] = "!?";
                }
            }
            if (tileentity instanceof TileEntitySign) {
                final int i = packet130updatesign.a;
                final int k = packet130updatesign.b;
                final int j = packet130updatesign.c;
                final TileEntitySign tileentitysign = (TileEntitySign)tileentity;
                final Player player = this.server.getPlayer(this.e);
                final SignChangeEvent event = new SignChangeEvent(Event.Type.SIGN_CHANGE, player.getWorld().getBlockAt(i, k, j), this.server.getPlayer(this.e), packet130updatesign.d);
                this.server.getPluginManager().callEvent(event);
                if (event.isCancelled()) {
                    for (int l = 0; l < 4; ++l) {
                        event.setLine(l, "");
                    }
                }
                for (int l = 0; l < 4; ++l) {
                    tileentitysign.a[l] = event.getLine(l);
                }
                tileentitysign.h();
                this.e.world.g(i, k, j);
            }
        }
    }
    
    static {
        NetServerHandler.a = Logger.getLogger("Minecraft");
    }
}
