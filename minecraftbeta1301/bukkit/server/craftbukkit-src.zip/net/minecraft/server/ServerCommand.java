// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ServerCommand
{
    public final String a;
    public final ICommandListener b;
    
    public ServerCommand(final String a, final ICommandListener b) {
        this.a = a;
        this.b = b;
    }
}
