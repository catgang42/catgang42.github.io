// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemSoup extends ItemFood
{
    public ItemSoup(final int n, final int n2) {
        super(n, n2);
    }
    
    @Override
    public ItemStack a(final ItemStack itemStack, final World world, final EntityHuman entityHuman) {
        super.a(itemStack, world, entityHuman);
        return new ItemStack(Item.BOWL);
    }
}
