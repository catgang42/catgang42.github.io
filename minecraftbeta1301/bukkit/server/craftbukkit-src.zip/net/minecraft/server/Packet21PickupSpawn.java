// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet21PickupSpawn extends Packet
{
    public int a;
    public int b;
    public int c;
    public int d;
    public byte e;
    public byte f;
    public byte g;
    public int h;
    public int i;
    public int l;
    
    public Packet21PickupSpawn() {
    }
    
    public Packet21PickupSpawn(final EntityItem entityItem) {
        this.a = entityItem.id;
        this.h = entityItem.a.id;
        this.i = entityItem.a.count;
        this.l = entityItem.a.h();
        this.b = MathHelper.b(entityItem.locX * 32.0);
        this.c = MathHelper.b(entityItem.locY * 32.0);
        this.d = MathHelper.b(entityItem.locZ * 32.0);
        this.e = (byte)(entityItem.motX * 128.0);
        this.f = (byte)(entityItem.motY * 128.0);
        this.g = (byte)(entityItem.motZ * 128.0);
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.h = dataInputStream.readShort();
        this.i = dataInputStream.readByte();
        this.l = dataInputStream.readShort();
        this.b = dataInputStream.readInt();
        this.c = dataInputStream.readInt();
        this.d = dataInputStream.readInt();
        this.e = dataInputStream.readByte();
        this.f = dataInputStream.readByte();
        this.g = dataInputStream.readByte();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeShort(this.h);
        dataOutputStream.writeByte(this.i);
        dataOutputStream.writeShort(this.l);
        dataOutputStream.writeInt(this.b);
        dataOutputStream.writeInt(this.c);
        dataOutputStream.writeInt(this.d);
        dataOutputStream.writeByte(this.e);
        dataOutputStream.writeByte(this.f);
        dataOutputStream.writeByte(this.g);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 24;
    }
}
