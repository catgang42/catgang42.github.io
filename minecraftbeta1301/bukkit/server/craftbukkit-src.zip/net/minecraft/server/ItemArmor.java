// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemArmor extends Item
{
    private static final int[] bl;
    private static final int[] bm;
    public final int a;
    public final int bi;
    public final int bj;
    public final int bk;
    
    public ItemArmor(final int n, final int a, final int bk, final int bi) {
        super(n);
        this.a = a;
        this.bi = bi;
        this.bk = bk;
        this.bj = ItemArmor.bl[bi];
        this.durability = ItemArmor.bm[bi] * 3 << a;
        this.maxStackSize = 1;
    }
    
    static {
        bl = new int[] { 3, 8, 6, 3 };
        bm = new int[] { 11, 16, 15, 13 };
    }
}
