// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class RecipesCrafting
{
    public void a(final CraftingManager craftingManager) {
        craftingManager.a(new ItemStack(Block.CHEST), "###", "# #", "###", '#', Block.WOOD);
        craftingManager.a(new ItemStack(Block.FURNACE), "###", "# #", "###", '#', Block.COBBLESTONE);
        craftingManager.a(new ItemStack(Block.WORKBENCH), "##", "##", '#', Block.WOOD);
        craftingManager.a(new ItemStack(Block.SANDSTONE), "##", "##", '#', Block.SAND);
    }
}
