// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockCrops extends BlockFlower
{
    protected BlockCrops(final int n, final int textureId) {
        super(n, textureId);
        this.textureId = textureId;
        this.a(true);
        final float n2 = 0.5f;
        this.a(0.5f - n2, 0.0f, 0.5f - n2, 0.5f + n2, 0.25f, 0.5f + n2);
    }
    
    @Override
    protected boolean c(final int n) {
        return n == Block.SOIL.id;
    }
    
    @Override
    public void a(final World world, final int i, final int n, final int k, final Random random) {
        super.a(world, i, n, k, random);
        if (world.j(i, n + 1, k) >= 9) {
            int data = world.getData(i, n, k);
            if (data < 7 && random.nextInt((int)(100.0f / this.h(world, i, n, k))) == 0) {
                ++data;
                world.c(i, n, k, data);
            }
        }
    }
    
    public void c_(final World world, final int i, final int j, final int k) {
        world.c(i, j, k, 7);
    }
    
    private float h(final World world, final int n, final int n2, final int n3) {
        float n4 = 1.0f;
        final int typeId = world.getTypeId(n, n2, n3 - 1);
        final int typeId2 = world.getTypeId(n, n2, n3 + 1);
        final int typeId3 = world.getTypeId(n - 1, n2, n3);
        final int typeId4 = world.getTypeId(n + 1, n2, n3);
        final int typeId5 = world.getTypeId(n - 1, n2, n3 - 1);
        final int typeId6 = world.getTypeId(n + 1, n2, n3 - 1);
        final int typeId7 = world.getTypeId(n + 1, n2, n3 + 1);
        final int typeId8 = world.getTypeId(n - 1, n2, n3 + 1);
        final boolean b = typeId3 == this.id || typeId4 == this.id;
        final boolean b2 = typeId == this.id || typeId2 == this.id;
        final boolean b3 = typeId5 == this.id || typeId6 == this.id || typeId7 == this.id || typeId8 == this.id;
        for (int i = n - 1; i <= n + 1; ++i) {
            for (int j = n3 - 1; j <= n3 + 1; ++j) {
                final int typeId9 = world.getTypeId(i, n2 - 1, j);
                float n5 = 0.0f;
                if (typeId9 == Block.SOIL.id) {
                    n5 = 1.0f;
                    if (world.getData(i, n2 - 1, j) > 0) {
                        n5 = 3.0f;
                    }
                }
                if (i != n || j != n3) {
                    n5 /= 4.0f;
                }
                n4 += n5;
            }
        }
        if (b3 || (b && b2)) {
            n4 /= 2.0f;
        }
        return n4;
    }
    
    @Override
    public int a(final int n, int n2) {
        if (n2 < 0) {
            n2 = 7;
        }
        return this.textureId + n2;
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3, final int n4) {
        super.b(world, n, n2, n3, n4);
        if (!world.isStatic) {
            for (int i = 0; i < 3; ++i) {
                if (world.k.nextInt(15) <= n4) {
                    final float n5 = 0.7f;
                    final EntityItem entity = new EntityItem(world, n + (world.k.nextFloat() * n5 + (1.0f - n5) * 0.5f), n2 + (world.k.nextFloat() * n5 + (1.0f - n5) * 0.5f), n3 + (world.k.nextFloat() * n5 + (1.0f - n5) * 0.5f), new ItemStack(Item.SEEDS));
                    entity.c = 10;
                    world.a(entity);
                }
            }
        }
    }
    
    @Override
    public int a(final int n, final Random random) {
        if (n == 7) {
            return Item.WHEAT.id;
        }
        return -1;
    }
    
    @Override
    public int a(final Random random) {
        return 1;
    }
}
