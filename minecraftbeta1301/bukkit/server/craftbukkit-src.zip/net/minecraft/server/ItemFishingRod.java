// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemFishingRod extends Item
{
    public ItemFishingRod(final int n) {
        super(n);
        this.durability = 64;
    }
    
    @Override
    public ItemStack a(final ItemStack itemStack, final World world, final EntityHuman entityHuman) {
        if (entityHuman.hookedFish != null) {
            itemStack.b(entityHuman.hookedFish.h());
            entityHuman.r();
        }
        else {
            world.a(entityHuman, "random.bow", 0.5f, 0.4f / (ItemFishingRod.b.nextFloat() * 0.4f + 0.8f));
            if (!world.isStatic) {
                world.a(new EntityFish(world, entityHuman));
            }
            entityHuman.r();
        }
        return itemStack;
    }
}
