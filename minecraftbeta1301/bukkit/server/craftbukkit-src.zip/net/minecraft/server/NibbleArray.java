// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class NibbleArray
{
    public final byte[] a;
    
    public NibbleArray(final int n) {
        this.a = new byte[n >> 1];
    }
    
    public NibbleArray(final byte[] a) {
        this.a = a;
    }
    
    public int a(final int n, final int n2, final int n3) {
        final int n4 = n << 11 | n3 << 7 | n2;
        final int n5 = n4 >> 1;
        if ((n4 & 0x1) == 0x0) {
            return this.a[n5] & 0xF;
        }
        return this.a[n5] >> 4 & 0xF;
    }
    
    public void a(final int n, final int n2, final int n3, final int n4) {
        final int n5 = n << 11 | n3 << 7 | n2;
        final int n6 = n5 >> 1;
        if ((n5 & 0x1) == 0x0) {
            this.a[n6] = (byte)((this.a[n6] & 0xF0) | (n4 & 0xF));
        }
        else {
            this.a[n6] = (byte)((this.a[n6] & 0xF) | (n4 & 0xF) << 4);
        }
    }
    
    public boolean a() {
        return this.a != null;
    }
}
