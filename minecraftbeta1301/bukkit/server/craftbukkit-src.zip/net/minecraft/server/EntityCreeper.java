// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.ExplosionPrimedEvent;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.Event;

public class EntityCreeper extends EntityMonster
{
    int a;
    int b;
    
    public EntityCreeper(final World world) {
        super(world);
        this.texture = "/mob/creeper.png";
    }
    
    @Override
    protected void a() {
        super.a();
        this.datawatcher.a(16, -1);
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
    }
    
    @Override
    public void f_() {
        this.b = this.a;
        if (this.world.isStatic) {
            final int i = this.r();
            if (i > 0 && this.a == 0) {
                this.world.a(this, "random.fuse", 1.0f, 0.5f);
            }
            this.a += i;
            if (this.a < 0) {
                this.a = 0;
            }
            if (this.a >= 30) {
                this.a = 30;
            }
        }
        super.f_();
    }
    
    @Override
    protected String f() {
        return "mob.creeper";
    }
    
    @Override
    protected String g() {
        return "mob.creeperdeath";
    }
    
    @Override
    public void a(final Entity entity) {
        super.a(entity);
        if (entity instanceof EntitySkeleton) {
            this.b(Item.GOLD_RECORD.id + this.random.nextInt(2), 1);
        }
    }
    
    @Override
    protected void a(final Entity entity, final float f) {
        final int i = this.r();
        if ((i > 0 || f >= 3.0f) && (i <= 0 || f >= 7.0f)) {
            this.e(-1);
            --this.a;
            if (this.a < 0) {
                this.a = 0;
            }
        }
        else {
            if (this.a == 0) {
                this.world.a(this, "random.fuse", 1.0f, 0.5f);
            }
            this.e(1);
            ++this.a;
            if (this.a >= 30) {
                final CraftServer server = ((WorldServer)this.world).getServer();
                final Event.Type eventType = Event.Type.EXPLOSION_PRIMED;
                final ExplosionPrimedEvent event = new ExplosionPrimedEvent(eventType, CraftEntity.getEntity(server, this), 3.0f, false);
                server.getPluginManager().callEvent(event);
                if (!event.isCancelled()) {
                    this.world.a(this, this.locX, this.locY, this.locZ, event.getRadius(), event.getFire());
                    this.C();
                }
                else {
                    this.a = 0;
                }
            }
            this.e = true;
        }
    }
    
    @Override
    protected int h() {
        return Item.SULPHUR.id;
    }
    
    private int r() {
        return this.datawatcher.a(16);
    }
    
    private void e(final int i) {
        this.datawatcher.b(16, (byte)i);
    }
}
