// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemDye extends Item
{
    public static final String[] a;
    
    public ItemDye(final int n) {
        super(n);
        this.a(true);
        this.d(0);
    }
    
    @Override
    public boolean a(final ItemStack itemStack, final EntityHuman entityHuman, final World world, final int i, final int j, final int k, final int n) {
        if (itemStack.h() == 15) {
            final int typeId = world.getTypeId(i, j, k);
            if (typeId == Block.SAPLING.id) {
                ((BlockSapling)Block.SAPLING).b(world, i, j, k, world.k);
                --itemStack.count;
                return true;
            }
            if (typeId == Block.CROPS.id) {
                ((BlockCrops)Block.CROPS).c_(world, i, j, k);
                --itemStack.count;
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void b(final ItemStack itemStack, final EntityLiving entityLiving) {
        if (entityLiving instanceof EntitySheep) {
            final EntitySheep entitySheep = (EntitySheep)entityLiving;
            final int c = BlockCloth.c(itemStack.h());
            if (!entitySheep.j_() && entitySheep.n() != c) {
                entitySheep.a_(c);
                --itemStack.count;
            }
        }
    }
    
    static {
        a = new String[] { "black", "red", "green", "brown", "blue", "purple", "cyan", "silver", "gray", "pink", "lime", "yellow", "lightBlue", "magenta", "orange", "white" };
    }
}
