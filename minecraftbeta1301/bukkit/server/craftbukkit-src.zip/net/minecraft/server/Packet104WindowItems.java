// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.util.List;

public class Packet104WindowItems extends Packet
{
    public int a;
    public ItemStack[] b;
    
    public Packet104WindowItems() {
    }
    
    public Packet104WindowItems(final int a, final List list) {
        this.a = a;
        this.b = new ItemStack[list.size()];
        for (int i = 0; i < this.b.length; ++i) {
            final ItemStack itemStack = list.get(i);
            this.b[i] = ((itemStack == null) ? null : itemStack.j());
        }
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readByte();
        final short short1 = dataInputStream.readShort();
        this.b = new ItemStack[short1];
        for (short n = 0; n < short1; ++n) {
            final short short2 = dataInputStream.readShort();
            if (short2 >= 0) {
                this.b[n] = new ItemStack(short2, dataInputStream.readByte(), dataInputStream.readShort());
            }
        }
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeByte(this.a);
        dataOutputStream.writeShort(this.b.length);
        for (int i = 0; i < this.b.length; ++i) {
            if (this.b[i] == null) {
                dataOutputStream.writeShort(-1);
            }
            else {
                dataOutputStream.writeShort((short)this.b[i].id);
                dataOutputStream.writeByte((byte)this.b[i].count);
                dataOutputStream.writeShort((short)this.b[i].h());
            }
        }
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 3 + this.b.length * 5;
    }
}
