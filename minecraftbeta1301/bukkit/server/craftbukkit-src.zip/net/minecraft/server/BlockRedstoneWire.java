// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.craftbukkit.block.CraftBlock;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class BlockRedstoneWire extends Block
{
    private boolean a;
    private Set b;
    
    public BlockRedstoneWire(final int i, final int j) {
        super(i, j, Material.ORIENTABLE);
        this.a = true;
        this.b = new HashSet();
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.0625f, 1.0f);
    }
    
    @Override
    public int a(final int i, final int j) {
        return this.textureId;
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k) {
        return world.d(i, j - 1, k);
    }
    
    private void g(final World world, final int i, final int j, final int k) {
        this.a(world, i, j, k, i, j, k);
        final ArrayList arraylist = new ArrayList(this.b);
        this.b.clear();
        for (int l = 0; l < arraylist.size(); ++l) {
            final ChunkPosition chunkposition = arraylist.get(l);
            world.h(chunkposition.a, chunkposition.b, chunkposition.c, this.id);
        }
    }
    
    private void a(final World world, final int i, final int j, final int k, final int l, final int i1, final int j1) {
        final int k2 = world.getData(i, j, k);
        int l2 = 0;
        this.a = false;
        final boolean flag = world.p(i, j, k);
        this.a = true;
        if (flag) {
            l2 = 15;
        }
        else {
            for (int i2 = 0; i2 < 4; ++i2) {
                int j2 = i;
                int k3 = k;
                if (i2 == 0) {
                    j2 = i - 1;
                }
                if (i2 == 1) {
                    ++j2;
                }
                if (i2 == 2) {
                    k3 = k - 1;
                }
                if (i2 == 3) {
                    ++k3;
                }
                if (j2 != l || j != i1 || k3 != j1) {
                    l2 = this.g(world, j2, j, k3, l2);
                }
                if (world.d(j2, j, k3) && !world.d(i, j + 1, k)) {
                    if (j2 != l || j + 1 != i1 || k3 != j1) {
                        l2 = this.g(world, j2, j + 1, k3, l2);
                    }
                }
                else if (!world.d(j2, j, k3) && (j2 != l || j - 1 != i1 || k3 != j1)) {
                    l2 = this.g(world, j2, j - 1, k3, l2);
                }
            }
            if (l2 > 0) {
                --l2;
            }
            else {
                l2 = 0;
            }
        }
        if (k2 != l2) {
            final CraftBlock block = (CraftBlock)((WorldServer)world).getWorld().getBlockAt(i, j, k);
            final BlockRedstoneEvent event = new BlockRedstoneEvent(block, k2, l2);
            ((WorldServer)world).getServer().getPluginManager().callEvent(event);
            l2 = event.getNewCurrent();
        }
        if (k2 != l2) {
            world.h = true;
            world.c(i, j, k, l2);
            world.b(i, j, k, i, j, k);
            world.h = false;
            for (int i2 = 0; i2 < 4; ++i2) {
                int j2 = i;
                int k3 = k;
                int l3 = j - 1;
                if (i2 == 0) {
                    j2 = i - 1;
                }
                if (i2 == 1) {
                    ++j2;
                }
                if (i2 == 2) {
                    k3 = k - 1;
                }
                if (i2 == 3) {
                    ++k3;
                }
                if (world.d(j2, j, k3)) {
                    l3 += 2;
                }
                final boolean flag2 = false;
                int i3 = this.g(world, j2, j, k3, -1);
                l2 = world.getData(i, j, k);
                if (l2 > 0) {
                    --l2;
                }
                if (i3 >= 0 && i3 != l2) {
                    this.a(world, j2, j, k3, i, j, k);
                }
                i3 = this.g(world, j2, l3, k3, -1);
                l2 = world.getData(i, j, k);
                if (l2 > 0) {
                    --l2;
                }
                if (i3 >= 0 && i3 != l2) {
                    this.a(world, j2, l3, k3, i, j, k);
                }
            }
            if (k2 == 0 || l2 == 0) {
                this.b.add(new ChunkPosition(i, j, k));
                this.b.add(new ChunkPosition(i - 1, j, k));
                this.b.add(new ChunkPosition(i + 1, j, k));
                this.b.add(new ChunkPosition(i, j - 1, k));
                this.b.add(new ChunkPosition(i, j + 1, k));
                this.b.add(new ChunkPosition(i, j, k - 1));
                this.b.add(new ChunkPosition(i, j, k + 1));
            }
        }
    }
    
    private void h(final World world, final int i, final int j, final int k) {
        if (world.getTypeId(i, j, k) == this.id) {
            world.h(i, j, k, this.id);
            world.h(i - 1, j, k, this.id);
            world.h(i + 1, j, k, this.id);
            world.h(i, j, k - 1, this.id);
            world.h(i, j, k + 1, this.id);
            world.h(i, j - 1, k, this.id);
            world.h(i, j + 1, k, this.id);
        }
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
        super.e(world, i, j, k);
        if (!world.isStatic) {
            this.g(world, i, j, k);
            world.h(i, j + 1, k, this.id);
            world.h(i, j - 1, k, this.id);
            this.h(world, i - 1, j, k);
            this.h(world, i + 1, j, k);
            this.h(world, i, j, k - 1);
            this.h(world, i, j, k + 1);
            if (world.d(i - 1, j, k)) {
                this.h(world, i - 1, j + 1, k);
            }
            else {
                this.h(world, i - 1, j - 1, k);
            }
            if (world.d(i + 1, j, k)) {
                this.h(world, i + 1, j + 1, k);
            }
            else {
                this.h(world, i + 1, j - 1, k);
            }
            if (world.d(i, j, k - 1)) {
                this.h(world, i, j + 1, k - 1);
            }
            else {
                this.h(world, i, j - 1, k - 1);
            }
            if (world.d(i, j, k + 1)) {
                this.h(world, i, j + 1, k + 1);
            }
            else {
                this.h(world, i, j - 1, k + 1);
            }
        }
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k) {
        super.b(world, i, j, k);
        if (!world.isStatic) {
            world.h(i, j + 1, k, this.id);
            world.h(i, j - 1, k, this.id);
            this.g(world, i, j, k);
            this.h(world, i - 1, j, k);
            this.h(world, i + 1, j, k);
            this.h(world, i, j, k - 1);
            this.h(world, i, j, k + 1);
            if (world.d(i - 1, j, k)) {
                this.h(world, i - 1, j + 1, k);
            }
            else {
                this.h(world, i - 1, j - 1, k);
            }
            if (world.d(i + 1, j, k)) {
                this.h(world, i + 1, j + 1, k);
            }
            else {
                this.h(world, i + 1, j - 1, k);
            }
            if (world.d(i, j, k - 1)) {
                this.h(world, i, j + 1, k - 1);
            }
            else {
                this.h(world, i, j - 1, k - 1);
            }
            if (world.d(i, j, k + 1)) {
                this.h(world, i, j + 1, k + 1);
            }
            else {
                this.h(world, i, j - 1, k + 1);
            }
        }
    }
    
    private int g(final World world, final int i, final int j, final int k, final int l) {
        if (world.getTypeId(i, j, k) != this.id) {
            return l;
        }
        final int i2 = world.getData(i, j, k);
        return (i2 > l) ? i2 : l;
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        if (!world.isStatic) {
            final int i2 = world.getData(i, j, k);
            final boolean flag = this.a(world, i, j, k);
            if (!flag) {
                this.b_(world, i, j, k, i2);
                world.e(i, j, k, 0);
            }
            else {
                this.g(world, i, j, k);
            }
            super.a(world, i, j, k, l);
        }
    }
    
    @Override
    public int a(final int i, final Random random) {
        return Item.REDSTONE.id;
    }
    
    @Override
    public boolean c(final World world, final int i, final int j, final int k, final int l) {
        return this.a && this.b((IBlockAccess)world, i, j, k, l);
    }
    
    @Override
    public boolean b(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        if (!this.a) {
            return false;
        }
        if (iblockaccess.getData(i, j, k) == 0) {
            return false;
        }
        if (l == 1) {
            return true;
        }
        boolean flag = b(iblockaccess, i - 1, j, k) || (!iblockaccess.d(i - 1, j, k) && b(iblockaccess, i - 1, j - 1, k));
        boolean flag2 = b(iblockaccess, i + 1, j, k) || (!iblockaccess.d(i + 1, j, k) && b(iblockaccess, i + 1, j - 1, k));
        boolean flag3 = b(iblockaccess, i, j, k - 1) || (!iblockaccess.d(i, j, k - 1) && b(iblockaccess, i, j - 1, k - 1));
        boolean flag4 = b(iblockaccess, i, j, k + 1) || (!iblockaccess.d(i, j, k + 1) && b(iblockaccess, i, j - 1, k + 1));
        if (!iblockaccess.d(i, j + 1, k)) {
            if (iblockaccess.d(i - 1, j, k) && b(iblockaccess, i - 1, j + 1, k)) {
                flag = true;
            }
            if (iblockaccess.d(i + 1, j, k) && b(iblockaccess, i + 1, j + 1, k)) {
                flag2 = true;
            }
            if (iblockaccess.d(i, j, k - 1) && b(iblockaccess, i, j + 1, k - 1)) {
                flag3 = true;
            }
            if (iblockaccess.d(i, j, k + 1) && b(iblockaccess, i, j + 1, k + 1)) {
                flag4 = true;
            }
        }
        return (!flag3 && !flag2 && !flag && !flag4 && l >= 2 && l <= 5) || (l == 2 && flag3 && !flag && !flag2) || (l == 3 && flag4 && !flag && !flag2) || (l == 4 && flag && !flag3 && !flag4) || (l == 5 && flag2 && !flag3 && !flag4);
    }
    
    @Override
    public boolean c() {
        return this.a;
    }
    
    public static boolean b(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final int l = iblockaccess.getTypeId(i, j, k);
        return l == Block.REDSTONE_WIRE.id || (l != 0 && Block.byId[l].c());
    }
}
