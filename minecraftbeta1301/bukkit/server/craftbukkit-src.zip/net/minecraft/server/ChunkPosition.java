// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ChunkPosition
{
    public final int a;
    public final int b;
    public final int c;
    
    public ChunkPosition(final int a, final int b, final int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o instanceof ChunkPosition) {
            final ChunkPosition chunkPosition = (ChunkPosition)o;
            return chunkPosition.a == this.a && chunkPosition.b == this.b && chunkPosition.c == this.c;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.a * 8976890 + this.b * 981131 + this.c;
    }
}
