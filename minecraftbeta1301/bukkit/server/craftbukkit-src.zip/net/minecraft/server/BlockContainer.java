// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public abstract class BlockContainer extends Block
{
    protected BlockContainer(final int n, final Material material) {
        super(n, material);
        BlockContainer.p[n] = true;
    }
    
    protected BlockContainer(final int n, final int n2, final Material material) {
        super(n, n2, material);
        BlockContainer.p[n] = true;
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
        super.e(world, i, j, k);
        world.setTileEntity(i, j, k, this.a_());
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k) {
        super.b(world, i, j, k);
        world.n(i, j, k);
    }
    
    protected abstract TileEntity a_();
}
