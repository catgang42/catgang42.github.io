// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.List;
import java.io.InputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.File;
import java.util.logging.Logger;

public class PlayerNBTManager implements PlayerFileData, IDataManager
{
    private static final Logger a;
    private final File b;
    private final File c;
    private final long d;
    
    public PlayerNBTManager(final File parent, final String child, final boolean b) {
        this.d = System.currentTimeMillis();
        (this.b = new File(parent, child)).mkdirs();
        this.c = new File(this.b, "players");
        if (b) {
            this.c.mkdirs();
        }
        this.f();
    }
    
    private void f() {
        try {
            final DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(new File(this.b, "session.lock")));
            try {
                dataOutputStream.writeLong(this.d);
            }
            finally {
                dataOutputStream.close();
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
            throw new RuntimeException("Failed to check session lock, aborting");
        }
    }
    
    protected File a() {
        return this.b;
    }
    
    public void b() {
        try {
            final DataInputStream dataInputStream = new DataInputStream(new FileInputStream(new File(this.b, "session.lock")));
            try {
                if (dataInputStream.readLong() != this.d) {
                    throw new MinecraftException("The save is being accessed from another location, aborting");
                }
            }
            finally {
                dataInputStream.close();
            }
        }
        catch (IOException ex) {
            throw new MinecraftException("Failed to check session lock, aborting");
        }
    }
    
    public IChunkLoader a(final WorldProvider worldProvider) {
        if (worldProvider instanceof WorldProviderHell) {
            final File file = new File(this.b, "DIM-1");
            file.mkdirs();
            return new ChunkLoader(file, true);
        }
        return new ChunkLoader(this.b, true);
    }
    
    public WorldData c() {
        final File file = new File(this.b, "level.dat");
        if (file.exists()) {
            try {
                return new WorldData(CompressedStreamTools.a(new FileInputStream(file)).k("Data"));
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }
    
    public void a(final WorldData worldData, final List list) {
        final NBTTagCompound a = worldData.a(list);
        final NBTTagCompound nbtTagCompound = new NBTTagCompound();
        nbtTagCompound.a("Data", (NBTBase)a);
        try {
            final File file = new File(this.b, "level.dat_new");
            final File dest = new File(this.b, "level.dat_old");
            final File dest2 = new File(this.b, "level.dat");
            CompressedStreamTools.a(nbtTagCompound, new FileOutputStream(file));
            if (dest.exists()) {
                dest.delete();
            }
            dest2.renameTo(dest);
            if (dest2.exists()) {
                dest2.delete();
            }
            file.renameTo(dest2);
            if (file.exists()) {
                file.delete();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void a(final WorldData worldData) {
        final NBTTagCompound a = worldData.a();
        final NBTTagCompound nbtTagCompound = new NBTTagCompound();
        nbtTagCompound.a("Data", (NBTBase)a);
        try {
            final File file = new File(this.b, "level.dat_new");
            final File dest = new File(this.b, "level.dat_old");
            final File dest2 = new File(this.b, "level.dat");
            CompressedStreamTools.a(nbtTagCompound, new FileOutputStream(file));
            if (dest.exists()) {
                dest.delete();
            }
            dest2.renameTo(dest);
            if (dest2.exists()) {
                dest2.delete();
            }
            file.renameTo(dest2);
            if (file.exists()) {
                file.delete();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void a(final EntityHuman entityHuman) {
        try {
            final NBTTagCompound nbttagcompound = new NBTTagCompound();
            entityHuman.d(nbttagcompound);
            final File file = new File(this.c, "_tmp_.dat");
            final File dest = new File(this.c, entityHuman.name + ".dat");
            CompressedStreamTools.a(nbttagcompound, new FileOutputStream(file));
            if (dest.exists()) {
                dest.delete();
            }
            file.renameTo(dest);
        }
        catch (Exception ex) {
            PlayerNBTManager.a.warning("Failed to save player data for " + entityHuman.name);
        }
    }
    
    public void b(final EntityHuman entityHuman) {
        try {
            final File file = new File(this.c, entityHuman.name + ".dat");
            if (file.exists()) {
                final NBTTagCompound a = CompressedStreamTools.a(new FileInputStream(file));
                if (a != null) {
                    entityHuman.e(a);
                }
            }
        }
        catch (Exception ex) {
            PlayerNBTManager.a.warning("Failed to load player data for " + entityHuman.name);
        }
    }
    
    public PlayerFileData d() {
        return this;
    }
    
    public void e() {
    }
    
    static {
        a = Logger.getLogger("Minecraft");
    }
}
