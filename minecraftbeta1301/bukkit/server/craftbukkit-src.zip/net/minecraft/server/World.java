// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.event.block.BlockCanBuildEvent;
import java.util.Iterator;
import java.util.Collection;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.Location;
import org.bukkit.entity.MobType;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.Event;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.List;

public class World implements IBlockAccess
{
    public boolean a;
    private List u;
    public List b;
    private List v;
    private TreeSet w;
    private Set x;
    public List c;
    public List d;
    private long y;
    public int e;
    protected int f;
    protected int g;
    public boolean h;
    private long z;
    protected int i;
    public int j;
    public Random k;
    public boolean l;
    public final WorldProvider m;
    protected List n;
    protected IChunkProvider o;
    protected final IDataManager p;
    public WorldData q;
    public boolean r;
    private boolean A;
    private ArrayList B;
    private int C;
    public boolean D;
    public boolean E;
    static int s;
    private Set F;
    private int G;
    private List H;
    public boolean isStatic;
    Chunk lastChunkAccessed;
    int lastXAccessed;
    int lastZAccessed;
    final Object chunkLock;
    
    public WorldChunkManager a() {
        return this.m.b;
    }
    
    public World(final IDataManager idatamanager, final String s, final long i, final WorldProvider worldprovider) {
        this.a = false;
        this.u = new ArrayList();
        this.b = new ArrayList();
        this.v = new ArrayList();
        this.w = new TreeSet();
        this.x = new HashSet();
        this.c = new ArrayList();
        this.d = new ArrayList();
        this.y = 16777215L;
        this.e = 0;
        this.f = new Random().nextInt();
        this.g = 1013904223;
        this.h = false;
        this.z = System.currentTimeMillis();
        this.i = 40;
        this.k = new Random();
        this.l = false;
        this.n = new ArrayList();
        this.B = new ArrayList();
        this.C = 0;
        this.D = true;
        this.E = true;
        this.F = new HashSet();
        this.lastXAccessed = Integer.MIN_VALUE;
        this.lastZAccessed = Integer.MIN_VALUE;
        this.chunkLock = new Object();
        this.G = this.k.nextInt(12000);
        this.H = new ArrayList();
        this.isStatic = false;
        this.p = idatamanager;
        this.q = idatamanager.c();
        this.l = (this.q == null);
        if (worldprovider != null) {
            this.m = worldprovider;
        }
        else if (this.q != null && this.q.h() == -1) {
            this.m = new WorldProviderHell();
        }
        else {
            this.m = new WorldProvider();
        }
        boolean flag = false;
        if (this.q == null) {
            this.q = new WorldData(i, s);
            flag = true;
        }
        else {
            this.q.a(s);
        }
        this.m.a(this);
        this.o = this.b();
        if (flag) {
            this.r = true;
            int j = 0;
            final byte b0 = 64;
            int k;
            for (k = 0; !this.m.a(j, k); j += this.k.nextInt(64) - this.k.nextInt(64), k += this.k.nextInt(64) - this.k.nextInt(64)) {}
            this.q.a(j, b0, k);
            this.r = false;
        }
        this.f();
    }
    
    protected IChunkProvider b() {
        final IChunkLoader ichunkloader = this.p.a(this.m);
        return new ChunkProviderLoadOrGenerate(this, ichunkloader, this.m.c());
    }
    
    public int a(final int i, final int j) {
        int k;
        for (k = 63; !this.isEmpty(i, k + 1, j); ++k) {}
        return this.getTypeId(i, k, j);
    }
    
    public void a(final boolean flag, final IProgressUpdate iprogressupdate) {
        if (this.o.b()) {
            if (iprogressupdate != null) {
                iprogressupdate.a("Saving level");
            }
            this.r();
            if (iprogressupdate != null) {
                iprogressupdate.b("Saving chunks");
            }
            this.o.a(flag, iprogressupdate);
        }
    }
    
    private void r() {
        this.i();
        this.p.a(this.q, this.d);
    }
    
    public int getTypeId(final int i, final int j, final int k) {
        return (i >= -32000000 && k >= -32000000 && i < 32000000 && k <= 32000000) ? ((j < 0) ? 0 : ((j >= 128) ? 0 : this.c(i >> 4, k >> 4).a(i & 0xF, j, k & 0xF))) : 0;
    }
    
    public boolean isEmpty(final int i, final int j, final int k) {
        return this.getTypeId(i, j, k) == 0;
    }
    
    public boolean f(final int i, final int j, final int k) {
        return j >= 0 && j < 128 && this.f(i >> 4, k >> 4);
    }
    
    public boolean a(final int i, final int j, final int k, final int l) {
        return this.a(i - l, j - l, k - l, i + l, j + l, k + l);
    }
    
    public boolean a(int i, int j, int k, int l, int i1, int j1) {
        if (i1 >= 0 && j < 128) {
            i >>= 4;
            j >>= 4;
            k >>= 4;
            l >>= 4;
            i1 >>= 4;
            j1 >>= 4;
            for (int k2 = i; k2 <= l; ++k2) {
                for (int l2 = k; l2 <= j1; ++l2) {
                    if (!this.f(k2, l2)) {
                        return false;
                    }
                }
            }
            return true;
        }
        return false;
    }
    
    private boolean f(final int i, final int j) {
        return this.o.a(i, j);
    }
    
    public Chunk b(final int i, final int j) {
        return this.c(i >> 4, j >> 4);
    }
    
    public Chunk c(final int i, final int j) {
        Chunk result = null;
        synchronized (this.chunkLock) {
            if (this.lastChunkAccessed == null || this.lastXAccessed != i || this.lastZAccessed != j) {
                this.lastXAccessed = i;
                this.lastZAccessed = j;
                this.lastChunkAccessed = this.o.b(i, j);
            }
            result = this.lastChunkAccessed;
        }
        return result;
    }
    
    public boolean setTypeIdAndData(final int i, final int j, final int k, final int l, final int i1) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return false;
        }
        if (j < 0) {
            return false;
        }
        if (j >= 128) {
            return false;
        }
        final Chunk chunk = this.c(i >> 4, k >> 4);
        return chunk.a(i & 0xF, j, k & 0xF, l, i1);
    }
    
    public boolean setTypeId(final int i, final int j, final int k, final int l) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return false;
        }
        if (j < 0) {
            return false;
        }
        if (j >= 128) {
            return false;
        }
        final Chunk chunk = this.c(i >> 4, k >> 4);
        return chunk.a(i & 0xF, j, k & 0xF, l);
    }
    
    public Material getMaterial(final int i, final int j, final int k) {
        final int l = this.getTypeId(i, j, k);
        return (l == 0) ? Material.AIR : Block.byId[l].material;
    }
    
    public int getData(int i, final int j, int k) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return 0;
        }
        if (j < 0) {
            return 0;
        }
        if (j >= 128) {
            return 0;
        }
        final Chunk chunk = this.c(i >> 4, k >> 4);
        i &= 0xF;
        k &= 0xF;
        return chunk.b(i, j, k);
    }
    
    public void c(final int i, final int j, final int k, final int l) {
        if (this.d(i, j, k, l)) {
            this.f(i, j, k, this.getTypeId(i, j, k));
        }
    }
    
    public boolean d(int i, final int j, int k, final int l) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return false;
        }
        if (j < 0) {
            return false;
        }
        if (j >= 128) {
            return false;
        }
        final Chunk chunk = this.c(i >> 4, k >> 4);
        i &= 0xF;
        k &= 0xF;
        chunk.b(i, j, k, l);
        return true;
    }
    
    public boolean e(final int i, final int j, final int k, final int l) {
        if (this.setTypeId(i, j, k, l)) {
            this.f(i, j, k, l);
            return true;
        }
        return false;
    }
    
    public boolean b(final int i, final int j, final int k, final int l, final int i1) {
        if (this.setTypeIdAndData(i, j, k, l, i1)) {
            this.f(i, j, k, l);
            return true;
        }
        return false;
    }
    
    public void g(final int i, final int j, final int k) {
        for (int l = 0; l < this.n.size(); ++l) {
            this.n.get(l).a(i, j, k);
        }
    }
    
    protected void f(final int i, final int j, final int k, final int l) {
        this.g(i, j, k);
        this.h(i, j, k, l);
    }
    
    public void g(final int i, final int j, int k, int l) {
        if (k > l) {
            final int i2 = l;
            l = k;
            k = i2;
        }
        this.b(i, k, j, i, l, j);
    }
    
    public void h(final int i, final int j, final int k) {
        for (int l = 0; l < this.n.size(); ++l) {
            this.n.get(l).a(i, j, k, i, j, k);
        }
    }
    
    public void b(final int i, final int j, final int k, final int l, final int i1, final int j1) {
        for (int k2 = 0; k2 < this.n.size(); ++k2) {
            this.n.get(k2).a(i, j, k, l, i1, j1);
        }
    }
    
    public void h(final int i, final int j, final int k, final int l) {
        this.k(i - 1, j, k, l);
        this.k(i + 1, j, k, l);
        this.k(i, j - 1, k, l);
        this.k(i, j + 1, k, l);
        this.k(i, j, k - 1, l);
        this.k(i, j, k + 1, l);
    }
    
    private void k(final int i, final int j, final int k, final int l) {
        if (!this.h && !this.isStatic) {
            final Block block = Block.byId[this.getTypeId(i, j, k)];
            if (block != null) {
                final CraftWorld world = ((WorldServer)this).getWorld();
                if (world != null) {
                    final BlockPhysicsEvent event = new BlockPhysicsEvent(Event.Type.BLOCK_PHYSICS, world.getBlockAt(i, j, k), l);
                    ((WorldServer)this).getServer().getPluginManager().callEvent(event);
                    if (event.isCancelled()) {
                        return;
                    }
                }
                block.a(this, i, j, k, l);
            }
        }
    }
    
    public boolean i(final int i, final int j, final int k) {
        return this.c(i >> 4, k >> 4).c(i & 0xF, j, k & 0xF);
    }
    
    public int j(final int i, final int j, final int k) {
        return this.a(i, j, k, true);
    }
    
    public int a(int i, final int j, int k, final boolean flag) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return 15;
        }
        if (flag) {
            final int l = this.getTypeId(i, j, k);
            if (l == Block.STEP.id || l == Block.SOIL.id) {
                int i2 = this.a(i, j + 1, k, false);
                final int j2 = this.a(i + 1, j, k, false);
                final int k2 = this.a(i - 1, j, k, false);
                final int l2 = this.a(i, j, k + 1, false);
                final int i3 = this.a(i, j, k - 1, false);
                if (j2 > i2) {
                    i2 = j2;
                }
                if (k2 > i2) {
                    i2 = k2;
                }
                if (l2 > i2) {
                    i2 = l2;
                }
                if (i3 > i2) {
                    i2 = i3;
                }
                return i2;
            }
        }
        if (j < 0) {
            return 0;
        }
        if (j >= 128) {
            int l = 15 - this.e;
            if (l < 0) {
                l = 0;
            }
            return l;
        }
        final Chunk chunk = this.c(i >> 4, k >> 4);
        i &= 0xF;
        k &= 0xF;
        return chunk.c(i, j, k, this.e);
    }
    
    public boolean k(int i, final int j, int k) {
        if (i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return false;
        }
        if (j < 0) {
            return false;
        }
        if (j >= 128) {
            return true;
        }
        if (!this.f(i >> 4, k >> 4)) {
            return false;
        }
        final Chunk chunk = this.c(i >> 4, k >> 4);
        i &= 0xF;
        k &= 0xF;
        return chunk.c(i, j, k);
    }
    
    public int d(final int i, final int j) {
        if (i < -32000000 || j < -32000000 || i >= 32000000 || j > 32000000) {
            return 0;
        }
        if (!this.f(i >> 4, j >> 4)) {
            return 0;
        }
        final Chunk chunk = this.c(i >> 4, j >> 4);
        return chunk.b(i & 0xF, j & 0xF);
    }
    
    public void a(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, int l) {
        if ((!this.m.e || enumskyblock != EnumSkyBlock.SKY) && this.f(i, j, k)) {
            if (enumskyblock == EnumSkyBlock.SKY) {
                if (this.k(i, j, k)) {
                    l = 15;
                }
            }
            else if (enumskyblock == EnumSkyBlock.BLOCK) {
                final int i2 = this.getTypeId(i, j, k);
                if (Block.s[i2] > l) {
                    l = Block.s[i2];
                }
            }
            if (this.a(enumskyblock, i, j, k) != l) {
                this.a(enumskyblock, i, j, k, i, j, k);
            }
        }
    }
    
    public int a(final EnumSkyBlock enumskyblock, final int i, final int j, final int k) {
        if (j < 0 || j >= 128 || i < -32000000 || k < -32000000 || i >= 32000000 || k > 32000000) {
            return enumskyblock.c;
        }
        final int l = i >> 4;
        final int i2 = k >> 4;
        if (!this.f(l, i2)) {
            return 0;
        }
        final Chunk chunk = this.c(l, i2);
        return chunk.a(enumskyblock, i & 0xF, j, k & 0xF);
    }
    
    public void b(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l) {
        if (i >= -32000000 && k >= -32000000 && i < 32000000 && k <= 32000000 && j >= 0 && j < 128 && this.f(i >> 4, k >> 4)) {
            final Chunk chunk = this.c(i >> 4, k >> 4);
            chunk.a(enumskyblock, i & 0xF, j, k & 0xF, l);
            for (int i2 = 0; i2 < this.n.size(); ++i2) {
                this.n.get(i2).a(i, j, k);
            }
        }
    }
    
    public float l(final int i, final int j, final int k) {
        return this.m.f[this.j(i, j, k)];
    }
    
    public boolean c() {
        return this.e < 4;
    }
    
    public MovingObjectPosition a(final Vec3D vec3d, final Vec3D vec3d1) {
        return this.a(vec3d, vec3d1, false);
    }
    
    public MovingObjectPosition a(final Vec3D vec3d, final Vec3D vec3d1, final boolean flag) {
        if (Double.isNaN(vec3d.a) || Double.isNaN(vec3d.b) || Double.isNaN(vec3d.c)) {
            return null;
        }
        if (!Double.isNaN(vec3d1.a) && !Double.isNaN(vec3d1.b) && !Double.isNaN(vec3d1.c)) {
            final int i = MathHelper.b(vec3d1.a);
            final int j = MathHelper.b(vec3d1.b);
            final int k = MathHelper.b(vec3d1.c);
            int l = MathHelper.b(vec3d.a);
            int i2 = MathHelper.b(vec3d.b);
            int j2 = MathHelper.b(vec3d.c);
            int k2 = 200;
            while (k2-- >= 0) {
                if (Double.isNaN(vec3d.a) || Double.isNaN(vec3d.b) || Double.isNaN(vec3d.c)) {
                    return null;
                }
                if (l == i && i2 == j && j2 == k) {
                    return null;
                }
                double d0 = 999.0;
                double d2 = 999.0;
                double d3 = 999.0;
                if (i > l) {
                    d0 = l + 1.0;
                }
                if (i < l) {
                    d0 = l + 0.0;
                }
                if (j > i2) {
                    d2 = i2 + 1.0;
                }
                if (j < i2) {
                    d2 = i2 + 0.0;
                }
                if (k > j2) {
                    d3 = j2 + 1.0;
                }
                if (k < j2) {
                    d3 = j2 + 0.0;
                }
                double d4 = 999.0;
                double d5 = 999.0;
                double d6 = 999.0;
                final double d7 = vec3d1.a - vec3d.a;
                final double d8 = vec3d1.b - vec3d.b;
                final double d9 = vec3d1.c - vec3d.c;
                if (d0 != 999.0) {
                    d4 = (d0 - vec3d.a) / d7;
                }
                if (d2 != 999.0) {
                    d5 = (d2 - vec3d.b) / d8;
                }
                if (d3 != 999.0) {
                    d6 = (d3 - vec3d.c) / d9;
                }
                final boolean flag2 = false;
                byte b0;
                if (d4 < d5 && d4 < d6) {
                    if (i > l) {
                        b0 = 4;
                    }
                    else {
                        b0 = 5;
                    }
                    vec3d.a = d0;
                    vec3d.b += d8 * d4;
                    vec3d.c += d9 * d4;
                }
                else if (d5 < d6) {
                    if (j > i2) {
                        b0 = 0;
                    }
                    else {
                        b0 = 1;
                    }
                    vec3d.a += d7 * d5;
                    vec3d.b = d2;
                    vec3d.c += d9 * d5;
                }
                else {
                    if (k > j2) {
                        b0 = 2;
                    }
                    else {
                        b0 = 3;
                    }
                    vec3d.a += d7 * d6;
                    vec3d.b += d8 * d6;
                    vec3d.c = d3;
                }
                final Vec3D b2;
                final Vec3D vec3d2 = b2 = Vec3D.b(vec3d.a, vec3d.b, vec3d.c);
                final double a = MathHelper.b(vec3d.a);
                b2.a = a;
                l = (int)a;
                if (b0 == 5) {
                    --l;
                    final Vec3D vec3D = vec3d2;
                    ++vec3D.a;
                }
                final Vec3D vec3D2 = vec3d2;
                final double b3 = MathHelper.b(vec3d.b);
                vec3D2.b = b3;
                i2 = (int)b3;
                if (b0 == 1) {
                    --i2;
                    final Vec3D vec3D3 = vec3d2;
                    ++vec3D3.b;
                }
                final Vec3D vec3D4 = vec3d2;
                final double c = MathHelper.b(vec3d.c);
                vec3D4.c = c;
                j2 = (int)c;
                if (b0 == 3) {
                    --j2;
                    final Vec3D vec3D5 = vec3d2;
                    ++vec3D5.c;
                }
                final int l2 = this.getTypeId(l, i2, j2);
                final int i3 = this.getData(l, i2, j2);
                final Block block = Block.byId[l2];
                if (l2 <= 0 || !block.a(i3, flag)) {
                    continue;
                }
                final MovingObjectPosition movingobjectposition = block.a(this, l, i2, j2, vec3d, vec3d1);
                if (movingobjectposition != null) {
                    return movingobjectposition;
                }
            }
            return null;
        }
        return null;
    }
    
    public void a(final Entity entity, final String s, final float f, final float f1) {
        for (int i = 0; i < this.n.size(); ++i) {
            this.n.get(i).a(s, entity.locX, entity.locY - entity.height, entity.locZ, f, f1);
        }
    }
    
    public void a(final double d0, final double d1, final double d2, final String s, final float f, final float f1) {
        for (int i = 0; i < this.n.size(); ++i) {
            this.n.get(i).a(s, d0, d1, d2, f, f1);
        }
    }
    
    public void a(final String s, final int i, final int j, final int k) {
        for (int l = 0; l < this.n.size(); ++l) {
            this.n.get(l).a(s, i, j, k);
        }
    }
    
    public void a(final String s, final double d0, final double d1, final double d2, final double d3, final double d4, final double d5) {
        for (int i = 0; i < this.n.size(); ++i) {
            this.n.get(i).a(s, d0, d1, d2, d3, d4, d5);
        }
    }
    
    public boolean a(final Entity entity) {
        final int i = MathHelper.b(entity.locX / 16.0);
        final int j = MathHelper.b(entity.locZ / 16.0);
        boolean flag = false;
        if (entity instanceof EntityHuman) {
            flag = true;
        }
        if (entity instanceof EntityLiving) {
            MobType type = null;
            if (entity instanceof EntityChicken) {
                type = MobType.CHICKEN;
            }
            else if (entity instanceof EntityCow) {
                type = MobType.COW;
            }
            else if (entity instanceof EntityCreeper) {
                type = MobType.CREEPER;
            }
            else if (entity instanceof EntityGhast) {
                type = MobType.GHAST;
            }
            else if (entity instanceof EntityPig) {
                type = MobType.PIG;
            }
            else if (entity instanceof EntityPigZombie) {
                type = MobType.PIG_ZOMBIE;
            }
            else if (entity instanceof EntitySheep) {
                type = MobType.SHEEP;
            }
            else if (entity instanceof EntitySkeleton) {
                type = MobType.SKELETON;
            }
            else if (entity instanceof EntitySpider) {
                type = MobType.SPIDER;
            }
            else if (entity instanceof EntityZombie) {
                type = MobType.ZOMBIE;
            }
            else if (entity instanceof EntitySlime) {
                type = MobType.SLIME;
            }
            if (type != null) {
                final CraftServer server = ((WorldServer)this).getServer();
                final Location loc = new Location(((WorldServer)this).getWorld(), entity.bi, entity.bj, entity.bk);
                final CreatureSpawnEvent event = new CreatureSpawnEvent(entity.getBukkitEntity(), type, loc);
                server.getPluginManager().callEvent(event);
                if (event.isCancelled()) {
                    return false;
                }
            }
        }
        if (!flag && !this.f(i, j)) {
            return false;
        }
        if (entity instanceof EntityHuman) {
            final EntityHuman entityhuman = (EntityHuman)entity;
            this.d.add(entityhuman);
            this.o();
        }
        this.c(i, j).a(entity);
        this.b.add(entity);
        this.b(entity);
        return true;
    }
    
    protected void b(final Entity entity) {
        for (int i = 0; i < this.n.size(); ++i) {
            this.n.get(i).a(entity);
        }
    }
    
    protected void c(final Entity entity) {
        for (int i = 0; i < this.n.size(); ++i) {
            this.n.get(i).b(entity);
        }
    }
    
    public void d(final Entity entity) {
        if (entity.passenger != null) {
            entity.passenger.b((Entity)null);
        }
        if (entity.vehicle != null) {
            entity.b((Entity)null);
        }
        entity.C();
        if (entity instanceof EntityHuman) {
            this.d.remove(entity);
            this.o();
        }
    }
    
    public void e(final Entity entity) {
        entity.C();
        if (entity instanceof EntityHuman) {
            this.d.remove(entity);
            this.o();
        }
        final int i = entity.chunkX;
        final int j = entity.chunkZ;
        if (entity.bA && this.f(i, j)) {
            this.c(i, j).b(entity);
        }
        this.b.remove(entity);
        this.c(entity);
    }
    
    public void a(final IWorldAccess iworldaccess) {
        this.n.add(iworldaccess);
    }
    
    public List a(final Entity entity, final AxisAlignedBB axisalignedbb) {
        this.B.clear();
        final int i = MathHelper.b(axisalignedbb.a);
        final int j = MathHelper.b(axisalignedbb.d + 1.0);
        final int k = MathHelper.b(axisalignedbb.b);
        final int l = MathHelper.b(axisalignedbb.e + 1.0);
        final int i2 = MathHelper.b(axisalignedbb.c);
        final int j2 = MathHelper.b(axisalignedbb.f + 1.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = i2; l2 < j2; ++l2) {
                if (this.f(k2, 64, l2)) {
                    for (int i3 = k - 1; i3 < l; ++i3) {
                        final Block block = Block.byId[this.getTypeId(k2, i3, l2)];
                        if (block != null) {
                            block.a(this, k2, i3, l2, axisalignedbb, this.B);
                        }
                    }
                }
            }
        }
        final double d0 = 0.25;
        final List list = this.b(entity, axisalignedbb.b(d0, d0, d0));
        for (int j3 = 0; j3 < list.size(); ++j3) {
            AxisAlignedBB axisalignedbb2 = list.get(j3).d();
            if (axisalignedbb2 != null && axisalignedbb2.a(axisalignedbb)) {
                this.B.add(axisalignedbb2);
            }
            axisalignedbb2 = entity.a_(list.get(j3));
            if (axisalignedbb2 != null && axisalignedbb2.a(axisalignedbb)) {
                this.B.add(axisalignedbb2);
            }
        }
        return this.B;
    }
    
    public int a(final float f) {
        final float f2 = this.b(f);
        float f3 = 1.0f - (MathHelper.b(f2 * 3.1415927f * 2.0f) * 2.0f + 0.5f);
        if (f3 < 0.0f) {
            f3 = 0.0f;
        }
        if (f3 > 1.0f) {
            f3 = 1.0f;
        }
        return (int)(f3 * 11.0f);
    }
    
    public float b(final float f) {
        return this.m.a(this.q.f(), f);
    }
    
    public int e(int i, int j) {
        final Chunk chunk = this.b(i, j);
        int k;
        for (k = 127; this.getMaterial(i, k, j).isSolid() && k > 0; --k) {}
        i &= 0xF;
        j &= 0xF;
        while (k > 0) {
            final int l = chunk.a(i, k, j);
            if (l != 0 && (Block.byId[l].material.isSolid() || Block.byId[l].material.isLiquid())) {
                return k + 1;
            }
            --k;
        }
        return -1;
    }
    
    public void c(final int i, final int j, final int k, final int l, final int i1) {
        final NextTickListEntry nextticklistentry = new NextTickListEntry(i, j, k, l);
        final byte b0 = 8;
        if (this.a) {
            if (this.a(nextticklistentry.a - b0, nextticklistentry.b - b0, nextticklistentry.c - b0, nextticklistentry.a + b0, nextticklistentry.b + b0, nextticklistentry.c + b0)) {
                final int j2 = this.getTypeId(nextticklistentry.a, nextticklistentry.b, nextticklistentry.c);
                if (j2 == nextticklistentry.d && j2 > 0) {
                    Block.byId[j2].a(this, nextticklistentry.a, nextticklistentry.b, nextticklistentry.c, this.k);
                }
            }
        }
        else if (this.a(i - b0, j - b0, k - b0, i + b0, j + b0, k + b0)) {
            if (l > 0) {
                nextticklistentry.a(i1 + this.q.f());
            }
            if (!this.x.contains(nextticklistentry)) {
                this.x.add(nextticklistentry);
                this.w.add(nextticklistentry);
            }
        }
    }
    
    public void d() {
        this.b.removeAll(this.v);
        for (int i = 0; i < this.v.size(); ++i) {
            final Entity entity = this.v.get(i);
            final int j = entity.chunkX;
            final int k = entity.chunkZ;
            if (entity.bA && this.f(j, k)) {
                this.c(j, k).b(entity);
            }
        }
        for (int i = 0; i < this.v.size(); ++i) {
            this.c(this.v.get(i));
        }
        this.v.clear();
        for (int i = 0; i < this.b.size(); ++i) {
            final Entity entity = this.b.get(i);
            if (entity.vehicle != null) {
                if (!entity.vehicle.dead && entity.vehicle.passenger == entity) {
                    continue;
                }
                entity.vehicle.passenger = null;
                entity.vehicle = null;
            }
            if (!entity.dead) {
                this.f(entity);
            }
            if (entity.dead) {
                final int j = entity.chunkX;
                final int k = entity.chunkZ;
                if (entity.bA && this.f(j, k)) {
                    this.c(j, k).b(entity);
                }
                this.b.remove(i--);
                this.c(entity);
            }
        }
        for (int i = 0; i < this.c.size(); ++i) {
            final TileEntity tileentity = this.c.get(i);
            tileentity.i_();
        }
    }
    
    public void f(final Entity entity) {
        this.a(entity, true);
    }
    
    public void a(final Entity entity, final boolean flag) {
        final int i = MathHelper.b(entity.locX);
        final int j = MathHelper.b(entity.locZ);
        final byte b0 = 32;
        if (!flag || this.a(i - b0, 0, j - b0, i + b0, 128, j + b0)) {
            entity.bi = entity.locX;
            entity.bj = entity.locY;
            entity.bk = entity.locZ;
            entity.lastYaw = entity.yaw;
            entity.lastPitch = entity.pitch;
            if (flag && entity.bA) {
                if (entity.vehicle != null) {
                    entity.x();
                }
                else {
                    entity.f_();
                }
            }
            if (Double.isNaN(entity.locX) || Double.isInfinite(entity.locX)) {
                entity.locX = entity.bi;
            }
            if (Double.isNaN(entity.locY) || Double.isInfinite(entity.locY)) {
                entity.locY = entity.bj;
            }
            if (Double.isNaN(entity.locZ) || Double.isInfinite(entity.locZ)) {
                entity.locZ = entity.bk;
            }
            if (Double.isNaN(entity.pitch) || Double.isInfinite(entity.pitch)) {
                entity.pitch = entity.lastPitch;
            }
            if (Double.isNaN(entity.yaw) || Double.isInfinite(entity.yaw)) {
                entity.yaw = entity.lastYaw;
            }
            final int k = MathHelper.b(entity.locX / 16.0);
            final int l = MathHelper.b(entity.locY / 16.0);
            final int i2 = MathHelper.b(entity.locZ / 16.0);
            if (!entity.bA || entity.chunkX != k || entity.bC != l || entity.chunkZ != i2) {
                if (entity.bA && this.f(entity.chunkX, entity.chunkZ)) {
                    this.c(entity.chunkX, entity.chunkZ).a(entity, entity.bC);
                }
                if (this.f(k, i2)) {
                    entity.bA = true;
                    this.c(k, i2).a(entity);
                }
                else {
                    entity.bA = false;
                }
            }
            if (flag && entity.bA && entity.passenger != null) {
                if (!entity.passenger.dead && entity.passenger.vehicle == entity) {
                    this.f(entity.passenger);
                }
                else {
                    entity.passenger.vehicle = null;
                    entity.passenger = null;
                }
            }
        }
    }
    
    public boolean a(final AxisAlignedBB axisalignedbb) {
        final List list = this.b(null, axisalignedbb);
        for (int i = 0; i < list.size(); ++i) {
            final Entity entity = list.get(i);
            if (!entity.dead && entity.aC) {
                return false;
            }
        }
        return true;
    }
    
    public boolean b(final AxisAlignedBB axisalignedbb) {
        int i = MathHelper.b(axisalignedbb.a);
        final int j = MathHelper.b(axisalignedbb.d + 1.0);
        int k = MathHelper.b(axisalignedbb.b);
        final int l = MathHelper.b(axisalignedbb.e + 1.0);
        int i2 = MathHelper.b(axisalignedbb.c);
        final int j2 = MathHelper.b(axisalignedbb.f + 1.0);
        if (axisalignedbb.a < 0.0) {
            --i;
        }
        if (axisalignedbb.b < 0.0) {
            --k;
        }
        if (axisalignedbb.c < 0.0) {
            --i2;
        }
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final Block block = Block.byId[this.getTypeId(k2, l2, i3)];
                    if (block != null && block.material.isLiquid()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean c(final AxisAlignedBB axisalignedbb) {
        final int i = MathHelper.b(axisalignedbb.a);
        final int j = MathHelper.b(axisalignedbb.d + 1.0);
        final int k = MathHelper.b(axisalignedbb.b);
        final int l = MathHelper.b(axisalignedbb.e + 1.0);
        final int i2 = MathHelper.b(axisalignedbb.c);
        final int j2 = MathHelper.b(axisalignedbb.f + 1.0);
        if (this.a(i, k, i2, j, l, j2)) {
            for (int k2 = i; k2 < j; ++k2) {
                for (int l2 = k; l2 < l; ++l2) {
                    for (int i3 = i2; i3 < j2; ++i3) {
                        final int j3 = this.getTypeId(k2, l2, i3);
                        if (j3 == Block.FIRE.id || j3 == Block.LAVA.id || j3 == Block.STATIONARY_LAVA.id) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    public boolean a(final AxisAlignedBB axisalignedbb, final Material material, final Entity entity) {
        final int i = MathHelper.b(axisalignedbb.a);
        final int j = MathHelper.b(axisalignedbb.d + 1.0);
        final int k = MathHelper.b(axisalignedbb.b);
        final int l = MathHelper.b(axisalignedbb.e + 1.0);
        final int i2 = MathHelper.b(axisalignedbb.c);
        final int j2 = MathHelper.b(axisalignedbb.f + 1.0);
        if (!this.a(i, k, i2, j, l, j2)) {
            return false;
        }
        boolean flag = false;
        Vec3D vec3d = Vec3D.b(0.0, 0.0, 0.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final Block block = Block.byId[this.getTypeId(k2, l2, i3)];
                    if (block != null && block.material == material) {
                        final double d0 = l2 + 1 - BlockFluids.c(this.getData(k2, l2, i3));
                        if (l >= d0) {
                            flag = true;
                            block.a(this, k2, l2, i3, entity, vec3d);
                        }
                    }
                }
            }
        }
        if (vec3d.c() > 0.0) {
            vec3d = vec3d.b();
            final double d2 = 0.004;
            entity.motX += vec3d.a * d2;
            entity.motY += vec3d.b * d2;
            entity.motZ += vec3d.c * d2;
        }
        return flag;
    }
    
    public boolean a(final AxisAlignedBB axisalignedbb, final Material material) {
        final int i = MathHelper.b(axisalignedbb.a);
        final int j = MathHelper.b(axisalignedbb.d + 1.0);
        final int k = MathHelper.b(axisalignedbb.b);
        final int l = MathHelper.b(axisalignedbb.e + 1.0);
        final int i2 = MathHelper.b(axisalignedbb.c);
        final int j2 = MathHelper.b(axisalignedbb.f + 1.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final Block block = Block.byId[this.getTypeId(k2, l2, i3)];
                    if (block != null && block.material == material) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public boolean b(final AxisAlignedBB axisalignedbb, final Material material) {
        final int i = MathHelper.b(axisalignedbb.a);
        final int j = MathHelper.b(axisalignedbb.d + 1.0);
        final int k = MathHelper.b(axisalignedbb.b);
        final int l = MathHelper.b(axisalignedbb.e + 1.0);
        final int i2 = MathHelper.b(axisalignedbb.c);
        final int j2 = MathHelper.b(axisalignedbb.f + 1.0);
        for (int k2 = i; k2 < j; ++k2) {
            for (int l2 = k; l2 < l; ++l2) {
                for (int i3 = i2; i3 < j2; ++i3) {
                    final Block block = Block.byId[this.getTypeId(k2, l2, i3)];
                    if (block != null && block.material == material) {
                        final int j3 = this.getData(k2, l2, i3);
                        double d0 = l2 + 1;
                        if (j3 < 8) {
                            d0 = l2 + 1 - j3 / 8.0;
                        }
                        if (d0 >= axisalignedbb.b) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    
    public Explosion a(final Entity entity, final double d0, final double d1, final double d2, final float f) {
        return this.a(entity, d0, d1, d2, f, false);
    }
    
    public Explosion a(final Entity entity, final double d0, final double d1, final double d2, final float f, final boolean flag) {
        final Explosion explosion = new Explosion(this, entity, d0, d1, d2, f);
        explosion.a = flag;
        explosion.a();
        explosion.b();
        return explosion;
    }
    
    public float a(final Vec3D vec3d, final AxisAlignedBB axisalignedbb) {
        final double d0 = 1.0 / ((axisalignedbb.d - axisalignedbb.a) * 2.0 + 1.0);
        final double d2 = 1.0 / ((axisalignedbb.e - axisalignedbb.b) * 2.0 + 1.0);
        final double d3 = 1.0 / ((axisalignedbb.f - axisalignedbb.c) * 2.0 + 1.0);
        int i = 0;
        int j = 0;
        for (float f = 0.0f; f <= 1.0f; f += (float)d0) {
            for (float f2 = 0.0f; f2 <= 1.0f; f2 += (float)d2) {
                for (float f3 = 0.0f; f3 <= 1.0f; f3 += (float)d3) {
                    final double d4 = axisalignedbb.a + (axisalignedbb.d - axisalignedbb.a) * f;
                    final double d5 = axisalignedbb.b + (axisalignedbb.e - axisalignedbb.b) * f2;
                    final double d6 = axisalignedbb.c + (axisalignedbb.f - axisalignedbb.c) * f3;
                    if (this.a(Vec3D.b(d4, d5, d6), vec3d) == null) {
                        ++i;
                    }
                    ++j;
                }
            }
        }
        return i / (float)j;
    }
    
    public TileEntity getTileEntity(final int i, final int j, final int k) {
        final Chunk chunk = this.c(i >> 4, k >> 4);
        return (chunk != null) ? chunk.d(i & 0xF, j, k & 0xF) : null;
    }
    
    public void setTileEntity(final int i, final int j, final int k, final TileEntity tileentity) {
        final Chunk chunk = this.c(i >> 4, k >> 4);
        if (chunk != null) {
            chunk.a(i & 0xF, j, k & 0xF, tileentity);
        }
    }
    
    public void n(final int i, final int j, final int k) {
        final Chunk chunk = this.c(i >> 4, k >> 4);
        if (chunk != null) {
            chunk.e(i & 0xF, j, k & 0xF);
        }
    }
    
    public boolean d(final int i, final int j, final int k) {
        final Block block = Block.byId[this.getTypeId(i, j, k)];
        return block != null && block.a();
    }
    
    public boolean e() {
        if (this.C >= 50) {
            return false;
        }
        ++this.C;
        try {
            int i = 500;
            while (this.u.size() > 0) {
                if (--i <= 0) {
                    final boolean flag = true;
                    return flag;
                }
                this.u.remove(this.u.size() - 1).a(this);
            }
            final boolean flag = false;
            return flag;
        }
        finally {
            --this.C;
        }
    }
    
    public void a(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l, final int i1, final int j1) {
        this.a(enumskyblock, i, j, k, l, i1, j1, true);
    }
    
    public void a(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l, final int i1, final int j1, final boolean flag) {
        if (!this.m.e || enumskyblock != EnumSkyBlock.SKY) {
            ++World.s;
            if (World.s == 50) {
                --World.s;
            }
            else {
                final int k2 = (l + i) / 2;
                final int l2 = (j1 + k) / 2;
                if (!this.f(k2, 64, l2)) {
                    --World.s;
                }
                else if (!this.b(k2, l2).g()) {
                    final int i2 = this.u.size();
                    if (flag) {
                        int j2 = 5;
                        if (j2 > i2) {
                            j2 = i2;
                        }
                        for (int k3 = 0; k3 < j2; ++k3) {
                            final MetadataChunkBlock metadatachunkblock = this.u.get(this.u.size() - k3 - 1);
                            if (metadatachunkblock.a == enumskyblock && metadatachunkblock.a(i, j, k, l, i1, j1)) {
                                --World.s;
                                return;
                            }
                        }
                    }
                    this.u.add(new MetadataChunkBlock(enumskyblock, i, j, k, l, i1, j1));
                    int j2 = 1000000;
                    if (this.u.size() > 1000000) {
                        System.out.println("More than " + j2 + " updates, aborting lighting updates");
                        this.u.clear();
                    }
                    --World.s;
                }
            }
        }
    }
    
    public void f() {
        final int i = this.a(1.0f);
        if (i != this.e) {
            this.e = i;
        }
    }
    
    public void a(final boolean flag, final boolean flag1) {
        this.D = flag;
        this.E = flag1;
    }
    
    public void g() {
        if (this.q()) {
            boolean flag = false;
            if (this.D && this.j >= 1) {
                flag = SpawnerCreature.a(this, this.d);
            }
            if (!flag) {
                final long i = this.q.f() + 24000L;
                this.q.a(i - i % 24000L);
                this.p();
            }
        }
        if ((this.D || this.E) && this instanceof WorldServer && ((WorldServer)this).getServer().getHandle().b.size() > 0) {
            SpawnerCreature.a(this, this.D, this.E);
        }
        this.o.a();
        final int j = this.a(1.0f);
        if (j != this.e) {
            this.e = j;
            for (int k = 0; k < this.n.size(); ++k) {
                this.n.get(k).a();
            }
        }
        final long i = this.q.f() + 1L;
        if (i % this.i == 0L) {
            this.a(false, null);
        }
        this.q.a(i);
        this.a(false);
        this.h();
    }
    
    protected void h() {
        this.F.clear();
        for (int i1 = 0; i1 < this.d.size(); ++i1) {
            final EntityHuman entityhuman = this.d.get(i1);
            final int j = MathHelper.b(entityhuman.locX / 16.0);
            final int k = MathHelper.b(entityhuman.locZ / 16.0);
            final byte b0 = 9;
            for (int l = -b0; l <= b0; ++l) {
                for (int m = -b0; m <= b0; ++m) {
                    this.F.add(new ChunkCoordIntPair(l + j, m + k));
                }
            }
        }
        if (this.G > 0) {
            --this.G;
        }
        for (final ChunkCoordIntPair chunkcoordintpair : this.F) {
            final int j = chunkcoordintpair.a * 16;
            final int k = chunkcoordintpair.b * 16;
            final Chunk chunk = this.c(chunkcoordintpair.a, chunkcoordintpair.b);
            if (this.G == 0) {
                this.f = this.f * 3 + this.g;
                final int l = this.f >> 2;
                int m = l & 0xF;
                int j2 = l >> 8 & 0xF;
                final int k2 = l >> 16 & 0x7F;
                final int l2 = chunk.a(m, k2, j2);
                m += j;
                j2 += k;
                if (l2 == 0 && this.j(m, k2, j2) <= this.k.nextInt(8) && this.a(EnumSkyBlock.SKY, m, k2, j2) <= 0) {
                    final EntityHuman entityhuman2 = this.a(m + 0.5, k2 + 0.5, j2 + 0.5, 8.0);
                    if (entityhuman2 != null && entityhuman2.d(m + 0.5, k2 + 0.5, j2 + 0.5) > 4.0) {
                        this.a(m + 0.5, k2 + 0.5, j2 + 0.5, "ambient.cave.cave", 0.7f, 0.8f + this.k.nextFloat() * 0.2f);
                        this.G = this.k.nextInt(12000) + 6000;
                    }
                }
            }
            for (int l = 0; l < 80; ++l) {
                this.f = this.f * 3 + this.g;
                final int m = this.f >> 2;
                final int j2 = m & 0xF;
                final int k2 = m >> 8 & 0xF;
                final int l2 = m >> 16 & 0x7F;
                final byte b2 = chunk.b[j2 << 11 | k2 << 7 | l2];
                if (Block.n[b2]) {
                    Block.byId[b2].a(this, j2 + j, l2, k2 + k, this.k);
                }
            }
        }
    }
    
    public boolean a(final boolean flag) {
        int i = this.w.size();
        if (i != this.x.size()) {
            throw new IllegalStateException("TickNextTick list out of synch");
        }
        if (i > 1000) {
            i = 1000;
        }
        for (int j = 0; j < i; ++j) {
            final NextTickListEntry nextticklistentry = this.w.first();
            if (!flag && nextticklistentry.e > this.q.f()) {
                break;
            }
            this.w.remove(nextticklistentry);
            this.x.remove(nextticklistentry);
            final byte b0 = 8;
            if (this.a(nextticklistentry.a - b0, nextticklistentry.b - b0, nextticklistentry.c - b0, nextticklistentry.a + b0, nextticklistentry.b + b0, nextticklistentry.c + b0)) {
                final int k = this.getTypeId(nextticklistentry.a, nextticklistentry.b, nextticklistentry.c);
                if (k == nextticklistentry.d && k > 0) {
                    Block.byId[k].a(this, nextticklistentry.a, nextticklistentry.b, nextticklistentry.c, this.k);
                }
            }
        }
        return this.w.size() != 0;
    }
    
    public List b(final Entity entity, final AxisAlignedBB axisalignedbb) {
        this.H.clear();
        final int i = MathHelper.b((axisalignedbb.a - 2.0) / 16.0);
        final int j = MathHelper.b((axisalignedbb.d + 2.0) / 16.0);
        final int k = MathHelper.b((axisalignedbb.c - 2.0) / 16.0);
        final int l = MathHelper.b((axisalignedbb.f + 2.0) / 16.0);
        for (int i2 = i; i2 <= j; ++i2) {
            for (int j2 = k; j2 <= l; ++j2) {
                if (this.f(i2, j2)) {
                    this.c(i2, j2).a(entity, axisalignedbb, this.H);
                }
            }
        }
        return this.H;
    }
    
    public List a(final Class oclass, final AxisAlignedBB axisalignedbb) {
        final int i = MathHelper.b((axisalignedbb.a - 2.0) / 16.0);
        final int j = MathHelper.b((axisalignedbb.d + 2.0) / 16.0);
        final int k = MathHelper.b((axisalignedbb.c - 2.0) / 16.0);
        final int l = MathHelper.b((axisalignedbb.f + 2.0) / 16.0);
        final ArrayList arraylist = new ArrayList();
        for (int i2 = i; i2 <= j; ++i2) {
            for (int j2 = k; j2 <= l; ++j2) {
                if (this.f(i2, j2)) {
                    this.c(i2, j2).a(oclass, axisalignedbb, arraylist);
                }
            }
        }
        return arraylist;
    }
    
    public void b(final int i, final int j, final int k, final TileEntity tileentity) {
        if (this.f(i, j, k)) {
            this.b(i, k).f();
        }
        for (int l = 0; l < this.n.size(); ++l) {
            this.n.get(l).a(i, j, k, tileentity);
        }
    }
    
    public int a(final Class oclass) {
        int i = 0;
        for (int j = 0; j < this.b.size(); ++j) {
            final Entity entity = this.b.get(j);
            if (oclass.isAssignableFrom(entity.getClass())) {
                ++i;
            }
        }
        return i;
    }
    
    public void a(final List list) {
        this.b.addAll(list);
        for (int i = 0; i < list.size(); ++i) {
            this.b(list.get(i));
        }
    }
    
    public void b(final List list) {
        this.v.addAll(list);
    }
    
    public boolean a(final int i, final int j, final int k, final int l, final boolean flag) {
        final int i2 = this.getTypeId(j, k, l);
        final Block block = Block.byId[i2];
        final Block block2 = Block.byId[i];
        AxisAlignedBB axisalignedbb = block2.d(this, j, k, l);
        if (flag) {
            axisalignedbb = null;
        }
        final boolean defaultReturn = (axisalignedbb == null || this.a(axisalignedbb)) && (block == Block.WATER || block == Block.STATIONARY_WATER || block == Block.LAVA || block == Block.STATIONARY_LAVA || block == Block.FIRE || block == Block.SNOW || (i > 0 && block == null && block2.a(this, j, k, l)));
        if (!defaultReturn) {
            return false;
        }
        final BlockCanBuildEvent event = new BlockCanBuildEvent(Event.Type.BLOCK_CANBUILD, ((WorldServer)this).getWorld().getBlockAt(j, k, l), i2, defaultReturn);
        ((WorldServer)this).getServer().getPluginManager().callEvent(event);
        return event.isBuildable();
    }
    
    public PathEntity a(final Entity entity, final Entity entity1, final float f) {
        final int i = MathHelper.b(entity.locX);
        final int j = MathHelper.b(entity.locY);
        final int k = MathHelper.b(entity.locZ);
        final int l = (int)(f + 16.0f);
        final int i2 = i - l;
        final int j2 = j - l;
        final int k2 = k - l;
        final int l2 = i + l;
        final int i3 = j + l;
        final int j3 = k + l;
        final ChunkCache chunkcache = new ChunkCache(this, i2, j2, k2, l2, i3, j3);
        return new Pathfinder(chunkcache).a(entity, entity1, f);
    }
    
    public PathEntity a(final Entity entity, final int i, final int j, final int k, final float f) {
        final int l = MathHelper.b(entity.locX);
        final int i2 = MathHelper.b(entity.locY);
        final int j2 = MathHelper.b(entity.locZ);
        final int k2 = (int)(f + 8.0f);
        final int l2 = l - k2;
        final int i3 = i2 - k2;
        final int j3 = j2 - k2;
        final int k3 = l + k2;
        final int l3 = i2 + k2;
        final int i4 = j2 + k2;
        final ChunkCache chunkcache = new ChunkCache(this, l2, i3, j3, k3, l3, i4);
        return new Pathfinder(chunkcache).a(entity, i, j, k, f);
    }
    
    public boolean i(final int i, final int j, final int k, final int l) {
        final int i2 = this.getTypeId(i, j, k);
        return i2 != 0 && Block.byId[i2].c(this, i, j, k, l);
    }
    
    public boolean o(final int i, final int j, final int k) {
        return this.i(i, j - 1, k, 0) || this.i(i, j + 1, k, 1) || this.i(i, j, k - 1, 2) || this.i(i, j, k + 1, 3) || this.i(i - 1, j, k, 4) || this.i(i + 1, j, k, 5);
    }
    
    public boolean j(final int i, final int j, final int k, final int l) {
        if (this.d(i, j, k)) {
            return this.o(i, j, k);
        }
        final int i2 = this.getTypeId(i, j, k);
        return i2 != 0 && Block.byId[i2].b((IBlockAccess)this, i, j, k, l);
    }
    
    public boolean p(final int i, final int j, final int k) {
        return this.j(i, j - 1, k, 0) || this.j(i, j + 1, k, 1) || this.j(i, j, k - 1, 2) || this.j(i, j, k + 1, 3) || this.j(i - 1, j, k, 4) || this.j(i + 1, j, k, 5);
    }
    
    public EntityHuman a(final Entity entity, final double d0) {
        return this.a(entity.locX, entity.locY, entity.locZ, d0);
    }
    
    public EntityHuman a(final double d0, final double d1, final double d2, final double d3) {
        double d4 = -1.0;
        EntityHuman entityhuman = null;
        for (int i = 0; i < this.d.size(); ++i) {
            final EntityHuman entityhuman2 = this.d.get(i);
            final double d5 = entityhuman2.d(d0, d1, d2);
            if ((d3 < 0.0 || d5 < d3 * d3) && (d4 == -1.0 || d5 < d4)) {
                d4 = d5;
                entityhuman = entityhuman2;
            }
        }
        return entityhuman;
    }
    
    public byte[] c(final int i, final int j, final int k, final int l, final int i1, final int j1) {
        final byte[] abyte = new byte[l * i1 * j1 * 5 / 2];
        final int k2 = i >> 4;
        final int l2 = k >> 4;
        final int i2 = i + l - 1 >> 4;
        final int j2 = k + j1 - 1 >> 4;
        int k3 = 0;
        int l3 = j;
        int i3 = j + i1;
        if (j < 0) {
            l3 = 0;
        }
        if (i3 > 128) {
            i3 = 128;
        }
        for (int j3 = k2; j3 <= i2; ++j3) {
            int k4 = i - j3 * 16;
            int l4 = i + l - j3 * 16;
            if (k4 < 0) {
                k4 = 0;
            }
            if (l4 > 16) {
                l4 = 16;
            }
            for (int i4 = l2; i4 <= j2; ++i4) {
                int j4 = k - i4 * 16;
                int k5 = k + j1 - i4 * 16;
                if (j4 < 0) {
                    j4 = 0;
                }
                if (k5 > 16) {
                    k5 = 16;
                }
                k3 = this.c(j3, i4).a(abyte, k4, l3, j4, l4, i3, k5, k3);
            }
        }
        return abyte;
    }
    
    public void i() {
        this.p.b();
    }
    
    public void a(final long i) {
        this.q.a(i);
    }
    
    public long j() {
        return this.q.b();
    }
    
    public long k() {
        return this.q.f();
    }
    
    public ChunkCoordinates l() {
        return new ChunkCoordinates(this.q.c(), this.q.d(), this.q.e());
    }
    
    public boolean a(final EntityHuman entityhuman, final int i, final int j, final int k) {
        return true;
    }
    
    public void a(final Entity entity, final byte b0) {
    }
    
    public void d(final int i, final int j, final int k, final int l, final int i1) {
        final int j2 = this.getTypeId(i, j, k);
        if (j2 > 0) {
            Block.byId[j2].a(this, i, j, k, l, i1);
        }
    }
    
    public IDataManager m() {
        return this.p;
    }
    
    public WorldData n() {
        return this.q;
    }
    
    public void o() {
        this.A = !this.d.isEmpty();
        for (final EntityHuman entityhuman : this.d) {
            if (!entityhuman.E()) {
                this.A = false;
                break;
            }
        }
    }
    
    protected void p() {
        this.A = false;
        for (final EntityHuman entityhuman : this.d) {
            if (entityhuman.E()) {
                entityhuman.a(false, false);
            }
        }
    }
    
    public boolean q() {
        if (this.A && !this.isStatic) {
            for (final EntityHuman entityhuman : this.d) {
                if (!entityhuman.F()) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    static {
        World.s = 0;
    }
}
