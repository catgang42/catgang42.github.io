// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BiomeBase
{
    public static final BiomeBase RAINFOREST;
    public static final BiomeBase SWAMPLAND;
    public static final BiomeBase SEASONAL_FOREST;
    public static final BiomeBase FOREST;
    public static final BiomeBase SAVANNA;
    public static final BiomeBase SHRUBLAND;
    public static final BiomeBase TAIGA;
    public static final BiomeBase DESERT;
    public static final BiomeBase PLAINS;
    public static final BiomeBase ICE_DESERT;
    public static final BiomeBase TUNDRA;
    public static final BiomeBase HELL;
    public String m;
    public int n;
    public byte o;
    public byte p;
    public int q;
    protected Class[] r;
    protected Class[] s;
    protected Class[] t;
    private static BiomeBase[] u;
    
    public BiomeBase() {
        this.o = (byte)Block.GRASS.id;
        this.p = (byte)Block.DIRT.id;
        this.q = 5169201;
        this.r = new Class[] { EntitySpider.class, EntityZombie.class, EntitySkeleton.class, EntityCreeper.class, EntitySlime.class };
        this.s = new Class[] { EntitySheep.class, EntityPig.class, EntityChicken.class, EntityCow.class };
        this.t = new Class[] { EntitySquid.class };
    }
    
    public static void a() {
        for (int i = 0; i < 64; ++i) {
            for (int j = 0; j < 64; ++j) {
                BiomeBase.u[i + j * 64] = a(i / 63.0f, j / 63.0f);
            }
        }
        final BiomeBase desert = BiomeBase.DESERT;
        final BiomeBase desert2 = BiomeBase.DESERT;
        final byte b = (byte)Block.SAND.id;
        desert2.p = b;
        desert.o = b;
        final BiomeBase ice_DESERT = BiomeBase.ICE_DESERT;
        final BiomeBase ice_DESERT2 = BiomeBase.ICE_DESERT;
        final byte b2 = (byte)Block.SAND.id;
        ice_DESERT2.p = b2;
        ice_DESERT.o = b2;
    }
    
    public WorldGenerator a(final Random random) {
        if (random.nextInt(10) == 0) {
            return new WorldGenBigTree();
        }
        return new WorldGenTrees();
    }
    
    protected BiomeBase b() {
        return this;
    }
    
    protected BiomeBase a(final String m) {
        this.m = m;
        return this;
    }
    
    protected BiomeBase a(final int q) {
        this.q = q;
        return this;
    }
    
    protected BiomeBase b(final int n) {
        this.n = n;
        return this;
    }
    
    public static BiomeBase a(final double n, final double n2) {
        return BiomeBase.u[(int)(n * 63.0) + (int)(n2 * 63.0) * 64];
    }
    
    public static BiomeBase a(final float n, float n2) {
        n2 *= n;
        if (n < 0.1f) {
            return BiomeBase.TUNDRA;
        }
        if (n2 < 0.2f) {
            if (n < 0.5f) {
                return BiomeBase.TUNDRA;
            }
            if (n < 0.95f) {
                return BiomeBase.SAVANNA;
            }
            return BiomeBase.DESERT;
        }
        else {
            if (n2 > 0.5f && n < 0.7f) {
                return BiomeBase.SWAMPLAND;
            }
            if (n < 0.5f) {
                return BiomeBase.TAIGA;
            }
            if (n < 0.97f) {
                if (n2 < 0.35f) {
                    return BiomeBase.SHRUBLAND;
                }
                return BiomeBase.FOREST;
            }
            else {
                if (n2 < 0.45f) {
                    return BiomeBase.PLAINS;
                }
                if (n2 < 0.9f) {
                    return BiomeBase.SEASONAL_FOREST;
                }
                return BiomeBase.RAINFOREST;
            }
        }
    }
    
    public Class[] a(final EnumCreatureType enumCreatureType) {
        if (enumCreatureType == EnumCreatureType.MONSTER) {
            return this.r;
        }
        if (enumCreatureType == EnumCreatureType.CREATURE) {
            return this.s;
        }
        if (enumCreatureType == EnumCreatureType.WATER_CREATURE) {
            return this.t;
        }
        return null;
    }
    
    static {
        RAINFOREST = new BiomeRainforest().b(588342).a("Rainforest").a(2094168);
        SWAMPLAND = new BiomeSwamp().b(522674).a("Swampland").a(9154376);
        SEASONAL_FOREST = new BiomeBase().b(10215459).a("Seasonal Forest");
        FOREST = new BiomeForest().b(353825).a("Forest").a(5159473);
        SAVANNA = new BiomeDesert().b(14278691).a("Savanna");
        SHRUBLAND = new BiomeBase().b(10595616).a("Shrubland");
        TAIGA = new BiomeTaiga().b(3060051).a("Taiga").b().a(8107825);
        DESERT = new BiomeDesert().b(16421912).a("Desert");
        PLAINS = new BiomeDesert().b(16767248).a("Plains");
        ICE_DESERT = new BiomeDesert().b(16772499).a("Ice Desert").b().a(12899129);
        TUNDRA = new BiomeBase().b(5762041).a("Tundra").b().a(12899129);
        HELL = new BiomeHell().b(16711680).a("Hell");
        BiomeBase.u = new BiomeBase[4096];
        a();
    }
}
