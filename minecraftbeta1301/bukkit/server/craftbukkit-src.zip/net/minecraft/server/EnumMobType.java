// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public enum EnumMobType
{
    EVERYTHING("everything", 0), 
    MOBS("mobs", 1), 
    PLAYERS("players", 2);
    
    private EnumMobType(final String name, final int ordinal) {
    }
}
