// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public class NBTTagLong extends NBTBase
{
    public long a;
    
    public NBTTagLong() {
    }
    
    public NBTTagLong(final long a) {
        this.a = a;
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        dataOutput.writeLong(this.a);
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.a = dataInput.readLong();
    }
    
    @Override
    public byte a() {
        return 4;
    }
    
    @Override
    public String toString() {
        return "" + this.a;
    }
}
