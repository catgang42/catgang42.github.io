// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockBreakable extends Block
{
    private boolean a;
    
    protected BlockBreakable(final int n, final int n2, final Material material, final boolean a) {
        super(n, n2, material);
        this.a = a;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        final int typeId = blockAccess.getTypeId(n, n2, n3);
        return (this.a || typeId != this.id) && super.a(blockAccess, n, n2, n3, n4);
    }
}
