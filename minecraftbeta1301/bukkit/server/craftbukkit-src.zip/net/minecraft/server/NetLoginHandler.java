// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.net.Socket;
import java.util.Random;
import java.util.logging.Logger;

public class NetLoginHandler extends NetHandler
{
    public static Logger a;
    private static Random d;
    public NetworkManager b;
    public boolean c;
    private MinecraftServer e;
    private int f;
    private String g;
    private Packet1Login h;
    private String i;
    
    public NetLoginHandler(final MinecraftServer minecraftserver, final Socket socket, final String s) {
        this.c = false;
        this.f = 0;
        this.g = null;
        this.h = null;
        this.i = "";
        this.e = minecraftserver;
        this.b = new NetworkManager(socket, s, this);
        this.b.d = 0;
    }
    
    public void a() {
        if (this.h != null) {
            this.b(this.h);
            this.h = null;
        }
        if (this.f++ == 600) {
            this.a("Took too long to log in");
        }
        else {
            this.b.a();
        }
    }
    
    public void a(final String s) {
        try {
            NetLoginHandler.a.info("Disconnecting " + this.b() + ": " + s);
            this.b.a(new Packet255KickDisconnect(s));
            this.b.c();
            this.c = true;
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    
    @Override
    public void a(final Packet2Handshake packet2handshake) {
        if (this.e.l) {
            this.i = Long.toHexString(NetLoginHandler.d.nextLong());
            this.b.a(new Packet2Handshake(this.i));
        }
        else {
            this.b.a(new Packet2Handshake("-"));
        }
    }
    
    @Override
    public void a(final Packet1Login packet1login) {
        this.g = packet1login.b;
        if (packet1login.a != 9) {
            if (packet1login.a > 9) {
                this.a("Outdated server!");
            }
            else {
                this.a("Outdated client!");
            }
        }
        else if (!this.e.l) {
            this.b(packet1login);
        }
        else {
            new ThreadLoginVerifier(this, packet1login).start();
        }
    }
    
    public void b(final Packet1Login packet1login) {
        final EntityPlayer entityplayer = this.e.f.a(this, packet1login.b, packet1login.c);
        if (entityplayer != null) {
            NetLoginHandler.a.info(this.b() + " logged in with entity id " + entityplayer.id);
            final NetServerHandler netserverhandler = new NetServerHandler(this.e, this.b, entityplayer);
            final ChunkCoordinates chunkcoordinates = entityplayer.world.l();
            netserverhandler.b(new Packet1Login("", "", entityplayer.id, entityplayer.world.j(), (byte)entityplayer.world.m.g));
            netserverhandler.b(new Packet6SpawnPosition(chunkcoordinates.a, chunkcoordinates.b, chunkcoordinates.c));
            this.e.f.a(new Packet3Chat("§e" + entityplayer.name + " joined the game."));
            this.e.f.a(entityplayer);
            netserverhandler.a(entityplayer.locX, entityplayer.locY, entityplayer.locZ, entityplayer.yaw, entityplayer.pitch);
            this.e.c.a(netserverhandler);
            netserverhandler.b(new Packet4UpdateTime(entityplayer.world.k()));
            entityplayer.l();
        }
        this.c = true;
    }
    
    @Override
    public void a(final String s, final Object[] aobject) {
        NetLoginHandler.a.info(this.b() + " lost connection");
        this.c = true;
    }
    
    @Override
    public void a(final Packet packet) {
        this.a("Protocol error");
    }
    
    public String b() {
        return (this.g != null) ? (this.g + " [" + this.b.b().toString() + "]") : this.b.b().toString();
    }
    
    static String a(final NetLoginHandler netloginhandler) {
        return netloginhandler.i;
    }
    
    static Packet1Login a(final NetLoginHandler netloginhandler, final Packet1Login packet1login) {
        return netloginhandler.h = packet1login;
    }
    
    static {
        NetLoginHandler.a = Logger.getLogger("Minecraft");
        NetLoginHandler.d = new Random();
    }
}
