// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemSnowball extends Item
{
    public ItemSnowball(final int n) {
        super(n);
        this.maxStackSize = 16;
    }
    
    @Override
    public ItemStack a(final ItemStack itemStack, final World world, final EntityHuman entityHuman) {
        --itemStack.count;
        world.a(entityHuman, "random.bow", 0.5f, 0.4f / (ItemSnowball.b.nextFloat() * 0.4f + 0.8f));
        if (!world.isStatic) {
            world.a(new EntitySnowball(world, entityHuman));
        }
        return itemStack;
    }
}
