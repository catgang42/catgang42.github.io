// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockStep extends Block
{
    public static final String[] a;
    private boolean b;
    
    public BlockStep(final int n, final boolean b) {
        super(n, 6, Material.STONE);
        if (!(this.b = b)) {
            this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
        }
        this.e(255);
    }
    
    @Override
    public int a(final int n, final int n2) {
        if (n2 == 0) {
            if (n <= 1) {
                return 6;
            }
            return 5;
        }
        else if (n2 == 1) {
            if (n == 0) {
                return 208;
            }
            if (n == 1) {
                return 176;
            }
            return 192;
        }
        else {
            if (n2 == 2) {
                return 4;
            }
            if (n2 == 3) {
                return 16;
            }
            return 6;
        }
    }
    
    @Override
    public int a(final int n) {
        return this.a(n, 0);
    }
    
    @Override
    public boolean a() {
        return this.b;
    }
    
    @Override
    public void e(final World world, final int i, final int n, final int k) {
        if (this != Block.STEP) {
            super.e(world, i, n, k);
        }
        final int typeId = world.getTypeId(i, n - 1, k);
        final int data = world.getData(i, n, k);
        if (data != world.getData(i, n - 1, k)) {
            return;
        }
        if (typeId == BlockStep.STEP.id) {
            world.e(i, n, k, 0);
            world.b(i, n - 1, k, Block.DOUBLE_STEP.id, data);
        }
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Block.STEP.id;
    }
    
    @Override
    public int a(final Random random) {
        if (this.b) {
            return 2;
        }
        return 1;
    }
    
    @Override
    protected int b(final int n) {
        return n;
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        if (this != Block.STEP) {
            super.a(blockAccess, n, n2, n3, n4);
        }
        return n4 == 1 || (super.a(blockAccess, n, n2, n3, n4) && (n4 == 0 || blockAccess.getTypeId(n, n2, n3) != this.id));
    }
    
    static {
        a = new String[] { "stone", "sand", "wood", "cobble" };
    }
}
