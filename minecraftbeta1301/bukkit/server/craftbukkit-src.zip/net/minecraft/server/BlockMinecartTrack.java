// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockMinecartTrack extends Block
{
    protected BlockMinecartTrack(final int n, final int n2) {
        super(n, n2, Material.ORIENTABLE);
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.125f, 1.0f);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public MovingObjectPosition a(final World world, final int n, final int n2, final int n3, final Vec3D vec3D, final Vec3D vec3D2) {
        this.a((IBlockAccess)world, n, n2, n3);
        return super.a(world, n, n2, n3, vec3D, vec3D2);
    }
    
    @Override
    public void a(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
        final int data = blockAccess.getData(n, n2, n3);
        if (data >= 2 && data <= 5) {
            this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.625f, 1.0f);
        }
        else {
            this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.125f, 1.0f);
        }
    }
    
    @Override
    public int a(final int n, final int n2) {
        if (n2 >= 6) {
            return this.textureId - 16;
        }
        return this.textureId;
    }
    
    @Override
    public int a(final Random random) {
        return 1;
    }
    
    @Override
    public boolean a(final World world, final int i, final int n, final int k) {
        return world.d(i, n - 1, k);
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
        if (!world.isStatic) {
            world.c(i, j, k, 15);
            this.g(world, i, j, k);
        }
    }
    
    @Override
    public void a(final World world, final int n, final int j, final int n2, final int n3) {
        if (world.isStatic) {
            return;
        }
        final int data = world.getData(n, j, n2);
        boolean b = false;
        if (!world.d(n, j - 1, n2)) {
            b = true;
        }
        if (data == 2 && !world.d(n + 1, j, n2)) {
            b = true;
        }
        if (data == 3 && !world.d(n - 1, j, n2)) {
            b = true;
        }
        if (data == 4 && !world.d(n, j, n2 - 1)) {
            b = true;
        }
        if (data == 5 && !world.d(n, j, n2 + 1)) {
            b = true;
        }
        if (b) {
            this.b_(world, n, j, n2, world.getData(n, j, n2));
            world.e(n, j, n2, 0);
        }
        else if (n3 > 0 && Block.byId[n3].c() && new MinecartTrackLogic(this, world, n, j, n2).c() == 3) {
            this.g(world, n, j, n2);
        }
    }
    
    private void g(final World world, final int i, final int j, final int k) {
        if (world.isStatic) {
            return;
        }
        new MinecartTrackLogic(this, world, i, j, k).a(world.p(i, j, k));
    }
}
