// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet52MultiBlockChange extends Packet
{
    public int a;
    public int b;
    public short[] c;
    public byte[] d;
    public byte[] e;
    public int f;
    
    public Packet52MultiBlockChange() {
        this.k = true;
    }
    
    public Packet52MultiBlockChange(final int n, final int n2, final short[] array, final int f, final World world) {
        this.k = true;
        this.a = n;
        this.b = n2;
        this.f = f;
        this.c = new short[f];
        this.d = new byte[f];
        this.e = new byte[f];
        final Chunk c = world.c(n, n2);
        for (int i = 0; i < f; ++i) {
            final int n3 = array[i] >> 12 & 0xF;
            final int n4 = array[i] >> 8 & 0xF;
            final int n5 = array[i] & 0xFF;
            this.c[i] = array[i];
            this.d[i] = (byte)c.a(n3, n5, n4);
            this.e[i] = (byte)c.b(n3, n5, n4);
        }
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readInt();
        this.f = (dataInputStream.readShort() & 0xFFFF);
        this.c = new short[this.f];
        this.d = new byte[this.f];
        this.e = new byte[this.f];
        for (int i = 0; i < this.f; ++i) {
            this.c[i] = dataInputStream.readShort();
        }
        dataInputStream.readFully(this.d);
        dataInputStream.readFully(this.e);
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeInt(this.b);
        dataOutputStream.writeShort((short)this.f);
        for (int i = 0; i < this.f; ++i) {
            dataOutputStream.writeShort(this.c[i]);
        }
        dataOutputStream.write(this.d);
        dataOutputStream.write(this.e);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 10 + this.f * 4;
    }
}
