// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

final class ServerWindowAdapter extends WindowAdapter
{
    final /* synthetic */ MinecraftServer a;
    
    ServerWindowAdapter(final MinecraftServer a) {
        this.a = a;
    }
    
    @Override
    public void windowClosing(final WindowEvent windowEvent) {
        this.a.a();
        while (!this.a.g) {
            try {
                Thread.sleep(100L);
            }
            catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
        System.exit(0);
    }
}
