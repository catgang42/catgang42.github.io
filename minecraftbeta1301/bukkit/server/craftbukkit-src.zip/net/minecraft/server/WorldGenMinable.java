// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class WorldGenMinable extends WorldGenerator
{
    private int a;
    private int b;
    
    public WorldGenMinable(final int a, final int b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public boolean a(final World world, final Random random, final int n, final int n2, final int n3) {
        final float n4 = random.nextFloat() * 3.1415927f;
        final double n5 = n + 8 + MathHelper.a(n4) * this.b / 8.0f;
        final double n6 = n + 8 - MathHelper.a(n4) * this.b / 8.0f;
        final double n7 = n3 + 8 + MathHelper.b(n4) * this.b / 8.0f;
        final double n8 = n3 + 8 - MathHelper.b(n4) * this.b / 8.0f;
        final double n9 = n2 + random.nextInt(3) + 2;
        final double n10 = n2 + random.nextInt(3) + 2;
        for (int i = 0; i <= this.b; ++i) {
            final double n11 = n5 + (n6 - n5) * i / this.b;
            final double n12 = n9 + (n10 - n9) * i / this.b;
            final double n13 = n7 + (n8 - n7) * i / this.b;
            final double n14 = random.nextDouble() * this.b / 16.0;
            final double n15 = (MathHelper.a(i * 3.1415927f / this.b) + 1.0f) * n14 + 1.0;
            final double n16 = (MathHelper.a(i * 3.1415927f / this.b) + 1.0f) * n14 + 1.0;
            final int n17 = (int)(n11 - n15 / 2.0);
            final int n18 = (int)(n12 - n16 / 2.0);
            final int n19 = (int)(n13 - n15 / 2.0);
            final int n20 = (int)(n11 + n15 / 2.0);
            final int n21 = (int)(n12 + n16 / 2.0);
            final int n22 = (int)(n13 + n15 / 2.0);
            for (int j = n17; j <= n20; ++j) {
                final double n23 = (j + 0.5 - n11) / (n15 / 2.0);
                if (n23 * n23 < 1.0) {
                    for (int k = n18; k <= n21; ++k) {
                        final double n24 = (k + 0.5 - n12) / (n16 / 2.0);
                        if (n23 * n23 + n24 * n24 < 1.0) {
                            for (int l = n19; l <= n22; ++l) {
                                final double n25 = (l + 0.5 - n13) / (n15 / 2.0);
                                if (n23 * n23 + n24 * n24 + n25 * n25 < 1.0 && world.getTypeId(j, k, l) == Block.STONE.id) {
                                    world.setTypeId(j, k, l, this.a);
                                }
                            }
                        }
                    }
                }
            }
        }
        return true;
    }
}
