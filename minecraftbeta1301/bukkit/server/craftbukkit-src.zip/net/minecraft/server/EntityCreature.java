// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.TrigMath;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityTargetEvent;

public class EntityCreature extends EntityLiving
{
    public PathEntity a;
    public Entity d;
    protected boolean e;
    
    public EntityCreature(final World world) {
        super(world);
        this.e = false;
    }
    
    @Override
    protected void c_() {
        this.e = false;
        final float f = 16.0f;
        if (this.d == null) {
            final Entity target = this.l();
            if (target != null) {
                final EntityTargetEvent event = new EntityTargetEvent(this.getBukkitEntity(), target.getBukkitEntity(), EntityTargetEvent.TargetReason.CLOSEST_PLAYER);
                final CraftServer server = ((WorldServer)this.world).getServer();
                server.getPluginManager().callEvent(event);
                if (!event.isCancelled()) {
                    if (event.getTarget() == null) {
                        this.d = null;
                    }
                    else {
                        this.d = ((CraftEntity)event.getTarget()).getHandle();
                    }
                }
            }
            if (this.d != null) {
                this.a = this.world.a(this, this.d, f);
            }
        }
        else if (!this.d.J()) {
            final EntityTargetEvent event2 = new EntityTargetEvent(this.getBukkitEntity(), null, EntityTargetEvent.TargetReason.TARGET_DIED);
            final CraftServer server2 = ((WorldServer)this.world).getServer();
            server2.getPluginManager().callEvent(event2);
            if (!event2.isCancelled()) {
                if (event2.getTarget() == null) {
                    this.d = null;
                }
                else {
                    this.d = ((CraftEntity)event2.getTarget()).getHandle();
                }
            }
        }
        else {
            final float f2 = this.d.f(this);
            if (this.e(this.d)) {
                this.a(this.d, f2);
            }
        }
        if (!this.e && this.d != null && (this.a == null || this.random.nextInt(20) == 0)) {
            this.a = this.world.a(this, this.d, f);
        }
        else if ((this.a == null && this.random.nextInt(80) == 0) || this.random.nextInt(80) == 0) {
            boolean flag = false;
            int i = -1;
            int j = -1;
            int k = -1;
            float f3 = -99999.0f;
            for (int l = 0; l < 10; ++l) {
                final int i2 = MathHelper.b(this.locX + this.random.nextInt(13) - 6.0);
                final int j2 = MathHelper.b(this.locY + this.random.nextInt(7) - 3.0);
                final int k2 = MathHelper.b(this.locZ + this.random.nextInt(13) - 6.0);
                final float f4 = this.a(i2, j2, k2);
                if (f4 > f3) {
                    f3 = f4;
                    i = i2;
                    j = j2;
                    k = k2;
                    flag = true;
                }
            }
            if (flag) {
                this.a = this.world.a(this, i, j, k, 10.0f);
            }
        }
        final int l2 = MathHelper.b(this.boundingBox.b);
        final boolean flag2 = this.g_();
        final boolean flag3 = this.Q();
        this.pitch = 0.0f;
        if (this.a != null && this.random.nextInt(100) != 0) {
            Vec3D vec3d = this.a.a(this);
            final double d0 = this.length * 2.0f;
            while (vec3d != null && vec3d.d(this.locX, vec3d.b, this.locZ) < d0 * d0) {
                this.a.a();
                if (this.a.b()) {
                    vec3d = null;
                    this.a = null;
                }
                else {
                    vec3d = this.a.a(this);
                }
            }
            this.ax = false;
            if (vec3d != null) {
                final double d2 = vec3d.a - this.locX;
                final double d3 = vec3d.c - this.locZ;
                final double d4 = vec3d.b - l2;
                final float f5 = (float)(TrigMath.atan2(d3, d2) * 180.0 / 3.1415927410125732) - 90.0f;
                float f6 = f5 - this.yaw;
                this.av = this.az;
                while (f6 < -180.0f) {
                    f6 += 360.0f;
                }
                while (f6 >= 180.0f) {
                    f6 -= 360.0f;
                }
                if (f6 > 30.0f) {
                    f6 = 30.0f;
                }
                if (f6 < -30.0f) {
                    f6 = -30.0f;
                }
                this.yaw += f6;
                if (this.e && this.d != null) {
                    final double d5 = this.d.locX - this.locX;
                    final double d6 = this.d.locZ - this.locZ;
                    final float f7 = this.yaw;
                    this.yaw = (float)(Math.atan2(d6, d5) * 180.0 / 3.1415927410125732) - 90.0f;
                    f6 = (f7 - this.yaw + 90.0f) * 3.1415927f / 180.0f;
                    this.au = -MathHelper.a(f6) * this.av * 1.0f;
                    this.av = MathHelper.b(f6) * this.av * 1.0f;
                }
                if (d4 > 0.0) {
                    this.ax = true;
                }
            }
            if (this.d != null) {
                this.b(this.d, 30.0f);
            }
            if (this.aV) {
                this.ax = true;
            }
            if (this.random.nextFloat() < 0.8f && (flag2 || flag3)) {
                this.ax = true;
            }
        }
        else {
            super.c_();
            this.a = null;
        }
    }
    
    protected void a(final Entity entity, final float f) {
    }
    
    protected float a(final int i, final int j, final int k) {
        return 0.0f;
    }
    
    protected Entity l() {
        return null;
    }
    
    @Override
    public boolean b() {
        final int i = MathHelper.b(this.locX);
        final int j = MathHelper.b(this.boundingBox.b);
        final int k = MathHelper.b(this.locZ);
        return super.b() && this.a(i, j, k) >= 0.0f;
    }
}
