// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public abstract class NBTBase
{
    private String a;
    
    public NBTBase() {
        this.a = null;
    }
    
    abstract void a(final DataOutput p0);
    
    abstract void a(final DataInput p0);
    
    public abstract byte a();
    
    public String b() {
        if (this.a == null) {
            return "";
        }
        return this.a;
    }
    
    public NBTBase a(final String a) {
        this.a = a;
        return this;
    }
    
    public static NBTBase b(final DataInput dataInput) {
        final byte byte1 = dataInput.readByte();
        if (byte1 == 0) {
            return new NBTTagEnd();
        }
        final NBTBase a = a(byte1);
        a.a = dataInput.readUTF();
        a.a(dataInput);
        return a;
    }
    
    public static void a(final NBTBase nbtBase, final DataOutput dataOutput) {
        dataOutput.writeByte(nbtBase.a());
        if (nbtBase.a() == 0) {
            return;
        }
        dataOutput.writeUTF(nbtBase.b());
        nbtBase.a(dataOutput);
    }
    
    public static NBTBase a(final byte b) {
        switch (b) {
            case 0: {
                return new NBTTagEnd();
            }
            case 1: {
                return new NBTTagByte();
            }
            case 2: {
                return new NBTTagShort();
            }
            case 3: {
                return new NBTTagInt();
            }
            case 4: {
                return new NBTTagLong();
            }
            case 5: {
                return new NBTTagFloat();
            }
            case 6: {
                return new NBTTagDouble();
            }
            case 7: {
                return new NBTTagByteArray();
            }
            case 8: {
                return new NBTTagString();
            }
            case 9: {
                return new NBTTagList();
            }
            case 10: {
                return new NBTTagCompound();
            }
            default: {
                return null;
            }
        }
    }
    
    public static String b(final byte b) {
        switch (b) {
            case 0: {
                return "TAG_End";
            }
            case 1: {
                return "TAG_Byte";
            }
            case 2: {
                return "TAG_Short";
            }
            case 3: {
                return "TAG_Int";
            }
            case 4: {
                return "TAG_Long";
            }
            case 5: {
                return "TAG_Float";
            }
            case 6: {
                return "TAG_Double";
            }
            case 7: {
                return "TAG_Byte_Array";
            }
            case 8: {
                return "TAG_String";
            }
            case 9: {
                return "TAG_List";
            }
            case 10: {
                return "TAG_Compound";
            }
            default: {
                return "UNKNOWN";
            }
        }
    }
}
