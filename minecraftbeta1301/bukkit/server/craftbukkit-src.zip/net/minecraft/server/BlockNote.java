// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockNote extends BlockContainer
{
    public BlockNote(final int n) {
        super(n, 74, Material.WOOD);
    }
    
    @Override
    public int a(final int n) {
        return this.textureId;
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        if (n4 > 0 && Block.byId[n4].c()) {
            final boolean o = world.o(n, n2, n3);
            final TileEntityNote tileEntityNote = (TileEntityNote)world.getTileEntity(n, n2, n3);
            if (tileEntityNote.b != o) {
                if (o) {
                    tileEntityNote.a(world, n, n2, n3);
                }
                tileEntityNote.b = o;
            }
        }
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k, final EntityHuman entityHuman) {
        if (world.isStatic) {
            return true;
        }
        final TileEntityNote tileEntityNote = (TileEntityNote)world.getTileEntity(i, j, k);
        tileEntityNote.a();
        tileEntityNote.a(world, i, j, k);
        return true;
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k, final EntityHuman entityHuman) {
        if (world.isStatic) {
            return;
        }
        ((TileEntityNote)world.getTileEntity(i, j, k)).a(world, i, j, k);
    }
    
    @Override
    protected TileEntity a_() {
        return new TileEntityNote();
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4, final int n5) {
        final float f1 = (float)Math.pow(2.0, (n5 - 12) / 12.0);
        String str = "harp";
        if (n4 == 1) {
            str = "bd";
        }
        if (n4 == 2) {
            str = "snare";
        }
        if (n4 == 3) {
            str = "hat";
        }
        if (n4 == 4) {
            str = "bassattack";
        }
        world.a(n + 0.5, n2 + 0.5, n3 + 0.5, "note." + str, 3.0f, f1);
        world.a("note", n + 0.5, n2 + 1.2, n3 + 0.5, n5 / 24.0, 0.0, 0.0);
    }
}
