// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

class NetworkReaderThread extends Thread
{
    final /* synthetic */ NetworkManager a;
    
    NetworkReaderThread(final NetworkManager a, final String name) {
        this.a = a;
        super(name);
    }
    
    @Override
    public void run() {
        synchronized (NetworkManager.a) {
            ++NetworkManager.b;
        }
        try {
            while (this.a.j && !this.a.o) {
                this.a.f();
                try {
                    Thread.sleep(0L);
                }
                catch (InterruptedException ex) {}
            }
        }
        finally {
            synchronized (NetworkManager.a) {
                --NetworkManager.b;
            }
        }
    }
}
