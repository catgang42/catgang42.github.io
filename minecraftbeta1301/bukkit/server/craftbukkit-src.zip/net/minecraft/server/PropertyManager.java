// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.OutputStream;
import java.io.FileOutputStream;
import java.util.logging.Level;
import java.io.InputStream;
import java.io.FileInputStream;
import joptsimple.OptionSet;
import java.io.File;
import java.util.Properties;
import java.util.logging.Logger;

public class PropertyManager
{
    public static Logger a;
    private Properties b;
    private File c;
    private OptionSet options;
    
    public PropertyManager(final File file1) {
        this.b = new Properties();
        this.options = null;
        this.c = file1;
        if (file1.exists()) {
            try {
                this.b.load(new FileInputStream(file1));
            }
            catch (Exception exception) {
                PropertyManager.a.log(Level.WARNING, "Failed to load " + file1, exception);
                this.a();
            }
        }
        else {
            PropertyManager.a.log(Level.WARNING, file1 + " does not exist");
            this.a();
        }
    }
    
    public PropertyManager(final OptionSet options) {
        this((File)options.valueOf("config"));
        this.options = options;
    }
    
    private <T> T getOverride(final String name, final T value) {
        if (this.options != null && this.options.has(name)) {
            return (T)this.options.valueOf(name);
        }
        return value;
    }
    
    public void a() {
        PropertyManager.a.log(Level.INFO, "Generating new properties file");
        this.b();
    }
    
    public void b() {
        try {
            this.b.store(new FileOutputStream(this.c), "Minecraft server properties");
        }
        catch (Exception exception) {
            PropertyManager.a.log(Level.WARNING, "Failed to save " + this.c, exception);
            this.a();
        }
    }
    
    public String a(final String s, final String s1) {
        if (!this.b.containsKey(s)) {
            this.b.setProperty(s, this.getOverride(s, s1));
            this.b();
        }
        return this.getOverride(s, this.b.getProperty(s, s1));
    }
    
    public int a(final String s, int i) {
        try {
            return this.getOverride(s, Integer.parseInt(this.a(s, "" + i)));
        }
        catch (Exception exception) {
            i = this.getOverride(s, i);
            this.b.setProperty(s, "" + i);
            return i;
        }
    }
    
    public boolean a(final String s, boolean flag) {
        try {
            return this.getOverride(s, Boolean.parseBoolean(this.a(s, "" + flag)));
        }
        catch (Exception exception) {
            flag = this.getOverride(s, flag);
            this.b.setProperty(s, "" + flag);
            return flag;
        }
    }
    
    public void b(final String s, boolean flag) {
        flag = this.getOverride(s, flag);
        this.b.setProperty(s, "" + flag);
        this.b();
    }
    
    static {
        PropertyManager.a = Logger.getLogger("Minecraft");
    }
}
