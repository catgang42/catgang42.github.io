// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class FontAllowedCharacters
{
    public static final String a;
    public static final char[] b;
    
    private static String a() {
        String string = "";
        try {
            final BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(FontAllowedCharacters.class.getResourceAsStream("/font.txt"), "UTF-8"));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                if (!line.startsWith("#")) {
                    string += line;
                }
            }
            bufferedReader.close();
        }
        catch (Exception ex) {}
        return string;
    }
    
    static {
        a = a();
        b = new char[] { '/', '\n', '\r', '\t', '\0', '\f', '`', '?', '*', '\\', '<', '>', '|', '\"', ':' };
    }
}
