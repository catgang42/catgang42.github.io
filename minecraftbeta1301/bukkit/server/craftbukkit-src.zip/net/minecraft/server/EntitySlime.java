// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntitySlime extends EntityLiving implements IMonster
{
    public float a;
    public float b;
    private int d;
    public int c;
    
    public EntitySlime(final World world) {
        super(world);
        this.d = 0;
        this.c = 1;
        this.texture = "/mob/slime.png";
        this.c = 1 << this.random.nextInt(3);
        this.height = 0.0f;
        this.d = this.random.nextInt(20) + 10;
        this.e(this.c);
    }
    
    public void e(final int c) {
        this.c = c;
        this.a(0.6f * c, 0.6f * c);
        this.health = c * c;
        this.a(this.locX, this.locY, this.locZ);
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
        nbttagcompound.a("Size", this.c - 1);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
        this.c = nbttagcompound.e("Size") + 1;
    }
    
    @Override
    public void f_() {
        this.b = this.a;
        final boolean onGround = this.onGround;
        super.f_();
        if (this.onGround && !onGround) {
            for (int i = 0; i < this.c * 8; ++i) {
                final float n = this.random.nextFloat() * 3.1415927f * 2.0f;
                final float n2 = this.random.nextFloat() * 0.5f + 0.5f;
                this.world.a("slime", this.locX + MathHelper.a(n) * this.c * 0.5f * n2, this.boundingBox.b, this.locZ + MathHelper.b(n) * this.c * 0.5f * n2, 0.0, 0.0, 0.0);
            }
            if (this.c > 2) {
                this.world.a(this, "mob.slime", this.i(), ((this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f) / 0.8f);
            }
            this.a = -0.5f;
        }
        this.a *= 0.6f;
    }
    
    @Override
    protected void c_() {
        final EntityHuman a = this.world.a(this, 16.0);
        if (a != null) {
            this.b(a, 10.0f);
        }
        if (this.onGround && this.d-- <= 0) {
            this.d = this.random.nextInt(20) + 10;
            if (a != null) {
                this.d /= 3;
            }
            this.ax = true;
            if (this.c > 1) {
                this.world.a(this, "mob.slime", this.i(), ((this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f) * 0.8f);
            }
            this.a = 1.0f;
            this.au = 1.0f - this.random.nextFloat() * 2.0f;
            this.av = (float)(1 * this.c);
        }
        else {
            this.ax = false;
            if (this.onGround) {
                final float n = 0.0f;
                this.av = n;
                this.au = n;
            }
        }
    }
    
    @Override
    public void C() {
        if (this.c > 1 && this.health == 0) {
            for (int i = 0; i < 4; ++i) {
                final float n = (i % 2 - 0.5f) * this.c / 4.0f;
                final float n2 = (i / 2 - 0.5f) * this.c / 4.0f;
                final EntitySlime entity = new EntitySlime(this.world);
                entity.e(this.c / 2);
                entity.c(this.locX + n, this.locY + 0.5, this.locZ + n2, this.random.nextFloat() * 360.0f, 0.0f);
                this.world.a(entity);
            }
        }
        super.C();
    }
    
    @Override
    public void b(final EntityHuman entityHuman) {
        if (this.c > 1 && this.e(entityHuman) && this.f(entityHuman) < 0.6 * this.c && entityHuman.a(this, this.c)) {
            this.world.a(this, "mob.slimeattack", 1.0f, (this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f);
        }
    }
    
    @Override
    protected String f() {
        return "mob.slime";
    }
    
    @Override
    protected String g() {
        return "mob.slime";
    }
    
    @Override
    protected int h() {
        if (this.c == 1) {
            return Item.SLIME_BALL.id;
        }
        return 0;
    }
    
    @Override
    public boolean b() {
        final Chunk b = this.world.b(MathHelper.b(this.locX), MathHelper.b(this.locZ));
        return (this.c == 1 || this.world.j > 0) && this.random.nextInt(10) == 0 && b.a(987234911L).nextInt(10) == 0 && this.locY < 16.0;
    }
    
    @Override
    protected float i() {
        return 0.6f;
    }
}
