// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public enum EnumToolMaterial
{
    WOOD("WOOD", 0, 0, 59, 2.0f, 0), 
    STONE("STONE", 1, 1, 131, 4.0f, 1), 
    IRON("IRON", 2, 2, 250, 6.0f, 2), 
    DIAMOND("EMERALD", 3, 3, 1561, 8.0f, 3), 
    GOLD("GOLD", 4, 0, 32, 12.0f, 0);
    
    private final int f;
    private final int g;
    private final float h;
    private final int i;
    
    private EnumToolMaterial(final String name, final int ordinal, final int f, final int g, final float h, final int i) {
        this.f = f;
        this.g = g;
        this.h = h;
        this.i = i;
    }
    
    public int a() {
        return this.g;
    }
    
    public float b() {
        return this.h;
    }
    
    public int c() {
        return this.i;
    }
    
    public int d() {
        return this.f;
    }
}
