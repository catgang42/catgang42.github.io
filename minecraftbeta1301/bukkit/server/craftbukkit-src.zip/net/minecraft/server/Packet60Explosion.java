// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Iterator;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Packet60Explosion extends Packet
{
    public double a;
    public double b;
    public double c;
    public float d;
    public Set e;
    
    public Packet60Explosion() {
    }
    
    public Packet60Explosion(final double a, final double b, final double c, final float d, final Set c2) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = new HashSet(c2);
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readDouble();
        this.b = dataInputStream.readDouble();
        this.c = dataInputStream.readDouble();
        this.d = dataInputStream.readFloat();
        final int int1 = dataInputStream.readInt();
        this.e = new HashSet();
        final int n = (int)this.a;
        final int n2 = (int)this.b;
        final int n3 = (int)this.c;
        for (int i = 0; i < int1; ++i) {
            this.e.add(new ChunkPosition(dataInputStream.readByte() + n, dataInputStream.readByte() + n2, dataInputStream.readByte() + n3));
        }
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeDouble(this.a);
        dataOutputStream.writeDouble(this.b);
        dataOutputStream.writeDouble(this.c);
        dataOutputStream.writeFloat(this.d);
        dataOutputStream.writeInt(this.e.size());
        final int n = (int)this.a;
        final int n2 = (int)this.b;
        final int n3 = (int)this.c;
        for (final ChunkPosition chunkPosition : this.e) {
            final int v = chunkPosition.a - n;
            final int v2 = chunkPosition.b - n2;
            final int v3 = chunkPosition.c - n3;
            dataOutputStream.writeByte(v);
            dataOutputStream.writeByte(v2);
            dataOutputStream.writeByte(v3);
        }
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 32 + this.e.size() * 3;
    }
}
