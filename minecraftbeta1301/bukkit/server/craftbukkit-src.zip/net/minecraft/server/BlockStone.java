// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockStone extends Block
{
    public BlockStone(final int n, final int n2) {
        super(n, n2, Material.STONE);
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Block.COBBLESTONE.id;
    }
}
