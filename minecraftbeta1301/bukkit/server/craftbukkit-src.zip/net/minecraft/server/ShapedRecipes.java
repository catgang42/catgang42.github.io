// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ShapedRecipes implements CraftingRecipe
{
    private int b;
    private int c;
    private ItemStack[] d;
    private ItemStack e;
    public final int a;
    
    public ShapedRecipes(final int b, final int c, final ItemStack[] d, final ItemStack e) {
        this.a = e.id;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
    }
    
    public boolean a(final InventoryCrafting inventoryCrafting) {
        for (int i = 0; i <= 3 - this.b; ++i) {
            for (int j = 0; j <= 3 - this.c; ++j) {
                if (this.a(inventoryCrafting, i, j, true)) {
                    return true;
                }
                if (this.a(inventoryCrafting, i, j, false)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean a(final InventoryCrafting inventoryCrafting, final int n, final int n2, final boolean b) {
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                final int n3 = i - n;
                final int n4 = j - n2;
                ItemStack itemStack = null;
                if (n3 >= 0 && n4 >= 0 && n3 < this.b && n4 < this.c) {
                    if (b) {
                        itemStack = this.d[this.b - n3 - 1 + n4 * this.b];
                    }
                    else {
                        itemStack = this.d[n3 + n4 * this.b];
                    }
                }
                final ItemStack b2 = inventoryCrafting.b(i, j);
                if (b2 != null || itemStack != null) {
                    if ((b2 == null && itemStack != null) || (b2 != null && itemStack == null)) {
                        return false;
                    }
                    if (itemStack.id != b2.id) {
                        return false;
                    }
                    if (itemStack.h() != -1 && itemStack.h() != b2.h()) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    public ItemStack b(final InventoryCrafting inventoryCrafting) {
        return new ItemStack(this.e.id, this.e.count, this.e.h());
    }
    
    public int a() {
        return this.b * this.c;
    }
}
