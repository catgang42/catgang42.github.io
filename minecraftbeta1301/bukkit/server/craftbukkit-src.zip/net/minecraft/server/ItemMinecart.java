// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.player.PlayerItemEvent;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class ItemMinecart extends Item
{
    public int a;
    
    public ItemMinecart(final int i, final int j) {
        super(i);
        this.maxStackSize = 1;
        this.a = j;
    }
    
    @Override
    public boolean a(final ItemStack itemstack, final EntityHuman entityhuman, final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getTypeId(i, j, k);
        if (i2 == Block.RAILS.id) {
            if (!world.isStatic) {
                final CraftWorld craftWorld = ((WorldServer)world).getWorld();
                final CraftServer craftServer = ((WorldServer)world).getServer();
                final Event.Type eventType = Event.Type.PLAYER_ITEM;
                final Player who = (entityhuman == null) ? null : ((Player)entityhuman.getBukkitEntity());
                final org.bukkit.inventory.ItemStack itemInHand = new CraftItemStack(itemstack);
                final org.bukkit.block.Block blockClicked = craftWorld.getBlockAt(i, j, k);
                final BlockFace blockFace = CraftBlock.notchToBlockFace(l);
                final PlayerItemEvent event = new PlayerItemEvent(eventType, who, itemInHand, blockClicked, blockFace);
                craftServer.getPluginManager().callEvent(event);
                if (event.isCancelled()) {
                    return false;
                }
                world.a(new EntityMinecart(world, i + 0.5f, j + 0.5f, k + 0.5f, this.a));
            }
            --itemstack.count;
            return true;
        }
        return false;
    }
}
