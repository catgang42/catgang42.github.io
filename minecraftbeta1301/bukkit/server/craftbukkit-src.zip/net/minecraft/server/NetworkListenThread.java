// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.logging.Level;
import java.net.InetAddress;
import java.util.ArrayList;
import java.net.ServerSocket;
import java.util.logging.Logger;

public class NetworkListenThread
{
    public static Logger a;
    private ServerSocket d;
    private Thread e;
    public volatile boolean b;
    private int f;
    private ArrayList g;
    private ArrayList h;
    public MinecraftServer c;
    
    public NetworkListenThread(final MinecraftServer c, final InetAddress bindAddr, final int port) {
        this.b = false;
        this.f = 0;
        this.g = new ArrayList();
        this.h = new ArrayList();
        this.c = c;
        (this.d = new ServerSocket(port, 0, bindAddr)).setPerformancePreferences(0, 2, 1);
        this.b = true;
        (this.e = new NetworkAcceptThread(this, "Listen thread", c)).start();
    }
    
    public void a(final NetServerHandler e) {
        this.h.add(e);
    }
    
    private void a(final NetLoginHandler e) {
        if (e == null) {
            throw new IllegalArgumentException("Got null pendingconnection!");
        }
        this.g.add(e);
    }
    
    public void a() {
        for (int i = 0; i < this.g.size(); ++i) {
            final NetLoginHandler netLoginHandler = this.g.get(i);
            try {
                netLoginHandler.a();
            }
            catch (Exception ex) {
                netLoginHandler.a("Internal server error");
                NetworkListenThread.a.log(Level.WARNING, "Failed to handle packet: " + ex, ex);
            }
            if (netLoginHandler.c) {
                this.g.remove(i--);
            }
        }
        for (int j = 0; j < this.h.size(); ++j) {
            final NetServerHandler netServerHandler = this.h.get(j);
            try {
                netServerHandler.a();
            }
            catch (Exception ex2) {
                NetworkListenThread.a.log(Level.WARNING, "Failed to handle packet: " + ex2, ex2);
                netServerHandler.a("Internal server error");
            }
            if (netServerHandler.c) {
                this.h.remove(j--);
            }
        }
    }
    
    static {
        NetworkListenThread.a = Logger.getLogger("Minecraft");
    }
}
