// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class InventoryCrafting implements IInventory
{
    private ItemStack[] a;
    private int b;
    private Container c;
    
    public ItemStack[] getContents() {
        return this.a;
    }
    
    public InventoryCrafting(final Container container, final int i, final int j) {
        final int k = i * j;
        this.a = new ItemStack[k];
        this.c = container;
        this.b = i;
    }
    
    public int m_() {
        return this.a.length;
    }
    
    public ItemStack c_(final int i) {
        return (i >= this.m_()) ? null : this.a[i];
    }
    
    public ItemStack b(final int i, final int j) {
        if (i >= 0 && i < this.b) {
            final int k = i + j * this.b;
            return this.c_(k);
        }
        return null;
    }
    
    public String c() {
        return "Crafting";
    }
    
    public ItemStack a(final int i, final int j) {
        if (this.a[i] == null) {
            return null;
        }
        if (this.a[i].count <= j) {
            final ItemStack itemstack = this.a[i];
            this.a[i] = null;
            this.c.a(this);
            return itemstack;
        }
        final ItemStack itemstack = this.a[i].a(j);
        if (this.a[i].count == 0) {
            this.a[i] = null;
        }
        this.c.a(this);
        return itemstack;
    }
    
    public void a(final int i, final ItemStack itemstack) {
        this.a[i] = itemstack;
        this.c.a(this);
    }
    
    public int n_() {
        return 64;
    }
    
    public void h() {
    }
    
    public boolean a_(final EntityHuman entityhuman) {
        return true;
    }
}
