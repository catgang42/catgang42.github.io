// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemDoor extends Item
{
    private Material a;
    
    public ItemDoor(final int n, final Material a) {
        super(n);
        this.a = a;
        this.durability = 64;
        this.maxStackSize = 1;
    }
    
    @Override
    public boolean a(final ItemStack itemStack, final EntityHuman entityHuman, final World world, final int n, int n2, final int n3, final int n4) {
        if (n4 != 1) {
            return false;
        }
        ++n2;
        Block block;
        if (this.a == Material.WOOD) {
            block = Block.WOODEN_DOOR;
        }
        else {
            block = Block.IRON_DOOR_BLOCK;
        }
        if (!block.a(world, n, n2, n3)) {
            return false;
        }
        int l = MathHelper.b((entityHuman.yaw + 180.0f) * 4.0f / 360.0f - 0.5) & 0x3;
        int n5 = 0;
        int n6 = 0;
        if (l == 0) {
            n6 = 1;
        }
        if (l == 1) {
            n5 = -1;
        }
        if (l == 2) {
            n6 = -1;
        }
        if (l == 3) {
            n5 = 1;
        }
        final int n7 = (world.d(n - n5, n2, n3 - n6) + world.d(n - n5, n2 + 1, n3 - n6)) ? 1 : 0;
        final int n8 = (world.d(n + n5, n2, n3 + n6) + world.d(n + n5, n2 + 1, n3 + n6)) ? 1 : 0;
        final boolean b = world.getTypeId(n - n5, n2, n3 - n6) == block.id || world.getTypeId(n - n5, n2 + 1, n3 - n6) == block.id;
        final boolean b2 = world.getTypeId(n + n5, n2, n3 + n6) == block.id || world.getTypeId(n + n5, n2 + 1, n3 + n6) == block.id;
        boolean b3 = false;
        if (b && !b2) {
            b3 = true;
        }
        else if (n8 > n7) {
            b3 = true;
        }
        if (b3) {
            l = (l - 1 & 0x3);
            l += 4;
        }
        world.e(n, n2, n3, block.id);
        world.c(n, n2, n3, l);
        world.e(n, n2 + 1, n3, block.id);
        world.c(n, n2 + 1, n3, l + 8);
        --itemStack.count;
        return true;
    }
}
