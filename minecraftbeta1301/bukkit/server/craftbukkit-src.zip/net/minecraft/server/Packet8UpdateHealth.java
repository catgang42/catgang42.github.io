// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet8UpdateHealth extends Packet
{
    public int a;
    
    public Packet8UpdateHealth() {
    }
    
    public Packet8UpdateHealth(final int a) {
        this.a = a;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readShort();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeShort(this.a);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 2;
    }
}
