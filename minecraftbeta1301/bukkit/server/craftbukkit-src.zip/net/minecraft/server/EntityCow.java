// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntityCow extends EntityAnimal
{
    public EntityCow(final World world) {
        super(world);
        this.texture = "/mob/cow.png";
        this.a(0.9f, 1.3f);
    }
    
    @Override
    public void a(final NBTTagCompound nbtTagCompound) {
        super.a(nbtTagCompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbtTagCompound) {
        super.b(nbtTagCompound);
    }
    
    @Override
    protected String e() {
        return "mob.cow";
    }
    
    @Override
    protected String f() {
        return "mob.cowhurt";
    }
    
    @Override
    protected String g() {
        return "mob.cowhurt";
    }
    
    @Override
    protected float i() {
        return 0.4f;
    }
    
    @Override
    protected int h() {
        return Item.LEATHER.id;
    }
    
    @Override
    public boolean a(final EntityHuman entityHuman) {
        final ItemStack b = entityHuman.inventory.b();
        if (b != null && b.id == Item.BUCKET.id) {
            entityHuman.inventory.a(entityHuman.inventory.c, new ItemStack(Item.MILK_BUCKET));
            return true;
        }
        return false;
    }
}
