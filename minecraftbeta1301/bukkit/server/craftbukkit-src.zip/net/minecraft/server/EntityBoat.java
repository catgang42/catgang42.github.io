// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.event.vehicle.VehicleEnterEvent;
import java.util.List;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.vehicle.VehicleMoveEvent;
import org.bukkit.event.vehicle.VehicleEvent;
import org.bukkit.Location;
import org.bukkit.event.vehicle.VehicleDamageEvent;
import org.bukkit.event.vehicle.VehicleCreateEvent;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.vehicle.VehicleEntityCollisionEvent;
import org.bukkit.entity.Vehicle;
import org.bukkit.event.Event;

public class EntityBoat extends Entity
{
    public int a;
    public int b;
    public int c;
    private int d;
    private double e;
    private double f;
    private double g;
    private double h;
    private double i;
    public double maxSpeed;
    
    @Override
    public void h(final Entity entity) {
        final CraftServer server = ((WorldServer)this.world).getServer();
        final Event.Type eventType = Event.Type.VEHICLE_COLLISION_ENTITY;
        final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
        final org.bukkit.entity.Entity hitEntity = (entity == null) ? null : entity.getBukkitEntity();
        final VehicleEntityCollisionEvent event = new VehicleEntityCollisionEvent(eventType, vehicle, hitEntity);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return;
        }
        super.h(entity);
    }
    
    public EntityBoat(final World world) {
        super(world);
        this.maxSpeed = 0.4;
        this.a = 0;
        this.b = 0;
        this.c = 1;
        this.aC = true;
        this.a(1.5f, 0.6f);
        this.height = this.width / 2.0f;
        this.bg = false;
    }
    
    @Override
    protected void a() {
    }
    
    @Override
    public AxisAlignedBB a_(final Entity entity) {
        return entity.boundingBox;
    }
    
    @Override
    public AxisAlignedBB d() {
        return this.boundingBox;
    }
    
    @Override
    public boolean e_() {
        return true;
    }
    
    public EntityBoat(final World world, final double d0, final double d1, final double d2) {
        this(world);
        this.a(d0, d1 + this.height, d2);
        this.motX = 0.0;
        this.motY = 0.0;
        this.motZ = 0.0;
        this.lastX = d0;
        this.lastY = d1;
        this.lastZ = d2;
        final CraftServer server = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.VEHICLE_CREATE;
        final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
        final VehicleCreateEvent event = new VehicleCreateEvent(eventType, vehicle);
        server.getPluginManager().callEvent(event);
    }
    
    @Override
    public double k() {
        return this.width * 0.0 - 0.30000001192092896;
    }
    
    @Override
    public boolean a(final Entity entity, final int i) {
        if (this.world.isStatic || this.dead) {
            return true;
        }
        final Event.Type eventType = Event.Type.VEHICLE_DAMAGE;
        final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
        final org.bukkit.entity.Entity attacker = (entity == null) ? null : entity.getBukkitEntity();
        final int damage = i;
        final VehicleDamageEvent event = new VehicleDamageEvent(eventType, vehicle, attacker, damage);
        ((WorldServer)this.world).getServer().getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        this.c = -this.c;
        this.b = 10;
        this.a += i * 10;
        this.R();
        if (this.a > 40) {
            for (int j = 0; j < 3; ++j) {
                this.a(Block.WOOD.id, 1, 0.0f);
            }
            for (int j = 0; j < 2; ++j) {
                this.a(Item.STICK.id, 1, 0.0f);
            }
            this.C();
        }
        return true;
    }
    
    @Override
    public boolean d_() {
        return !this.dead;
    }
    
    @Override
    public void f_() {
        final double prevX = this.locX;
        final double prevY = this.locY;
        final double prevZ = this.locZ;
        final float prevYaw = this.yaw;
        final float prevPitch = this.pitch;
        super.f_();
        if (this.b > 0) {
            --this.b;
        }
        if (this.a > 0) {
            --this.a;
        }
        this.lastX = this.locX;
        this.lastY = this.locY;
        this.lastZ = this.locZ;
        final byte b0 = 5;
        double d0 = 0.0;
        for (int i = 0; i < b0; ++i) {
            final double d2 = this.boundingBox.b + (this.boundingBox.e - this.boundingBox.b) * (i + 0) / b0 - 0.125;
            final double d3 = this.boundingBox.b + (this.boundingBox.e - this.boundingBox.b) * (i + 1) / b0 - 0.125;
            final AxisAlignedBB axisalignedbb = AxisAlignedBB.b(this.boundingBox.a, d2, this.boundingBox.c, this.boundingBox.d, d3, this.boundingBox.f);
            if (this.world.b(axisalignedbb, Material.WATER)) {
                d0 += 1.0 / b0;
            }
        }
        if (this.world.isStatic) {
            if (this.d > 0) {
                final double d4 = this.locX + (this.e - this.locX) / this.d;
                final double d5 = this.locY + (this.f - this.locY) / this.d;
                final double d6 = this.locZ + (this.g - this.locZ) / this.d;
                double d7;
                for (d7 = this.h - this.yaw; d7 < -180.0; d7 += 360.0) {}
                while (d7 >= 180.0) {
                    d7 -= 360.0;
                }
                this.yaw += (float)(d7 / this.d);
                this.pitch += (float)((this.i - this.pitch) / this.d);
                --this.d;
                this.a(d4, d5, d6);
                this.c(this.yaw, this.pitch);
            }
            else {
                final double d4 = this.locX + this.motX;
                final double d5 = this.locY + this.motY;
                final double d6 = this.locZ + this.motZ;
                this.a(d4, d5, d6);
                if (this.onGround) {
                    this.motX *= 0.5;
                    this.motY *= 0.5;
                    this.motZ *= 0.5;
                }
                this.motX *= 0.9900000095367432;
                this.motY *= 0.949999988079071;
                this.motZ *= 0.9900000095367432;
            }
        }
        else {
            final double d4 = d0 * 2.0 - 1.0;
            this.motY += 0.03999999910593033 * d4;
            if (this.passenger != null) {
                this.motX += this.passenger.motX * 0.2;
                this.motZ += this.passenger.motZ * 0.2;
            }
            final double d5 = this.maxSpeed;
            if (this.motX < -d5) {
                this.motX = -d5;
            }
            if (this.motX > d5) {
                this.motX = d5;
            }
            if (this.motZ < -d5) {
                this.motZ = -d5;
            }
            if (this.motZ > d5) {
                this.motZ = d5;
            }
            if (this.onGround) {
                this.motX *= 0.5;
                this.motY *= 0.5;
                this.motZ *= 0.5;
            }
            this.c(this.motX, this.motY, this.motZ);
            final double d6 = Math.sqrt(this.motX * this.motX + this.motZ * this.motZ);
            if (d6 > 0.15) {
                final double d7 = Math.cos(this.yaw * 3.141592653589793 / 180.0);
                final double d8 = Math.sin(this.yaw * 3.141592653589793 / 180.0);
                for (int j = 0; j < 1.0 + d6 * 60.0; ++j) {
                    final double d9 = this.random.nextFloat() * 2.0f - 1.0f;
                    final double d10 = (this.random.nextInt(2) * 2 - 1) * 0.7;
                    if (this.random.nextBoolean()) {
                        final double d11 = this.locX - d7 * d9 * 0.8 + d8 * d10;
                        final double d12 = this.locZ - d8 * d9 * 0.8 - d7 * d10;
                        this.world.a("splash", d11, this.locY - 0.125, d12, this.motX, this.motY, this.motZ);
                    }
                    else {
                        final double d11 = this.locX + d7 + d8 * d9 * 0.7;
                        final double d12 = this.locZ + d8 - d7 * d9 * 0.7;
                        this.world.a("splash", d11, this.locY - 0.125, d12, this.motX, this.motY, this.motZ);
                    }
                }
            }
            if (this.aV && d6 > 0.15) {
                if (!this.world.isStatic) {
                    this.C();
                    for (int k = 0; k < 3; ++k) {
                        this.a(Block.WOOD.id, 1, 0.0f);
                    }
                    for (int k = 0; k < 2; ++k) {
                        this.a(Item.STICK.id, 1, 0.0f);
                    }
                }
            }
            else {
                this.motX *= 0.9900000095367432;
                this.motY *= 0.949999988079071;
                this.motZ *= 0.9900000095367432;
            }
            this.pitch = 0.0f;
            double d7 = this.yaw;
            final double d8 = this.lastX - this.locX;
            final double d13 = this.lastZ - this.locZ;
            if (d8 * d8 + d13 * d13 > 0.001) {
                d7 = (float)(Math.atan2(d13, d8) * 180.0 / 3.141592653589793);
            }
            double d14;
            for (d14 = d7 - this.yaw; d14 >= 180.0; d14 -= 360.0) {}
            while (d14 < -180.0) {
                d14 += 360.0;
            }
            if (d14 > 20.0) {
                d14 = 20.0;
            }
            if (d14 < -20.0) {
                d14 = -20.0;
            }
            this.c(this.yaw += (float)d14, this.pitch);
            final CraftServer server = ((WorldServer)this.world).getServer();
            final CraftWorld world = ((WorldServer)this.world).getWorld();
            final Location from = new Location(world, prevX, prevY, prevZ, prevYaw, prevPitch);
            final Location to = new Location(world, this.locX, this.locY, this.locZ, this.yaw, this.pitch);
            final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
            server.getPluginManager().callEvent(new VehicleEvent(Event.Type.VEHICLE_UPDATE, vehicle));
            if (!from.equals(to)) {
                final VehicleMoveEvent event = new VehicleMoveEvent(Event.Type.VEHICLE_MOVE, vehicle, from, to);
                server.getPluginManager().callEvent(event);
            }
            final List list = this.world.b(this, this.boundingBox.b(0.20000000298023224, 0.0, 0.20000000298023224));
            if (list != null && list.size() > 0) {
                for (int l = 0; l < list.size(); ++l) {
                    final Entity entity = list.get(l);
                    if (entity != this.passenger && entity.e_() && entity instanceof EntityBoat) {
                        entity.h(this);
                    }
                }
            }
            if (this.passenger != null && this.passenger.dead) {
                this.passenger = null;
            }
        }
    }
    
    @Override
    public void h_() {
        if (this.passenger != null) {
            final double d0 = Math.cos(this.yaw * 3.141592653589793 / 180.0) * 0.4;
            final double d2 = Math.sin(this.yaw * 3.141592653589793 / 180.0) * 0.4;
            this.passenger.a(this.locX + d0, this.locY + this.k() + this.passenger.B(), this.locZ + d2);
        }
    }
    
    @Override
    protected void a(final NBTTagCompound nbttagcompound) {
    }
    
    @Override
    protected void b(final NBTTagCompound nbttagcompound) {
    }
    
    @Override
    public boolean a(final EntityHuman entityhuman) {
        if (this.passenger != null && this.passenger instanceof EntityHuman && this.passenger != entityhuman) {
            return true;
        }
        if (!this.world.isStatic) {
            final CraftServer server = ((WorldServer)this.world).getServer();
            final Event.Type eventType = Event.Type.VEHICLE_ENTER;
            final Vehicle vehicle = (Vehicle)this.getBukkitEntity();
            final org.bukkit.entity.Entity player = entityhuman.getBukkitEntity();
            final VehicleEnterEvent event = new VehicleEnterEvent(eventType, vehicle, player);
            server.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                return true;
            }
            entityhuman.b(this);
        }
        return true;
    }
}
