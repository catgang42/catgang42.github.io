// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Iterator;
import org.bukkit.Server;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.Event;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.List;

public class EntityPlayer extends EntityHuman implements ICrafting
{
    public NetServerHandler a;
    public MinecraftServer b;
    public ItemInWorldManager c;
    public double d;
    public double e;
    public List f;
    public Set g;
    private int bE;
    private int bF;
    private ItemStack[] bG;
    private int bH;
    public boolean h;
    
    public EntityPlayer(final MinecraftServer minecraftserver, final World world, final String s, final ItemInWorldManager iteminworldmanager) {
        super(world);
        this.f = new LinkedList();
        this.g = new HashSet();
        this.bE = -99999999;
        this.bF = 60;
        this.bG = new ItemStack[] { null, null, null, null, null };
        this.bH = 0;
        final ChunkCoordinates chunkcoordinates = world.l();
        int i = chunkcoordinates.a;
        int j = chunkcoordinates.c;
        int k = chunkcoordinates.b;
        if (!world.m.e) {
            i += this.random.nextInt(20) - 10;
            k = world.e(i, j);
            j += this.random.nextInt(20) - 10;
        }
        this.c(i + 0.5, k, j + 0.5, 0.0f, 0.0f);
        this.b = minecraftserver;
        this.bm = 0.0f;
        iteminworldmanager.a = this;
        this.name = s;
        this.c = iteminworldmanager;
        this.height = 0.0f;
    }
    
    public void l() {
        this.activeContainer.a((ICrafting)this);
    }
    
    @Override
    public ItemStack[] k_() {
        return this.bG;
    }
    
    @Override
    protected void l_() {
        this.height = 0.0f;
    }
    
    @Override
    public float p() {
        return 1.62f;
    }
    
    @Override
    public void f_() {
        this.c.a();
        --this.bF;
        this.activeContainer.a();
        for (int i = 0; i < 5; ++i) {
            final ItemStack itemstack = this.b_(i);
            if (itemstack != this.bG[i]) {
                this.b.k.a(this, new Packet5EntityEquipment(this.id, i, itemstack));
                this.bG[i] = itemstack;
            }
        }
    }
    
    public ItemStack b_(final int i) {
        return (i == 0) ? this.inventory.b() : this.inventory.b[i - 1];
    }
    
    @Override
    public void a(final Entity entity) {
        final List<org.bukkit.inventory.ItemStack> loot = new ArrayList<org.bukkit.inventory.ItemStack>();
        for (int i = 0; i < this.inventory.a.length; ++i) {
            if (this.inventory.a[i] != null) {
                loot.add(new CraftItemStack(this.inventory.a[i]));
            }
        }
        for (int i = 0; i < this.inventory.b.length; ++i) {
            if (this.inventory.b[i] != null) {
                loot.add(new CraftItemStack(this.inventory.b[i]));
            }
        }
        final CraftEntity craftEntity = (CraftEntity)this.getBukkitEntity();
        final CraftWorld cworld = ((WorldServer)this.world).getWorld();
        final Server server = ((WorldServer)this.world).getServer();
        final EntityDeathEvent event = new EntityDeathEvent(Event.Type.ENTITY_DEATH, craftEntity, loot);
        server.getPluginManager().callEvent(event);
        for (final org.bukkit.inventory.ItemStack stack : event.getDrops()) {
            cworld.dropItemNaturally(craftEntity.getLocation(), stack);
        }
    }
    
    @Override
    public boolean a(final Entity entity, final int i) {
        if (this.bF > 0) {
            return false;
        }
        if (!this.b.n) {
            if (entity instanceof EntityHuman) {
                return false;
            }
            if (entity instanceof EntityArrow) {
                final EntityArrow entityarrow = (EntityArrow)entity;
                if (entityarrow.b instanceof EntityHuman) {
                    return false;
                }
            }
        }
        return super.a(entity, i);
    }
    
    @Override
    public void b(final int i) {
        super.b(i);
    }
    
    public void a(final boolean flag) {
        super.f_();
        if (flag && !this.f.isEmpty()) {
            final ChunkCoordIntPair chunkcoordintpair = this.f.get(0);
            if (chunkcoordintpair != null) {
                boolean flag2 = false;
                if (this.a.b() < 2) {
                    flag2 = true;
                }
                if (flag2) {
                    this.f.remove(chunkcoordintpair);
                    this.a.b(new Packet51MapChunk(chunkcoordintpair.a * 16, 0, chunkcoordintpair.b * 16, 16, 128, 16, this.world));
                    final List list = ((WorldServer)this.world).d(chunkcoordintpair.a * 16, 0, chunkcoordintpair.b * 16, chunkcoordintpair.a * 16 + 16, 128, chunkcoordintpair.b * 16 + 16);
                    for (int i = 0; i < list.size(); ++i) {
                        this.a(list.get(i));
                    }
                }
            }
        }
        if (this.health != this.bE) {
            this.a.b(new Packet8UpdateHealth(this.health));
            this.bE = this.health;
        }
    }
    
    private void a(final TileEntity tileentity) {
        if (tileentity != null) {
            final Packet packet = tileentity.e();
            if (packet != null) {
                this.a.b(packet);
            }
        }
    }
    
    @Override
    public void q() {
        super.q();
    }
    
    @Override
    public void b(final Entity entity, final int i) {
        if (!entity.dead) {
            if (entity instanceof EntityItem) {
                this.b.k.a(entity, new Packet22Collect(entity.id, this.id));
            }
            if (entity instanceof EntityArrow) {
                this.b.k.a(entity, new Packet22Collect(entity.id, this.id));
            }
        }
        super.b(entity, i);
        this.activeContainer.a();
    }
    
    @Override
    public void r() {
        if (!this.p) {
            this.q = -1;
            this.p = true;
            this.b.k.a(this, new Packet18ArmAnimation(this, 1));
        }
    }
    
    public void s() {
    }
    
    @Override
    public boolean a(final int i, final int j, final int k) {
        if (super.a(i, j, k)) {
            this.b.k.a(this, new Packet17(this, 0, i, j, k));
            return true;
        }
        return false;
    }
    
    @Override
    public void a(final boolean flag, final boolean flag1) {
        if (this.E()) {
            this.b.k.b(this, new Packet18ArmAnimation(this, 3));
        }
        super.a(flag, flag1);
        this.a.a(this.locX, this.locY, this.locZ, this.yaw, this.pitch);
    }
    
    @Override
    public void b(final Entity entity) {
        this.setPassengerOf(entity);
    }
    
    @Override
    public void setPassengerOf(final Entity entity) {
        super.setPassengerOf(entity);
        this.a.b(new Packet39AttachEntity(this, this.vehicle));
        this.a.a(this.locX, this.locY, this.locZ, this.yaw, this.pitch);
    }
    
    @Override
    protected void a(final double d0, final boolean flag) {
    }
    
    public void b(final double d0, final boolean flag) {
        super.a(d0, flag);
    }
    
    private void V() {
        this.bH = this.bH % 100 + 1;
    }
    
    @Override
    public void b(final int i, final int j, final int k) {
        this.V();
        this.a.b(new Packet100OpenWindow(this.bH, 1, "Crafting", 9));
        this.activeContainer = new ContainerWorkbench(this.inventory, this.world, i, j, k);
        this.activeContainer.f = this.bH;
        this.activeContainer.a((ICrafting)this);
    }
    
    @Override
    public void a(final IInventory iinventory) {
        this.V();
        this.a.b(new Packet100OpenWindow(this.bH, 0, iinventory.c(), iinventory.m_()));
        this.activeContainer = new ContainerChest(this.inventory, iinventory);
        this.activeContainer.f = this.bH;
        this.activeContainer.a((ICrafting)this);
    }
    
    @Override
    public void a(final TileEntityFurnace tileentityfurnace) {
        this.V();
        this.a.b(new Packet100OpenWindow(this.bH, 2, tileentityfurnace.c(), tileentityfurnace.m_()));
        this.activeContainer = new ContainerFurnace(this.inventory, tileentityfurnace);
        this.activeContainer.f = this.bH;
        this.activeContainer.a((ICrafting)this);
    }
    
    @Override
    public void a(final TileEntityDispenser tileentitydispenser) {
        this.V();
        this.a.b(new Packet100OpenWindow(this.bH, 3, tileentitydispenser.c(), tileentitydispenser.m_()));
        this.activeContainer = new ContainerDispenser(this.inventory, tileentitydispenser);
        this.activeContainer.f = this.bH;
        this.activeContainer.a((ICrafting)this);
    }
    
    public void a(final Container container, final int i, final ItemStack itemstack) {
        if (!(container.a(i) instanceof SlotResult) && !this.h) {
            this.a.b(new Packet103SetSlot(container.f, i, itemstack));
        }
    }
    
    public void a(final Container container, final List list) {
        this.a.b(new Packet104WindowItems(container.f, list));
        this.a.b(new Packet103SetSlot(-1, -1, this.inventory.i()));
    }
    
    public void a(final Container container, final int i, final int j) {
        this.a.b(new Packet105CraftProgressBar(container.f, i, j));
    }
    
    @Override
    public void a(final ItemStack itemstack) {
    }
    
    public void t() {
        this.a.b(new Packet101CloseWindow(this.activeContainer.f));
        this.v();
    }
    
    public void u() {
        if (!this.h) {
            this.a.b(new Packet103SetSlot(-1, -1, this.inventory.i()));
        }
    }
    
    public void v() {
        this.activeContainer.a((EntityHuman)this);
        this.activeContainer = this.defaultContainer;
    }
    
    public void a(final float f, final float f1, final boolean flag, final boolean flag1, final float f2, final float f3) {
        this.au = f;
        this.av = f1;
        this.ax = flag;
        this.b(flag1);
        this.pitch = f2;
        this.yaw = f3;
    }
}
