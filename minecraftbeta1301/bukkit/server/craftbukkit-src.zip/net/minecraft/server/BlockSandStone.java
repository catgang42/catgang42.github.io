// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockSandStone extends Block
{
    public BlockSandStone(final int n) {
        super(n, 192, Material.STONE);
    }
    
    @Override
    public int a(final int n) {
        if (n == 1) {
            return this.textureId - 16;
        }
        if (n == 0) {
            return this.textureId + 16;
        }
        return this.textureId;
    }
}
