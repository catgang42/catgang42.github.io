// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet20NamedEntitySpawn extends Packet
{
    public int a;
    public String b;
    public int c;
    public int d;
    public int e;
    public byte f;
    public byte g;
    public int h;
    
    public Packet20NamedEntitySpawn() {
    }
    
    public Packet20NamedEntitySpawn(final EntityHuman entityHuman) {
        this.a = entityHuman.id;
        this.b = entityHuman.name;
        this.c = MathHelper.b(entityHuman.locX * 32.0);
        this.d = MathHelper.b(entityHuman.locY * 32.0);
        this.e = MathHelper.b(entityHuman.locZ * 32.0);
        this.f = (byte)(entityHuman.yaw * 256.0f / 360.0f);
        this.g = (byte)(entityHuman.pitch * 256.0f / 360.0f);
        final ItemStack b = entityHuman.inventory.b();
        this.h = ((b == null) ? 0 : b.id);
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readUTF();
        this.c = dataInputStream.readInt();
        this.d = dataInputStream.readInt();
        this.e = dataInputStream.readInt();
        this.f = dataInputStream.readByte();
        this.g = dataInputStream.readByte();
        this.h = dataInputStream.readShort();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeUTF(this.b);
        dataOutputStream.writeInt(this.c);
        dataOutputStream.writeInt(this.d);
        dataOutputStream.writeInt(this.e);
        dataOutputStream.writeByte(this.f);
        dataOutputStream.writeByte(this.g);
        dataOutputStream.writeShort(this.h);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 28;
    }
}
