// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockFence extends Block
{
    public BlockFence(final int n, final int n2) {
        super(n, n2, Material.WOOD);
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3) {
        return world.getTypeId(n, n2 - 1, n3) != this.id && world.getMaterial(n, n2 - 1, n3).isBuildable() && super.a(world, n, n2, n3);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return AxisAlignedBB.b(n, n2, n3, n + 1, n2 + 1.5f, n3 + 1);
    }
    
    @Override
    public boolean a() {
        return false;
    }
}
