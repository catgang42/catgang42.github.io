// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntityGhast extends EntityFlying implements IMonster
{
    public int a;
    public double b;
    public double c;
    public double d;
    private Entity g;
    private int h;
    public int e;
    public int f;
    
    public EntityGhast(final World world) {
        super(world);
        this.a = 0;
        this.g = null;
        this.h = 0;
        this.e = 0;
        this.f = 0;
        this.texture = "/mob/ghast.png";
        this.a(4.0f, 4.0f);
        this.by = true;
    }
    
    @Override
    protected void c_() {
        if (this.world.j == 0) {
            this.C();
        }
        this.e = this.f;
        final double n = this.b - this.locX;
        final double n2 = this.c - this.locY;
        final double n3 = this.d - this.locZ;
        final double n4 = MathHelper.a(n * n + n2 * n2 + n3 * n3);
        if (n4 < 1.0 || n4 > 60.0) {
            this.b = this.locX + (this.random.nextFloat() * 2.0f - 1.0f) * 16.0f;
            this.c = this.locY + (this.random.nextFloat() * 2.0f - 1.0f) * 16.0f;
            this.d = this.locZ + (this.random.nextFloat() * 2.0f - 1.0f) * 16.0f;
        }
        if (this.a-- <= 0) {
            this.a += this.random.nextInt(5) + 2;
            if (this.a(this.b, this.c, this.d, n4)) {
                this.motX += n / n4 * 0.1;
                this.motY += n2 / n4 * 0.1;
                this.motZ += n3 / n4 * 0.1;
            }
            else {
                this.b = this.locX;
                this.c = this.locY;
                this.d = this.locZ;
            }
        }
        if (this.g != null && this.g.dead) {
            this.g = null;
        }
        if (this.g == null || this.h-- <= 0) {
            this.g = this.world.a(this, 100.0);
            if (this.g != null) {
                this.h = 20;
            }
        }
        final double n5 = 64.0;
        if (this.g != null && this.g.g(this) < n5 * n5) {
            final double n6 = this.g.locX - this.locX;
            final double d1 = this.g.boundingBox.b + this.g.width / 2.0f - (this.locY + this.width / 2.0f);
            final double n7 = this.g.locZ - this.locZ;
            final float n8 = -(float)Math.atan2(n6, n7) * 180.0f / 3.1415927f;
            this.yaw = n8;
            this.F = n8;
            if (this.e(this.g)) {
                if (this.f == 10) {
                    this.world.a(this, "mob.ghast.charge", this.i(), (this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f);
                }
                ++this.f;
                if (this.f == 20) {
                    this.world.a(this, "mob.ghast.fireball", this.i(), (this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f);
                    final EntityFireball entity = new EntityFireball(this.world, this, n6, d1, n7);
                    final double n9 = 4.0;
                    final Vec3D b = this.b(1.0f);
                    entity.locX = this.locX + b.a * n9;
                    entity.locY = this.locY + this.width / 2.0f + 0.5;
                    entity.locZ = this.locZ + b.c * n9;
                    this.world.a(entity);
                    this.f = -40;
                }
            }
            else if (this.f > 0) {
                --this.f;
            }
        }
        else {
            final float n10 = -(float)Math.atan2(this.motX, this.motZ) * 180.0f / 3.1415927f;
            this.yaw = n10;
            this.F = n10;
            if (this.f > 0) {
                --this.f;
            }
        }
        this.texture = ((this.f > 10) ? "/mob/ghast_fire.png" : "/mob/ghast.png");
    }
    
    private boolean a(final double n, final double n2, final double n3, final double n4) {
        final double n5 = (this.b - this.locX) / n4;
        final double n6 = (this.c - this.locY) / n4;
        final double n7 = (this.d - this.locZ) / n4;
        final AxisAlignedBB b = this.boundingBox.b();
        for (int n8 = 1; n8 < n4; ++n8) {
            b.d(n5, n6, n7);
            if (this.world.a(this, b).size() > 0) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    protected String e() {
        return "mob.ghast.moan";
    }
    
    @Override
    protected String f() {
        return "mob.ghast.scream";
    }
    
    @Override
    protected String g() {
        return "mob.ghast.death";
    }
    
    @Override
    protected int h() {
        return Item.SULPHUR.id;
    }
    
    @Override
    protected float i() {
        return 10.0f;
    }
    
    @Override
    public boolean b() {
        return this.random.nextInt(20) == 0 && super.b() && this.world.j > 0;
    }
    
    @Override
    public int j() {
        return 1;
    }
}
