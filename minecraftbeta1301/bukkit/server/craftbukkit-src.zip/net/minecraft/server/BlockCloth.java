// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockCloth extends Block
{
    public BlockCloth() {
        super(35, 64, Material.CLOTH);
    }
    
    @Override
    public int a(final int n, int n2) {
        if (n2 == 0) {
            return this.textureId;
        }
        n2 = ~(n2 & 0xF);
        return 113 + ((n2 & 0x8) >> 3) + (n2 & 0x7) * 16;
    }
    
    @Override
    protected int b(final int n) {
        return n;
    }
    
    public static int c(final int n) {
        return ~n & 0xF;
    }
    
    public static int d(final int n) {
        return ~n & 0xF;
    }
}
