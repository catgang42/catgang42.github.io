// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockReed extends Block
{
    protected BlockReed(final int n, final int textureId) {
        super(n, Material.PLANT);
        this.textureId = textureId;
        final float n2 = 0.375f;
        this.a(0.5f - n2, 0.0f, 0.5f - n2, 0.5f + n2, 1.0f, 0.5f + n2);
        this.a(true);
    }
    
    @Override
    public void a(final World world, final int n, final int j, final int n2, final Random random) {
        if (world.isEmpty(n, j + 1, n2)) {
            int n3;
            for (n3 = 1; world.getTypeId(n, j - n3, n2) == this.id; ++n3) {}
            if (n3 < 3) {
                final int data = world.getData(n, j, n2);
                if (data == 15) {
                    world.e(n, j + 1, n2, this.id);
                    world.c(n, j, n2, 0);
                }
                else {
                    world.c(n, j, n2, data + 1);
                }
            }
        }
    }
    
    @Override
    public boolean a(final World world, final int i, final int n, final int k) {
        final int typeId = world.getTypeId(i, n - 1, k);
        return typeId == this.id || ((typeId == Block.GRASS.id || typeId == Block.DIRT.id) && (world.getMaterial(i - 1, n - 1, k) == Material.WATER || world.getMaterial(i + 1, n - 1, k) == Material.WATER || world.getMaterial(i, n - 1, k - 1) == Material.WATER || world.getMaterial(i, n - 1, k + 1) == Material.WATER));
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        this.g(world, n, n2, n3);
    }
    
    protected final void g(final World world, final int n, final int n2, final int n3) {
        if (!this.f(world, n, n2, n3)) {
            this.b_(world, n, n2, n3, world.getData(n, n2, n3));
            world.e(n, n2, n3, 0);
        }
    }
    
    @Override
    public boolean f(final World world, final int n, final int n2, final int n3) {
        return this.a(world, n, n2, n3);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Item.SUGAR_CANE.id;
    }
    
    @Override
    public boolean a() {
        return false;
    }
}
