// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemRecord extends Item
{
    private String a;
    
    protected ItemRecord(final int n, final String a) {
        super(n);
        this.a = a;
        this.maxStackSize = 1;
    }
    
    @Override
    public boolean a(final ItemStack itemStack, final EntityHuman entityHuman, final World world, final int n, final int n2, final int n3, final int n4) {
        if (world.getTypeId(n, n2, n3) == Block.JUKEBOX.id && world.getData(n, n2, n3) == 0) {
            world.c(n, n2, n3, this.id - Item.GOLD_RECORD.id + 1);
            world.a(this.a, n, n2, n3);
            --itemStack.count;
            return true;
        }
        return false;
    }
}
