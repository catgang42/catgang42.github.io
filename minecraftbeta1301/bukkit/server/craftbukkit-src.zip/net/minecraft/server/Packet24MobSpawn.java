// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.util.List;

public class Packet24MobSpawn extends Packet
{
    public int a;
    public byte b;
    public int c;
    public int d;
    public int e;
    public byte f;
    public byte g;
    private DataWatcher h;
    private List i;
    
    public Packet24MobSpawn() {
    }
    
    public Packet24MobSpawn(final EntityLiving entityLiving) {
        this.a = entityLiving.id;
        this.b = (byte)EntityTypes.a(entityLiving);
        this.c = MathHelper.b(entityLiving.locX * 32.0);
        this.d = MathHelper.b(entityLiving.locY * 32.0);
        this.e = MathHelper.b(entityLiving.locZ * 32.0);
        this.f = (byte)(entityLiving.yaw * 256.0f / 360.0f);
        this.g = (byte)(entityLiving.pitch * 256.0f / 360.0f);
        this.h = entityLiving.O();
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readByte();
        this.c = dataInputStream.readInt();
        this.d = dataInputStream.readInt();
        this.e = dataInputStream.readInt();
        this.f = dataInputStream.readByte();
        this.g = dataInputStream.readByte();
        this.i = DataWatcher.a(dataInputStream);
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeByte(this.b);
        dataOutputStream.writeInt(this.c);
        dataOutputStream.writeInt(this.d);
        dataOutputStream.writeInt(this.e);
        dataOutputStream.writeByte(this.f);
        dataOutputStream.writeByte(this.g);
        this.h.a(dataOutputStream);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 20;
    }
}
