// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public interface IProgressUpdate
{
    void a(final String p0);
    
    void b(final String p0);
    
    void a(final int p0);
}
