// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet102WindowClick extends Packet
{
    public int a;
    public int b;
    public int c;
    public short d;
    public ItemStack e;
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readByte();
        this.b = dataInputStream.readShort();
        this.c = dataInputStream.readByte();
        this.d = dataInputStream.readShort();
        final short short1 = dataInputStream.readShort();
        if (short1 >= 0) {
            this.e = new ItemStack(short1, dataInputStream.readByte(), dataInputStream.readShort());
        }
        else {
            this.e = null;
        }
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeByte(this.a);
        dataOutputStream.writeShort(this.b);
        dataOutputStream.writeByte(this.c);
        dataOutputStream.writeShort(this.d);
        if (this.e == null) {
            dataOutputStream.writeShort(-1);
        }
        else {
            dataOutputStream.writeShort(this.e.id);
            dataOutputStream.writeByte(this.e.count);
            dataOutputStream.writeShort(this.e.h());
        }
    }
    
    @Override
    public int a() {
        return 11;
    }
}
