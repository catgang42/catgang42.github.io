// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockGlass extends BlockBreakable
{
    public BlockGlass(final int n, final int n2, final Material material, final boolean b) {
        super(n, n2, material, b);
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
}
