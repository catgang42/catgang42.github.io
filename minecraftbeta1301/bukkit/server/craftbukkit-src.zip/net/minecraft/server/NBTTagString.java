// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public class NBTTagString extends NBTBase
{
    public String a;
    
    public NBTTagString() {
    }
    
    public NBTTagString(final String a) {
        this.a = a;
        if (a == null) {
            throw new IllegalArgumentException("Empty string not allowed");
        }
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        dataOutput.writeUTF(this.a);
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.a = dataInput.readUTF();
    }
    
    @Override
    public byte a() {
        return 8;
    }
    
    @Override
    public String toString() {
        return "" + this.a;
    }
}
