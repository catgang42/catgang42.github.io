// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.util.List;

public class Packet40EntityMetadata extends Packet
{
    public int a;
    private List b;
    
    public Packet40EntityMetadata() {
    }
    
    public Packet40EntityMetadata(final int a, final DataWatcher dataWatcher) {
        this.a = a;
        this.b = dataWatcher.b();
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = DataWatcher.a(dataInputStream);
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        DataWatcher.a(this.b, dataOutputStream);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 5;
    }
}
