// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class WorldGenFlowers extends WorldGenerator
{
    private int a;
    
    public WorldGenFlowers(final int a) {
        this.a = a;
    }
    
    @Override
    public boolean a(final World world, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 64; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int n5 = n2 + random.nextInt(4) - random.nextInt(4);
            final int n6 = n3 + random.nextInt(8) - random.nextInt(8);
            if (world.isEmpty(n4, n5, n6) && ((BlockFlower)Block.byId[this.a]).f(world, n4, n5, n6)) {
                world.setTypeId(n4, n5, n6, this.a);
            }
        }
        return true;
    }
}
