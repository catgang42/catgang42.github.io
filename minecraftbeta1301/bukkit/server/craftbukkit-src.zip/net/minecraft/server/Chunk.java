// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;
import java.util.Collection;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.CraftChunk;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Chunk
{
    public static boolean a;
    public byte[] b;
    public boolean c;
    public World d;
    public NibbleArray e;
    public NibbleArray f;
    public NibbleArray g;
    public byte[] h;
    public int i;
    public final int j;
    public final int k;
    public Map l;
    public List[] m;
    public boolean n;
    public boolean o;
    public boolean p;
    public boolean q;
    public long r;
    public org.bukkit.Chunk bukkitChunk;
    
    public Chunk(final World world, final int i, final int j) {
        this.l = new HashMap();
        this.m = new List[8];
        this.n = false;
        this.o = false;
        this.q = false;
        this.r = 0L;
        this.d = world;
        this.j = i;
        this.k = j;
        this.h = new byte[256];
        for (int k = 0; k < this.m.length; ++k) {
            this.m[k] = new ArrayList();
        }
        final CraftWorld cw = ((WorldServer)world).getWorld();
        this.bukkitChunk = ((cw == null) ? null : cw.popPreservedChunk(i, j));
        if (this.bukkitChunk == null) {
            this.bukkitChunk = new CraftChunk(this);
        }
    }
    
    public Chunk(final World world, final byte[] abyte, final int i, final int j) {
        this(world, i, j);
        this.b = abyte;
        this.e = new NibbleArray(abyte.length);
        this.f = new NibbleArray(abyte.length);
        this.g = new NibbleArray(abyte.length);
    }
    
    public boolean a(final int i, final int j) {
        return i == this.j && j == this.k;
    }
    
    public int b(final int i, final int j) {
        return this.h[j << 4 | i] & 0xFF;
    }
    
    public void a() {
    }
    
    public void b() {
        int i = 127;
        for (int j = 0; j < 16; ++j) {
            for (int k = 0; k < 16; ++k) {
                int l;
                int i2;
                for (l = 127, i2 = (j << 11 | k << 7); l > 0 && Block.q[this.b[i2 + l - 1]] == 0; --l) {}
                this.h[k << 4 | j] = (byte)l;
                if (l < i) {
                    i = l;
                }
                if (!this.d.m.e) {
                    int j2 = 15;
                    int k2 = 127;
                    do {
                        j2 -= Block.q[this.b[i2 + k2]];
                        if (j2 > 0) {
                            this.f.a(j, k2, k, j2);
                        }
                    } while (--k2 > 0 && j2 > 0);
                }
            }
        }
        this.i = i;
        for (int j = 0; j < 16; ++j) {
            for (int k = 0; k < 16; ++k) {
                this.c(j, k);
            }
        }
        this.o = true;
    }
    
    public void c() {
    }
    
    private void c(final int i, final int j) {
        final int k = this.b(i, j);
        final int l = this.j * 16 + i;
        final int i2 = this.k * 16 + j;
        this.f(l - 1, i2, k);
        this.f(l + 1, i2, k);
        this.f(l, i2 - 1, k);
        this.f(l, i2 + 1, k);
    }
    
    private void f(final int i, final int j, final int k) {
        final int l = this.d.d(i, j);
        if (l > k) {
            this.d.a(EnumSkyBlock.SKY, i, k, j, i, l, j);
            this.o = true;
        }
        else if (l < k) {
            this.d.a(EnumSkyBlock.SKY, i, l, j, i, k, j);
            this.o = true;
        }
    }
    
    private void g(final int i, final int j, final int k) {
        int i2;
        final int l = i2 = (this.h[k << 4 | i] & 0xFF);
        if (j > l) {
            i2 = j;
        }
        for (int j2 = i << 11 | k << 7; i2 > 0 && Block.q[this.b[j2 + i2 - 1]] == 0; --i2) {}
        if (i2 != l) {
            this.d.g(i, k, i2, l);
            this.h[k << 4 | i] = (byte)i2;
            if (i2 < this.i) {
                this.i = i2;
            }
            else {
                int k2 = 127;
                for (int l2 = 0; l2 < 16; ++l2) {
                    for (int i3 = 0; i3 < 16; ++i3) {
                        if ((this.h[i3 << 4 | l2] & 0xFF) < k2) {
                            k2 = (this.h[i3 << 4 | l2] & 0xFF);
                        }
                    }
                }
                this.i = k2;
            }
            int k2 = this.j * 16 + i;
            int l2 = this.k * 16 + k;
            if (i2 < l) {
                for (int i3 = i2; i3 < l; ++i3) {
                    this.f.a(i, i3, k, 15);
                }
            }
            else {
                this.d.a(EnumSkyBlock.SKY, k2, l, l2, k2, i2, l2);
                for (int i3 = l; i3 < i2; ++i3) {
                    this.f.a(i, i3, k, 0);
                }
            }
            int i3 = 15;
            final int j3 = i2;
            while (i2 > 0 && i3 > 0) {
                --i2;
                int k3 = Block.q[this.a(i, i2, k)];
                if (k3 == 0) {
                    k3 = 1;
                }
                i3 -= k3;
                if (i3 < 0) {
                    i3 = 0;
                }
                this.f.a(i, i2, k, i3);
            }
            while (i2 > 0 && Block.q[this.a(i, i2 - 1, k)] == 0) {
                --i2;
            }
            if (i2 != j3) {
                this.d.a(EnumSkyBlock.SKY, k2 - 1, i2, l2 - 1, k2 + 1, j3, l2 + 1);
            }
            this.o = true;
        }
    }
    
    public int a(final int i, final int j, final int k) {
        return this.b[i << 11 | k << 7 | j];
    }
    
    public boolean a(final int i, final int j, final int k, final int l, final int i1) {
        final byte b0 = (byte)l;
        final int j2 = this.h[k << 4 | i] & 0xFF;
        final int k2 = this.b[i << 11 | k << 7 | j] & 0xFF;
        if (k2 == l && this.e.a(i, j, k) == i1) {
            return false;
        }
        final int l2 = this.j * 16 + i;
        final int i2 = this.k * 16 + k;
        this.b[i << 11 | k << 7 | j] = b0;
        if (k2 != 0 && !this.d.isStatic) {
            Block.byId[k2].b(this.d, l2, j, i2);
        }
        this.e.a(i, j, k, i1);
        if (!this.d.m.e) {
            if (Block.q[b0] != 0) {
                if (j >= j2) {
                    this.g(i, j + 1, k);
                }
            }
            else if (j == j2 - 1) {
                this.g(i, j, k);
            }
            this.d.a(EnumSkyBlock.SKY, l2, j, i2, l2, j, i2);
        }
        this.d.a(EnumSkyBlock.BLOCK, l2, j, i2, l2, j, i2);
        this.c(i, k);
        this.e.a(i, j, k, i1);
        if (l != 0) {
            Block.byId[l].e(this.d, l2, j, i2);
        }
        return this.o = true;
    }
    
    public boolean a(final int i, final int j, final int k, final int l) {
        final byte b0 = (byte)l;
        final int i2 = this.h[k << 4 | i] & 0xFF;
        final int j2 = this.b[i << 11 | k << 7 | j] & 0xFF;
        if (j2 == l) {
            return false;
        }
        final int k2 = this.j * 16 + i;
        final int l2 = this.k * 16 + k;
        this.b[i << 11 | k << 7 | j] = b0;
        if (j2 != 0) {
            Block.byId[j2].b(this.d, k2, j, l2);
        }
        this.e.a(i, j, k, 0);
        if (Block.q[b0] != 0) {
            if (j >= i2) {
                this.g(i, j + 1, k);
            }
        }
        else if (j == i2 - 1) {
            this.g(i, j, k);
        }
        this.d.a(EnumSkyBlock.SKY, k2, j, l2, k2, j, l2);
        this.d.a(EnumSkyBlock.BLOCK, k2, j, l2, k2, j, l2);
        this.c(i, k);
        if (l != 0 && !this.d.isStatic) {
            Block.byId[l].e(this.d, k2, j, l2);
        }
        return this.o = true;
    }
    
    public int b(final int i, final int j, final int k) {
        return this.e.a(i, j, k);
    }
    
    public void b(final int i, final int j, final int k, final int l) {
        this.o = true;
        this.e.a(i, j, k, l);
    }
    
    public int a(final EnumSkyBlock enumskyblock, final int i, final int j, final int k) {
        return (enumskyblock == EnumSkyBlock.SKY) ? this.f.a(i, j, k) : ((enumskyblock == EnumSkyBlock.BLOCK) ? this.g.a(i, j, k) : 0);
    }
    
    public void a(final EnumSkyBlock enumskyblock, final int i, final int j, final int k, final int l) {
        this.o = true;
        if (enumskyblock == EnumSkyBlock.SKY) {
            this.f.a(i, j, k, l);
        }
        else {
            if (enumskyblock != EnumSkyBlock.BLOCK) {
                return;
            }
            this.g.a(i, j, k, l);
        }
    }
    
    public int c(final int i, final int j, final int k, final int l) {
        int i2 = this.f.a(i, j, k);
        if (i2 > 0) {
            Chunk.a = true;
        }
        i2 -= l;
        final int j2 = this.g.a(i, j, k);
        if (j2 > i2) {
            i2 = j2;
        }
        return i2;
    }
    
    public void a(final Entity entity) {
        this.q = true;
        final int i = MathHelper.b(entity.locX / 16.0);
        final int j = MathHelper.b(entity.locZ / 16.0);
        if (i != this.j || j != this.k) {
            System.out.println("Wrong location! " + entity);
            System.out.println("" + entity.locX + "," + entity.locZ + "(" + i + "," + j + ") vs " + this.j + "," + this.k);
            Thread.dumpStack();
        }
        int k = MathHelper.b(entity.locY / 16.0);
        if (k < 0) {
            k = 0;
        }
        if (k >= this.m.length) {
            k = this.m.length - 1;
        }
        entity.bA = true;
        entity.chunkX = this.j;
        entity.bC = k;
        entity.chunkZ = this.k;
        this.m[k].add(entity);
    }
    
    public void b(final Entity entity) {
        this.a(entity, entity.bC);
    }
    
    public void a(final Entity entity, int i) {
        if (i < 0) {
            i = 0;
        }
        if (i >= this.m.length) {
            i = this.m.length - 1;
        }
        this.m[i].remove(entity);
    }
    
    public boolean c(final int i, final int j, final int k) {
        return j >= (this.h[k << 4 | i] & 0xFF);
    }
    
    public TileEntity d(final int i, final int j, final int k) {
        final ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        TileEntity tileentity = this.l.get(chunkposition);
        if (tileentity == null) {
            final int l = this.a(i, j, k);
            if (!Block.p[l]) {
                return null;
            }
            final BlockContainer blockcontainer = (BlockContainer)Block.byId[l];
            blockcontainer.e(this.d, this.j * 16 + i, j, this.k * 16 + k);
            tileentity = this.l.get(chunkposition);
        }
        return tileentity;
    }
    
    public void a(final TileEntity tileentity) {
        final int i = tileentity.e - this.j * 16;
        final int j = tileentity.f;
        final int k = tileentity.g - this.k * 16;
        this.a(i, j, k, tileentity);
    }
    
    public void a(final int i, final int j, final int k, final TileEntity tileentity) {
        final ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        tileentity.d = this.d;
        tileentity.e = this.j * 16 + i;
        tileentity.f = j;
        tileentity.g = this.k * 16 + k;
        if (this.a(i, j, k) != 0 && Block.byId[this.a(i, j, k)] instanceof BlockContainer) {
            if (this.c) {
                if (this.l.get(chunkposition) != null) {
                    this.d.c.remove(this.l.get(chunkposition));
                }
                this.d.c.add(tileentity);
            }
            this.l.put(chunkposition, tileentity);
        }
        else {
            System.out.println("Attempted to place a tile entity where there was no entity tile!");
        }
    }
    
    public void e(final int i, final int j, final int k) {
        final ChunkPosition chunkposition = new ChunkPosition(i, j, k);
        if (this.c) {
            this.d.c.remove(this.l.remove(chunkposition));
        }
    }
    
    public void d() {
        this.c = true;
        this.d.c.addAll(this.l.values());
        for (int i = 0; i < this.m.length; ++i) {
            this.d.a(this.m[i]);
        }
    }
    
    public void e() {
        this.c = false;
        this.d.c.removeAll(this.l.values());
        for (int i = 0; i < this.m.length; ++i) {
            this.d.b(this.m[i]);
        }
    }
    
    public void f() {
        this.o = true;
    }
    
    public void a(final Entity entity, final AxisAlignedBB axisalignedbb, final List list) {
        int i = MathHelper.b((axisalignedbb.b - 2.0) / 16.0);
        int j = MathHelper.b((axisalignedbb.e + 2.0) / 16.0);
        if (i < 0) {
            i = 0;
        }
        if (j >= this.m.length) {
            j = this.m.length - 1;
        }
        for (int k = i; k <= j; ++k) {
            final List list2 = this.m[k];
            for (int l = 0; l < list2.size(); ++l) {
                final Entity entity2 = list2.get(l);
                if (entity2 != entity && entity2.boundingBox.a(axisalignedbb)) {
                    list.add(entity2);
                }
            }
        }
    }
    
    public void a(final Class oclass, final AxisAlignedBB axisalignedbb, final List list) {
        int i = MathHelper.b((axisalignedbb.b - 2.0) / 16.0);
        int j = MathHelper.b((axisalignedbb.e + 2.0) / 16.0);
        if (i < 0) {
            i = 0;
        }
        if (j >= this.m.length) {
            j = this.m.length - 1;
        }
        for (int k = i; k <= j; ++k) {
            final List list2 = this.m[k];
            for (int l = 0; l < list2.size(); ++l) {
                final Entity entity = list2.get(l);
                if (oclass.isAssignableFrom(entity.getClass()) && entity.boundingBox.a(axisalignedbb)) {
                    list.add(entity);
                }
            }
        }
    }
    
    public boolean a(final boolean flag) {
        if (this.p) {
            return false;
        }
        if (flag) {
            if (this.q && this.d.k() != this.r) {
                return true;
            }
        }
        else if (this.q && this.d.k() >= this.r + 600L) {
            return true;
        }
        return this.o;
    }
    
    public int a(final byte[] abyte, final int i, final int j, final int k, final int l, final int i1, final int j1, int k1) {
        for (int l2 = i; l2 < l; ++l2) {
            for (int i2 = k; i2 < j1; ++i2) {
                final int j2 = l2 << 11 | i2 << 7 | j;
                final int k2 = i1 - j;
                System.arraycopy(this.b, j2, abyte, k1, k2);
                k1 += k2;
            }
        }
        for (int l2 = i; l2 < l; ++l2) {
            for (int i2 = k; i2 < j1; ++i2) {
                final int j2 = (l2 << 11 | i2 << 7 | j) >> 1;
                final int k2 = (i1 - j) / 2;
                System.arraycopy(this.e.a, j2, abyte, k1, k2);
                k1 += k2;
            }
        }
        for (int l2 = i; l2 < l; ++l2) {
            for (int i2 = k; i2 < j1; ++i2) {
                final int j2 = (l2 << 11 | i2 << 7 | j) >> 1;
                final int k2 = (i1 - j) / 2;
                System.arraycopy(this.g.a, j2, abyte, k1, k2);
                k1 += k2;
            }
        }
        for (int l2 = i; l2 < l; ++l2) {
            for (int i2 = k; i2 < j1; ++i2) {
                final int j2 = (l2 << 11 | i2 << 7 | j) >> 1;
                final int k2 = (i1 - j) / 2;
                System.arraycopy(this.f.a, j2, abyte, k1, k2);
                k1 += k2;
            }
        }
        return k1;
    }
    
    public Random a(final long i) {
        return new Random(this.d.j() + this.j * this.j * 4987142 + this.j * 5947611 + this.k * this.k * 4392871L + this.k * 389711 ^ i);
    }
    
    public boolean g() {
        return false;
    }
}
