// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.HashMap;
import java.util.Comparator;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;

public class CraftingManager
{
    private static final CraftingManager a;
    private List b;
    
    public static final CraftingManager a() {
        return CraftingManager.a;
    }
    
    private CraftingManager() {
        this.b = new ArrayList();
        new RecipesTools().a(this);
        new RecipesWeapons().a(this);
        new RecipeIngots().a(this);
        new RecipesFood().a(this);
        new RecipesCrafting().a(this);
        new RecipesArmor().a(this);
        new RecipesDyes().a(this);
        this.a(new ItemStack(Item.PAPER, 3), "###", '#', Item.SUGAR_CANE);
        this.a(new ItemStack(Item.BOOK, 1), "#", "#", "#", '#', Item.PAPER);
        this.a(new ItemStack(Block.FENCE, 2), "###", "###", '#', Item.STICK);
        this.a(new ItemStack(Block.JUKEBOX, 1), "###", "#X#", "###", '#', Block.WOOD, 'X', Item.DIAMOND);
        this.a(new ItemStack(Block.NOTE_BLOCK, 1), "###", "#X#", "###", '#', Block.WOOD, 'X', Item.REDSTONE);
        this.a(new ItemStack(Block.BOOKSHELF, 1), "###", "XXX", "###", '#', Block.WOOD, 'X', Item.BOOK);
        this.a(new ItemStack(Block.SNOW_BLOCK, 1), "##", "##", '#', Item.SNOW_BALL);
        this.a(new ItemStack(Block.CLAY, 1), "##", "##", '#', Item.CLAY_BALL);
        this.a(new ItemStack(Block.BRICK, 1), "##", "##", '#', Item.CLAY_BRICK);
        this.a(new ItemStack(Block.GLOWSTONE, 1), "###", "###", "###", '#', Item.GLOWSTONE_DUST);
        this.a(new ItemStack(Block.WOOL, 1), "###", "###", "###", '#', Item.STRING);
        this.a(new ItemStack(Block.TNT, 1), "X#X", "#X#", "X#X", 'X', Item.SULPHUR, '#', Block.SAND);
        this.a(new ItemStack(Block.STEP, 3, 3), "###", '#', Block.COBBLESTONE);
        this.a(new ItemStack(Block.STEP, 3, 0), "###", '#', Block.STONE);
        this.a(new ItemStack(Block.STEP, 3, 1), "###", '#', Block.SANDSTONE);
        this.a(new ItemStack(Block.STEP, 3, 2), "###", '#', Block.WOOD);
        this.a(new ItemStack(Block.LADDER, 1), "# #", "###", "# #", '#', Item.STICK);
        this.a(new ItemStack(Item.WOOD_DOOR, 1), "##", "##", "##", '#', Block.WOOD);
        this.a(new ItemStack(Item.IRON_DOOR, 1), "##", "##", "##", '#', Item.IRON_INGOT);
        this.a(new ItemStack(Item.SIGN, 1), "###", "###", " X ", '#', Block.WOOD, 'X', Item.STICK);
        this.a(new ItemStack(Item.CAKE, 1), "AAA", "BEB", "CCC", 'A', Item.MILK_BUCKET, 'B', Item.SUGAR, 'C', Item.WHEAT, 'E', Item.EGG);
        this.a(new ItemStack(Item.SUGAR, 1), "#", '#', Item.SUGAR_CANE);
        this.a(new ItemStack(Block.WOOD, 4), "#", '#', Block.LOG);
        this.a(new ItemStack(Item.STICK, 4), "#", "#", '#', Block.WOOD);
        this.a(new ItemStack(Block.TORCH, 4), "X", "#", 'X', Item.COAL, '#', Item.STICK);
        this.a(new ItemStack(Block.TORCH, 4), "X", "#", 'X', new ItemStack(Item.COAL, 1, 1), '#', Item.STICK);
        this.a(new ItemStack(Item.BOWL, 4), "# #", " # ", '#', Block.WOOD);
        this.a(new ItemStack(Block.RAILS, 16), "X X", "X#X", "X X", 'X', Item.IRON_INGOT, '#', Item.STICK);
        this.a(new ItemStack(Item.MINECART, 1), "# #", "###", '#', Item.IRON_INGOT);
        this.a(new ItemStack(Block.JACK_O_LANTERN, 1), "A", "B", 'A', Block.PUMPKIN, 'B', Block.TORCH);
        this.a(new ItemStack(Item.STORAGE_MINECART, 1), "A", "B", 'A', Block.CHEST, 'B', Item.MINECART);
        this.a(new ItemStack(Item.POWERED_MINECART, 1), "A", "B", 'A', Block.FURNACE, 'B', Item.MINECART);
        this.a(new ItemStack(Item.BOAT, 1), "# #", "###", '#', Block.WOOD);
        this.a(new ItemStack(Item.BUCKET, 1), "# #", " # ", '#', Item.IRON_INGOT);
        this.a(new ItemStack(Item.FLINT_AND_STEEL, 1), "A ", " B", 'A', Item.IRON_INGOT, 'B', Item.FLINT);
        this.a(new ItemStack(Item.BREAD, 1), "###", '#', Item.WHEAT);
        this.a(new ItemStack(Block.WOOD_STAIRS, 4), "#  ", "## ", "###", '#', Block.WOOD);
        this.a(new ItemStack(Item.FISHING_ROD, 1), "  #", " #X", "# X", '#', Item.STICK, 'X', Item.STRING);
        this.a(new ItemStack(Block.COBBLESTONE_STAIRS, 4), "#  ", "## ", "###", '#', Block.COBBLESTONE);
        this.a(new ItemStack(Item.PAINTING, 1), "###", "#X#", "###", '#', Item.STICK, 'X', Block.WOOL);
        this.a(new ItemStack(Item.GOLDEN_APPLE, 1), "###", "#X#", "###", '#', Block.GOLD_BLOCK, 'X', Item.APPLE);
        this.a(new ItemStack(Block.LEVER, 1), "X", "#", '#', Block.COBBLESTONE, 'X', Item.STICK);
        this.a(new ItemStack(Block.REDSTONE_TORCH_ON, 1), "X", "#", '#', Item.STICK, 'X', Item.REDSTONE);
        this.a(new ItemStack(Item.DIODE, 1), "#X#", "III", '#', Block.REDSTONE_TORCH_ON, 'X', Item.REDSTONE, 'I', Block.STONE);
        this.a(new ItemStack(Item.WATCH, 1), " # ", "#X#", " # ", '#', Item.GOLD_INGOT, 'X', Item.REDSTONE);
        this.a(new ItemStack(Item.COMPASS, 1), " # ", "#X#", " # ", '#', Item.IRON_INGOT, 'X', Item.REDSTONE);
        this.a(new ItemStack(Block.STONE_BUTTON, 1), "#", "#", '#', Block.STONE);
        this.a(new ItemStack(Block.STONE_PLATE, 1), "##", '#', Block.STONE);
        this.a(new ItemStack(Block.WOOD_PLATE, 1), "##", '#', Block.WOOD);
        this.a(new ItemStack(Block.DISPENSER, 1), "###", "#X#", "#R#", '#', Block.COBBLESTONE, 'X', Item.BOW, 'R', Item.REDSTONE);
        this.a(new ItemStack(Item.BED, 1), "###", "XXX", '#', Block.WOOL, 'X', Block.WOOD);
        Collections.sort((List<Object>)this.b, new RecipeSorter(this));
        System.out.println(this.b.size() + " recipes");
    }
    
    void a(final ItemStack itemStack, final Object... array) {
        String s = "";
        int i = 0;
        int n = 0;
        int n2 = 0;
        if (array[i] instanceof String[]) {
            final String[] array2 = (String[])array[i++];
            for (int j = 0; j < array2.length; ++j) {
                final String str = array2[j];
                ++n2;
                n = str.length();
                s += str;
            }
        }
        else {
            while (array[i] instanceof String) {
                final String str2 = (String)array[i++];
                ++n2;
                n = str2.length();
                s += str2;
            }
        }
        final HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
        while (i < array.length) {
            final Character c = (Character)array[i];
            ItemStack itemStack2 = null;
            if (array[i + 1] instanceof Item) {
                itemStack2 = new ItemStack((Item)array[i + 1]);
            }
            else if (array[i + 1] instanceof Block) {
                itemStack2 = new ItemStack((Block)array[i + 1], 1, -1);
            }
            else if (array[i + 1] instanceof ItemStack) {
                itemStack2 = (ItemStack)array[i + 1];
            }
            hashMap.put(c, itemStack2);
            i += 2;
        }
        final ItemStack[] array3 = new ItemStack[n * n2];
        for (int k = 0; k < n * n2; ++k) {
            final char char1 = s.charAt(k);
            if (hashMap.containsKey(char1)) {
                array3[k] = hashMap.get(char1).j();
            }
            else {
                array3[k] = null;
            }
        }
        this.b.add(new ShapedRecipes(n, n2, array3, itemStack));
    }
    
    void b(final ItemStack itemStack, final Object... array) {
        final ArrayList<ItemStack> list = new ArrayList<ItemStack>();
        for (final Object o : array) {
            if (o instanceof ItemStack) {
                list.add(((ItemStack)o).j());
            }
            else if (o instanceof Item) {
                list.add(new ItemStack((Item)o));
            }
            else {
                if (!(o instanceof Block)) {
                    throw new RuntimeException("Invalid shapeless recipy!");
                }
                list.add(new ItemStack((Block)o));
            }
        }
        this.b.add(new ShapelessRecipes(itemStack, list));
    }
    
    public ItemStack a(final InventoryCrafting inventoryCrafting) {
        for (int i = 0; i < this.b.size(); ++i) {
            final CraftingRecipe craftingRecipe = this.b.get(i);
            if (craftingRecipe.a(inventoryCrafting)) {
                return craftingRecipe.b(inventoryCrafting);
            }
        }
        return null;
    }
    
    static {
        a = new CraftingManager();
    }
}
