// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet17 extends Packet
{
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    
    public Packet17() {
    }
    
    public Packet17(final Entity entity, final int e, final int b, final int c, final int d) {
        this.e = e;
        this.b = b;
        this.c = c;
        this.d = d;
        this.a = entity.id;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.e = dataInputStream.readByte();
        this.b = dataInputStream.readInt();
        this.c = dataInputStream.readByte();
        this.d = dataInputStream.readInt();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeByte(this.e);
        dataOutputStream.writeInt(this.b);
        dataOutputStream.writeByte(this.c);
        dataOutputStream.writeInt(this.d);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 14;
    }
}
