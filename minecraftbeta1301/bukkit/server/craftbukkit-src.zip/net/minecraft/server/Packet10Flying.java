// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet10Flying extends Packet
{
    public double a;
    public double b;
    public double c;
    public double d;
    public float e;
    public float f;
    public boolean g;
    public boolean h;
    public boolean i;
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.g = (dataInputStream.read() != 0);
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.write(this.g ? 1 : 0);
    }
    
    @Override
    public int a() {
        return 1;
    }
}
