// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemFood extends Item
{
    private int a;
    
    public ItemFood(final int n, final int a) {
        super(n);
        this.a = a;
        this.maxStackSize = 1;
    }
    
    @Override
    public ItemStack a(final ItemStack itemStack, final World world, final EntityHuman entityHuman) {
        --itemStack.count;
        entityHuman.b(this.a);
        return itemStack;
    }
}
