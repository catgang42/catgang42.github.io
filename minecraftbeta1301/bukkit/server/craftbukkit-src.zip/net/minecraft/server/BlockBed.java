// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockBed extends Block
{
    public static final int[][] a;
    
    public BlockBed(final int n) {
        super(n, 134, Material.CLOTH);
        this.f();
    }
    
    @Override
    public boolean a(final World world, int n, final int n2, int n3, final EntityHuman entityHuman) {
        int n4 = world.getData(n, n2, n3);
        if (!d(n4)) {
            final int c = c(n4);
            n += BlockBed.a[c][0];
            n3 += BlockBed.a[c][1];
            if (world.getTypeId(n, n2, n3) != this.id) {
                return true;
            }
            n4 = world.getData(n, n2, n3);
        }
        if (f(n4)) {
            entityHuman.a("tile.bed.occupied");
            return true;
        }
        if (entityHuman.a(n, n2, n3)) {
            a(world, n, n2, n3, true);
            return true;
        }
        entityHuman.a("tile.bed.noSleep");
        return true;
    }
    
    @Override
    public int a(final int n, final int n2) {
        if (n == 0) {
            return Block.WOOD.textureId;
        }
        final int n3 = BedBlockTextures.c[c(n2)][n];
        if (d(n2)) {
            if (n3 == 2) {
                return this.textureId + 2 + 16;
            }
            if (n3 == 5 || n3 == 4) {
                return this.textureId + 1 + 16;
            }
            return this.textureId + 1;
        }
        else {
            if (n3 == 3) {
                return this.textureId - 1 + 16;
            }
            if (n3 == 5 || n3 == 4) {
                return this.textureId + 16;
            }
            return this.textureId;
        }
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public void a(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
        this.f();
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int n) {
        final int data = world.getData(i, j, k);
        final int c = c(data);
        if (d(data)) {
            if (world.getTypeId(i - BlockBed.a[c][0], j, k - BlockBed.a[c][1]) != this.id) {
                world.e(i, j, k, 0);
            }
        }
        else if (world.getTypeId(i + BlockBed.a[c][0], j, k + BlockBed.a[c][1]) != this.id) {
            world.e(i, j, k, 0);
            if (!world.isStatic) {
                this.b_(world, i, j, k, data);
            }
        }
    }
    
    @Override
    public int a(final int n, final Random random) {
        if (d(n)) {
            return 0;
        }
        return Item.BED.id;
    }
    
    private void f() {
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.5625f, 1.0f);
    }
    
    public static int c(final int n) {
        return n & 0x3;
    }
    
    public static boolean d(final int n) {
        return (n & 0x8) != 0x0;
    }
    
    public static boolean f(final int n) {
        return (n & 0x4) != 0x0;
    }
    
    public static void a(final World world, final int n, final int n2, final int n3, final boolean b) {
        final int data = world.getData(n, n2, n3);
        int l;
        if (b) {
            l = (data | 0x4);
        }
        else {
            l = (data & 0xFFFFFFFB);
        }
        world.c(n, n2, n3, l);
    }
    
    public static ChunkCoordinates g(final World world, final int i, final int n, final int k, int n2) {
        final int c = c(world.getData(i, n, k));
        for (int j = 0; j <= 1; ++j) {
            final int n3 = i - BlockBed.a[c][0] * j - 1;
            final int n4 = k - BlockBed.a[c][1] * j - 1;
            final int n5 = n3 + 2;
            final int n6 = n4 + 2;
            for (int l = n3; l <= n5; ++l) {
                for (int m = n4; m <= n6; ++m) {
                    if (world.d(l, n - 1, m) && world.isEmpty(l, n, m) && world.isEmpty(l, n + 1, m)) {
                        if (n2 <= 0) {
                            return new ChunkCoordinates(l, n, m);
                        }
                        --n2;
                    }
                }
            }
        }
        return new ChunkCoordinates(i, n + 1, k);
    }
    
    static {
        a = new int[][] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 } };
    }
}
