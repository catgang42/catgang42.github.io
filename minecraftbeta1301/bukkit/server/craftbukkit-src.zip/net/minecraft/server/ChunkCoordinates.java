// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ChunkCoordinates implements Comparable
{
    public int a;
    public int b;
    public int c;
    
    public ChunkCoordinates() {
    }
    
    public ChunkCoordinates(final int a, final int b, final int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof ChunkCoordinates)) {
            return false;
        }
        final ChunkCoordinates chunkCoordinates = (ChunkCoordinates)o;
        return this.a == chunkCoordinates.a && this.b == chunkCoordinates.b && this.c == chunkCoordinates.c;
    }
    
    @Override
    public int hashCode() {
        return this.a + this.c << 8 + this.b << 16;
    }
    
    public int compareTo(final ChunkCoordinates chunkCoordinates) {
        if (this.b != chunkCoordinates.b) {
            return this.b - chunkCoordinates.b;
        }
        if (this.c == chunkCoordinates.c) {
            return this.a - chunkCoordinates.a;
        }
        return this.c - chunkCoordinates.c;
    }
}
