// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

class SlotArmor extends Slot
{
    final /* synthetic */ int d;
    final /* synthetic */ ContainerPlayer e;
    
    SlotArmor(final ContainerPlayer e, final IInventory iinventory, final int i, final int j, final int k, final int d) {
        this.e = e;
        this.d = d;
        super(iinventory, i, j, k);
    }
    
    @Override
    public int d() {
        return 1;
    }
    
    @Override
    public boolean a(final ItemStack itemStack) {
        if (itemStack.a() instanceof ItemArmor) {
            return ((ItemArmor)itemStack.a()).bi == this.d;
        }
        return itemStack.a().id == Block.PUMPKIN.id && this.d == 0;
    }
}
