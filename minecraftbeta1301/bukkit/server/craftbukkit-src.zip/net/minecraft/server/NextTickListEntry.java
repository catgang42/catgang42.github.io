// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class NextTickListEntry implements Comparable
{
    private static long f;
    public int a;
    public int b;
    public int c;
    public int d;
    public long e;
    private long g;
    
    public NextTickListEntry(final int a, final int b, final int c, final int d) {
        this.g = NextTickListEntry.f++;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o instanceof NextTickListEntry) {
            final NextTickListEntry nextTickListEntry = (NextTickListEntry)o;
            return this.a == nextTickListEntry.a && this.b == nextTickListEntry.b && this.c == nextTickListEntry.c && this.d == nextTickListEntry.d;
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return (this.a * 128 * 1024 + this.c * 128 + this.b) * 256 + this.d;
    }
    
    public NextTickListEntry a(final long e) {
        this.e = e;
        return this;
    }
    
    public int compareTo(final NextTickListEntry nextTickListEntry) {
        if (this.e < nextTickListEntry.e) {
            return -1;
        }
        if (this.e > nextTickListEntry.e) {
            return 1;
        }
        if (this.g < nextTickListEntry.g) {
            return -1;
        }
        if (this.g > nextTickListEntry.g) {
            return 1;
        }
        return 0;
    }
    
    static {
        NextTickListEntry.f = 0L;
    }
}
