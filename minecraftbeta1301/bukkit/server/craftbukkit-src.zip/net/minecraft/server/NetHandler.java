// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class NetHandler
{
    public void a(final Packet51MapChunk packet51MapChunk) {
    }
    
    public void a(final Packet packet) {
    }
    
    public void a(final String s, final Object[] array) {
    }
    
    public void a(final Packet255KickDisconnect packet255KickDisconnect) {
        this.a((Packet)packet255KickDisconnect);
    }
    
    public void a(final Packet1Login packet1Login) {
        this.a((Packet)packet1Login);
    }
    
    public void a(final Packet10Flying packet10Flying) {
        this.a((Packet)packet10Flying);
    }
    
    public void a(final Packet52MultiBlockChange packet52MultiBlockChange) {
        this.a((Packet)packet52MultiBlockChange);
    }
    
    public void a(final Packet14BlockDig packet14BlockDig) {
        this.a((Packet)packet14BlockDig);
    }
    
    public void a(final Packet53BlockChange packet53BlockChange) {
        this.a((Packet)packet53BlockChange);
    }
    
    public void a(final Packet50PreChunk packet50PreChunk) {
        this.a((Packet)packet50PreChunk);
    }
    
    public void a(final Packet20NamedEntitySpawn packet20NamedEntitySpawn) {
        this.a((Packet)packet20NamedEntitySpawn);
    }
    
    public void a(final Packet30Entity packet30Entity) {
        this.a((Packet)packet30Entity);
    }
    
    public void a(final Packet34EntityTeleport packet34EntityTeleport) {
        this.a((Packet)packet34EntityTeleport);
    }
    
    public void a(final Packet15Place packet15Place) {
        this.a((Packet)packet15Place);
    }
    
    public void a(final Packet16BlockItemSwitch packet16BlockItemSwitch) {
        this.a((Packet)packet16BlockItemSwitch);
    }
    
    public void a(final Packet29DestroyEntity packet29DestroyEntity) {
        this.a((Packet)packet29DestroyEntity);
    }
    
    public void a(final Packet21PickupSpawn packet21PickupSpawn) {
        this.a((Packet)packet21PickupSpawn);
    }
    
    public void a(final Packet22Collect packet22Collect) {
        this.a((Packet)packet22Collect);
    }
    
    public void a(final Packet3Chat packet3Chat) {
        this.a((Packet)packet3Chat);
    }
    
    public void a(final Packet23VehicleSpawn packet23VehicleSpawn) {
        this.a((Packet)packet23VehicleSpawn);
    }
    
    public void a(final Packet18ArmAnimation packet18ArmAnimation) {
        this.a((Packet)packet18ArmAnimation);
    }
    
    public void a(final Packet19EntityAction packet19EntityAction) {
        this.a((Packet)packet19EntityAction);
    }
    
    public void a(final Packet2Handshake packet2Handshake) {
        this.a((Packet)packet2Handshake);
    }
    
    public void a(final Packet24MobSpawn packet24MobSpawn) {
        this.a((Packet)packet24MobSpawn);
    }
    
    public void a(final Packet4UpdateTime packet4UpdateTime) {
        this.a((Packet)packet4UpdateTime);
    }
    
    public void a(final Packet6SpawnPosition packet6SpawnPosition) {
        this.a((Packet)packet6SpawnPosition);
    }
    
    public void a(final Packet28EntityVelocity packet28EntityVelocity) {
        this.a((Packet)packet28EntityVelocity);
    }
    
    public void a(final Packet40EntityMetadata packet40EntityMetadata) {
        this.a((Packet)packet40EntityMetadata);
    }
    
    public void a(final Packet39AttachEntity packet39AttachEntity) {
        this.a((Packet)packet39AttachEntity);
    }
    
    public void a(final Packet7UseEntity packet7UseEntity) {
        this.a((Packet)packet7UseEntity);
    }
    
    public void a(final Packet38EntityStatus packet38EntityStatus) {
        this.a((Packet)packet38EntityStatus);
    }
    
    public void a(final Packet8UpdateHealth packet8UpdateHealth) {
        this.a((Packet)packet8UpdateHealth);
    }
    
    public void a(final Packet9Respawn packet9Respawn) {
        this.a((Packet)packet9Respawn);
    }
    
    public void a(final Packet60Explosion packet60Explosion) {
        this.a((Packet)packet60Explosion);
    }
    
    public void a(final Packet100OpenWindow packet100OpenWindow) {
        this.a((Packet)packet100OpenWindow);
    }
    
    public void a(final Packet101CloseWindow packet101CloseWindow) {
        this.a((Packet)packet101CloseWindow);
    }
    
    public void a(final Packet102WindowClick packet102WindowClick) {
        this.a((Packet)packet102WindowClick);
    }
    
    public void a(final Packet103SetSlot packet103SetSlot) {
        this.a((Packet)packet103SetSlot);
    }
    
    public void a(final Packet104WindowItems packet104WindowItems) {
        this.a((Packet)packet104WindowItems);
    }
    
    public void a(final Packet130UpdateSign packet130UpdateSign) {
        this.a((Packet)packet130UpdateSign);
    }
    
    public void a(final Packet105CraftProgressBar packet105CraftProgressBar) {
        this.a((Packet)packet105CraftProgressBar);
    }
    
    public void a(final Packet5EntityEquipment packet5EntityEquipment) {
        this.a((Packet)packet5EntityEquipment);
    }
    
    public void a(final Packet106Transaction packet106Transaction) {
        this.a((Packet)packet106Transaction);
    }
    
    public void a(final Packet25EntityPainting packet25EntityPainting) {
        this.a((Packet)packet25EntityPainting);
    }
    
    public void a(final Packet54PlayNoteBlock packet54PlayNoteBlock) {
        this.a((Packet)packet54PlayNoteBlock);
    }
    
    public void a(final Packet17 packet17) {
    }
    
    public void a(final Packet27 packet27) {
    }
}
