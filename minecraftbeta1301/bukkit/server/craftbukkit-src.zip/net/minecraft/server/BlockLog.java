// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockLog extends Block
{
    protected BlockLog(final int n) {
        super(n, Material.WOOD);
        this.textureId = 20;
    }
    
    @Override
    public int a(final Random random) {
        return 1;
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Block.LOG.id;
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3) {
        final int n4 = 4;
        final int n5 = n4 + 1;
        if (world.a(n - n5, n2 - n5, n3 - n5, n + n5, n2 + n5, n3 + n5)) {
            for (int i = -n4; i <= n4; ++i) {
                for (int j = -n4; j <= n4; ++j) {
                    for (int k = -n4; k <= n4; ++k) {
                        if (world.getTypeId(n + i, n2 + j, n3 + k) == Block.LEAVES.id) {
                            final int data = world.getData(n + i, n2 + j, n3 + k);
                            if ((data & 0x4) == 0x0) {
                                world.d(n + i, n2 + j, n3 + k, data | 0x4);
                            }
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public int a(final int n, final int n2) {
        if (n == 1) {
            return 21;
        }
        if (n == 0) {
            return 21;
        }
        if (n2 == 1) {
            return 116;
        }
        if (n2 == 2) {
            return 117;
        }
        return 20;
    }
    
    @Override
    protected int b(final int n) {
        return n;
    }
}
