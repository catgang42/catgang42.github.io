// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class InventoryLargeChest implements IInventory
{
    private String a;
    private IInventory b;
    private IInventory c;
    
    public ItemStack[] getContents() {
        final ItemStack[] result = new ItemStack[this.m_()];
        for (int i = 0; i < result.length; ++i) {
            result[i] = this.c_(i);
        }
        return result;
    }
    
    public InventoryLargeChest(final String s, final IInventory iinventory, final IInventory iinventory1) {
        this.a = s;
        this.b = iinventory;
        this.c = iinventory1;
    }
    
    public int m_() {
        return this.b.m_() + this.c.m_();
    }
    
    public String c() {
        return this.a;
    }
    
    public ItemStack c_(final int i) {
        return (i >= this.b.m_()) ? this.c.c_(i - this.b.m_()) : this.b.c_(i);
    }
    
    public ItemStack a(final int i, final int j) {
        return (i >= this.b.m_()) ? this.c.a(i - this.b.m_(), j) : this.b.a(i, j);
    }
    
    public void a(final int i, final ItemStack itemstack) {
        if (i >= this.b.m_()) {
            this.c.a(i - this.b.m_(), itemstack);
        }
        else {
            this.b.a(i, itemstack);
        }
    }
    
    public int n_() {
        return this.b.n_();
    }
    
    public void h() {
        this.b.h();
        this.c.h();
    }
    
    public boolean a_(final EntityHuman entityhuman) {
        return this.b.a_(entityhuman) && this.c.a_(entityhuman);
    }
}
