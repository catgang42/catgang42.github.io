// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntityPig extends EntityAnimal
{
    public EntityPig(final World world) {
        super(world);
        this.texture = "/mob/pig.png";
        this.a(0.9f, 0.9f);
    }
    
    @Override
    protected void a() {
        this.datawatcher.a(16, 0);
    }
    
    @Override
    public void a(final NBTTagCompound nbtTagCompound) {
        super.a(nbtTagCompound);
        nbtTagCompound.a("Saddle", this.r());
    }
    
    @Override
    public void b(final NBTTagCompound nbtTagCompound) {
        super.b(nbtTagCompound);
        this.a(nbtTagCompound.m("Saddle"));
    }
    
    @Override
    protected String e() {
        return "mob.pig";
    }
    
    @Override
    protected String f() {
        return "mob.pig";
    }
    
    @Override
    protected String g() {
        return "mob.pigdeath";
    }
    
    @Override
    public boolean a(final EntityHuman entityHuman) {
        if (this.r() && !this.world.isStatic && (this.passenger == null || this.passenger == entityHuman)) {
            entityHuman.b(this);
            return true;
        }
        return false;
    }
    
    @Override
    protected int h() {
        return Item.PORK.id;
    }
    
    public boolean r() {
        return (this.datawatcher.a(16) & 0x1) != 0x0;
    }
    
    public void a(final boolean b) {
        if (b) {
            this.datawatcher.b(16, 1);
        }
        else {
            this.datawatcher.b(16, 0);
        }
    }
}
