// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutput;
import java.io.DataInput;

public class NBTTagEnd extends NBTBase
{
    @Override
    void a(final DataInput dataInput) {
    }
    
    @Override
    void a(final DataOutput dataOutput) {
    }
    
    @Override
    public byte a() {
        return 0;
    }
    
    @Override
    public String toString() {
        return "END";
    }
}
