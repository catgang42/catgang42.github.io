// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityTargetEvent;

public class EntitySpider extends EntityMonster
{
    public EntitySpider(final World world) {
        super(world);
        this.texture = "/mob/spider.png";
        this.a(1.4f, 0.9f);
        this.az = 0.8f;
    }
    
    @Override
    public double k() {
        return this.width * 0.75 - 0.5;
    }
    
    @Override
    protected Entity l() {
        final float f = this.c(1.0f);
        if (f < 0.5f) {
            final double d0 = 16.0;
            return this.world.a(this, d0);
        }
        return null;
    }
    
    @Override
    protected String e() {
        return "mob.spider";
    }
    
    @Override
    protected String f() {
        return "mob.spider";
    }
    
    @Override
    protected String g() {
        return "mob.spiderdeath";
    }
    
    @Override
    protected void a(final Entity entity, final float f) {
        final float f2 = this.c(1.0f);
        if (f2 > 0.5f && this.random.nextInt(100) == 0) {
            final CraftServer server = ((WorldServer)this.world).getServer();
            final EntityTargetEvent event = new EntityTargetEvent(this.getBukkitEntity(), null, EntityTargetEvent.TargetReason.FORGOT_TARGET);
            server.getPluginManager().callEvent(event);
            if (!event.isCancelled()) {
                if (event.getTarget() == null) {
                    this.d = null;
                }
                else {
                    this.d = ((CraftEntity)event.getTarget()).getHandle();
                }
            }
        }
        else if (f > 2.0f && f < 6.0f && this.random.nextInt(10) == 0) {
            if (this.onGround) {
                final double d0 = entity.locX - this.locX;
                final double d2 = entity.locZ - this.locZ;
                final float f3 = MathHelper.a(d0 * d0 + d2 * d2);
                this.motX = d0 / f3 * 0.5 * 0.800000011920929 + this.motX * 0.20000000298023224;
                this.motZ = d2 / f3 * 0.5 * 0.800000011920929 + this.motZ * 0.20000000298023224;
                this.motY = 0.4000000059604645;
            }
        }
        else {
            super.a(entity, f);
        }
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
    }
    
    @Override
    protected int h() {
        return Item.STRING.id;
    }
    
    @Override
    public boolean m() {
        return this.aV;
    }
}
