// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.Writer;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Iterator;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.Location;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerEvent;
import org.bukkit.event.Event;
import org.bukkit.craftbukkit.command.ColouredConsoleSender;
import java.util.HashSet;
import java.util.ArrayList;
import org.bukkit.craftbukkit.CraftServer;
import java.io.File;
import java.util.Set;
import java.util.List;
import java.util.logging.Logger;

public class ServerConfigurationManager
{
    public static Logger a;
    public List b;
    public MinecraftServer c;
    public int e;
    private Set f;
    private Set g;
    private Set h;
    private Set i;
    private File j;
    private File k;
    private File l;
    private File m;
    private PlayerFileData n;
    private boolean o;
    private CraftServer server;
    
    public ServerConfigurationManager(final MinecraftServer minecraftserver) {
        this.b = new ArrayList();
        this.f = new HashSet();
        this.g = new HashSet();
        this.h = new HashSet();
        this.i = new HashSet();
        minecraftserver.server = new CraftServer(minecraftserver, this);
        minecraftserver.console = new ColouredConsoleSender(minecraftserver.server);
        this.server = minecraftserver.server;
        this.c = minecraftserver;
        this.j = minecraftserver.a("banned-players.txt");
        this.k = minecraftserver.a("banned-ips.txt");
        this.l = minecraftserver.a("ops.txt");
        this.m = minecraftserver.a("white-list.txt");
        this.e = minecraftserver.d.a("max-players", 20);
        this.o = minecraftserver.d.a("white-list", false);
        this.g();
        this.i();
        this.k();
        this.m();
        this.h();
        this.j();
        this.l();
        this.n();
    }
    
    public void a(final WorldServer worldserver) {
        if (this.n == null) {
            this.n = worldserver.m().d();
        }
    }
    
    public int a() {
        return 144;
    }
    
    public void a(final EntityPlayer entityplayer) {
        this.b.add(entityplayer);
        this.n.b(entityplayer);
        ((WorldServer)entityplayer.world).u.d((int)entityplayer.locX >> 4, (int)entityplayer.locZ >> 4);
        while (entityplayer.world.a(entityplayer, entityplayer.boundingBox).size() != 0) {
            entityplayer.a(entityplayer.locX, entityplayer.locY + 1.0, entityplayer.locZ);
        }
        entityplayer.world.a(entityplayer);
        this.server.getPluginManager().callEvent(new PlayerEvent(Event.Type.PLAYER_JOIN, this.server.getPlayer(entityplayer)));
        ((WorldServer)entityplayer.world).manager.a(entityplayer);
    }
    
    public void b(final EntityPlayer entityplayer) {
        ((WorldServer)entityplayer.world).manager.c(entityplayer);
    }
    
    public void c(final EntityPlayer entityplayer) {
        this.n.a(entityplayer);
        entityplayer.world.d(entityplayer);
        this.b.remove(entityplayer);
        ((WorldServer)entityplayer.world).manager.b(entityplayer);
        this.server.getPluginManager().callEvent(new PlayerEvent(Event.Type.PLAYER_QUIT, this.server.getPlayer(entityplayer)));
    }
    
    public EntityPlayer a(final NetLoginHandler netloginhandler, final String s, final String s1) {
        final EntityPlayer entity = new EntityPlayer(this.c, this.c.worlds.get(0), s, new ItemInWorldManager(this.c.worlds.get(0)));
        final Player player = (entity == null) ? null : ((Player)entity.getBukkitEntity());
        final PlayerLoginEvent event = new PlayerLoginEvent(Event.Type.PLAYER_LOGIN, player);
        String s2 = netloginhandler.b.b().toString();
        s2 = s2.substring(s2.indexOf("/") + 1);
        s2 = s2.substring(0, s2.indexOf(":"));
        if (this.f.contains(s.trim().toLowerCase())) {
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED, "You are banned from this server!");
        }
        else if (!this.g(s)) {
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED, "You are not white-listed on this server!");
        }
        else if (this.g.contains(s2)) {
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED, "Your IP address is banned from this server!");
        }
        else if (this.b.size() >= this.e) {
            event.disallow(PlayerLoginEvent.Result.KICK_FULL, "The server is full!");
        }
        this.server.getPluginManager().callEvent(event);
        if (event.getResult() != PlayerLoginEvent.Result.ALLOWED) {
            netloginhandler.a(event.getKickMessage());
            return null;
        }
        for (int i = 0; i < this.b.size(); ++i) {
            final EntityPlayer entityplayer = this.b.get(i);
            if (entityplayer.name.equalsIgnoreCase(s)) {
                entityplayer.a.a("You logged in from another location");
            }
        }
        return new EntityPlayer(this.c, entity.world, s, new ItemInWorldManager(entity.world));
    }
    
    public EntityPlayer d(final EntityPlayer entityplayer) {
        this.c.k.a(entityplayer);
        this.c.k.b(entityplayer);
        ((WorldServer)entityplayer.world).manager.b(entityplayer);
        this.b.remove(entityplayer);
        entityplayer.world.e(entityplayer);
        final EntityPlayer entityplayer2 = new EntityPlayer(this.c, entityplayer.world, entityplayer.name, new ItemInWorldManager(entityplayer.world));
        entityplayer2.id = entityplayer.id;
        entityplayer2.a = entityplayer.a;
        ((WorldServer)entityplayer.world).u.d((int)entityplayer2.locX >> 4, (int)entityplayer2.locZ >> 4);
        while (entityplayer.world.a(entityplayer2, entityplayer2.boundingBox).size() != 0) {
            entityplayer2.a(entityplayer2.locX, entityplayer2.locY + 1.0, entityplayer2.locZ);
        }
        final Player respawnPlayer = this.server.getPlayer(entityplayer);
        final Location respawnLocation = new Location(respawnPlayer.getWorld(), entityplayer2.locX, entityplayer2.locY, entityplayer2.locZ, entityplayer2.yaw, entityplayer2.pitch);
        final PlayerRespawnEvent respawnEvent = new PlayerRespawnEvent(Event.Type.PLAYER_RESPAWN, respawnPlayer, respawnLocation);
        this.server.getPluginManager().callEvent(respawnEvent);
        entityplayer2.world = ((CraftWorld)respawnEvent.getRespawnLocation().getWorld()).getHandle();
        entityplayer2.locX = respawnEvent.getRespawnLocation().getX();
        entityplayer2.locY = respawnEvent.getRespawnLocation().getY();
        entityplayer2.locZ = respawnEvent.getRespawnLocation().getZ();
        entityplayer2.yaw = respawnEvent.getRespawnLocation().getYaw();
        entityplayer2.pitch = respawnEvent.getRespawnLocation().getPitch();
        entityplayer2.c = new ItemInWorldManager(((CraftWorld)respawnEvent.getRespawnLocation().getWorld()).getHandle());
        entityplayer2.c.a = entityplayer2;
        ((WorldServer)entityplayer2.world).u.d((int)entityplayer2.locX >> 4, (int)entityplayer2.locZ >> 4);
        entityplayer2.a.b(new Packet9Respawn());
        entityplayer2.a.a(entityplayer2.locX, entityplayer2.locY, entityplayer2.locZ, entityplayer2.yaw, entityplayer2.pitch);
        ((WorldServer)entityplayer2.world).manager.a(entityplayer2);
        entityplayer.world.a(entityplayer2);
        this.b.add(entityplayer2);
        entityplayer2.l();
        entityplayer2.s();
        return entityplayer2;
    }
    
    public void b() {
        for (final WorldServer world : this.c.worlds) {
            world.manager.a();
        }
    }
    
    public void a(final int i, final int j, final int k, final WorldServer world) {
        world.manager.a(i, j, k);
    }
    
    public void a(final Packet packet) {
        for (int i = 0; i < this.b.size(); ++i) {
            final EntityPlayer entityplayer = this.b.get(i);
            entityplayer.a.b(packet);
        }
    }
    
    public String c() {
        String s = "";
        for (int i = 0; i < this.b.size(); ++i) {
            if (i > 0) {
                s += ", ";
            }
            s += this.b.get(i).name;
        }
        return s;
    }
    
    public void a(final String s) {
        this.f.add(s.toLowerCase());
        this.h();
    }
    
    public void b(final String s) {
        this.f.remove(s.toLowerCase());
        this.h();
    }
    
    private void g() {
        try {
            this.f.clear();
            final BufferedReader bufferedreader = new BufferedReader(new FileReader(this.j));
            String s = "";
            while ((s = bufferedreader.readLine()) != null) {
                this.f.add(s.trim().toLowerCase());
            }
            bufferedreader.close();
        }
        catch (Exception exception) {
            ServerConfigurationManager.a.warning("Failed to load ban list: " + exception);
        }
    }
    
    private void h() {
        try {
            final PrintWriter printwriter = new PrintWriter(new FileWriter(this.j, false));
            for (final String s : this.f) {
                printwriter.println(s);
            }
            printwriter.close();
        }
        catch (Exception exception) {
            ServerConfigurationManager.a.warning("Failed to save ban list: " + exception);
        }
    }
    
    public void c(final String s) {
        this.g.add(s.toLowerCase());
        this.j();
    }
    
    public void d(final String s) {
        this.g.remove(s.toLowerCase());
        this.j();
    }
    
    private void i() {
        try {
            this.g.clear();
            final BufferedReader bufferedreader = new BufferedReader(new FileReader(this.k));
            String s = "";
            while ((s = bufferedreader.readLine()) != null) {
                this.g.add(s.trim().toLowerCase());
            }
            bufferedreader.close();
        }
        catch (Exception exception) {
            ServerConfigurationManager.a.warning("Failed to load ip ban list: " + exception);
        }
    }
    
    private void j() {
        try {
            final PrintWriter printwriter = new PrintWriter(new FileWriter(this.k, false));
            for (final String s : this.g) {
                printwriter.println(s);
            }
            printwriter.close();
        }
        catch (Exception exception) {
            ServerConfigurationManager.a.warning("Failed to save ip ban list: " + exception);
        }
    }
    
    public void e(final String s) {
        this.h.add(s.toLowerCase());
        this.l();
    }
    
    public void f(final String s) {
        this.h.remove(s.toLowerCase());
        this.l();
    }
    
    private void k() {
        try {
            this.h.clear();
            final BufferedReader bufferedreader = new BufferedReader(new FileReader(this.l));
            String s = "";
            while ((s = bufferedreader.readLine()) != null) {
                this.h.add(s.trim().toLowerCase());
            }
            bufferedreader.close();
        }
        catch (Exception exception) {
            ServerConfigurationManager.a.warning("Failed to load ops: " + exception);
        }
    }
    
    private void l() {
        try {
            final PrintWriter printwriter = new PrintWriter(new FileWriter(this.l, false));
            for (final String s : this.h) {
                printwriter.println(s);
            }
            printwriter.close();
        }
        catch (Exception exception) {
            ServerConfigurationManager.a.warning("Failed to save ops: " + exception);
        }
    }
    
    private void m() {
        try {
            this.i.clear();
            final BufferedReader bufferedreader = new BufferedReader(new FileReader(this.m));
            String s = "";
            while ((s = bufferedreader.readLine()) != null) {
                this.i.add(s.trim().toLowerCase());
            }
            bufferedreader.close();
        }
        catch (Exception exception) {
            ServerConfigurationManager.a.warning("Failed to load white-list: " + exception);
        }
    }
    
    private void n() {
        try {
            final PrintWriter printwriter = new PrintWriter(new FileWriter(this.m, false));
            for (final String s : this.i) {
                printwriter.println(s);
            }
            printwriter.close();
        }
        catch (Exception exception) {
            ServerConfigurationManager.a.warning("Failed to save white-list: " + exception);
        }
    }
    
    public boolean g(String s) {
        s = s.trim().toLowerCase();
        return !this.o || this.h.contains(s) || this.i.contains(s);
    }
    
    public boolean h(final String s) {
        return this.h.contains(s.trim().toLowerCase());
    }
    
    public EntityPlayer i(final String s) {
        for (int i = 0; i < this.b.size(); ++i) {
            final EntityPlayer entityplayer = this.b.get(i);
            if (entityplayer.name.equalsIgnoreCase(s)) {
                return entityplayer;
            }
        }
        return null;
    }
    
    public void a(final String s, final String s1) {
        final EntityPlayer entityplayer = this.i(s);
        if (entityplayer != null) {
            entityplayer.a.b(new Packet3Chat(s1));
        }
    }
    
    public void a(final double d0, final double d1, final double d2, final double d3, final Packet packet) {
        for (int i = 0; i < this.b.size(); ++i) {
            final EntityPlayer entityplayer = this.b.get(i);
            final double d4 = d0 - entityplayer.locX;
            final double d5 = d1 - entityplayer.locY;
            final double d6 = d2 - entityplayer.locZ;
            if (d4 * d4 + d5 * d5 + d6 * d6 < d3 * d3) {
                entityplayer.a.b(packet);
            }
        }
    }
    
    public void j(final String s) {
        final Packet3Chat packet3chat = new Packet3Chat(s);
        for (int i = 0; i < this.b.size(); ++i) {
            final EntityPlayer entityplayer = this.b.get(i);
            if (this.h(entityplayer.name)) {
                entityplayer.a.b(packet3chat);
            }
        }
    }
    
    public boolean a(final String s, final Packet packet) {
        final EntityPlayer entityplayer = this.i(s);
        if (entityplayer != null) {
            entityplayer.a.b(packet);
            return true;
        }
        return false;
    }
    
    public void d() {
        for (int i = 0; i < this.b.size(); ++i) {
            this.n.a(this.b.get(i));
        }
    }
    
    public void a(final int i, final int j, final int k, final TileEntity tileentity) {
    }
    
    public void k(final String s) {
        this.i.add(s);
        this.n();
    }
    
    public void l(final String s) {
        this.i.remove(s);
        this.n();
    }
    
    public Set e() {
        return this.i;
    }
    
    public void f() {
        this.m();
    }
    
    static {
        ServerConfigurationManager.a = Logger.getLogger("Minecraft");
    }
}
