// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.awt.event.FocusListener;
import java.awt.event.ActionListener;
import javax.swing.JTextField;
import java.util.logging.Handler;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.JPanel;
import java.awt.LayoutManager;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowListener;
import java.awt.Component;
import javax.swing.JFrame;
import javax.swing.UIManager;
import java.util.logging.Logger;
import javax.swing.JComponent;

public class ServerGUI extends JComponent implements ICommandListener
{
    public static Logger a;
    private MinecraftServer b;
    
    public static void a(final MinecraftServer minecraftServer) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }
        catch (Exception ex) {}
        final ServerGUI comp = new ServerGUI(minecraftServer);
        final JFrame frame = new JFrame("Minecraft server");
        frame.add(comp);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.addWindowListener(new ServerWindowAdapter(minecraftServer));
    }
    
    public ServerGUI(final MinecraftServer b) {
        this.b = b;
        this.setPreferredSize(new Dimension(854, 480));
        this.setLayout(new BorderLayout());
        try {
            this.add(this.d(), "Center");
            this.add(this.a(), "West");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private JComponent a() {
        final JPanel panel = new JPanel(new BorderLayout());
        panel.add(new GuiStatsComponent(), "North");
        panel.add(this.b(), "Center");
        panel.setBorder(new TitledBorder(new EtchedBorder(), "Stats"));
        return panel;
    }
    
    private JComponent b() {
        final JScrollPane scrollPane = new JScrollPane(new PlayerListBox(this.b), 22, 30);
        scrollPane.setBorder(new TitledBorder(new EtchedBorder(), "Players"));
        return scrollPane;
    }
    
    private JComponent d() {
        final JPanel panel = new JPanel(new BorderLayout());
        final JTextArea view = new JTextArea();
        ServerGUI.a.addHandler(new GuiLogOutputHandler(view));
        final JScrollPane comp = new JScrollPane(view, 22, 30);
        view.setEditable(false);
        final JTextField comp2 = new JTextField();
        comp2.addActionListener(new ServerGuiCommandListener(this, comp2));
        view.addFocusListener(new ServerGuiFocusAdapter(this));
        panel.add(comp, "Center");
        panel.add(comp2, "South");
        panel.setBorder(new TitledBorder(new EtchedBorder(), "Log and chat"));
        return panel;
    }
    
    public void b(final String msg) {
        ServerGUI.a.info(msg);
    }
    
    public String c() {
        return "CONSOLE";
    }
    
    static {
        ServerGUI.a = Logger.getLogger("Minecraft");
    }
}
