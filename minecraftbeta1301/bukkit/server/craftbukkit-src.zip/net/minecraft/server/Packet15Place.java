// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet15Place extends Packet
{
    public int a;
    public int b;
    public int c;
    public int d;
    public ItemStack e;
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.read();
        this.c = dataInputStream.readInt();
        this.d = dataInputStream.read();
        final short short1 = dataInputStream.readShort();
        if (short1 >= 0) {
            this.e = new ItemStack(short1, dataInputStream.readByte(), dataInputStream.readShort());
        }
        else {
            this.e = null;
        }
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.write(this.b);
        dataOutputStream.writeInt(this.c);
        dataOutputStream.write(this.d);
        if (this.e == null) {
            dataOutputStream.writeShort(-1);
        }
        else {
            dataOutputStream.writeShort(this.e.id);
            dataOutputStream.writeByte(this.e.count);
            dataOutputStream.writeShort(this.e.h());
        }
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 15;
    }
}
