// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Iterator;
import java.util.Set;
import java.util.logging.Logger;

public class ConsoleCommandHandler
{
    private static Logger a;
    private MinecraftServer b;
    
    public ConsoleCommandHandler(final MinecraftServer minecraftserver) {
        this.b = minecraftserver;
    }
    
    public void a(final ServerCommand servercommand) {
        String s = servercommand.a;
        final ICommandListener icommandlistener = servercommand.b;
        final String s2 = icommandlistener.c();
        final WorldServer worldserver = this.b.worlds.get(0);
        final ServerConfigurationManager serverconfigurationmanager = this.b.f;
        if (!s.toLowerCase().startsWith("help") && !s.toLowerCase().startsWith("?")) {
            if (s.toLowerCase().startsWith("list")) {
                icommandlistener.b("Connected players: " + serverconfigurationmanager.c());
            }
            else if (s.toLowerCase().startsWith("stop")) {
                this.a(s2, "Stopping the server..");
                this.b.a();
            }
            else if (s.toLowerCase().startsWith("save-all")) {
                this.a(s2, "Forcing save..");
                this.b.f();
                this.a(s2, "Save complete.");
            }
            else if (s.toLowerCase().startsWith("save-off")) {
                this.a(s2, "Disabling level saving..");
                worldserver.w = true;
            }
            else if (s.toLowerCase().startsWith("save-on")) {
                this.a(s2, "Enabling level saving..");
                worldserver.w = false;
            }
            else if (s.toLowerCase().startsWith("op ")) {
                final String s3 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.e(s3);
                this.a(s2, "Opping " + s3);
                serverconfigurationmanager.a(s3, "§eYou are now op!");
            }
            else if (s.toLowerCase().startsWith("deop ")) {
                final String s3 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.f(s3);
                serverconfigurationmanager.a(s3, "§eYou are no longer op!");
                this.a(s2, "De-opping " + s3);
            }
            else if (s.toLowerCase().startsWith("ban-ip ")) {
                final String s3 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.c(s3);
                this.a(s2, "Banning ip " + s3);
            }
            else if (s.toLowerCase().startsWith("pardon-ip ")) {
                final String s3 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.d(s3);
                this.a(s2, "Pardoning ip " + s3);
            }
            else if (s.toLowerCase().startsWith("ban ")) {
                final String s3 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.a(s3);
                this.a(s2, "Banning " + s3);
                final EntityPlayer entityplayer = serverconfigurationmanager.i(s3);
                if (entityplayer != null) {
                    entityplayer.a.a("Banned by admin");
                }
            }
            else if (s.toLowerCase().startsWith("pardon ")) {
                final String s3 = s.substring(s.indexOf(" ")).trim();
                serverconfigurationmanager.b(s3);
                this.a(s2, "Pardoning " + s3);
            }
            else if (s.toLowerCase().startsWith("kick ")) {
                final String s3 = s.substring(s.indexOf(" ")).trim();
                EntityPlayer entityplayer = null;
                for (int i = 0; i < serverconfigurationmanager.b.size(); ++i) {
                    final EntityPlayer entityplayer2 = serverconfigurationmanager.b.get(i);
                    if (entityplayer2.name.equalsIgnoreCase(s3)) {
                        entityplayer = entityplayer2;
                    }
                }
                if (entityplayer != null) {
                    entityplayer.a.a("Kicked by admin");
                    this.a(s2, "Kicking " + entityplayer.name);
                }
                else {
                    icommandlistener.b("Can't find user " + s3 + ". No kick.");
                }
            }
            else if (s.toLowerCase().startsWith("tp ")) {
                final String[] astring = s.split(" ");
                if (astring.length == 3) {
                    final EntityPlayer entityplayer = serverconfigurationmanager.i(astring[1]);
                    final EntityPlayer entityplayer3 = serverconfigurationmanager.i(astring[2]);
                    if (entityplayer == null) {
                        icommandlistener.b("Can't find user " + astring[1] + ". No tp.");
                    }
                    else if (entityplayer3 == null) {
                        icommandlistener.b("Can't find user " + astring[2] + ". No tp.");
                    }
                    else {
                        entityplayer.a.a(entityplayer3.locX, entityplayer3.locY, entityplayer3.locZ, entityplayer3.yaw, entityplayer3.pitch);
                        this.a(s2, "Teleporting " + astring[1] + " to " + astring[2] + ".");
                    }
                }
                else {
                    icommandlistener.b("Syntax error, please provice a source and a target.");
                }
            }
            else if (s.toLowerCase().startsWith("give ")) {
                final String[] astring = s.split(" ");
                if (astring.length != 3 && astring.length != 4) {
                    return;
                }
                final String s4 = astring[1];
                final EntityPlayer entityplayer3 = serverconfigurationmanager.i(s4);
                if (entityplayer3 != null) {
                    try {
                        final int j = Integer.parseInt(astring[2]);
                        if (Item.byId[j] != null) {
                            this.a(s2, "Giving " + entityplayer3.name + " some " + j);
                            int k = 1;
                            if (astring.length > 3) {
                                k = this.a(astring[3], 1);
                            }
                            if (k < 1) {
                                k = 1;
                            }
                            if (k > 64) {
                                k = 64;
                            }
                            entityplayer3.b(new ItemStack(j, k, 0));
                        }
                        else {
                            icommandlistener.b("There's no item with id " + j);
                        }
                    }
                    catch (NumberFormatException numberformatexception) {
                        icommandlistener.b("There's no item with id " + astring[2]);
                    }
                }
                else {
                    icommandlistener.b("Can't find user " + s4);
                }
            }
            else if (s.toLowerCase().startsWith("time ")) {
                final String[] astring = s.split(" ");
                if (astring.length != 3) {
                    return;
                }
                final String s4 = astring[1];
                try {
                    final int i = Integer.parseInt(astring[2]);
                    if ("add".equalsIgnoreCase(s4)) {
                        worldserver.a(worldserver.k() + i);
                        this.a(s2, "Added " + i + " to time");
                    }
                    else if ("set".equalsIgnoreCase(s4)) {
                        worldserver.a(i);
                        this.a(s2, "Set time to " + i);
                    }
                    else {
                        icommandlistener.b("Unknown method, use either \"add\" or \"set\"");
                    }
                }
                catch (NumberFormatException numberformatexception2) {
                    icommandlistener.b("Unable to convert time value, " + astring[2]);
                }
            }
            else if (s.toLowerCase().startsWith("say ")) {
                s = s.substring(s.indexOf(" ")).trim();
                ConsoleCommandHandler.a.info("[" + s2 + "] " + s);
                serverconfigurationmanager.a(new Packet3Chat("§d[Server] " + s));
            }
            else if (s.toLowerCase().startsWith("tell ")) {
                final String[] astring = s.split(" ");
                if (astring.length >= 3) {
                    s = s.substring(s.indexOf(" ")).trim();
                    s = s.substring(s.indexOf(" ")).trim();
                    ConsoleCommandHandler.a.info("[" + s2 + "->" + astring[1] + "] " + s);
                    s = "§7" + s2 + " whispers " + s;
                    ConsoleCommandHandler.a.info(s);
                    if (!serverconfigurationmanager.a(astring[1], new Packet3Chat(s))) {
                        icommandlistener.b("There's no player by that name online.");
                    }
                }
            }
            else if (s.toLowerCase().startsWith("whitelist ")) {
                this.a(s2, s, icommandlistener);
            }
            else {
                ConsoleCommandHandler.a.info("Unknown console command. Type \"help\" for help.");
            }
        }
        else {
            this.a(icommandlistener);
        }
    }
    
    private void a(final String s, final String s1, final ICommandListener icommandlistener) {
        final String[] astring = s1.split(" ");
        if (astring.length >= 2) {
            final String s2 = astring[1].toLowerCase();
            if ("on".equals(s2)) {
                this.a(s, "Turned on white-listing");
                this.b.d.b("white-list", true);
            }
            else if ("off".equals(s2)) {
                this.a(s, "Turned off white-listing");
                this.b.d.b("white-list", false);
            }
            else if ("list".equals(s2)) {
                final Set set = this.b.f.e();
                String s3 = "";
                for (final String s4 : set) {
                    s3 = s3 + s4 + " ";
                }
                icommandlistener.b("White-listed players: " + s3);
            }
            else if ("add".equals(s2) && astring.length == 3) {
                final String s5 = astring[2].toLowerCase();
                this.b.f.k(s5);
                this.a(s, "Added " + s5 + " to white-list");
            }
            else if ("remove".equals(s2) && astring.length == 3) {
                final String s5 = astring[2].toLowerCase();
                this.b.f.l(s5);
                this.a(s, "Removed " + s5 + " from white-list");
            }
            else if ("reload".equals(s2)) {
                this.b.f.f();
                this.a(s, "Reloaded white-list from file");
            }
        }
    }
    
    private void a(final ICommandListener icommandlistener) {
        icommandlistener.b("To run the server without a gui, start it like this:");
        icommandlistener.b("   java -Xmx1024M -Xms1024M -jar minecraft_server.jar nogui");
        icommandlistener.b("Console commands:");
        icommandlistener.b("   help  or  ?               shows this message");
        icommandlistener.b("   kick <player>             removes a player from the server");
        icommandlistener.b("   ban <player>              bans a player from the server");
        icommandlistener.b("   pardon <player>           pardons a banned player so that they can connect again");
        icommandlistener.b("   ban-ip <ip>               bans an IP address from the server");
        icommandlistener.b("   pardon-ip <ip>            pardons a banned IP address so that they can connect again");
        icommandlistener.b("   op <player>               turns a player into an op");
        icommandlistener.b("   deop <player>             removes op status from a player");
        icommandlistener.b("   tp <player1> <player2>    moves one player to the same location as another player");
        icommandlistener.b("   give <player> <id> [num]  gives a player a resource");
        icommandlistener.b("   tell <player> <message>   sends a private message to a player");
        icommandlistener.b("   stop                      gracefully stops the server");
        icommandlistener.b("   save-all                  forces a server-wide level save");
        icommandlistener.b("   save-off                  disables terrain saving (useful for backup scripts)");
        icommandlistener.b("   save-on                   re-enables terrain saving");
        icommandlistener.b("   list                      lists all currently connected players");
        icommandlistener.b("   say <message>             broadcasts a message to all players");
        icommandlistener.b("   time <add|set> <amount>   adds to or sets the world time (0-24000)");
    }
    
    private void a(final String s, final String s1) {
        final String s2 = s + ": " + s1;
        this.b.f.j("§7(" + s2 + ")");
        ConsoleCommandHandler.a.info(s2);
    }
    
    private int a(final String s, final int i) {
        try {
            return Integer.parseInt(s);
        }
        catch (NumberFormatException numberformatexception) {
            return i;
        }
    }
    
    static {
        ConsoleCommandHandler.a = Logger.getLogger("Minecraft");
    }
}
