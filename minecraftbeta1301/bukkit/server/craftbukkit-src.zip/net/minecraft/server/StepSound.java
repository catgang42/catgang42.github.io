// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class StepSound
{
    public final String a;
    public final float b;
    public final float c;
    
    public StepSound(final String a, final float b, final float c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public float a() {
        return this.b;
    }
    
    public float b() {
        return this.c;
    }
    
    public String c() {
        return "step." + this.a;
    }
}
