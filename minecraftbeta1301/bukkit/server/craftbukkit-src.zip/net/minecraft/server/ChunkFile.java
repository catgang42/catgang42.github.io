// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.regex.Matcher;
import java.io.File;

class ChunkFile implements Comparable
{
    private final File a;
    private final int b;
    private final int c;
    
    public ChunkFile(final File a) {
        this.a = a;
        final Matcher matcher = ChunkFilenameFilter.a.matcher(a.getName());
        if (matcher.matches()) {
            this.b = Integer.parseInt(matcher.group(1), 36);
            this.c = Integer.parseInt(matcher.group(2), 36);
        }
        else {
            this.b = 0;
            this.c = 0;
        }
    }
    
    public int compareTo(final ChunkFile chunkFile) {
        final int n = this.b >> 5;
        final int n2 = chunkFile.b >> 5;
        if (n == n2) {
            return (this.c >> 5) - (chunkFile.c >> 5);
        }
        return n - n2;
    }
    
    public File a() {
        return this.a;
    }
    
    public int b() {
        return this.b;
    }
    
    public int c() {
        return this.c;
    }
}
