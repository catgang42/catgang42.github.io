// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public interface CraftingRecipe
{
    boolean a(final InventoryCrafting p0);
    
    ItemStack b(final InventoryCrafting p0);
    
    int a();
}
