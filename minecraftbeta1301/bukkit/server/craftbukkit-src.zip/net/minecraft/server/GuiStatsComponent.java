// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import java.awt.Dimension;
import javax.swing.JComponent;

public class GuiStatsComponent extends JComponent
{
    private int[] a;
    private int b;
    private String[] c;
    
    public GuiStatsComponent() {
        this.a = new int[256];
        this.b = 0;
        this.c = new String[10];
        this.setPreferredSize(new Dimension(256, 196));
        this.setMinimumSize(new Dimension(256, 196));
        this.setMaximumSize(new Dimension(256, 196));
        new Timer(500, new GuiStatsListener(this)).start();
        this.setBackground(Color.BLACK);
    }
    
    private void a() {
        final long n = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        System.gc();
        this.c[0] = "Memory use: " + n / 1024L / 1024L + " mb (" + Runtime.getRuntime().freeMemory() * 100L / Runtime.getRuntime().maxMemory() + "% free)";
        this.c[1] = "Threads: " + NetworkManager.b + " + " + NetworkManager.c;
        this.a[this.b++ & 0xFF] = (int)(n * 100L / Runtime.getRuntime().maxMemory());
        this.repaint();
    }
    
    @Override
    public void paint(final Graphics graphics) {
        graphics.setColor(new Color(16777215));
        graphics.fillRect(0, 0, 256, 192);
        for (int i = 0; i < 256; ++i) {
            final int n = this.a[i + this.b & 0xFF];
            graphics.setColor(new Color(n + 28 << 16));
            graphics.fillRect(i, 100 - n, 1, n);
        }
        graphics.setColor(Color.BLACK);
        for (int j = 0; j < this.c.length; ++j) {
            final String s = this.c[j];
            if (s != null) {
                graphics.drawString(s, 32, 116 + j * 16);
            }
        }
    }
}
