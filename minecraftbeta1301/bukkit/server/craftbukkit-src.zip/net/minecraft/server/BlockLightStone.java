// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockLightStone extends Block
{
    public BlockLightStone(final int n, final int n2, final Material material) {
        super(n, n2, material);
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Item.GLOWSTONE_DUST.id;
    }
}
