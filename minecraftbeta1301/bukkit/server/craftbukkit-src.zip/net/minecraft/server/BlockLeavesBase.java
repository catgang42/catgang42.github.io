// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockLeavesBase extends Block
{
    protected boolean b;
    
    protected BlockLeavesBase(final int n, final int n2, final Material material, final boolean b) {
        super(n, n2, material);
        this.b = b;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        final int typeId = blockAccess.getTypeId(n, n2, n3);
        return (this.b || typeId != this.id) && super.a(blockAccess, n, n2, n3, n4);
    }
}
