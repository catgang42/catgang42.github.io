// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.io.DataOutputStream;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class DataWatcher
{
    private static final HashMap a;
    private final Map b;
    private boolean c;
    
    public DataWatcher() {
        this.b = new HashMap();
    }
    
    public void a(final int n, final Object o) {
        final Integer n2 = DataWatcher.a.get(o.getClass());
        if (n2 == null) {
            throw new IllegalArgumentException("Unknown data type: " + o.getClass());
        }
        if (n > 31) {
            throw new IllegalArgumentException("Data value id is too big with " + n + "! (Max is " + 31 + ")");
        }
        if (this.b.containsKey(n)) {
            throw new IllegalArgumentException("Duplicate id value for " + n + "!");
        }
        this.b.put(n, new WatchableObject(n2, n, o));
    }
    
    public byte a(final int i) {
        return (byte)this.b.get(i).b();
    }
    
    public void b(final int i, final Object o) {
        final WatchableObject watchableObject = this.b.get(i);
        if (!o.equals(watchableObject.b())) {
            watchableObject.a(o);
            watchableObject.a(true);
            this.c = true;
        }
    }
    
    public boolean a() {
        return this.c;
    }
    
    public static void a(final List list, final DataOutputStream dataOutputStream) {
        if (list != null) {
            final Iterator<WatchableObject> iterator = list.iterator();
            while (iterator.hasNext()) {
                a(dataOutputStream, iterator.next());
            }
        }
        dataOutputStream.writeByte(127);
    }
    
    public ArrayList b() {
        ArrayList<WatchableObject> list = null;
        if (this.c) {
            for (final WatchableObject e : this.b.values()) {
                if (e.d()) {
                    e.a(false);
                    if (list == null) {
                        list = new ArrayList<WatchableObject>();
                    }
                    list.add(e);
                }
            }
        }
        this.c = false;
        return list;
    }
    
    public void a(final DataOutputStream dataOutputStream) {
        final Iterator<WatchableObject> iterator = this.b.values().iterator();
        while (iterator.hasNext()) {
            a(dataOutputStream, iterator.next());
        }
        dataOutputStream.writeByte(127);
    }
    
    private static void a(final DataOutputStream dataOutputStream, final WatchableObject watchableObject) {
        dataOutputStream.writeByte((watchableObject.c() << 5 | (watchableObject.a() & 0x1F)) & 0xFF);
        switch (watchableObject.c()) {
            case 0: {
                dataOutputStream.writeByte((byte)watchableObject.b());
                break;
            }
            case 1: {
                dataOutputStream.writeShort((short)watchableObject.b());
                break;
            }
            case 2: {
                dataOutputStream.writeInt((int)watchableObject.b());
                break;
            }
            case 3: {
                dataOutputStream.writeFloat((float)watchableObject.b());
                break;
            }
            case 4: {
                dataOutputStream.writeUTF((String)watchableObject.b());
                break;
            }
            case 5: {
                final ItemStack itemStack = (ItemStack)watchableObject.b();
                dataOutputStream.writeShort(itemStack.a().id);
                dataOutputStream.writeByte(itemStack.count);
                dataOutputStream.writeShort(itemStack.h());
            }
            case 6: {
                final ChunkCoordinates chunkCoordinates = (ChunkCoordinates)watchableObject.b();
                dataOutputStream.writeInt(chunkCoordinates.a);
                dataOutputStream.writeInt(chunkCoordinates.b);
                dataOutputStream.writeInt(chunkCoordinates.c);
                break;
            }
        }
    }
    
    public static List a(final DataInputStream dataInputStream) {
        ArrayList<Object> list = null;
        for (byte b = dataInputStream.readByte(); b != 127; b = dataInputStream.readByte()) {
            if (list == null) {
                list = new ArrayList<Object>();
            }
            final int n = (b & 0xE0) >> 5;
            final int n2 = b & 0x1F;
            Object e = null;
            switch (n) {
                case 0: {
                    e = new WatchableObject(n, n2, dataInputStream.readByte());
                    break;
                }
                case 1: {
                    e = new WatchableObject(n, n2, dataInputStream.readShort());
                    break;
                }
                case 2: {
                    e = new WatchableObject(n, n2, dataInputStream.readInt());
                    break;
                }
                case 3: {
                    e = new WatchableObject(n, n2, dataInputStream.readFloat());
                    break;
                }
                case 4: {
                    e = new WatchableObject(n, n2, dataInputStream.readUTF());
                    break;
                }
                case 5: {
                    final WatchableObject watchableObject = new WatchableObject(n, n2, new ItemStack(dataInputStream.readShort(), dataInputStream.readByte(), dataInputStream.readShort()));
                }
                case 6: {
                    e = new WatchableObject(n, n2, new ChunkCoordinates(dataInputStream.readInt(), dataInputStream.readInt(), dataInputStream.readInt()));
                    break;
                }
            }
            list.add(e);
        }
        return list;
    }
    
    static {
        (a = new HashMap()).put(Byte.class, 0);
        DataWatcher.a.put(Short.class, 1);
        DataWatcher.a.put(Integer.class, 2);
        DataWatcher.a.put(Float.class, 3);
        DataWatcher.a.put(String.class, 4);
        DataWatcher.a.put(ItemStack.class, 5);
        DataWatcher.a.put(ChunkCoordinates.class, 6);
    }
}
