// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntityWaterAnimal extends EntityCreature implements IAnimal
{
    public EntityWaterAnimal(final World world) {
        super(world);
    }
    
    @Override
    public boolean b_() {
        return true;
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
    }
    
    @Override
    public boolean b() {
        return this.world.a(this.boundingBox);
    }
    
    @Override
    public int c() {
        return 120;
    }
}
