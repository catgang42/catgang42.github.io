// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BiomeRainforest extends BiomeBase
{
    @Override
    public WorldGenerator a(final Random random) {
        if (random.nextInt(3) == 0) {
            return new WorldGenBigTree();
        }
        return new WorldGenTrees();
    }
}
