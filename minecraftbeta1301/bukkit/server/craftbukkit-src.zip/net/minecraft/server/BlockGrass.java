// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockGrass extends Block
{
    protected BlockGrass(final int n) {
        super(n, Material.EARTH);
        this.textureId = 3;
        this.a(true);
    }
    
    @Override
    public void a(final World world, final int n, final int j, final int n2, final Random random) {
        if (world.isStatic) {
            return;
        }
        if (world.j(n, j + 1, n2) < 4 && world.getMaterial(n, j + 1, n2).blocksLight()) {
            if (random.nextInt(4) != 0) {
                return;
            }
            world.e(n, j, n2, Block.DIRT.id);
        }
        else if (world.j(n, j + 1, n2) >= 9) {
            final int n3 = n + random.nextInt(3) - 1;
            final int n4 = j + random.nextInt(5) - 3;
            final int n5 = n2 + random.nextInt(3) - 1;
            if (world.getTypeId(n3, n4, n5) == Block.DIRT.id && world.j(n3, n4 + 1, n5) >= 4 && !world.getMaterial(n3, n4 + 1, n5).blocksLight()) {
                world.e(n3, n4, n5, Block.GRASS.id);
            }
        }
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Block.DIRT.a(0, random);
    }
}
