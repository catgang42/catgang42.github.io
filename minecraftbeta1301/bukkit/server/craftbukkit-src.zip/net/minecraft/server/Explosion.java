// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.Server;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.Material;
import org.bukkit.Location;
import org.bukkit.craftbukkit.CraftServer;
import java.util.List;
import java.util.Collection;
import java.util.ArrayList;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import java.util.HashSet;
import java.util.Set;
import java.util.Random;

public class Explosion
{
    public boolean a;
    private Random h;
    private World i;
    public double b;
    public double c;
    public double d;
    public Entity e;
    public float f;
    public Set g;
    public boolean wasCanceled;
    
    public Explosion(final World world, final Entity entity, final double d0, final double d1, final double d2, final float f) {
        this.a = false;
        this.h = new Random();
        this.g = new HashSet();
        this.wasCanceled = false;
        this.i = world;
        this.e = entity;
        this.f = f;
        this.b = d0;
        this.c = d1;
        this.d = d2;
    }
    
    public void a() {
        final float f = this.f;
        final byte b0 = 16;
        for (int i = 0; i < b0; ++i) {
            for (int j = 0; j < b0; ++j) {
                for (int k = 0; k < b0; ++k) {
                    if (i == 0 || i == b0 - 1 || j == 0 || j == b0 - 1 || k == 0 || k == b0 - 1) {
                        double d3 = i / (b0 - 1.0f) * 2.0f - 1.0f;
                        double d4 = j / (b0 - 1.0f) * 2.0f - 1.0f;
                        double d5 = k / (b0 - 1.0f) * 2.0f - 1.0f;
                        final double d6 = Math.sqrt(d3 * d3 + d4 * d4 + d5 * d5);
                        d3 /= d6;
                        d4 /= d6;
                        d5 /= d6;
                        float f2 = this.f * (0.7f + this.i.k.nextFloat() * 0.6f);
                        double d7 = this.b;
                        double d8 = this.c;
                        double d9 = this.d;
                        for (float f3 = 0.3f; f2 > 0.0f; f2 -= f3 * 0.75f) {
                            final int l = MathHelper.b(d7);
                            final int i2 = MathHelper.b(d8);
                            final int j2 = MathHelper.b(d9);
                            final int k2 = this.i.getTypeId(l, i2, j2);
                            if (k2 > 0) {
                                f2 -= (Block.byId[k2].a(this.e) + 0.3f) * f3;
                            }
                            if (f2 > 0.0f) {
                                this.g.add(new ChunkPosition(l, i2, j2));
                            }
                            d7 += d3 * f3;
                            d8 += d4 * f3;
                            d9 += d5 * f3;
                        }
                    }
                }
            }
        }
        this.f *= 2.0f;
        int i = MathHelper.b(this.b - this.f - 1.0);
        int j = MathHelper.b(this.b + this.f + 1.0);
        int k = MathHelper.b(this.c - this.f - 1.0);
        final int l2 = MathHelper.b(this.c + this.f + 1.0);
        final int i3 = MathHelper.b(this.d - this.f - 1.0);
        final int j3 = MathHelper.b(this.d + this.f + 1.0);
        final List list = this.i.b(this.e, AxisAlignedBB.b(i, k, i3, j, l2, j3));
        final Vec3D vec3d = Vec3D.b(this.b, this.c, this.d);
        for (int k3 = 0; k3 < list.size(); ++k3) {
            final Entity entity = list.get(k3);
            final double d10 = entity.e(this.b, this.c, this.d) / this.f;
            if (d10 <= 1.0) {
                double d7 = entity.locX - this.b;
                double d8 = entity.locY - this.c;
                double d9 = entity.locZ - this.d;
                final double d11 = MathHelper.a(d7 * d7 + d8 * d8 + d9 * d9);
                d7 /= d11;
                d8 /= d11;
                d9 /= d11;
                final double d12 = this.i.a(vec3d, entity.boundingBox);
                final double d13 = (1.0 - d10) * d12;
                final CraftServer server = ((WorldServer)this.i).getServer();
                final org.bukkit.entity.Entity damagee = (entity == null) ? null : entity.getBukkitEntity();
                final int damageDone = (int)((d13 * d13 + d13) / 2.0 * 8.0 * this.f + 1.0);
                if (damagee != null) {
                    if (this.e == null) {
                        final EntityDamageEvent.DamageCause damageType = EntityDamageEvent.DamageCause.BLOCK_EXPLOSION;
                        final EntityDamageByBlockEvent event = new EntityDamageByBlockEvent((org.bukkit.block.Block)null, damagee, damageType, damageDone);
                        server.getPluginManager().callEvent(event);
                        if (!event.isCancelled()) {
                            entity.a(this.e, event.getDamage());
                            final Entity entity2 = entity;
                            entity2.motX += d7 * d13;
                            final Entity entity3 = entity;
                            entity3.motY += d8 * d13;
                            final Entity entity4 = entity;
                            entity4.motZ += d9 * d13;
                        }
                    }
                    else {
                        final org.bukkit.entity.Entity damager = this.e.getBukkitEntity();
                        final EntityDamageEvent.DamageCause damageType = EntityDamageEvent.DamageCause.ENTITY_EXPLOSION;
                        final EntityDamageByEntityEvent event2 = new EntityDamageByEntityEvent(damager, damagee, damageType, damageDone);
                        server.getPluginManager().callEvent(event2);
                        if (!event2.isCancelled()) {
                            entity.a(this.e, event2.getDamage());
                            final Entity entity5 = entity;
                            entity5.motX += d7 * d13;
                            final Entity entity6 = entity;
                            entity6.motY += d8 * d13;
                            final Entity entity7 = entity;
                            entity7.motZ += d9 * d13;
                        }
                    }
                }
            }
        }
        this.f = f;
        final ArrayList arraylist = new ArrayList();
        arraylist.addAll(this.g);
        if (this.a) {
            for (int l3 = arraylist.size() - 1; l3 >= 0; --l3) {
                final ChunkPosition chunkposition = arraylist.get(l3);
                final int i4 = chunkposition.a;
                final int j4 = chunkposition.b;
                final int k4 = chunkposition.c;
                final int l4 = this.i.getTypeId(i4, j4, k4);
                final int i5 = this.i.getTypeId(i4, j4 - 1, k4);
                if (l4 == 0 && Block.o[i5] && this.h.nextInt(3) == 0) {
                    this.i.e(i4, j4, k4, Block.FIRE.id);
                }
            }
        }
    }
    
    public void b() {
        this.i.a(this.b, this.c, this.d, "random.explode", 4.0f, (1.0f + (this.i.k.nextFloat() - this.i.k.nextFloat()) * 0.2f) * 0.7f);
        final ArrayList arraylist = new ArrayList();
        arraylist.addAll(this.g);
        final Server server = ((WorldServer)this.i).getServer();
        final CraftWorld world = ((WorldServer)this.i).getWorld();
        final org.bukkit.entity.Entity explode = (this.e == null) ? null : this.e.getBukkitEntity();
        final Location location = new Location(world, this.b, this.c, this.d);
        final List<org.bukkit.block.Block> blockList = new ArrayList<org.bukkit.block.Block>();
        for (int j = arraylist.size() - 1; j >= 0; --j) {
            final ChunkPosition cpos = arraylist.get(j);
            final org.bukkit.block.Block block = world.getBlockAt(cpos.a, cpos.b, cpos.c);
            if (!block.getType().equals(Material.AIR)) {
                blockList.add(block);
            }
        }
        final Event.Type eventType = Event.Type.ENTITY_EXPLODE;
        final EntityExplodeEvent event = new EntityExplodeEvent(eventType, explode, location, blockList);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            this.wasCanceled = true;
            return;
        }
        for (int i = arraylist.size() - 1; i >= 0; --i) {
            final ChunkPosition chunkposition = arraylist.get(i);
            final int k = chunkposition.a;
            final int l = chunkposition.b;
            final int m = chunkposition.c;
            final int i2 = this.i.getTypeId(k, l, m);
            for (int j2 = 0; j2 < 1; ++j2) {
                final double d0 = k + this.i.k.nextFloat();
                final double d2 = l + this.i.k.nextFloat();
                final double d3 = m + this.i.k.nextFloat();
                double d4 = d0 - this.b;
                double d5 = d2 - this.c;
                double d6 = d3 - this.d;
                final double d7 = MathHelper.a(d4 * d4 + d5 * d5 + d6 * d6);
                d4 /= d7;
                d5 /= d7;
                d6 /= d7;
                double d8 = 0.5 / (d7 / this.f + 0.1);
                d8 *= this.i.k.nextFloat() * this.i.k.nextFloat() + 0.3f;
                d4 *= d8;
                d5 *= d8;
                d6 *= d8;
                this.i.a("explode", (d0 + this.b * 1.0) / 2.0, (d2 + this.c * 1.0) / 2.0, (d3 + this.d * 1.0) / 2.0, d4, d5, d6);
                this.i.a("smoke", d0, d2, d3, d4, d5, d6);
            }
            if (i2 > 0) {
                Block.byId[i2].a(this.i, k, l, m, this.i.getData(k, l, m), event.getYield());
                this.i.e(k, l, m, 0);
                Block.byId[i2].c(this.i, k, l, m);
            }
        }
    }
}
