// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemSword extends Item
{
    private int a;
    
    public ItemSword(final int n, final EnumToolMaterial enumToolMaterial) {
        super(n);
        this.maxStackSize = 1;
        this.durability = enumToolMaterial.a();
        this.a = 4 + enumToolMaterial.c() * 2;
    }
    
    @Override
    public float a(final ItemStack itemStack, final Block block) {
        return 1.5f;
    }
    
    @Override
    public void a(final ItemStack itemStack, final EntityLiving entityLiving) {
        itemStack.b(1);
    }
    
    @Override
    public void a(final ItemStack itemStack, final int n, final int n2, final int n3, final int n4) {
        itemStack.b(2);
    }
    
    @Override
    public int a(final Entity entity) {
        return this.a;
    }
}
