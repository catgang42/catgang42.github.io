// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

class NetworkMasterThread extends Thread
{
    final /* synthetic */ NetworkManager a;
    
    NetworkMasterThread(final NetworkManager a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        try {
            Thread.sleep(5000L);
            if (this.a.q.isAlive()) {
                try {
                    this.a.q.stop();
                }
                catch (Throwable t) {}
            }
            if (this.a.p.isAlive()) {
                try {
                    this.a.p.stop();
                }
                catch (Throwable t2) {}
            }
        }
        catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
}
