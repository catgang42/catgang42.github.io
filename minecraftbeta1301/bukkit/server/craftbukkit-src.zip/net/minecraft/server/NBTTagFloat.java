// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public class NBTTagFloat extends NBTBase
{
    public float a;
    
    public NBTTagFloat() {
    }
    
    public NBTTagFloat(final float a) {
        this.a = a;
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        dataOutput.writeFloat(this.a);
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.a = dataInput.readFloat();
    }
    
    @Override
    public byte a() {
        return 5;
    }
    
    @Override
    public String toString() {
        return "" + this.a;
    }
}
