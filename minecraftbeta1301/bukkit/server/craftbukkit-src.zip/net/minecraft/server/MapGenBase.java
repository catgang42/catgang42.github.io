// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class MapGenBase
{
    protected int a;
    protected Random b;
    
    public MapGenBase() {
        this.a = 8;
        this.b = new Random();
    }
    
    public void a(final IChunkProvider chunkProvider, final World world, final int n, final int n2, final byte[] array) {
        final int a = this.a;
        this.b.setSeed(world.j());
        final long n3 = this.b.nextLong() / 2L * 2L + 1L;
        final long n4 = this.b.nextLong() / 2L * 2L + 1L;
        for (int i = n - a; i <= n + a; ++i) {
            for (int j = n2 - a; j <= n2 + a; ++j) {
                this.b.setSeed(i * n3 + j * n4 ^ world.j());
                this.a(world, i, j, n, n2, array);
            }
        }
    }
    
    protected void a(final World world, final int n, final int n2, final int n3, final int n4, final byte[] array) {
    }
}
