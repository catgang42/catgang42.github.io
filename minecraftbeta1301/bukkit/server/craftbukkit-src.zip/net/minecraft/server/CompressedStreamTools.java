// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.IOException;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.util.zip.GZIPOutputStream;
import java.io.OutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.util.zip.GZIPInputStream;
import java.io.InputStream;

public class CompressedStreamTools
{
    public static NBTTagCompound a(final InputStream in) {
        final DataInputStream dataInputStream = new DataInputStream(new GZIPInputStream(in));
        try {
            return a((DataInput)dataInputStream);
        }
        finally {
            dataInputStream.close();
        }
    }
    
    public static void a(final NBTTagCompound nbtTagCompound, final OutputStream out) {
        final DataOutputStream dataOutputStream = new DataOutputStream(new GZIPOutputStream(out));
        try {
            a(nbtTagCompound, (DataOutput)dataOutputStream);
        }
        finally {
            dataOutputStream.close();
        }
    }
    
    public static NBTTagCompound a(final DataInput dataInput) {
        final NBTBase b = NBTBase.b(dataInput);
        if (b instanceof NBTTagCompound) {
            return (NBTTagCompound)b;
        }
        throw new IOException("Root tag must be a named compound tag");
    }
    
    public static void a(final NBTTagCompound nbtTagCompound, final DataOutput dataOutput) {
        NBTBase.a(nbtTagCompound, dataOutput);
    }
}
