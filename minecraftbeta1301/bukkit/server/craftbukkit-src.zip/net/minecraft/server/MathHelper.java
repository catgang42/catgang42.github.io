// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class MathHelper
{
    private static float[] a;
    
    public static final float a(final float n) {
        return MathHelper.a[(int)(n * 10430.378f) & 0xFFFF];
    }
    
    public static final float b(final float n) {
        return MathHelper.a[(int)(n * 10430.378f + 16384.0f) & 0xFFFF];
    }
    
    public static final float c(final float n) {
        return (float)Math.sqrt(n);
    }
    
    public static final float a(final double a) {
        return (float)Math.sqrt(a);
    }
    
    public static int d(final float n) {
        final int n2 = (int)n;
        return (n < n2) ? (n2 - 1) : n2;
    }
    
    public static int b(final double n) {
        final int n2 = (int)n;
        return (n < n2) ? (n2 - 1) : n2;
    }
    
    public static float e(final float n) {
        return (n >= 0.0f) ? n : (-n);
    }
    
    public static double a(double n, double n2) {
        if (n < 0.0) {
            n = -n;
        }
        if (n2 < 0.0) {
            n2 = -n2;
        }
        return (n > n2) ? n : n2;
    }
    
    static {
        MathHelper.a = new float[65536];
        for (int i = 0; i < 65536; ++i) {
            MathHelper.a[i] = (float)Math.sin(i * 3.141592653589793 * 2.0 / 65536.0);
        }
    }
}
