// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class InventoryPlayer implements IInventory
{
    public ItemStack[] a;
    public ItemStack[] b;
    public int c;
    public EntityHuman e;
    private ItemStack f;
    public boolean d;
    
    public ItemStack[] getContents() {
        return this.a;
    }
    
    public ItemStack[] getArmorContents() {
        return this.b;
    }
    
    public InventoryPlayer(final EntityHuman entityhuman) {
        this.a = new ItemStack[36];
        this.b = new ItemStack[4];
        this.c = 0;
        this.d = false;
        this.e = entityhuman;
    }
    
    public ItemStack b() {
        return this.a[this.c];
    }
    
    private int d(final int i) {
        for (int j = 0; j < this.a.length; ++j) {
            if (this.a[j] != null && this.a[j].id == i) {
                return j;
            }
        }
        return -1;
    }
    
    private int c(final ItemStack itemstack) {
        for (int i = 0; i < this.a.length; ++i) {
            if (this.a[i] != null && this.a[i].id == itemstack.id && this.a[i].c() && this.a[i].count < this.a[i].b() && this.a[i].count < this.n_() && (!this.a[i].e() || this.a[i].h() == itemstack.h())) {
                return i;
            }
        }
        return -1;
    }
    
    private int j() {
        for (int i = 0; i < this.a.length; ++i) {
            if (this.a[i] == null) {
                return i;
            }
        }
        return -1;
    }
    
    private int d(final ItemStack itemstack) {
        final int i = itemstack.id;
        int j = itemstack.count;
        int k = this.c(itemstack);
        if (k < 0) {
            k = this.j();
        }
        if (k < 0) {
            return j;
        }
        if (this.a[k] == null) {
            this.a[k] = new ItemStack(i, 0, itemstack.h());
        }
        int l;
        if ((l = j) > this.a[k].b() - this.a[k].count) {
            l = this.a[k].b() - this.a[k].count;
        }
        if (l > this.n_() - this.a[k].count) {
            l = this.n_() - this.a[k].count;
        }
        if (l == 0) {
            return j;
        }
        j -= l;
        final ItemStack itemStack = this.a[k];
        itemStack.count += l;
        this.a[k].b = 5;
        return j;
    }
    
    public void e() {
        for (int i = 0; i < this.a.length; ++i) {
            if (this.a[i] != null && this.a[i].b > 0) {
                final ItemStack itemStack = this.a[i];
                --itemStack.b;
            }
        }
    }
    
    public boolean b(final int i) {
        final int j = this.d(i);
        if (j < 0) {
            return false;
        }
        final ItemStack itemStack = this.a[j];
        if (--itemStack.count <= 0) {
            this.a[j] = null;
        }
        return true;
    }
    
    public boolean a(final ItemStack itemstack) {
        if (!itemstack.f()) {
            itemstack.count = this.d(itemstack);
            if (itemstack.count == 0) {
                return true;
            }
        }
        final int i = this.j();
        if (i >= 0) {
            this.a[i] = itemstack;
            this.a[i].b = 5;
            return true;
        }
        return false;
    }
    
    public ItemStack a(int i, final int j) {
        ItemStack[] aitemstack = this.a;
        if (i >= this.a.length) {
            aitemstack = this.b;
            i -= this.a.length;
        }
        if (aitemstack[i] == null) {
            return null;
        }
        if (aitemstack[i].count <= j) {
            final ItemStack itemstack = aitemstack[i];
            aitemstack[i] = null;
            return itemstack;
        }
        final ItemStack itemstack = aitemstack[i].a(j);
        if (aitemstack[i].count == 0) {
            aitemstack[i] = null;
        }
        return itemstack;
    }
    
    public void a(int i, final ItemStack itemstack) {
        ItemStack[] aitemstack = this.a;
        if (i >= aitemstack.length) {
            i -= aitemstack.length;
            aitemstack = this.b;
        }
        aitemstack[i] = itemstack;
    }
    
    public float a(final Block block) {
        float f = 1.0f;
        if (this.a[this.c] != null) {
            f *= this.a[this.c].a(block);
        }
        return f;
    }
    
    public NBTTagList a(final NBTTagList nbttaglist) {
        for (int i = 0; i < this.a.length; ++i) {
            if (this.a[i] != null) {
                final NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.a("Slot", (byte)i);
                this.a[i].a(nbttagcompound);
                nbttaglist.a(nbttagcompound);
            }
        }
        for (int i = 0; i < this.b.length; ++i) {
            if (this.b[i] != null) {
                final NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.a("Slot", (byte)(i + 100));
                this.b[i].a(nbttagcompound);
                nbttaglist.a(nbttagcompound);
            }
        }
        return nbttaglist;
    }
    
    public void b(final NBTTagList nbttaglist) {
        this.a = new ItemStack[36];
        this.b = new ItemStack[4];
        for (int i = 0; i < nbttaglist.c(); ++i) {
            final NBTTagCompound nbttagcompound = (NBTTagCompound)nbttaglist.a(i);
            final int j = nbttagcompound.c("Slot") & 0xFF;
            final ItemStack itemstack = new ItemStack(nbttagcompound);
            if (itemstack.a() != null) {
                if (j >= 0 && j < this.a.length) {
                    this.a[j] = itemstack;
                }
                if (j >= 100 && j < this.b.length + 100) {
                    this.b[j - 100] = itemstack;
                }
            }
        }
    }
    
    public int m_() {
        return this.a.length + 4;
    }
    
    public ItemStack c_(int i) {
        ItemStack[] aitemstack = this.a;
        if (i >= aitemstack.length) {
            i -= aitemstack.length;
            aitemstack = this.b;
        }
        return aitemstack[i];
    }
    
    public String c() {
        return "Inventory";
    }
    
    public int n_() {
        return 64;
    }
    
    public int a(final Entity entity) {
        final ItemStack itemstack = this.c_(this.c);
        return (itemstack != null) ? itemstack.a(entity) : 1;
    }
    
    public boolean b(final Block block) {
        if (block.material != Material.STONE && block.material != Material.ORE && block.material != Material.SNOW_BLOCK && block.material != Material.SNOW_LAYER) {
            return true;
        }
        final ItemStack itemstack = this.c_(this.c);
        return itemstack != null && itemstack.b(block);
    }
    
    public int f() {
        int i = 0;
        int j = 0;
        int k = 0;
        for (int l = 0; l < this.b.length; ++l) {
            if (this.b[l] != null && this.b[l].a() instanceof ItemArmor) {
                final int i2 = this.b[l].i();
                final int j2 = this.b[l].g();
                final int k2 = i2 - j2;
                j += k2;
                k += i2;
                final int l2 = ((ItemArmor)this.b[l].a()).bj;
                i += l2;
            }
        }
        if (k == 0) {
            return 0;
        }
        return (i - 1) * j / k + 1;
    }
    
    public void c(final int i) {
        for (int j = 0; j < this.b.length; ++j) {
            if (this.b[j] != null && this.b[j].a() instanceof ItemArmor) {
                this.b[j].b(i);
                if (this.b[j].count == 0) {
                    this.b[j].a(this.e);
                    this.b[j] = null;
                }
            }
        }
    }
    
    public void g() {
        for (int i = 0; i < this.a.length; ++i) {
            if (this.a[i] != null) {
                this.e.a(this.a[i], true);
                this.a[i] = null;
            }
        }
        for (int i = 0; i < this.b.length; ++i) {
            if (this.b[i] != null) {
                this.e.a(this.b[i], true);
                this.b[i] = null;
            }
        }
    }
    
    public void h() {
        this.d = true;
    }
    
    public void b(final ItemStack itemstack) {
        this.f = itemstack;
        this.e.a(itemstack);
    }
    
    public ItemStack i() {
        return this.f;
    }
    
    public boolean a_(final EntityHuman entityhuman) {
        return !this.e.dead && entityhuman.g(this.e) <= 64.0;
    }
}
