// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;

class ServerGuiFocusAdapter extends FocusAdapter
{
    final /* synthetic */ ServerGUI a;
    
    ServerGuiFocusAdapter(final ServerGUI a) {
        this.a = a;
    }
    
    @Override
    public void focusGained(final FocusEvent focusEvent) {
    }
}
