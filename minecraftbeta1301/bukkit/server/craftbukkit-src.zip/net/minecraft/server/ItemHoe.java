// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.player.PlayerItemEvent;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class ItemHoe extends Item
{
    public ItemHoe(final int i, final EnumToolMaterial enumtoolmaterial) {
        super(i);
        this.maxStackSize = 1;
        this.durability = enumtoolmaterial.a();
    }
    
    @Override
    public boolean a(final ItemStack itemstack, final EntityHuman entityhuman, final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getTypeId(i, j, k);
        final Material material = world.getMaterial(i, j + 1, k);
        if ((material.isBuildable() || i2 != Block.GRASS.id) && i2 != Block.DIRT.id) {
            return false;
        }
        final Block block = Block.SOIL;
        world.a(i + 0.5f, j + 0.5f, k + 0.5f, block.stepSound.c(), (block.stepSound.a() + 1.0f) / 2.0f, block.stepSound.b() * 0.8f);
        if (world.isStatic) {
            return true;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer craftServer = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.PLAYER_ITEM;
        final Player who = (entityhuman == null) ? null : ((Player)entityhuman.getBukkitEntity());
        final org.bukkit.inventory.ItemStack itemInHand = new CraftItemStack(itemstack);
        final org.bukkit.block.Block blockClicked = craftWorld.getBlockAt(i, j, k);
        final BlockFace blockFace = CraftBlock.notchToBlockFace(l);
        final PlayerItemEvent event = new PlayerItemEvent(eventType, who, itemInHand, blockClicked, blockFace);
        craftServer.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return false;
        }
        world.e(i, j, k, block.id);
        itemstack.b(1);
        if (world.k.nextInt(8) == 0 && i2 == Block.GRASS.id) {
            final byte b0 = 1;
            for (int j2 = 0; j2 < b0; ++j2) {
                final float f = 0.7f;
                final float f2 = world.k.nextFloat() * f + (1.0f - f) * 0.5f;
                final float f3 = 1.2f;
                final float f4 = world.k.nextFloat() * f + (1.0f - f) * 0.5f;
                final EntityItem entityitem = new EntityItem(world, i + f2, j + f3, k + f4, new ItemStack(Item.SEEDS));
                entityitem.c = 10;
                world.a(entityitem);
            }
        }
        return true;
    }
}
