// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockPumpkin extends Block
{
    private boolean a;
    
    protected BlockPumpkin(final int n, final int textureId, final boolean a) {
        super(n, Material.PUMPKIN);
        this.textureId = textureId;
        this.a(true);
        this.a = a;
    }
    
    @Override
    public int a(final int n, final int n2) {
        if (n == 1) {
            return this.textureId;
        }
        if (n == 0) {
            return this.textureId;
        }
        int n3 = this.textureId + 1 + 16;
        if (this.a) {
            ++n3;
        }
        if (n2 == 0 && n == 2) {
            return n3;
        }
        if (n2 == 1 && n == 5) {
            return n3;
        }
        if (n2 == 2 && n == 3) {
            return n3;
        }
        if (n2 == 3 && n == 4) {
            return n3;
        }
        return this.textureId + 16;
    }
    
    @Override
    public int a(final int n) {
        if (n == 1) {
            return this.textureId;
        }
        if (n == 0) {
            return this.textureId;
        }
        if (n == 3) {
            return this.textureId + 1 + 16;
        }
        return this.textureId + 16;
    }
    
    @Override
    public void e(final World world, final int n, final int n2, final int n3) {
        super.e(world, n, n2, n3);
    }
    
    @Override
    public boolean a(final World world, final int n, final int j, final int n2) {
        final int typeId = world.getTypeId(n, j, n2);
        return (typeId == 0 || Block.byId[typeId].material.isLiquid()) && world.d(n, j - 1, n2);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final EntityLiving entityLiving) {
        world.c(i, j, k, MathHelper.b(entityLiving.yaw * 4.0f / 360.0f + 0.5) & 0x3);
    }
}
