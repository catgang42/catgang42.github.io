// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Iterator;
import org.bukkit.Server;
import org.bukkit.craftbukkit.CraftWorld;
import java.util.List;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.inventory.ItemStack;
import java.util.ArrayList;
import org.bukkit.craftbukkit.TrigMath;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageEvent;

public abstract class EntityLiving extends Entity
{
    public int maxNoDamageTicks;
    public float D;
    public float E;
    public float F;
    public float G;
    protected float H;
    protected float I;
    protected float J;
    protected float K;
    protected boolean L;
    protected String texture;
    protected boolean N;
    protected float O;
    protected String P;
    protected float Q;
    protected int R;
    protected float S;
    public boolean T;
    public float U;
    public float V;
    public int health;
    public int X;
    private int a;
    public int hurtTicks;
    public int Z;
    public float aa;
    public int deathTicks;
    public int attackTicks;
    public float ad;
    public float ae;
    protected boolean af;
    public int ag;
    public float ah;
    public float ai;
    public float aj;
    public float ak;
    protected int al;
    protected double am;
    protected double an;
    protected double ao;
    protected double ap;
    protected double aq;
    float ar;
    protected int lastDamage;
    protected int at;
    protected float au;
    protected float av;
    protected float aw;
    protected boolean ax;
    protected float ay;
    protected float az;
    private Entity b;
    private int c;
    
    public EntityLiving(final World world) {
        super(world);
        this.maxNoDamageTicks = 20;
        this.F = 0.0f;
        this.G = 0.0f;
        this.L = true;
        this.texture = "/mob/char.png";
        this.N = true;
        this.O = 0.0f;
        this.P = null;
        this.Q = 1.0f;
        this.R = 0;
        this.S = 0.0f;
        this.T = false;
        this.health = 10;
        this.aa = 0.0f;
        this.deathTicks = 0;
        this.attackTicks = 0;
        this.af = false;
        this.ag = -1;
        this.ah = (float)(Math.random() * 0.8999999761581421 + 0.10000000149011612);
        this.ar = 0.0f;
        this.lastDamage = 0;
        this.at = 0;
        this.ax = false;
        this.ay = 0.0f;
        this.az = 0.7f;
        this.c = 0;
        this.aC = true;
        this.E = (float)(Math.random() + 1.0) * 0.01f;
        this.a(this.locX, this.locY, this.locZ);
        this.D = (float)Math.random() * 12398.0f;
        this.yaw = (float)(Math.random() * 3.1415927410125732 * 2.0);
        this.bm = 0.5f;
    }
    
    @Override
    protected void a() {
    }
    
    public boolean e(final Entity entity) {
        return this.world.a(Vec3D.b(this.locX, this.locY + this.p(), this.locZ), Vec3D.b(entity.locX, entity.locY + entity.p(), entity.locZ)) == null;
    }
    
    @Override
    public boolean d_() {
        return !this.dead;
    }
    
    @Override
    public boolean e_() {
        return !this.dead;
    }
    
    @Override
    public float p() {
        return this.width * 0.85f;
    }
    
    public int c() {
        return 80;
    }
    
    public void G() {
        final String s = this.e();
        if (s != null) {
            this.world.a(this, s, this.i(), (this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f);
        }
    }
    
    @Override
    public void H() {
        this.U = this.V;
        super.H();
        if (this.random.nextInt(1000) < this.a++) {
            this.a = -this.c();
            this.G();
        }
        if (this.J() && this.D()) {
            final CraftServer server = ((WorldServer)this.world).getServer();
            final org.bukkit.entity.Entity victim = this.getBukkitEntity();
            final EntityDamageEvent.DamageCause damageType = EntityDamageEvent.DamageCause.SUFFOCATION;
            final EntityDamageEvent event = new EntityDamageEvent(victim, damageType, 1);
            server.getPluginManager().callEvent(event);
            if (!event.isCancelled()) {
                this.a(null, 1);
            }
        }
        if (this.by || this.world.isStatic) {
            this.fireTicks = 0;
        }
        if (this.J() && this.a(Material.WATER) && !this.b_()) {
            --this.airTicks;
            if (this.airTicks == -20) {
                this.airTicks = 0;
                for (int i = 0; i < 8; ++i) {
                    final float f = this.random.nextFloat() - this.random.nextFloat();
                    final float f2 = this.random.nextFloat() - this.random.nextFloat();
                    final float f3 = this.random.nextFloat() - this.random.nextFloat();
                    this.world.a("bubble", this.locX + f, this.locY + f2, this.locZ + f3, this.motX, this.motY, this.motZ);
                }
                final CraftServer server2 = ((WorldServer)this.world).getServer();
                final org.bukkit.entity.Entity damagee = this.getBukkitEntity();
                final EntityDamageEvent.DamageCause damageType2 = EntityDamageEvent.DamageCause.DROWNING;
                final int damageDone = 2;
                final EntityDamageEvent event2 = new EntityDamageEvent(damagee, damageType2, damageDone);
                server2.getPluginManager().callEvent(event2);
                if (!event2.isCancelled()) {
                    this.a(null, event2.getDamage());
                }
            }
            this.fireTicks = 0;
        }
        else {
            this.airTicks = this.maxAirTicks;
        }
        this.ad = this.ae;
        if (this.attackTicks > 0) {
            --this.attackTicks;
        }
        if (this.hurtTicks > 0) {
            --this.hurtTicks;
        }
        if (this.noDamageTicks > 0) {
            --this.noDamageTicks;
        }
        if (this.health <= 0) {
            ++this.deathTicks;
            if (this.deathTicks > 20) {
                this.L();
                this.C();
                for (int i = 0; i < 20; ++i) {
                    final double d0 = this.random.nextGaussian() * 0.02;
                    final double d2 = this.random.nextGaussian() * 0.02;
                    final double d3 = this.random.nextGaussian() * 0.02;
                    this.world.a("explode", this.locX + this.random.nextFloat() * this.length * 2.0f - this.length, this.locY + this.random.nextFloat() * this.width, this.locZ + this.random.nextFloat() * this.length * 2.0f - this.length, d0, d2, d3);
                }
            }
        }
        this.K = this.J;
        this.G = this.F;
        this.lastYaw = this.yaw;
        this.lastPitch = this.pitch;
    }
    
    public void I() {
        for (int i = 0; i < 20; ++i) {
            final double d0 = this.random.nextGaussian() * 0.02;
            final double d2 = this.random.nextGaussian() * 0.02;
            final double d3 = this.random.nextGaussian() * 0.02;
            final double d4 = 10.0;
            this.world.a("explode", this.locX + this.random.nextFloat() * this.length * 2.0f - this.length - d0 * d4, this.locY + this.random.nextFloat() * this.width - d2 * d4, this.locZ + this.random.nextFloat() * this.length * 2.0f - this.length - d3 * d4, d0, d2, d3);
        }
    }
    
    @Override
    public void x() {
        super.x();
        this.H = this.I;
        this.I = 0.0f;
    }
    
    @Override
    public void f_() {
        super.f_();
        this.q();
        final double d0 = this.locX - this.lastX;
        final double d2 = this.locZ - this.lastZ;
        final float f = MathHelper.a(d0 * d0 + d2 * d2);
        float f2 = this.F;
        float f3 = 0.0f;
        this.H = this.I;
        float f4 = 0.0f;
        if (f > 0.05f) {
            f4 = 1.0f;
            f3 = f * 3.0f;
            f2 = (float)TrigMath.atan2(d2, d0) * 180.0f / 3.1415927f - 90.0f;
        }
        if (this.V > 0.0f) {
            f2 = this.yaw;
        }
        if (!this.onGround) {
            f4 = 0.0f;
        }
        this.I += (f4 - this.I) * 0.3f;
        float f5;
        for (f5 = f2 - this.F; f5 < -180.0f; f5 += 360.0f) {}
        while (f5 >= 180.0f) {
            f5 -= 360.0f;
        }
        this.F += f5 * 0.3f;
        float f6;
        for (f6 = this.yaw - this.F; f6 < -180.0f; f6 += 360.0f) {}
        while (f6 >= 180.0f) {
            f6 -= 360.0f;
        }
        final boolean flag = f6 < -90.0f || f6 >= 90.0f;
        if (f6 < -75.0f) {
            f6 = -75.0f;
        }
        if (f6 >= 75.0f) {
            f6 = 75.0f;
        }
        this.F = this.yaw - f6;
        if (f6 * f6 > 2500.0f) {
            this.F += f6 * 0.2f;
        }
        if (flag) {
            f3 *= -1.0f;
        }
        while (this.yaw - this.lastYaw < -180.0f) {
            this.lastYaw -= 360.0f;
        }
        while (this.yaw - this.lastYaw >= 180.0f) {
            this.lastYaw += 360.0f;
        }
        while (this.F - this.G < -180.0f) {
            this.G -= 360.0f;
        }
        while (this.F - this.G >= 180.0f) {
            this.G += 360.0f;
        }
        while (this.pitch - this.lastPitch < -180.0f) {
            this.lastPitch -= 360.0f;
        }
        while (this.pitch - this.lastPitch >= 180.0f) {
            this.lastPitch += 360.0f;
        }
        this.J += f3;
    }
    
    @Override
    protected void a(final float f, final float f1) {
        super.a(f, f1);
    }
    
    public void b(final int i) {
        if (this.health > 0) {
            this.health += i;
            if (this.health > 20) {
                this.health = 20;
            }
            this.noDamageTicks = this.maxNoDamageTicks / 2;
        }
    }
    
    @Override
    public boolean a(final Entity entity, final int i) {
        if (this.world.isStatic) {
            return false;
        }
        this.at = 0;
        if (this.health <= 0) {
            return false;
        }
        this.aj = 1.5f;
        boolean flag = true;
        if (this.noDamageTicks > this.maxNoDamageTicks / 2.0f) {
            if (i <= this.lastDamage) {
                return false;
            }
            this.c(i - this.lastDamage);
            this.lastDamage = i;
            flag = false;
        }
        else {
            this.lastDamage = i;
            this.X = this.health;
            this.noDamageTicks = this.maxNoDamageTicks;
            this.c(i);
            final int n = 10;
            this.Z = n;
            this.hurtTicks = n;
        }
        this.aa = 0.0f;
        if (flag) {
            this.world.a(this, (byte)2);
            this.R();
            if (entity != null) {
                double d0;
                double d2;
                for (d0 = entity.locX - this.locX, d2 = entity.locZ - this.locZ; d0 * d0 + d2 * d2 < 1.0E-4; d0 = (Math.random() - Math.random()) * 0.01, d2 = (Math.random() - Math.random()) * 0.01) {}
                this.aa = (float)(Math.atan2(d2, d0) * 180.0 / 3.1415927410125732) - this.yaw;
                this.a(entity, i, d0, d2);
            }
            else {
                this.aa = (float)((int)(Math.random() * 2.0) * 180);
            }
        }
        if (this.health <= 0) {
            if (flag) {
                this.world.a(this, this.g(), this.i(), (this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f);
            }
            this.a(entity);
        }
        else if (flag) {
            this.world.a(this, this.f(), this.i(), (this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f);
        }
        return true;
    }
    
    protected void c(final int i) {
        this.health -= i;
    }
    
    protected float i() {
        return 1.0f;
    }
    
    protected String e() {
        return null;
    }
    
    protected String f() {
        return "random.hurt";
    }
    
    protected String g() {
        return "random.hurt";
    }
    
    public void a(final Entity entity, final int i, final double d0, final double d1) {
        final float f = MathHelper.a(d0 * d0 + d1 * d1);
        final float f2 = 0.4f;
        this.motX /= 2.0;
        this.motY /= 2.0;
        this.motZ /= 2.0;
        this.motX -= d0 / f * f2;
        this.motY += 0.4000000059604645;
        this.motZ -= d1 / f * f2;
        if (this.motY > 0.4000000059604645) {
            this.motY = 0.4000000059604645;
        }
    }
    
    public void a(final Entity entity) {
        if (this.R > 0 && entity != null) {
            entity.c(this, this.R);
        }
        this.af = true;
        if (!this.world.isStatic) {
            this.o();
        }
        this.world.a(this, (byte)3);
    }
    
    protected void o() {
        final int i = this.h();
        final List<ItemStack> loot = new ArrayList<ItemStack>();
        final int count = this.random.nextInt(3);
        if (i > 0 && count > 0) {
            loot.add(new ItemStack(i, count));
        }
        final CraftEntity entity = (CraftEntity)this.getBukkitEntity();
        final EntityDeathEvent event = new EntityDeathEvent(Event.Type.ENTITY_DEATH, entity, loot);
        final CraftWorld cworld = ((WorldServer)this.world).getWorld();
        final Server server = ((WorldServer)this.world).getServer();
        server.getPluginManager().callEvent(event);
        for (final ItemStack stack : event.getDrops()) {
            cworld.dropItemNaturally(entity.getLocation(), stack);
        }
    }
    
    protected int h() {
        return 0;
    }
    
    @Override
    protected void a(final float f) {
        final int i = (int)Math.ceil(f - 3.0f);
        if (i > 0) {
            final CraftServer server = ((WorldServer)this.world).getServer();
            final org.bukkit.entity.Entity victim = this.getBukkitEntity();
            final EntityDamageEvent.DamageCause damageType = EntityDamageEvent.DamageCause.FALL;
            final EntityDamageEvent event = new EntityDamageEvent(victim, damageType, i);
            server.getPluginManager().callEvent(event);
            if (!event.isCancelled()) {
                this.a(null, event.getDamage());
            }
            final int j = this.world.getTypeId(MathHelper.b(this.locX), MathHelper.b(this.locY - 0.20000000298023224 - this.height), MathHelper.b(this.locZ));
            if (j > 0) {
                final StepSound stepsound = Block.byId[j].stepSound;
                this.world.a(this, stepsound.c(), stepsound.a() * 0.5f, stepsound.b() * 0.75f);
            }
        }
    }
    
    public void b(final float f, final float f1) {
        if (this.g_()) {
            final double d0 = this.locY;
            this.a(f, f1, 0.02f);
            this.c(this.motX, this.motY, this.motZ);
            this.motX *= 0.800000011920929;
            this.motY *= 0.800000011920929;
            this.motZ *= 0.800000011920929;
            this.motY -= 0.02;
            if (this.aV && this.b(this.motX, this.motY + 0.6000000238418579 - this.locY + d0, this.motZ)) {
                this.motY = 0.30000001192092896;
            }
        }
        else if (this.Q()) {
            final double d0 = this.locY;
            this.a(f, f1, 0.02f);
            this.c(this.motX, this.motY, this.motZ);
            this.motX *= 0.5;
            this.motY *= 0.5;
            this.motZ *= 0.5;
            this.motY -= 0.02;
            if (this.aV && this.b(this.motX, this.motY + 0.6000000238418579 - this.locY + d0, this.motZ)) {
                this.motY = 0.30000001192092896;
            }
        }
        else {
            float f2 = 0.91f;
            if (this.onGround) {
                f2 = 0.54600006f;
                final int i = this.world.getTypeId(MathHelper.b(this.locX), MathHelper.b(this.boundingBox.b) - 1, MathHelper.b(this.locZ));
                if (i > 0) {
                    f2 = Block.byId[i].frictionFactor * 0.91f;
                }
            }
            final float f3 = 0.16277136f / (f2 * f2 * f2);
            this.a(f, f1, this.onGround ? (0.1f * f3) : 0.02f);
            f2 = 0.91f;
            if (this.onGround) {
                f2 = 0.54600006f;
                final int j = this.world.getTypeId(MathHelper.b(this.locX), MathHelper.b(this.boundingBox.b) - 1, MathHelper.b(this.locZ));
                if (j > 0) {
                    f2 = Block.byId[j].frictionFactor * 0.91f;
                }
            }
            if (this.m()) {
                this.fallDistance = 0.0f;
                if (this.motY < -0.15) {
                    this.motY = -0.15;
                }
            }
            this.c(this.motX, this.motY, this.motZ);
            if (this.aV && this.m()) {
                this.motY = 0.2;
            }
            this.motY -= 0.08;
            this.motY *= 0.9800000190734863;
            this.motX *= f2;
            this.motZ *= f2;
        }
        this.ai = this.aj;
        final double d0 = this.locX - this.lastX;
        final double d2 = this.locZ - this.lastZ;
        float f4 = MathHelper.a(d0 * d0 + d2 * d2) * 4.0f;
        if (f4 > 1.0f) {
            f4 = 1.0f;
        }
        this.aj += (f4 - this.aj) * 0.4f;
        this.ak += this.aj;
    }
    
    public boolean m() {
        final int i = MathHelper.b(this.locX);
        final int j = MathHelper.b(this.boundingBox.b);
        final int k = MathHelper.b(this.locZ);
        return this.world.getTypeId(i, j, k) == Block.LADDER.id || this.world.getTypeId(i, j + 1, k) == Block.LADDER.id;
    }
    
    public void a(final NBTTagCompound nbttagcompound) {
        nbttagcompound.a("Health", (short)this.health);
        nbttagcompound.a("HurtTime", (short)this.hurtTicks);
        nbttagcompound.a("DeathTime", (short)this.deathTicks);
        nbttagcompound.a("AttackTime", (short)this.attackTicks);
    }
    
    public void b(final NBTTagCompound nbttagcompound) {
        this.health = nbttagcompound.d("Health");
        if (!nbttagcompound.b("Health")) {
            this.health = 10;
        }
        this.hurtTicks = nbttagcompound.d("HurtTime");
        this.deathTicks = nbttagcompound.d("DeathTime");
        this.attackTicks = nbttagcompound.d("AttackTime");
    }
    
    @Override
    public boolean J() {
        return !this.dead && this.health > 0;
    }
    
    public boolean b_() {
        return false;
    }
    
    public void q() {
        if (this.al > 0) {
            final double d0 = this.locX + (this.am - this.locX) / this.al;
            final double d2 = this.locY + (this.an - this.locY) / this.al;
            final double d3 = this.locZ + (this.ao - this.locZ) / this.al;
            double d4;
            for (d4 = this.ap - this.yaw; d4 < -180.0; d4 += 360.0) {}
            while (d4 >= 180.0) {
                d4 -= 360.0;
            }
            this.yaw += (float)(d4 / this.al);
            this.pitch += (float)((this.aq - this.pitch) / this.al);
            --this.al;
            this.a(d0, d2, d3);
            this.c(this.yaw, this.pitch);
        }
        if (this.w()) {
            this.ax = false;
            this.au = 0.0f;
            this.av = 0.0f;
            this.aw = 0.0f;
        }
        else if (!this.T) {
            this.c_();
        }
        final boolean flag = this.g_();
        final boolean flag2 = this.Q();
        if (this.ax) {
            if (flag) {
                this.motY += 0.03999999910593033;
            }
            else if (flag2) {
                this.motY += 0.03999999910593033;
            }
            else if (this.onGround) {
                this.K();
            }
        }
        this.au *= 0.98f;
        this.av *= 0.98f;
        this.aw *= 0.9f;
        this.b(this.au, this.av);
        final List list = this.world.b(this, this.boundingBox.b(0.20000000298023224, 0.0, 0.20000000298023224));
        if (list != null && list.size() > 0) {
            for (int i = 0; i < list.size(); ++i) {
                final Entity entity = list.get(i);
                if (entity.e_()) {
                    entity.h(this);
                }
            }
        }
    }
    
    protected boolean w() {
        return this.health <= 0;
    }
    
    protected void K() {
        this.motY = 0.41999998688697815;
    }
    
    protected void c_() {
        ++this.at;
        EntityHuman entityhuman = this.world.a(this, -1.0);
        if (entityhuman != null) {
            final double d0 = entityhuman.locX - this.locX;
            final double d2 = entityhuman.locY - this.locY;
            final double d3 = entityhuman.locZ - this.locZ;
            final double d4 = d0 * d0 + d2 * d2 + d3 * d3;
            if (d4 > 16384.0) {
                this.C();
            }
            if (this.at > 600 && this.random.nextInt(800) == 0) {
                if (d4 < 1024.0) {
                    this.at = 0;
                }
                else {
                    this.C();
                }
            }
        }
        this.au = 0.0f;
        this.av = 0.0f;
        final float f = 8.0f;
        if (this.random.nextFloat() < 0.02f) {
            entityhuman = this.world.a(this, f);
            if (entityhuman != null) {
                this.b = entityhuman;
                this.c = 10 + this.random.nextInt(20);
            }
            else {
                this.aw = (this.random.nextFloat() - 0.5f) * 20.0f;
            }
        }
        if (this.b != null) {
            this.b(this.b, 10.0f);
            if (this.c-- <= 0 || this.b.dead || this.b.g(this) > f * f) {
                this.b = null;
            }
        }
        else {
            if (this.random.nextFloat() < 0.05f) {
                this.aw = (this.random.nextFloat() - 0.5f) * 20.0f;
            }
            this.yaw += this.aw;
            this.pitch = this.ay;
        }
        final boolean flag = this.g_();
        final boolean flag2 = this.Q();
        if (flag || flag2) {
            this.ax = (this.random.nextFloat() < 0.8f);
        }
    }
    
    public void b(final Entity entity, final float f) {
        final double d0 = entity.locX - this.locX;
        final double d2 = entity.locZ - this.locZ;
        double d3;
        if (entity instanceof EntityLiving) {
            final EntityLiving entityliving = (EntityLiving)entity;
            d3 = entityliving.locY + entityliving.p() - (this.locY + this.p());
        }
        else {
            d3 = (entity.boundingBox.b + entity.boundingBox.e) / 2.0 - (this.locY + this.p());
        }
        final double d4 = MathHelper.a(d0 * d0 + d2 * d2);
        final float f2 = (float)(Math.atan2(d2, d0) * 180.0 / 3.1415927410125732) - 90.0f;
        final float f3 = (float)(Math.atan2(d3, d4) * 180.0 / 3.1415927410125732);
        this.pitch = -this.b(this.pitch, f3, f);
        this.yaw = this.b(this.yaw, f2, f);
    }
    
    private float b(final float f, final float f1, final float f2) {
        float f3;
        for (f3 = f1 - f; f3 < -180.0f; f3 += 360.0f) {}
        while (f3 >= 180.0f) {
            f3 -= 360.0f;
        }
        if (f3 > f2) {
            f3 = f2;
        }
        if (f3 < -f2) {
            f3 = -f2;
        }
        return f + f3;
    }
    
    public void L() {
    }
    
    public boolean b() {
        return this.world.a(this.boundingBox) && this.world.a(this, this.boundingBox).size() == 0 && !this.world.b(this.boundingBox);
    }
    
    @Override
    protected void M() {
        this.a(null, 4);
    }
    
    @Override
    public Vec3D N() {
        return this.b(1.0f);
    }
    
    public Vec3D b(final float f) {
        if (f == 1.0f) {
            final float f2 = MathHelper.b(-this.yaw * 0.017453292f - 3.1415927f);
            final float f3 = MathHelper.a(-this.yaw * 0.017453292f - 3.1415927f);
            final float f4 = -MathHelper.b(-this.pitch * 0.017453292f);
            final float f5 = MathHelper.a(-this.pitch * 0.017453292f);
            return Vec3D.b(f3 * f4, f5, f2 * f4);
        }
        final float f2 = this.lastPitch + (this.pitch - this.lastPitch) * f;
        final float f3 = this.lastYaw + (this.yaw - this.lastYaw) * f;
        final float f4 = MathHelper.b(-f3 * 0.017453292f - 3.1415927f);
        final float f5 = MathHelper.a(-f3 * 0.017453292f - 3.1415927f);
        final float f6 = -MathHelper.b(-f2 * 0.017453292f);
        final float f7 = MathHelper.a(-f2 * 0.017453292f);
        return Vec3D.b(f5 * f6, f7, f4 * f6);
    }
    
    public int j() {
        return 4;
    }
    
    public boolean E() {
        return false;
    }
}
