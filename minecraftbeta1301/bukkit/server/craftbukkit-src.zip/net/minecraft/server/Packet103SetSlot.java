// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet103SetSlot extends Packet
{
    public int a;
    public int b;
    public ItemStack c;
    
    public Packet103SetSlot() {
    }
    
    public Packet103SetSlot(final int a, final int b, final ItemStack itemStack) {
        this.a = a;
        this.b = b;
        this.c = ((itemStack == null) ? itemStack : itemStack.j());
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readByte();
        this.b = dataInputStream.readShort();
        final short short1 = dataInputStream.readShort();
        if (short1 >= 0) {
            this.c = new ItemStack(short1, dataInputStream.readByte(), dataInputStream.readShort());
        }
        else {
            this.c = null;
        }
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeByte(this.a);
        dataOutputStream.writeShort(this.b);
        if (this.c == null) {
            dataOutputStream.writeShort(-1);
        }
        else {
            dataOutputStream.writeShort(this.c.id);
            dataOutputStream.writeByte(this.c.count);
            dataOutputStream.writeShort(this.c.h());
        }
    }
    
    @Override
    public int a() {
        return 8;
    }
}
