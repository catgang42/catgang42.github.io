// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemAxe extends ItemTool
{
    private static Block[] bi;
    
    protected ItemAxe(final int n, final EnumToolMaterial enumToolMaterial) {
        super(n, 3, enumToolMaterial, ItemAxe.bi);
    }
    
    static {
        ItemAxe.bi = new Block[] { Block.WOOD, Block.BOOKSHELF, Block.LOG, Block.CHEST };
    }
}
