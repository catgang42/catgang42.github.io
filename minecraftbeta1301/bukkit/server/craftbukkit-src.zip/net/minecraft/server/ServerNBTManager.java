// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.List;
import java.io.File;

public class ServerNBTManager extends PlayerNBTManager
{
    public ServerNBTManager(final File file, final String s, final boolean b) {
        super(file, s, b);
    }
    
    @Override
    public IChunkLoader a(final WorldProvider worldProvider) {
        final File a = this.a();
        if (worldProvider instanceof WorldProviderHell) {
            final File file = new File(a, "DIM-1");
            file.mkdirs();
            return new ChunkRegionLoader(file);
        }
        return new ChunkRegionLoader(a);
    }
    
    @Override
    public void a(final WorldData worldData, final List list) {
        worldData.a(19132);
        super.a(worldData, list);
    }
    
    @Override
    public void e() {
        RegionFileCache.a();
    }
}
