// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockRedstoneOre extends Block
{
    private boolean a;
    
    public BlockRedstoneOre(final int n, final int n2, final boolean a) {
        super(n, n2, Material.STONE);
        if (a) {
            this.a(true);
        }
        this.a = a;
    }
    
    @Override
    public int b() {
        return 30;
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        this.g(world, n, n2, n3);
        super.b(world, n, n2, n3, entityHuman);
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3, final Entity entity) {
        this.g(world, n, n2, n3);
        super.b(world, n, n2, n3, entity);
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        this.g(world, n, n2, n3);
        return super.a(world, n, n2, n3, entityHuman);
    }
    
    private void g(final World world, final int i, final int j, final int k) {
        this.h(world, i, j, k);
        if (this.id == Block.REDSTONE_ORE.id) {
            world.e(i, j, k, Block.GLOWING_REDSTONE_ORE.id);
        }
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (this.id == Block.GLOWING_REDSTONE_ORE.id) {
            world.e(i, j, k, Block.REDSTONE_ORE.id);
        }
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Item.REDSTONE.id;
    }
    
    @Override
    public int a(final Random random) {
        return 4 + random.nextInt(2);
    }
    
    private void h(final World world, final int n, final int n2, final int n3) {
        final Random k = world.k;
        final double n4 = 0.0625;
        for (int i = 0; i < 6; ++i) {
            double d0 = n + k.nextFloat();
            double d2 = n2 + k.nextFloat();
            double d3 = n3 + k.nextFloat();
            if (i == 0 && !world.d(n, n2 + 1, n3)) {
                d2 = n2 + 1 + n4;
            }
            if (i == 1 && !world.d(n, n2 - 1, n3)) {
                d2 = n2 + 0 - n4;
            }
            if (i == 2 && !world.d(n, n2, n3 + 1)) {
                d3 = n3 + 1 + n4;
            }
            if (i == 3 && !world.d(n, n2, n3 - 1)) {
                d3 = n3 + 0 - n4;
            }
            if (i == 4 && !world.d(n + 1, n2, n3)) {
                d0 = n + 1 + n4;
            }
            if (i == 5 && !world.d(n - 1, n2, n3)) {
                d0 = n + 0 - n4;
            }
            if (d0 < n || d0 > n + 1 || d2 < 0.0 || d2 > n2 + 1 || d3 < n3 || d3 > n3 + 1) {
                world.a("reddust", d0, d2, d3, 0.0, 0.0, 0.0);
            }
        }
    }
}
