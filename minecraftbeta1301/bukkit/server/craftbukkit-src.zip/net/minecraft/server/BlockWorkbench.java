// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockInteractEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.event.Event;

public class BlockWorkbench extends Block
{
    protected BlockWorkbench(final int i) {
        super(i, Material.WOOD);
        this.textureId = 59;
    }
    
    @Override
    public int a(final int i) {
        return (i == 1) ? (this.textureId - 16) : ((i == 0) ? Block.WOOD.a(0) : ((i != 2 && i != 4) ? this.textureId : (this.textureId + 1)));
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        if (world.isStatic) {
            return true;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer server = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.BLOCK_INTERACT;
        final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
        final LivingEntity who = (entityhuman == null) ? null : ((LivingEntity)entityhuman.getBukkitEntity());
        final BlockInteractEvent event = new BlockInteractEvent(eventType, block, who);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        entityhuman.b(i, j, k);
        return true;
    }
}
