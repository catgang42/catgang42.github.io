// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemSaddle extends Item
{
    public ItemSaddle(final int n) {
        super(n);
        this.maxStackSize = 1;
        this.durability = 64;
    }
    
    @Override
    public void b(final ItemStack itemStack, final EntityLiving entityLiving) {
        if (entityLiving instanceof EntityPig) {
            final EntityPig entityPig = (EntityPig)entityLiving;
            if (!entityPig.r()) {
                entityPig.a(true);
                --itemStack.count;
            }
        }
    }
    
    @Override
    public void a(final ItemStack itemStack, final EntityLiving entityLiving) {
        this.b(itemStack, entityLiving);
    }
}
