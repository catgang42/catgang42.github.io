// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntityGiantZombie extends EntityMonster
{
    public EntityGiantZombie(final World world) {
        super(world);
        this.texture = "/mob/zombie.png";
        this.az = 0.5f;
        this.c = 50;
        this.health *= 10;
        this.height *= 6.0f;
        this.a(this.length * 6.0f, this.width * 6.0f);
    }
    
    @Override
    protected float a(final int i, final int j, final int k) {
        return this.world.l(i, j, k) - 0.5f;
    }
}
