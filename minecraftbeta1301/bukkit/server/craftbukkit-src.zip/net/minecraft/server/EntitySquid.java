// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntitySquid extends EntityWaterAnimal
{
    public float a;
    public float b;
    public float c;
    public float f;
    public float g;
    public float h;
    public float i;
    public float j;
    private float k;
    private float l;
    private float m;
    private float n;
    private float o;
    private float p;
    
    public EntitySquid(final World world) {
        super(world);
        this.a = 0.0f;
        this.b = 0.0f;
        this.c = 0.0f;
        this.f = 0.0f;
        this.g = 0.0f;
        this.h = 0.0f;
        this.i = 0.0f;
        this.j = 0.0f;
        this.k = 0.0f;
        this.l = 0.0f;
        this.m = 0.0f;
        this.n = 0.0f;
        this.o = 0.0f;
        this.p = 0.0f;
        this.texture = "/mob/squid.png";
        this.a(0.95f, 0.95f);
        this.l = 1.0f / (this.random.nextFloat() + 1.0f) * 0.2f;
    }
    
    @Override
    public void a(final NBTTagCompound nbtTagCompound) {
        super.a(nbtTagCompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbtTagCompound) {
        super.b(nbtTagCompound);
    }
    
    @Override
    protected String e() {
        return null;
    }
    
    @Override
    protected String f() {
        return null;
    }
    
    @Override
    protected String g() {
        return null;
    }
    
    @Override
    protected float i() {
        return 0.4f;
    }
    
    @Override
    protected int h() {
        return 0;
    }
    
    @Override
    protected void o() {
        for (int n = this.random.nextInt(3) + 1, i = 0; i < n; ++i) {
            this.a(new ItemStack(Item.INK_SACK, 1, 0), 0.0f);
        }
    }
    
    @Override
    public boolean a(final EntityHuman entityHuman) {
        return false;
    }
    
    @Override
    public boolean g_() {
        return this.world.a(this.boundingBox.b(0.0, -0.6000000238418579, 0.0), Material.WATER, this);
    }
    
    @Override
    public void q() {
        super.q();
        this.b = this.a;
        this.f = this.c;
        this.h = this.g;
        this.j = this.i;
        this.g += this.l;
        if (this.g > 6.2831855f) {
            this.g -= 6.2831855f;
            if (this.random.nextInt(10) == 0) {
                this.l = 1.0f / (this.random.nextFloat() + 1.0f) * 0.2f;
            }
        }
        if (this.g_()) {
            if (this.g < 3.1415927f) {
                final float n = this.g / 3.1415927f;
                this.i = MathHelper.a(n * n * 3.1415927f) * 3.1415927f * 0.25f;
                if (n > 0.75) {
                    this.k = 1.0f;
                    this.m = 1.0f;
                }
                else {
                    this.m *= 0.8f;
                }
            }
            else {
                this.i = 0.0f;
                this.k *= 0.9f;
                this.m *= 0.99f;
            }
            if (!this.T) {
                this.motX = this.n * this.k;
                this.motY = this.o * this.k;
                this.motZ = this.p * this.k;
            }
            final float a = MathHelper.a(this.motX * this.motX + this.motZ * this.motZ);
            this.F += (-(float)Math.atan2(this.motX, this.motZ) * 180.0f / 3.1415927f - this.F) * 0.1f;
            this.yaw = this.F;
            this.c += 3.1415927f * this.m * 1.5f;
            this.a += (-(float)Math.atan2(a, this.motY) * 180.0f / 3.1415927f - this.a) * 0.1f;
        }
        else {
            this.i = MathHelper.e(MathHelper.a(this.g)) * 3.1415927f * 0.25f;
            if (!this.T) {
                this.motX = 0.0;
                this.motY -= 0.08;
                this.motY *= 0.9800000190734863;
                this.motZ = 0.0;
            }
            this.a += (float)((-90.0f - this.a) * 0.02);
        }
    }
    
    @Override
    public void b(final float n, final float n2) {
        this.c(this.motX, this.motY, this.motZ);
    }
    
    @Override
    protected void c_() {
        if (this.random.nextInt(50) == 0 || !this.bv || (this.n == 0.0f && this.o == 0.0f && this.p == 0.0f)) {
            final float n = this.random.nextFloat() * 3.1415927f * 2.0f;
            this.n = MathHelper.b(n) * 0.2f;
            this.o = -0.1f + this.random.nextFloat() * 0.2f;
            this.p = MathHelper.a(n) * 0.2f;
        }
    }
}
