// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class WorldGenClay extends WorldGenerator
{
    private int a;
    private int b;
    
    public WorldGenClay(final int b) {
        this.a = Block.CLAY.id;
        this.b = b;
    }
    
    @Override
    public boolean a(final World world, final Random random, final int i, final int j, final int k) {
        if (world.getMaterial(i, j, k) != Material.WATER) {
            return false;
        }
        final float n = random.nextFloat() * 3.1415927f;
        final double n2 = i + 8 + MathHelper.a(n) * this.b / 8.0f;
        final double n3 = i + 8 - MathHelper.a(n) * this.b / 8.0f;
        final double n4 = k + 8 + MathHelper.b(n) * this.b / 8.0f;
        final double n5 = k + 8 - MathHelper.b(n) * this.b / 8.0f;
        final double n6 = j + random.nextInt(3) + 2;
        final double n7 = j + random.nextInt(3) + 2;
        for (int l = 0; l <= this.b; ++l) {
            final double n8 = n2 + (n3 - n2) * l / this.b;
            final double n9 = n6 + (n7 - n6) * l / this.b;
            final double n10 = n4 + (n5 - n4) * l / this.b;
            final double n11 = random.nextDouble() * this.b / 16.0;
            final double n12 = (MathHelper.a(l * 3.1415927f / this.b) + 1.0f) * n11 + 1.0;
            final double n13 = (MathHelper.a(l * 3.1415927f / this.b) + 1.0f) * n11 + 1.0;
            for (int n14 = (int)(n8 - n12 / 2.0); n14 <= (int)(n8 + n12 / 2.0); ++n14) {
                for (int n15 = (int)(n9 - n13 / 2.0); n15 <= (int)(n9 + n13 / 2.0); ++n15) {
                    for (int n16 = (int)(n10 - n12 / 2.0); n16 <= (int)(n10 + n12 / 2.0); ++n16) {
                        final double n17 = (n14 + 0.5 - n8) / (n12 / 2.0);
                        final double n18 = (n15 + 0.5 - n9) / (n13 / 2.0);
                        final double n19 = (n16 + 0.5 - n10) / (n12 / 2.0);
                        if (n17 * n17 + n18 * n18 + n19 * n19 < 1.0 && world.getTypeId(n14, n15, n16) == Block.SAND.id) {
                            world.setTypeId(n14, n15, n16, this.a);
                        }
                    }
                }
            }
        }
        return true;
    }
}
