// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;

public class Vec3D
{
    private static List d;
    private static int e;
    public double a;
    public double b;
    public double c;
    
    public static Vec3D a(final double n, final double n2, final double n3) {
        return new Vec3D(n, n2, n3);
    }
    
    public static void a() {
        Vec3D.e = 0;
    }
    
    public static Vec3D b(final double n, final double n2, final double n3) {
        if (Vec3D.e >= Vec3D.d.size()) {
            Vec3D.d.add(a(0.0, 0.0, 0.0));
        }
        return Vec3D.d.get(Vec3D.e++).e(n, n2, n3);
    }
    
    private Vec3D(double a, double b, double c) {
        if (a == -0.0) {
            a = 0.0;
        }
        if (b == -0.0) {
            b = 0.0;
        }
        if (c == -0.0) {
            c = 0.0;
        }
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    private Vec3D e(final double a, final double b, final double c) {
        this.a = a;
        this.b = b;
        this.c = c;
        return this;
    }
    
    public Vec3D b() {
        final double n = MathHelper.a(this.a * this.a + this.b * this.b + this.c * this.c);
        if (n < 1.0E-4) {
            return b(0.0, 0.0, 0.0);
        }
        return b(this.a / n, this.b / n, this.c / n);
    }
    
    public Vec3D c(final double n, final double n2, final double n3) {
        return b(this.a + n, this.b + n2, this.c + n3);
    }
    
    public double a(final Vec3D vec3D) {
        final double n = vec3D.a - this.a;
        final double n2 = vec3D.b - this.b;
        final double n3 = vec3D.c - this.c;
        return MathHelper.a(n * n + n2 * n2 + n3 * n3);
    }
    
    public double b(final Vec3D vec3D) {
        final double n = vec3D.a - this.a;
        final double n2 = vec3D.b - this.b;
        final double n3 = vec3D.c - this.c;
        return n * n + n2 * n2 + n3 * n3;
    }
    
    public double d(final double n, final double n2, final double n3) {
        final double n4 = n - this.a;
        final double n5 = n2 - this.b;
        final double n6 = n3 - this.c;
        return n4 * n4 + n5 * n5 + n6 * n6;
    }
    
    public double c() {
        return MathHelper.a(this.a * this.a + this.b * this.b + this.c * this.c);
    }
    
    public Vec3D a(final Vec3D vec3D, final double n) {
        final double n2 = vec3D.a - this.a;
        final double n3 = vec3D.b - this.b;
        final double n4 = vec3D.c - this.c;
        if (n2 * n2 < 1.0000000116860974E-7) {
            return null;
        }
        final double n5 = (n - this.a) / n2;
        if (n5 < 0.0 || n5 > 1.0) {
            return null;
        }
        return b(this.a + n2 * n5, this.b + n3 * n5, this.c + n4 * n5);
    }
    
    public Vec3D b(final Vec3D vec3D, final double n) {
        final double n2 = vec3D.a - this.a;
        final double n3 = vec3D.b - this.b;
        final double n4 = vec3D.c - this.c;
        if (n3 * n3 < 1.0000000116860974E-7) {
            return null;
        }
        final double n5 = (n - this.b) / n3;
        if (n5 < 0.0 || n5 > 1.0) {
            return null;
        }
        return b(this.a + n2 * n5, this.b + n3 * n5, this.c + n4 * n5);
    }
    
    public Vec3D c(final Vec3D vec3D, final double n) {
        final double n2 = vec3D.a - this.a;
        final double n3 = vec3D.b - this.b;
        final double n4 = vec3D.c - this.c;
        if (n4 * n4 < 1.0000000116860974E-7) {
            return null;
        }
        final double n5 = (n - this.c) / n4;
        if (n5 < 0.0 || n5 > 1.0) {
            return null;
        }
        return b(this.a + n2 * n5, this.b + n3 * n5, this.c + n4 * n5);
    }
    
    @Override
    public String toString() {
        return "(" + this.a + ", " + this.b + ", " + this.c + ")";
    }
    
    static {
        Vec3D.d = new ArrayList();
        Vec3D.e = 0;
    }
}
