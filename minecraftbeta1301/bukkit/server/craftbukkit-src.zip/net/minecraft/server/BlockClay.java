// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockClay extends Block
{
    public BlockClay(final int n, final int n2) {
        super(n, n2, Material.CLAY);
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Item.CLAY_BALL.id;
    }
    
    @Override
    public int a(final Random random) {
        return 4;
    }
}
