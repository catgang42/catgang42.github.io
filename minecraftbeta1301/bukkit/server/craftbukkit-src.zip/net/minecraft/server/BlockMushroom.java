// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockMushroom extends BlockFlower
{
    protected BlockMushroom(final int n, final int n2) {
        super(n, n2);
        final float n3 = 0.2f;
        this.a(0.5f - n3, 0.0f, 0.5f - n3, 0.5f + n3, n3 * 2.0f, 0.5f + n3);
    }
    
    @Override
    protected boolean c(final int n) {
        return Block.o[n];
    }
    
    @Override
    public boolean f(final World world, final int n, final int j, final int n2) {
        return world.j(n, j, n2) <= 13 && this.c(world.getTypeId(n, j - 1, n2));
    }
}
