// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntityChicken extends EntityAnimal
{
    public boolean a;
    public float b;
    public float c;
    public float f;
    public float g;
    public float h;
    public int i;
    
    public EntityChicken(final World world) {
        super(world);
        this.a = false;
        this.b = 0.0f;
        this.c = 0.0f;
        this.h = 1.0f;
        this.texture = "/mob/chicken.png";
        this.a(0.3f, 0.4f);
        this.health = 4;
        this.i = this.random.nextInt(6000) + 6000;
    }
    
    @Override
    public void q() {
        super.q();
        this.g = this.b;
        this.f = this.c;
        this.c += (float)((this.onGround ? -1 : 4) * 0.3);
        if (this.c < 0.0f) {
            this.c = 0.0f;
        }
        if (this.c > 1.0f) {
            this.c = 1.0f;
        }
        if (!this.onGround && this.h < 1.0f) {
            this.h = 1.0f;
        }
        this.h *= (float)0.9;
        if (!this.onGround && this.motY < 0.0) {
            this.motY *= 0.6;
        }
        this.b += this.h * 2.0f;
        if (!this.world.isStatic && --this.i <= 0) {
            this.world.a(this, "mob.chickenplop", 1.0f, (this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f);
            this.b(Item.EGG.id, 1);
            this.i = this.random.nextInt(6000) + 6000;
        }
    }
    
    @Override
    protected void a(final float n) {
    }
    
    @Override
    public void a(final NBTTagCompound nbtTagCompound) {
        super.a(nbtTagCompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbtTagCompound) {
        super.b(nbtTagCompound);
    }
    
    @Override
    protected String e() {
        return "mob.chicken";
    }
    
    @Override
    protected String f() {
        return "mob.chickenhurt";
    }
    
    @Override
    protected String g() {
        return "mob.chickenhurt";
    }
    
    @Override
    protected int h() {
        return Item.FEATHER.id;
    }
}
