// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ChunkCache implements IBlockAccess
{
    private int a;
    private int b;
    private Chunk[][] c;
    private World d;
    
    public ChunkCache(final World d, final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        this.d = d;
        this.a = n >> 4;
        this.b = n3 >> 4;
        final int n7 = n4 >> 4;
        final int n8 = n6 >> 4;
        this.c = new Chunk[n7 - this.a + 1][n8 - this.b + 1];
        for (int i = this.a; i <= n7; ++i) {
            for (int j = this.b; j <= n8; ++j) {
                this.c[i - this.a][j - this.b] = d.c(i, j);
            }
        }
    }
    
    public int getTypeId(final int n, final int j, final int n2) {
        if (j < 0) {
            return 0;
        }
        if (j >= 128) {
            return 0;
        }
        final int n3 = (n >> 4) - this.a;
        final int n4 = (n2 >> 4) - this.b;
        if (n3 < 0 || n3 >= this.c.length || n4 < 0 || n4 >= this.c[n3].length) {
            return 0;
        }
        final Chunk chunk = this.c[n3][n4];
        if (chunk == null) {
            return 0;
        }
        return chunk.a(n & 0xF, j, n2 & 0xF);
    }
    
    public int getData(final int n, final int j, final int n2) {
        if (j < 0) {
            return 0;
        }
        if (j >= 128) {
            return 0;
        }
        return this.c[(n >> 4) - this.a][(n2 >> 4) - this.b].b(n & 0xF, j, n2 & 0xF);
    }
    
    public Material getMaterial(final int n, final int n2, final int n3) {
        final int typeId = this.getTypeId(n, n2, n3);
        if (typeId == 0) {
            return Material.AIR;
        }
        return Block.byId[typeId].material;
    }
    
    public boolean d(final int n, final int n2, final int n3) {
        final Block block = Block.byId[this.getTypeId(n, n2, n3)];
        return block != null && block.a();
    }
}
