// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

class ThreadMonitorConnection extends Thread
{
    final /* synthetic */ NetworkManager a;
    
    ThreadMonitorConnection(final NetworkManager a) {
        this.a = a;
    }
    
    @Override
    public void run() {
        try {
            Thread.sleep(2000L);
            if (this.a.j) {
                this.a.p.interrupt();
                this.a.a("disconnect.closed", new Object[0]);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
