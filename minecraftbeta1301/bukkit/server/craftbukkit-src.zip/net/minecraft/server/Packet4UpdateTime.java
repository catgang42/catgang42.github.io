// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet4UpdateTime extends Packet
{
    public long a;
    
    public Packet4UpdateTime() {
    }
    
    public Packet4UpdateTime(final long a) {
        this.a = a;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readLong();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeLong(this.a);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 8;
    }
}
