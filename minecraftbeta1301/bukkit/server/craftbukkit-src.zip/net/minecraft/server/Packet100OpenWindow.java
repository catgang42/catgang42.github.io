// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet100OpenWindow extends Packet
{
    public int a;
    public int b;
    public String c;
    public int d;
    
    public Packet100OpenWindow() {
    }
    
    public Packet100OpenWindow(final int a, final int b, final String c, final int d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readByte();
        this.b = dataInputStream.readByte();
        this.c = dataInputStream.readUTF();
        this.d = dataInputStream.readByte();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeByte(this.a);
        dataOutputStream.writeByte(this.b);
        dataOutputStream.writeUTF(this.c);
        dataOutputStream.writeByte(this.d);
    }
    
    @Override
    public int a() {
        return 3 + this.c.length();
    }
}
