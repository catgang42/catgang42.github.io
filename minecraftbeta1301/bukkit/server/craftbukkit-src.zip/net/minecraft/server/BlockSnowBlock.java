// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockSnowBlock extends Block
{
    protected BlockSnowBlock(final int n, final int n2) {
        super(n, n2, Material.SNOW_BLOCK);
        this.a(true);
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Item.SNOW_BALL.id;
    }
    
    @Override
    public int a(final Random random) {
        return 4;
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (world.a(EnumSkyBlock.BLOCK, i, j, k) > 11) {
            this.b_(world, i, j, k, world.getData(i, j, k));
            world.e(i, j, k, 0);
        }
    }
}
