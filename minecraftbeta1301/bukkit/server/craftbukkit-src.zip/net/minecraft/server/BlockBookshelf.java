// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockBookshelf extends Block
{
    public BlockBookshelf(final int n, final int n2) {
        super(n, n2, Material.WOOD);
    }
    
    @Override
    public int a(final int n) {
        if (n <= 1) {
            return 4;
        }
        return this.textureId;
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
}
