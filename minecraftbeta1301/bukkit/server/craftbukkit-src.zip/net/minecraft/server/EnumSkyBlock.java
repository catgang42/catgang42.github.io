// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public enum EnumSkyBlock
{
    SKY("Sky", 0, 15), 
    BLOCK("Block", 1, 0);
    
    public final int c;
    
    private EnumSkyBlock(final String name, final int ordinal, final int c) {
        this.c = c;
    }
}
