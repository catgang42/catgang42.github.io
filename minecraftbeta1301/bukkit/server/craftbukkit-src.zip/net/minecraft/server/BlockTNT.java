// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockTNT extends Block
{
    public BlockTNT(final int n, final int n2) {
        super(n, n2, Material.TNT);
    }
    
    @Override
    public int a(final int n) {
        if (n == 0) {
            return this.textureId + 2;
        }
        if (n == 1) {
            return this.textureId + 1;
        }
        return this.textureId;
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        if (n4 > 0 && Block.byId[n4].c() && world.p(n, n2, n3)) {
            this.b(world, n, n2, n3, 0);
            world.e(n, n2, n3, 0);
        }
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
    
    @Override
    public void c(final World world, final int n, final int n2, final int n3) {
        final EntityTNTPrimed entity = new EntityTNTPrimed(world, n + 0.5f, n2 + 0.5f, n3 + 0.5f);
        entity.a = world.k.nextInt(entity.a / 4) + entity.a / 8;
        world.a(entity);
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3, final int n4) {
        if (world.isStatic) {
            return;
        }
        final EntityTNTPrimed entityTNTPrimed = new EntityTNTPrimed(world, n + 0.5f, n2 + 0.5f, n3 + 0.5f);
        world.a(entityTNTPrimed);
        world.a(entityTNTPrimed, "random.fuse", 1.0f, 1.0f);
    }
}
