// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Formatter;
import org.bukkit.craftbukkit.util.ShortConsoleLogFormatter;
import org.bukkit.craftbukkit.util.TerminalConsoleHandler;
import java.util.logging.Logger;

public class ConsoleLogManager
{
    public static Logger a;
    public static Logger global;
    
    public static void a(final MinecraftServer server) {
        final ConsoleLogFormatter consolelogformatter = new ConsoleLogFormatter();
        ConsoleLogManager.a.setUseParentHandlers(false);
        final ConsoleHandler consolehandler = new TerminalConsoleHandler(server.reader);
        for (final Handler handler : ConsoleLogManager.global.getHandlers()) {
            ConsoleLogManager.global.removeHandler(handler);
        }
        consolehandler.setFormatter(new ShortConsoleLogFormatter(server));
        ConsoleLogManager.a.addHandler(consolehandler);
        ConsoleLogManager.global.addHandler(consolehandler);
        try {
            final FileHandler filehandler = new FileHandler("server.log", true);
            filehandler.setFormatter(consolelogformatter);
            ConsoleLogManager.a.addHandler(filehandler);
            ConsoleLogManager.global.addHandler(filehandler);
        }
        catch (Exception exception) {
            ConsoleLogManager.a.log(Level.WARNING, "Failed to log to server.log", exception);
        }
    }
    
    static {
        ConsoleLogManager.a = Logger.getLogger("Minecraft");
        ConsoleLogManager.global = Logger.getLogger("");
    }
}
