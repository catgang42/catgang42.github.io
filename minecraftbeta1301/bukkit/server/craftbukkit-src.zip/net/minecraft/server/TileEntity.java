// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.HashMap;
import java.util.Map;

public class TileEntity
{
    private static Map a;
    private static Map b;
    public World d;
    public int e;
    public int f;
    public int g;
    
    private static void a(final Class clazz, final String str) {
        if (TileEntity.b.containsKey(str)) {
            throw new IllegalArgumentException("Duplicate id: " + str);
        }
        TileEntity.a.put(str, clazz);
        TileEntity.b.put(clazz, str);
    }
    
    public void a(final NBTTagCompound nbtTagCompound) {
        this.e = nbtTagCompound.e("x");
        this.f = nbtTagCompound.e("y");
        this.g = nbtTagCompound.e("z");
    }
    
    public void b(final NBTTagCompound nbtTagCompound) {
        final String s = TileEntity.b.get(this.getClass());
        if (s == null) {
            throw new RuntimeException(this.getClass() + " is missing a mapping! This is a bug!");
        }
        nbtTagCompound.a("id", s);
        nbtTagCompound.a("x", this.e);
        nbtTagCompound.a("y", this.f);
        nbtTagCompound.a("z", this.g);
    }
    
    public void i_() {
    }
    
    public static TileEntity c(final NBTTagCompound nbtTagCompound) {
        TileEntity tileEntity = null;
        try {
            final Class<TileEntity> clazz = TileEntity.a.get(nbtTagCompound.i("id"));
            if (clazz != null) {
                tileEntity = clazz.newInstance();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        if (tileEntity != null) {
            tileEntity.a(nbtTagCompound);
        }
        else {
            System.out.println("Skipping TileEntity with id " + nbtTagCompound.i("id"));
        }
        return tileEntity;
    }
    
    public void h() {
        if (this.d != null) {
            this.d.b(this.e, this.f, this.g, this);
        }
    }
    
    public Packet e() {
        return null;
    }
    
    static {
        TileEntity.a = new HashMap();
        TileEntity.b = new HashMap();
        a(TileEntityFurnace.class, "Furnace");
        a(TileEntityChest.class, "Chest");
        a(TileEntityDispenser.class, "Trap");
        a(TileEntitySign.class, "Sign");
        a(TileEntityMobSpawner.class, "MobSpawner");
        a(TileEntityNote.class, "Music");
    }
}
