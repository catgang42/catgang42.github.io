// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet27 extends Packet
{
    private float a;
    private float b;
    private boolean c;
    private boolean d;
    private float e;
    private float f;
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readFloat();
        this.b = dataInputStream.readFloat();
        this.e = dataInputStream.readFloat();
        this.f = dataInputStream.readFloat();
        this.c = dataInputStream.readBoolean();
        this.d = dataInputStream.readBoolean();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeFloat(this.a);
        dataOutputStream.writeFloat(this.b);
        dataOutputStream.writeFloat(this.e);
        dataOutputStream.writeFloat(this.f);
        dataOutputStream.writeBoolean(this.c);
        dataOutputStream.writeBoolean(this.d);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 18;
    }
    
    public float c() {
        return this.a;
    }
    
    public float d() {
        return this.e;
    }
    
    public float e() {
        return this.b;
    }
    
    public float f() {
        return this.f;
    }
    
    public boolean g() {
        return this.c;
    }
    
    public boolean h() {
        return this.d;
    }
}
