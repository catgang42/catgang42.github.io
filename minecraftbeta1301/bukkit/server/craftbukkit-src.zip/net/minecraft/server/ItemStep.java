// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemStep extends ItemBlock
{
    public ItemStep(final int i) {
        super(i);
        this.d(0);
        this.a(true);
    }
    
    @Override
    public int a(final int n) {
        return n;
    }
}
