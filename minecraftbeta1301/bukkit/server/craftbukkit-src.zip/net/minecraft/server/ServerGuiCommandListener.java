// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.event.ActionListener;

class ServerGuiCommandListener implements ActionListener
{
    final /* synthetic */ JTextField a;
    final /* synthetic */ ServerGUI b;
    
    ServerGuiCommandListener(final ServerGUI b, final JTextField a) {
        this.b = b;
        this.a = a;
    }
    
    public void actionPerformed(final ActionEvent actionEvent) {
        final String trim = this.a.getText().trim();
        if (trim.length() > 0) {
            this.b.b.a(trim, this.b);
        }
        this.a.setText("");
    }
}
