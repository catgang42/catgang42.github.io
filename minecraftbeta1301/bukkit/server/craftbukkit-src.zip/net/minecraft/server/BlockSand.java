// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockSand extends Block
{
    public static boolean a;
    
    public BlockSand(final int n, final int n2) {
        super(n, n2, Material.SAND);
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
        world.c(i, j, k, this.id, this.b());
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int n) {
        world.c(i, j, k, this.id, this.b());
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Random random) {
        this.g(world, n, n2, n3);
    }
    
    private void g(final World world, final int n, int n2, final int n3) {
        final int n4 = n2;
        if (b_(world, n, n4 - 1, n3) && n4 >= 0) {
            final int n5 = 32;
            if (BlockSand.a || !world.a(n - n5, n2 - n5, n3 - n5, n + n5, n2 + n5, n3 + n5)) {
                world.e(n, n2, n3, 0);
                while (b_(world, n, n2 - 1, n3) && n2 > 0) {
                    --n2;
                }
                if (n2 > 0) {
                    world.e(n, n2, n3, this.id);
                }
            }
            else {
                world.a(new EntityFallingSand(world, n + 0.5f, n2 + 0.5f, n3 + 0.5f, this.id));
            }
        }
    }
    
    @Override
    public int b() {
        return 3;
    }
    
    public static boolean b_(final World world, final int i, final int j, final int k) {
        final int typeId = world.getTypeId(i, j, k);
        if (typeId == 0) {
            return true;
        }
        if (typeId == Block.FIRE.id) {
            return true;
        }
        final Material material = Block.byId[typeId].material;
        return material == Material.WATER || material == Material.LAVA;
    }
    
    static {
        BlockSand.a = false;
    }
}
