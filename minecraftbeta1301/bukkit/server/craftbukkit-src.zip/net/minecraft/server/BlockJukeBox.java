// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockInteractEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.event.Event;

public class BlockJukeBox extends Block
{
    protected BlockJukeBox(final int i, final int j) {
        super(i, j, Material.WOOD);
    }
    
    @Override
    public int a(final int i) {
        return this.textureId + ((i == 1) ? 1 : 0);
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        final int l = world.getData(i, j, k);
        if (l <= 0) {
            return false;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer server = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.BLOCK_INTERACT;
        final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
        final LivingEntity who = (entityhuman == null) ? null : ((LivingEntity)entityhuman.getBukkitEntity());
        final BlockInteractEvent event = new BlockInteractEvent(eventType, block, who);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        this.e(world, i, j, k, l);
        return true;
    }
    
    public void e(final World world, final int i, final int j, final int k, final int l) {
        world.a((String)null, i, j, k);
        world.c(i, j, k, 0);
        final int i2 = Item.GOLD_RECORD.id + l - 1;
        final float f = 0.7f;
        final double d0 = world.k.nextFloat() * f + (1.0f - f) * 0.5;
        final double d2 = world.k.nextFloat() * f + (1.0f - f) * 0.2 + 0.6;
        final double d3 = world.k.nextFloat() * f + (1.0f - f) * 0.5;
        final EntityItem entityitem = new EntityItem(world, i + d0, j + d2, k + d3, new ItemStack(i2, 1, 0));
        entityitem.c = 10;
        world.a(entityitem);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l, final float f) {
        if (!world.isStatic) {
            if (l > 0) {
                this.e(world, i, j, k, l);
            }
            super.a(world, i, j, k, l, f);
        }
    }
}
