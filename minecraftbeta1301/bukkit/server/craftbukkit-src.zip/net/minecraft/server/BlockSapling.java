// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockSapling extends BlockFlower
{
    protected BlockSapling(final int n, final int n2) {
        super(n, n2);
        final float n3 = 0.4f;
        this.a(0.5f - n3, 0.0f, 0.5f - n3, 0.5f + n3, n3 * 2.0f, 0.5f + n3);
    }
    
    @Override
    public void a(final World world, final int i, final int n, final int k, final Random random) {
        super.a(world, i, n, k, random);
        if (world.j(i, n + 1, k) >= 9 && random.nextInt(5) == 0) {
            final int data = world.getData(i, n, k);
            if (data < 15) {
                world.c(i, n, k, data + 1);
            }
            else {
                this.b(world, i, n, k, random);
            }
        }
    }
    
    public void b(final World world, final int n, final int n2, final int n3, final Random random) {
        world.setTypeId(n, n2, n3, 0);
        WorldGenerator worldGenerator = new WorldGenTrees();
        if (random.nextInt(10) == 0) {
            worldGenerator = new WorldGenBigTree();
        }
        if (!worldGenerator.a(world, random, n, n2, n3)) {
            world.setTypeId(n, n2, n3, this.id);
        }
    }
}
