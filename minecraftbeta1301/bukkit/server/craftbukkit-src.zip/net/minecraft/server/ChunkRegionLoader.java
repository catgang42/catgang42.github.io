// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataOutput;
import java.io.DataInputStream;
import java.io.DataInput;
import java.io.File;

public class ChunkRegionLoader implements IChunkLoader
{
    private final File a;
    
    public ChunkRegionLoader(final File a) {
        this.a = a;
    }
    
    public Chunk a(final World world, final int i, final int j) {
        final DataInputStream c = RegionFileCache.c(this.a, i, j);
        if (c == null) {
            return null;
        }
        final NBTTagCompound a = CompressedStreamTools.a((DataInput)c);
        if (!a.b("Level")) {
            System.out.println("Chunk file at " + i + "," + j + " is missing level data, skipping");
            return null;
        }
        if (!a.k("Level").b("Blocks")) {
            System.out.println("Chunk file at " + i + "," + j + " is missing block data, skipping");
            return null;
        }
        Chunk chunk = ChunkLoader.a(world, a.k("Level"));
        if (!chunk.a(i, j)) {
            System.out.println("Chunk file at " + i + "," + j + " is in the wrong location; relocating. (Expected " + i + ", " + j + ", got " + chunk.j + ", " + chunk.k + ")");
            a.a("xPos", i);
            a.a("zPos", j);
            chunk = ChunkLoader.a(world, a.k("Level"));
        }
        return chunk;
    }
    
    public void a(final World world, final Chunk chunk) {
        world.i();
        try {
            final DataOutputStream d = RegionFileCache.d(this.a, chunk.j, chunk.k);
            final NBTTagCompound nbtTagCompound = new NBTTagCompound();
            final NBTTagCompound nbtTagCompound2 = new NBTTagCompound();
            nbtTagCompound.a("Level", (NBTBase)nbtTagCompound2);
            ChunkLoader.a(chunk, world, nbtTagCompound2);
            CompressedStreamTools.a(nbtTagCompound, (DataOutput)d);
            d.close();
            final WorldData n = world.n();
            n.b(n.g() + RegionFileCache.b(this.a, chunk.j, chunk.k));
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void b(final World world, final Chunk chunk) {
    }
    
    public void a() {
    }
    
    public void b() {
    }
}
