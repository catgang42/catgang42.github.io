// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;
import java.util.ArrayList;

public class BlockStairs extends Block
{
    private Block a;
    
    protected BlockStairs(final int n, final Block a) {
        super(n, a.textureId, a.material);
        this.a = a;
        this.c(a.strength);
        this.b(a.durability / 3.0f);
        this.a(a.stepSound);
    }
    
    @Override
    public void a(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return super.d(world, n, n2, n3);
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        return super.a(blockAccess, n, n2, n3, n4);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final AxisAlignedBB axisAlignedBB, final ArrayList list) {
        final int data = world.getData(i, j, k);
        if (data == 0) {
            this.a(0.0f, 0.0f, 0.0f, 0.5f, 0.5f, 1.0f);
            super.a(world, i, j, k, axisAlignedBB, list);
            this.a(0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
            super.a(world, i, j, k, axisAlignedBB, list);
        }
        else if (data == 1) {
            this.a(0.0f, 0.0f, 0.0f, 0.5f, 1.0f, 1.0f);
            super.a(world, i, j, k, axisAlignedBB, list);
            this.a(0.5f, 0.0f, 0.0f, 1.0f, 0.5f, 1.0f);
            super.a(world, i, j, k, axisAlignedBB, list);
        }
        else if (data == 2) {
            this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.5f, 0.5f);
            super.a(world, i, j, k, axisAlignedBB, list);
            this.a(0.0f, 0.0f, 0.5f, 1.0f, 1.0f, 1.0f);
            super.a(world, i, j, k, axisAlignedBB, list);
        }
        else if (data == 3) {
            this.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.5f);
            super.a(world, i, j, k, axisAlignedBB, list);
            this.a(0.0f, 0.0f, 0.5f, 1.0f, 0.5f, 1.0f);
            super.a(world, i, j, k, axisAlignedBB, list);
        }
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        this.a.b(world, n, n2, n3, entityHuman);
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3, final int n4) {
        this.a.b(world, n, n2, n3, n4);
    }
    
    @Override
    public float a(final Entity entity) {
        return this.a.a(entity);
    }
    
    @Override
    public int a(final int n, final Random random) {
        return this.a.a(n, random);
    }
    
    @Override
    public int a(final Random random) {
        return this.a.a(random);
    }
    
    @Override
    public int a(final int n, final int n2) {
        return this.a.a(n, n2);
    }
    
    @Override
    public int a(final int n) {
        return this.a.a(n);
    }
    
    @Override
    public int b() {
        return this.a.b();
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Entity entity, final Vec3D vec3D) {
        this.a.a(world, n, n2, n3, entity, vec3D);
    }
    
    @Override
    public boolean d() {
        return this.a.d();
    }
    
    @Override
    public boolean a(final int n, final boolean b) {
        return this.a.a(n, b);
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3) {
        return this.a.a(world, n, n2, n3);
    }
    
    @Override
    public void e(final World world, final int n, final int n2, final int n3) {
        this.a(world, n, n2, n3, 0);
        this.a.e(world, n, n2, n3);
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3) {
        this.a.b(world, n, n2, n3);
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4, final float n5) {
        this.a.a(world, n, n2, n3, n4, n5);
    }
    
    @Override
    public void b_(final World world, final int n, final int n2, final int n3, final int n4) {
        this.a.b_(world, n, n2, n3, n4);
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3, final Entity entity) {
        this.a.b(world, n, n2, n3, entity);
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Random random) {
        this.a.a(world, n, n2, n3, random);
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        return this.a.a(world, n, n2, n3, entityHuman);
    }
    
    @Override
    public void c(final World world, final int n, final int n2, final int n3) {
        this.a.c(world, n, n2, n3);
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final EntityLiving entityLiving) {
        final int n4 = MathHelper.b(entityLiving.yaw * 4.0f / 360.0f + 0.5) & 0x3;
        if (n4 == 0) {
            world.c(n, n2, n3, 2);
        }
        if (n4 == 1) {
            world.c(n, n2, n3, 1);
        }
        if (n4 == 2) {
            world.c(n, n2, n3, 3);
        }
        if (n4 == 3) {
            world.c(n, n2, n3, 0);
        }
    }
}
