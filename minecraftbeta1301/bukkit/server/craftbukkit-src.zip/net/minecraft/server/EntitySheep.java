// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class EntitySheep extends EntityAnimal
{
    public static final float[][] a;
    
    public EntitySheep(final World world) {
        super(world);
        this.texture = "/mob/sheep.png";
        this.a(0.9f, 1.3f);
    }
    
    @Override
    protected void a() {
        super.a();
        this.datawatcher.a(16, new Byte((byte)0));
    }
    
    @Override
    public boolean a(final Entity entity, final int i) {
        if (!this.world.isStatic && !this.j_() && entity instanceof EntityLiving) {
            this.a(true);
            for (int n = 1 + this.random.nextInt(3), j = 0; j < n; ++j) {
                final EntityItem a;
                final EntityItem entityItem = a = this.a(new ItemStack(Block.WOOL.id, 1, this.n()), 1.0f);
                a.motY += this.random.nextFloat() * 0.05f;
                final EntityItem entityItem2 = entityItem;
                entityItem2.motX += (this.random.nextFloat() - this.random.nextFloat()) * 0.1f;
                final EntityItem entityItem3 = entityItem;
                entityItem3.motZ += (this.random.nextFloat() - this.random.nextFloat()) * 0.1f;
            }
        }
        return super.a(entity, i);
    }
    
    @Override
    public void a(final NBTTagCompound nbtTagCompound) {
        super.a(nbtTagCompound);
        nbtTagCompound.a("Sheared", this.j_());
        nbtTagCompound.a("Color", (byte)this.n());
    }
    
    @Override
    public void b(final NBTTagCompound nbtTagCompound) {
        super.b(nbtTagCompound);
        this.a(nbtTagCompound.m("Sheared"));
        this.a_(nbtTagCompound.c("Color"));
    }
    
    @Override
    protected String e() {
        return "mob.sheep";
    }
    
    @Override
    protected String f() {
        return "mob.sheep";
    }
    
    @Override
    protected String g() {
        return "mob.sheep";
    }
    
    public int n() {
        return this.datawatcher.a(16) & 0xF;
    }
    
    public void a_(final int n) {
        this.datawatcher.b(16, (byte)((this.datawatcher.a(16) & 0xF0) | (n & 0xF)));
    }
    
    public boolean j_() {
        return (this.datawatcher.a(16) & 0x10) != 0x0;
    }
    
    public void a(final boolean b) {
        final byte a = this.datawatcher.a(16);
        if (b) {
            this.datawatcher.b(16, (byte)(a | 0x10));
        }
        else {
            this.datawatcher.b(16, (byte)(a & 0xFFFFFFEF));
        }
    }
    
    public static int a(final Random random) {
        final int nextInt = random.nextInt(100);
        if (nextInt < 5) {
            return 15;
        }
        if (nextInt < 10) {
            return 7;
        }
        if (nextInt < 15) {
            return 8;
        }
        return 0;
    }
    
    static {
        a = new float[][] { { 1.0f, 1.0f, 1.0f }, { 0.95f, 0.7f, 0.2f }, { 0.9f, 0.5f, 0.85f }, { 0.6f, 0.7f, 0.95f }, { 0.9f, 0.9f, 0.2f }, { 0.5f, 0.8f, 0.1f }, { 0.95f, 0.7f, 0.8f }, { 0.3f, 0.3f, 0.3f }, { 0.6f, 0.6f, 0.6f }, { 0.3f, 0.6f, 0.7f }, { 0.7f, 0.4f, 0.9f }, { 0.2f, 0.4f, 0.8f }, { 0.5f, 0.4f, 0.3f }, { 0.4f, 0.5f, 0.2f }, { 0.8f, 0.3f, 0.3f }, { 0.1f, 0.1f, 0.1f } };
    }
}
