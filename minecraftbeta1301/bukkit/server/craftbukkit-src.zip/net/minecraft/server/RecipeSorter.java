// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Comparator;

class RecipeSorter implements Comparator
{
    final /* synthetic */ CraftingManager a;
    
    RecipeSorter(final CraftingManager a) {
        this.a = a;
    }
    
    public int a(final CraftingRecipe craftingRecipe, final CraftingRecipe craftingRecipe2) {
        if (craftingRecipe instanceof ShapelessRecipes && craftingRecipe2 instanceof ShapedRecipes) {
            return 1;
        }
        if (craftingRecipe2 instanceof ShapelessRecipes && craftingRecipe instanceof ShapedRecipes) {
            return -1;
        }
        if (craftingRecipe2.a() < craftingRecipe.a()) {
            return -1;
        }
        if (craftingRecipe2.a() > craftingRecipe.a()) {
            return 1;
        }
        return 0;
    }
}
