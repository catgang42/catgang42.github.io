// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.File;
import java.util.regex.Pattern;
import java.io.FilenameFilter;

class ChunkFilenameFilter implements FilenameFilter
{
    public static final Pattern a;
    
    private ChunkFilenameFilter() {
    }
    
    public boolean accept(final File file, final String input) {
        return ChunkFilenameFilter.a.matcher(input).matches();
    }
    
    static {
        a = Pattern.compile("c\\.(-?[0-9a-z]+)\\.(-?[0-9a-z]+)\\.dat");
    }
}
