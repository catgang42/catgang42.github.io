// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public interface IInventory
{
    int m_();
    
    ItemStack c_(final int p0);
    
    ItemStack a(final int p0, final int p1);
    
    void a(final int p0, final ItemStack p1);
    
    String c();
    
    int n_();
    
    void h();
    
    boolean a_(final EntityHuman p0);
    
    ItemStack[] getContents();
}
