// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Arrays;

public class WorldChunkManagerHell extends WorldChunkManager
{
    private BiomeBase e;
    private double f;
    private double g;
    
    public WorldChunkManagerHell(final BiomeBase e, final double f, final double g) {
        this.e = e;
        this.f = f;
        this.g = g;
    }
    
    @Override
    public BiomeBase a(final ChunkCoordIntPair chunkCoordIntPair) {
        return this.e;
    }
    
    @Override
    public BiomeBase a(final int n, final int n2) {
        return this.e;
    }
    
    @Override
    public BiomeBase[] a(final int n, final int n2, final int n3, final int n4) {
        return this.d = this.a(this.d, n, n2, n3, n4);
    }
    
    @Override
    public double[] a(double[] a, final int n, final int n2, final int n3, final int n4) {
        if (a == null || a.length < n3 * n4) {
            a = new double[n3 * n4];
        }
        Arrays.fill(a, 0, n3 * n4, this.f);
        return a;
    }
    
    @Override
    public BiomeBase[] a(BiomeBase[] a, final int n, final int n2, final int n3, final int n4) {
        if (a == null || a.length < n3 * n4) {
            a = new BiomeBase[n3 * n4];
            this.a = new double[n3 * n4];
            this.b = new double[n3 * n4];
        }
        Arrays.fill(a, 0, n3 * n4, this.e);
        Arrays.fill(this.b, 0, n3 * n4, this.g);
        Arrays.fill(this.a, 0, n3 * n4, this.f);
        return a;
    }
}
