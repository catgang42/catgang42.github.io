// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.ArrayList;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.craftbukkit.block.CraftBlock;
import java.util.Random;
import java.util.List;

public class BlockRedstoneTorch extends BlockTorch
{
    private boolean a;
    private static List b;
    
    @Override
    public int a(final int i, final int j) {
        return (i == 1) ? Block.REDSTONE_WIRE.a(i, j) : super.a(i, j);
    }
    
    private boolean a(final World world, final int i, final int j, final int k, final boolean flag) {
        if (flag) {
            BlockRedstoneTorch.b.add(new RedstoneUpdateInfo(i, j, k, world.k()));
        }
        int l = 0;
        for (int i2 = 0; i2 < BlockRedstoneTorch.b.size(); ++i2) {
            final RedstoneUpdateInfo redstoneupdateinfo = BlockRedstoneTorch.b.get(i2);
            if (redstoneupdateinfo.a == i && redstoneupdateinfo.b == j && redstoneupdateinfo.c == k && ++l >= 8) {
                return true;
            }
        }
        return false;
    }
    
    protected BlockRedstoneTorch(final int i, final int j, final boolean flag) {
        super(i, j);
        this.a = false;
        this.a = flag;
        this.a(true);
    }
    
    @Override
    public int b() {
        return 2;
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
        if (world.getData(i, j, k) == 0) {
            super.e(world, i, j, k);
        }
        if (this.a) {
            world.h(i, j - 1, k, this.id);
            world.h(i, j + 1, k, this.id);
            world.h(i - 1, j, k, this.id);
            world.h(i + 1, j, k, this.id);
            world.h(i, j, k - 1, this.id);
            world.h(i, j, k + 1, this.id);
        }
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k) {
        if (this.a) {
            world.h(i, j - 1, k, this.id);
            world.h(i, j + 1, k, this.id);
            world.h(i - 1, j, k, this.id);
            world.h(i + 1, j, k, this.id);
            world.h(i, j, k - 1, this.id);
            world.h(i, j, k + 1, this.id);
        }
    }
    
    @Override
    public boolean b(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        if (!this.a) {
            return false;
        }
        final int i2 = iblockaccess.getData(i, j, k);
        return (i2 != 5 || l != 1) && (i2 != 3 || l != 3) && (i2 != 4 || l != 2) && (i2 != 1 || l != 5) && (i2 != 2 || l != 4);
    }
    
    private boolean g(final World world, final int i, final int j, final int k) {
        final int l = world.getData(i, j, k);
        return (l == 5 && world.j(i, j - 1, k, 0)) || (l == 3 && world.j(i, j, k - 1, 2)) || (l == 4 && world.j(i, j, k + 1, 3)) || (l == 1 && world.j(i - 1, j, k, 4)) || (l == 2 && world.j(i + 1, j, k, 5));
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        final boolean flag = this.g(world, i, j, k);
        while (BlockRedstoneTorch.b.size() > 0 && world.k() - BlockRedstoneTorch.b.get(0).d > 100L) {
            BlockRedstoneTorch.b.remove(0);
        }
        final CraftBlock block = (CraftBlock)((WorldServer)world).getWorld().getBlockAt(i, j, k);
        final BlockRedstoneEvent event = new BlockRedstoneEvent(block, flag ? 15 : 0, flag ? 0 : 15);
        ((WorldServer)world).getServer().getPluginManager().callEvent(event);
        if (event.getNewCurrent() != 0 == flag) {
            return;
        }
        if (this.a) {
            if (flag) {
                world.b(i, j, k, Block.REDSTONE_TORCH_OFF.id, world.getData(i, j, k));
                if (this.a(world, i, j, k, true)) {
                    world.a(i + 0.5f, j + 0.5f, k + 0.5f, "random.fizz", 0.5f, 2.6f + (world.k.nextFloat() - world.k.nextFloat()) * 0.8f);
                    for (int l = 0; l < 5; ++l) {
                        final double d0 = i + random.nextDouble() * 0.6 + 0.2;
                        final double d2 = j + random.nextDouble() * 0.6 + 0.2;
                        final double d3 = k + random.nextDouble() * 0.6 + 0.2;
                        world.a("smoke", d0, d2, d3, 0.0, 0.0, 0.0);
                    }
                }
            }
        }
        else if (!flag && !this.a(world, i, j, k, false)) {
            world.b(i, j, k, Block.REDSTONE_TORCH_ON.id, world.getData(i, j, k));
        }
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        super.a(world, i, j, k, l);
        world.c(i, j, k, this.id, this.b());
    }
    
    @Override
    public boolean c(final World world, final int i, final int j, final int k, final int l) {
        return l == 0 && this.b((IBlockAccess)world, i, j, k, l);
    }
    
    @Override
    public int a(final int i, final Random random) {
        return Block.REDSTONE_TORCH_ON.id;
    }
    
    @Override
    public boolean c() {
        return true;
    }
    
    static {
        BlockRedstoneTorch.b = new ArrayList();
    }
}
