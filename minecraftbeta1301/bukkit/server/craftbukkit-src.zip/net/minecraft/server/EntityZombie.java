// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.Event;

public class EntityZombie extends EntityMonster
{
    public EntityZombie(final World world) {
        super(world);
        this.texture = "/mob/zombie.png";
        this.az = 0.5f;
        this.c = 5;
    }
    
    @Override
    public void q() {
        if (this.world.c()) {
            final float f = this.c(1.0f);
            if (f > 0.5f && this.world.i(MathHelper.b(this.locX), MathHelper.b(this.locY), MathHelper.b(this.locZ)) && this.random.nextFloat() * 30.0f < (f - 0.4f) * 2.0f) {
                final CraftServer server = ((WorldServer)this.world).getServer();
                final EntityCombustEvent event = new EntityCombustEvent(Event.Type.ENTITY_COMBUST, this.getBukkitEntity());
                server.getPluginManager().callEvent(event);
                if (!event.isCancelled()) {
                    this.fireTicks = 300;
                }
            }
        }
        super.q();
    }
    
    @Override
    protected String e() {
        return "mob.zombie";
    }
    
    @Override
    protected String f() {
        return "mob.zombiehurt";
    }
    
    @Override
    protected String g() {
        return "mob.zombiedeath";
    }
    
    @Override
    protected int h() {
        return Item.FEATHER.id;
    }
}
