// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockBloodStone extends Block
{
    public BlockBloodStone(final int n, final int n2) {
        super(n, n2, Material.STONE);
    }
}
