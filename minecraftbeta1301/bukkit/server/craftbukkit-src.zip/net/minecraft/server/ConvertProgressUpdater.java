// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ConvertProgressUpdater implements IProgressUpdate
{
    private long b;
    final /* synthetic */ MinecraftServer a;
    
    public ConvertProgressUpdater(final MinecraftServer a) {
        this.a = a;
        this.b = System.currentTimeMillis();
    }
    
    public void a(final String s) {
    }
    
    public void a(final int i) {
        if (System.currentTimeMillis() - this.b >= 1000L) {
            this.b = System.currentTimeMillis();
            MinecraftServer.a.info("Converting... " + i + "%");
        }
    }
    
    public void b(final String s) {
    }
}
