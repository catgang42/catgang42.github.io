// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class ChunkProviderHell implements IChunkProvider
{
    private Random h;
    private NoiseGeneratorOctaves i;
    private NoiseGeneratorOctaves j;
    private NoiseGeneratorOctaves k;
    private NoiseGeneratorOctaves l;
    private NoiseGeneratorOctaves m;
    public NoiseGeneratorOctaves a;
    public NoiseGeneratorOctaves b;
    private World n;
    private double[] o;
    private double[] p;
    private double[] q;
    private double[] r;
    private MapGenBase s;
    double[] c;
    double[] d;
    double[] e;
    double[] f;
    double[] g;
    
    public ChunkProviderHell(final World n, final long seed) {
        this.p = new double[256];
        this.q = new double[256];
        this.r = new double[256];
        this.s = new MapGenCavesHell();
        this.n = n;
        this.h = new Random(seed);
        this.i = new NoiseGeneratorOctaves(this.h, 16);
        this.j = new NoiseGeneratorOctaves(this.h, 16);
        this.k = new NoiseGeneratorOctaves(this.h, 8);
        this.l = new NoiseGeneratorOctaves(this.h, 4);
        this.m = new NoiseGeneratorOctaves(this.h, 4);
        this.a = new NoiseGeneratorOctaves(this.h, 10);
        this.b = new NoiseGeneratorOctaves(this.h, 16);
    }
    
    public void a(final int n, final int n2, final byte[] array) {
        final int n3 = 4;
        final int n4 = 32;
        final int n5 = n3 + 1;
        final int n6 = 17;
        final int n7 = n3 + 1;
        this.o = this.a(this.o, n * n3, 0, n2 * n3, n5, n6, n7);
        for (int i = 0; i < n3; ++i) {
            for (int j = 0; j < n3; ++j) {
                for (int k = 0; k < 16; ++k) {
                    final double n8 = 0.125;
                    double n9 = this.o[((i + 0) * n7 + (j + 0)) * n6 + (k + 0)];
                    double n10 = this.o[((i + 0) * n7 + (j + 1)) * n6 + (k + 0)];
                    double n11 = this.o[((i + 1) * n7 + (j + 0)) * n6 + (k + 0)];
                    double n12 = this.o[((i + 1) * n7 + (j + 1)) * n6 + (k + 0)];
                    final double n13 = (this.o[((i + 0) * n7 + (j + 0)) * n6 + (k + 1)] - n9) * n8;
                    final double n14 = (this.o[((i + 0) * n7 + (j + 1)) * n6 + (k + 1)] - n10) * n8;
                    final double n15 = (this.o[((i + 1) * n7 + (j + 0)) * n6 + (k + 1)] - n11) * n8;
                    final double n16 = (this.o[((i + 1) * n7 + (j + 1)) * n6 + (k + 1)] - n12) * n8;
                    for (int l = 0; l < 8; ++l) {
                        final double n17 = 0.25;
                        double n18 = n9;
                        double n19 = n10;
                        final double n20 = (n11 - n9) * n17;
                        final double n21 = (n12 - n10) * n17;
                        for (int n22 = 0; n22 < 4; ++n22) {
                            int n23 = n22 + i * 4 << 11 | 0 + j * 4 << 7 | k * 8 + l;
                            final int n24 = 128;
                            final double n25 = 0.25;
                            double n26 = n18;
                            final double n27 = (n19 - n18) * n25;
                            for (int n28 = 0; n28 < 4; ++n28) {
                                int n29 = 0;
                                if (k * 8 + l < n4) {
                                    n29 = Block.STATIONARY_LAVA.id;
                                }
                                if (n26 > 0.0) {
                                    n29 = Block.NETHERRACK.id;
                                }
                                array[n23] = (byte)n29;
                                n23 += n24;
                                n26 += n27;
                            }
                            n18 += n20;
                            n19 += n21;
                        }
                        n9 += n13;
                        n10 += n14;
                        n11 += n15;
                        n12 += n16;
                    }
                }
            }
        }
    }
    
    public void b(final int n, final int n2, final byte[] array) {
        final int n3 = 64;
        final double n4 = 0.03125;
        this.p = this.l.a(this.p, n * 16, n2 * 16, 0.0, 16, 16, 1, n4, n4, 1.0);
        this.q = this.l.a(this.q, n * 16, 109.0134, n2 * 16, 16, 1, 16, n4, 1.0, n4);
        this.r = this.m.a(this.r, n * 16, n2 * 16, 0.0, 16, 16, 1, n4 * 2.0, n4 * 2.0, n4 * 2.0);
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                final boolean b = this.p[i + j * 16] + this.h.nextDouble() * 0.2 > 0.0;
                final boolean b2 = this.q[i + j * 16] + this.h.nextDouble() * 0.2 > 0.0;
                final int n5 = (int)(this.r[i + j * 16] / 3.0 + 3.0 + this.h.nextDouble() * 0.25);
                int n6 = -1;
                byte b3 = (byte)Block.NETHERRACK.id;
                byte b4 = (byte)Block.NETHERRACK.id;
                for (int k = 127; k >= 0; --k) {
                    final int n7 = (j * 16 + i) * 128 + k;
                    if (k >= 127 - this.h.nextInt(5)) {
                        array[n7] = (byte)Block.BEDROCK.id;
                    }
                    else if (k <= 0 + this.h.nextInt(5)) {
                        array[n7] = (byte)Block.BEDROCK.id;
                    }
                    else {
                        final byte b5 = array[n7];
                        if (b5 == 0) {
                            n6 = -1;
                        }
                        else if (b5 == Block.NETHERRACK.id) {
                            if (n6 == -1) {
                                if (n5 <= 0) {
                                    b3 = 0;
                                    b4 = (byte)Block.NETHERRACK.id;
                                }
                                else if (k >= n3 - 4 && k <= n3 + 1) {
                                    b3 = (byte)Block.NETHERRACK.id;
                                    b4 = (byte)Block.NETHERRACK.id;
                                    if (b2) {
                                        b3 = (byte)Block.GRAVEL.id;
                                    }
                                    if (b2) {
                                        b4 = (byte)Block.NETHERRACK.id;
                                    }
                                    if (b) {
                                        b3 = (byte)Block.SOUL_SAND.id;
                                    }
                                    if (b) {
                                        b4 = (byte)Block.SOUL_SAND.id;
                                    }
                                }
                                if (k < n3 && b3 == 0) {
                                    b3 = (byte)Block.STATIONARY_LAVA.id;
                                }
                                n6 = n5;
                                if (k >= n3 - 1) {
                                    array[n7] = b3;
                                }
                                else {
                                    array[n7] = b4;
                                }
                            }
                            else if (n6 > 0) {
                                --n6;
                                array[n7] = b4;
                            }
                        }
                    }
                }
            }
        }
    }
    
    public Chunk b(final int i, final int j) {
        this.h.setSeed(i * 341873128712L + j * 132897987541L);
        final byte[] abyte = new byte[32768];
        this.a(i, j, abyte);
        this.b(i, j, abyte);
        this.s.a(this, this.n, i, j, abyte);
        return new Chunk(this.n, abyte, i, j);
    }
    
    private double[] a(double[] array, final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        if (array == null) {
            array = new double[n4 * n5 * n6];
        }
        final double n7 = 684.412;
        final double n8 = 2053.236;
        this.f = this.a.a(this.f, n, n2, n3, n4, 1, n6, 1.0, 0.0, 1.0);
        this.g = this.b.a(this.g, n, n2, n3, n4, 1, n6, 100.0, 0.0, 100.0);
        this.c = this.k.a(this.c, n, n2, n3, n4, n5, n6, n7 / 80.0, n8 / 60.0, n7 / 80.0);
        this.d = this.i.a(this.d, n, n2, n3, n4, n5, n6, n7, n8, n7);
        this.e = this.j.a(this.e, n, n2, n3, n4, n5, n6, n7, n8, n7);
        int n9 = 0;
        int n10 = 0;
        final double[] array2 = new double[n5];
        for (int i = 0; i < n5; ++i) {
            array2[i] = Math.cos(i * 3.141592653589793 * 6.0 / n5) * 2.0;
            double n11 = i;
            if (i > n5 / 2) {
                n11 = n5 - 1 - i;
            }
            if (n11 < 4.0) {
                final double n12 = 4.0 - n11;
                final double[] array3 = array2;
                final int n13 = i;
                array3[n13] -= n12 * n12 * n12 * 10.0;
            }
        }
        for (int j = 0; j < n4; ++j) {
            for (int k = 0; k < n6; ++k) {
                double n14 = (this.f[n10] + 256.0) / 512.0;
                if (n14 > 1.0) {
                    n14 = 1.0;
                }
                final double n15 = 0.0;
                double n16 = this.g[n10] / 8000.0;
                if (n16 < 0.0) {
                    n16 = -n16;
                }
                double n17 = n16 * 3.0 - 3.0;
                double n19;
                if (n17 < 0.0) {
                    double n18 = n17 / 2.0;
                    if (n18 < -1.0) {
                        n18 = -1.0;
                    }
                    n19 = n18 / 1.4 / 2.0;
                    n14 = 0.0;
                }
                else {
                    if (n17 > 1.0) {
                        n17 = 1.0;
                    }
                    n19 = n17 / 6.0;
                }
                final double n20 = n19 * n5 / 16.0;
                ++n10;
                for (int l = 0; l < n5; ++l) {
                    final double n21 = array2[l];
                    final double n22 = this.d[n9] / 512.0;
                    final double n23 = this.e[n9] / 512.0;
                    final double n24 = (this.c[n9] / 10.0 + 1.0) / 2.0;
                    double n25;
                    if (n24 < 0.0) {
                        n25 = n22;
                    }
                    else if (n24 > 1.0) {
                        n25 = n23;
                    }
                    else {
                        n25 = n22 + (n23 - n22) * n24;
                    }
                    double n26 = n25 - n21;
                    if (l > n5 - 4) {
                        final double n27 = (l - (n5 - 4)) / 3.0f;
                        n26 = n26 * (1.0 - n27) + -10.0 * n27;
                    }
                    if (l < n15) {
                        double n28 = (n15 - l) / 4.0;
                        if (n28 < 0.0) {
                            n28 = 0.0;
                        }
                        if (n28 > 1.0) {
                            n28 = 1.0;
                        }
                        n26 = n26 * (1.0 - n28) + -10.0 * n28;
                    }
                    array[n9] = n26;
                    ++n9;
                }
            }
        }
        return array;
    }
    
    public boolean a(final int n, final int n2) {
        return true;
    }
    
    public void a(final IChunkProvider chunkProvider, final int n, final int n2) {
        BlockSand.a = true;
        final int n3 = n * 16;
        final int n4 = n2 * 16;
        for (int i = 0; i < 8; ++i) {
            new WorldGenHellLava(Block.LAVA.id).a(this.n, this.h, n3 + this.h.nextInt(16) + 8, this.h.nextInt(120) + 4, n4 + this.h.nextInt(16) + 8);
        }
        for (int n5 = this.h.nextInt(this.h.nextInt(10) + 1) + 1, j = 0; j < n5; ++j) {
            new WorldGenFire().a(this.n, this.h, n3 + this.h.nextInt(16) + 8, this.h.nextInt(120) + 4, n4 + this.h.nextInt(16) + 8);
        }
        for (int nextInt = this.h.nextInt(this.h.nextInt(10) + 1), k = 0; k < nextInt; ++k) {
            new WorldGenLightStone1().a(this.n, this.h, n3 + this.h.nextInt(16) + 8, this.h.nextInt(120) + 4, n4 + this.h.nextInt(16) + 8);
        }
        for (int l = 0; l < 10; ++l) {
            new WorldGenLightStone2().a(this.n, this.h, n3 + this.h.nextInt(16) + 8, this.h.nextInt(128), n4 + this.h.nextInt(16) + 8);
        }
        if (this.h.nextInt(1) == 0) {
            new WorldGenFlowers(Block.BROWN_MUSHROOM.id).a(this.n, this.h, n3 + this.h.nextInt(16) + 8, this.h.nextInt(128), n4 + this.h.nextInt(16) + 8);
        }
        if (this.h.nextInt(1) == 0) {
            new WorldGenFlowers(Block.RED_MUSHROOM.id).a(this.n, this.h, n3 + this.h.nextInt(16) + 8, this.h.nextInt(128), n4 + this.h.nextInt(16) + 8);
        }
        BlockSand.a = false;
    }
    
    public boolean a(final boolean b, final IProgressUpdate progressUpdate) {
        return true;
    }
    
    public boolean a() {
        return false;
    }
    
    public boolean b() {
        return true;
    }
}
