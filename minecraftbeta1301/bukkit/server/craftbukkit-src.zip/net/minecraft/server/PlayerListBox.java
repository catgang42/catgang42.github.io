// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Vector;
import javax.swing.JList;

public class PlayerListBox extends JList implements IUpdatePlayerListBox
{
    private MinecraftServer a;
    private int b;
    
    public PlayerListBox(final MinecraftServer a) {
        this.b = 0;
        (this.a = a).a(this);
    }
    
    public void a() {
        if (this.b++ % 20 == 0) {
            final Vector<String> listData = new Vector<String>();
            for (int i = 0; i < this.a.f.b.size(); ++i) {
                listData.add(((EntityPlayer)this.a.f.b.get(i)).name);
            }
            this.setListData(listData);
        }
    }
}
