// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class WorldGenLiquids extends WorldGenerator
{
    private int a;
    
    public WorldGenLiquids(final int a) {
        this.a = a;
    }
    
    @Override
    public boolean a(final World world, final Random random, final int i, final int j, final int k) {
        if (world.getTypeId(i, j + 1, k) != Block.STONE.id) {
            return false;
        }
        if (world.getTypeId(i, j - 1, k) != Block.STONE.id) {
            return false;
        }
        if (world.getTypeId(i, j, k) != 0 && world.getTypeId(i, j, k) != Block.STONE.id) {
            return false;
        }
        int n = 0;
        if (world.getTypeId(i - 1, j, k) == Block.STONE.id) {
            ++n;
        }
        if (world.getTypeId(i + 1, j, k) == Block.STONE.id) {
            ++n;
        }
        if (world.getTypeId(i, j, k - 1) == Block.STONE.id) {
            ++n;
        }
        if (world.getTypeId(i, j, k + 1) == Block.STONE.id) {
            ++n;
        }
        int n2 = 0;
        if (world.isEmpty(i - 1, j, k)) {
            ++n2;
        }
        if (world.isEmpty(i + 1, j, k)) {
            ++n2;
        }
        if (world.isEmpty(i, j, k - 1)) {
            ++n2;
        }
        if (world.isEmpty(i, j, k + 1)) {
            ++n2;
        }
        if (n == 3 && n2 == 1) {
            world.e(i, j, k, this.a);
            world.a = true;
            Block.byId[this.a].a(world, i, j, k, random);
            world.a = false;
        }
        return true;
    }
}
