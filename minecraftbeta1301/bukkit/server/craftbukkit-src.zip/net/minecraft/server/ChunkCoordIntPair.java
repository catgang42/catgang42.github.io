// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ChunkCoordIntPair
{
    public final int a;
    public final int b;
    
    public ChunkCoordIntPair(final int a, final int b) {
        this.a = a;
        this.b = b;
    }
    
    public static int a(final int n, final int n2) {
        return ((n < 0) ? Integer.MIN_VALUE : 0) | (n & 0x7FFF) << 16 | ((n2 < 0) ? 32768 : 0) | (n2 & 0x7FFF);
    }
    
    @Override
    public int hashCode() {
        return a(this.a, this.b);
    }
    
    @Override
    public boolean equals(final Object o) {
        final ChunkCoordIntPair chunkCoordIntPair = (ChunkCoordIntPair)o;
        return chunkCoordIntPair.a == this.a && chunkCoordIntPair.b == this.b;
    }
}
