// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class Slot
{
    public final int d;
    public final IInventory e;
    public int a;
    public int b;
    public int c;
    
    public Slot(final IInventory iinventory, final int i, final int j, final int k) {
        this.e = iinventory;
        this.d = i;
        this.b = j;
        this.c = k;
    }
    
    public void a() {
        this.c();
    }
    
    public boolean a(final ItemStack itemstack) {
        return true;
    }
    
    public ItemStack b() {
        return this.e.c_(this.d);
    }
    
    public void b(final ItemStack itemstack) {
        this.e.a(this.d, itemstack);
        this.c();
    }
    
    public void c() {
        this.e.h();
    }
    
    public int d() {
        return this.e.n_();
    }
    
    public ItemStack a(final int i) {
        return this.e.a(this.d, i);
    }
    
    public boolean a(final IInventory iinventory, final int i) {
        return iinventory == this.e && i == this.d;
    }
}
