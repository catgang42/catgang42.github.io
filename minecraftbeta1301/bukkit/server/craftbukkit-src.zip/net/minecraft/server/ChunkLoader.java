// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Iterator;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.File;

public class ChunkLoader implements IChunkLoader
{
    private File a;
    private boolean b;
    
    public ChunkLoader(final File a, final boolean b) {
        this.a = a;
        this.b = b;
    }
    
    private File a(final int i, final int j) {
        final String string = "c." + Integer.toString(i, 36) + "." + Integer.toString(j, 36) + ".dat";
        final String string2 = Integer.toString(i & 0x3F, 36);
        final String string3 = Integer.toString(j & 0x3F, 36);
        final File parent = new File(this.a, string2);
        if (!parent.exists()) {
            if (!this.b) {
                return null;
            }
            parent.mkdir();
        }
        final File parent2 = new File(parent, string3);
        if (!parent2.exists()) {
            if (!this.b) {
                return null;
            }
            parent2.mkdir();
        }
        final File file = new File(parent2, string);
        if (!file.exists() && !this.b) {
            return null;
        }
        return file;
    }
    
    public Chunk a(final World world, final int i, final int j) {
        final File a = this.a(i, j);
        if (a != null && a.exists()) {
            try {
                final NBTTagCompound a2 = CompressedStreamTools.a(new FileInputStream(a));
                if (!a2.b("Level")) {
                    System.out.println("Chunk file at " + i + "," + j + " is missing level data, skipping");
                    return null;
                }
                if (!a2.k("Level").b("Blocks")) {
                    System.out.println("Chunk file at " + i + "," + j + " is missing block data, skipping");
                    return null;
                }
                Chunk chunk = a(world, a2.k("Level"));
                if (!chunk.a(i, j)) {
                    System.out.println("Chunk file at " + i + "," + j + " is in the wrong location; relocating. (Expected " + i + ", " + j + ", got " + chunk.j + ", " + chunk.k + ")");
                    a2.a("xPos", i);
                    a2.a("zPos", j);
                    chunk = a(world, a2.k("Level"));
                }
                return chunk;
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }
    
    public void a(final World world, final Chunk chunk) {
        world.i();
        final File a = this.a(chunk.j, chunk.k);
        if (a.exists()) {
            final WorldData n = world.n();
            n.b(n.g() - a.length());
        }
        try {
            final File file = new File(this.a, "tmp_chunk.dat");
            final FileOutputStream fileOutputStream = new FileOutputStream(file);
            final NBTTagCompound nbtTagCompound = new NBTTagCompound();
            final NBTTagCompound nbtTagCompound2 = new NBTTagCompound();
            nbtTagCompound.a("Level", (NBTBase)nbtTagCompound2);
            a(chunk, world, nbtTagCompound2);
            CompressedStreamTools.a(nbtTagCompound, fileOutputStream);
            fileOutputStream.close();
            if (a.exists()) {
                a.delete();
            }
            file.renameTo(a);
            final WorldData n2 = world.n();
            n2.b(n2.g() + a.length());
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static void a(final Chunk chunk, final World world, final NBTTagCompound nbtTagCompound) {
        world.i();
        nbtTagCompound.a("xPos", chunk.j);
        nbtTagCompound.a("zPos", chunk.k);
        nbtTagCompound.a("LastUpdate", world.k());
        nbtTagCompound.a("Blocks", chunk.b);
        nbtTagCompound.a("Data", chunk.e.a);
        nbtTagCompound.a("SkyLight", chunk.f.a);
        nbtTagCompound.a("BlockLight", chunk.g.a);
        nbtTagCompound.a("HeightMap", chunk.h);
        nbtTagCompound.a("TerrainPopulated", chunk.n);
        chunk.q = false;
        final NBTTagList list = new NBTTagList();
        for (int i = 0; i < chunk.m.length; ++i) {
            for (final Entity entity : chunk.m[i]) {
                chunk.q = true;
                final NBTTagCompound nbttagcompound = new NBTTagCompound();
                if (entity.c(nbttagcompound)) {
                    list.a(nbttagcompound);
                }
            }
        }
        nbtTagCompound.a("Entities", list);
        final NBTTagList list2 = new NBTTagList();
        for (final TileEntity tileEntity : chunk.l.values()) {
            final NBTTagCompound nbtTagCompound2 = new NBTTagCompound();
            tileEntity.b(nbtTagCompound2);
            list2.a(nbtTagCompound2);
        }
        nbtTagCompound.a("TileEntities", list2);
    }
    
    public static Chunk a(final World world, final NBTTagCompound nbtTagCompound) {
        final Chunk chunk = new Chunk(world, nbtTagCompound.e("xPos"), nbtTagCompound.e("zPos"));
        chunk.b = nbtTagCompound.j("Blocks");
        chunk.e = new NibbleArray(nbtTagCompound.j("Data"));
        chunk.f = new NibbleArray(nbtTagCompound.j("SkyLight"));
        chunk.g = new NibbleArray(nbtTagCompound.j("BlockLight"));
        chunk.h = nbtTagCompound.j("HeightMap");
        chunk.n = nbtTagCompound.m("TerrainPopulated");
        if (!chunk.e.a()) {
            chunk.e = new NibbleArray(chunk.b.length);
        }
        if (chunk.h == null || !chunk.f.a()) {
            chunk.h = new byte[256];
            chunk.f = new NibbleArray(chunk.b.length);
            chunk.b();
        }
        if (!chunk.g.a()) {
            chunk.g = new NibbleArray(chunk.b.length);
            chunk.a();
        }
        final NBTTagList l = nbtTagCompound.l("Entities");
        if (l != null) {
            for (int i = 0; i < l.c(); ++i) {
                final Entity a = EntityTypes.a((NBTTagCompound)l.a(i), world);
                chunk.q = true;
                if (a != null) {
                    chunk.a(a);
                }
            }
        }
        final NBTTagList j = nbtTagCompound.l("TileEntities");
        if (j != null) {
            for (int k = 0; k < j.c(); ++k) {
                final TileEntity c = TileEntity.c((NBTTagCompound)j.a(k));
                if (c != null) {
                    chunk.a(c);
                }
            }
        }
        return chunk;
    }
    
    public void a() {
    }
    
    public void b() {
    }
    
    public void b(final World world, final Chunk chunk) {
    }
}
