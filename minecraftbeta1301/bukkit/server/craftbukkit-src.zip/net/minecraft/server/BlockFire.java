// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.entity.Player;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.Server;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockIgniteEvent;
import java.util.Random;

public class BlockFire extends Block
{
    private int[] a;
    private int[] b;
    
    protected BlockFire(final int i, final int j) {
        super(i, j, Material.FIRE);
        this.a = new int[256];
        this.b = new int[256];
        this.a(Block.WOOD.id, 5, 20);
        this.a(Block.LOG.id, 5, 5);
        this.a(Block.LEAVES.id, 30, 60);
        this.a(Block.BOOKSHELF.id, 30, 20);
        this.a(Block.TNT.id, 15, 100);
        this.a(Block.WOOL.id, 30, 60);
        this.a(true);
    }
    
    private void a(final int i, final int j, final int k) {
        this.a[i] = j;
        this.b[i] = k;
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
    
    @Override
    public int b() {
        return 10;
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        final boolean flag = world.getTypeId(i, j - 1, k) == Block.NETHERRACK.id;
        final int l = world.getData(i, j, k);
        if (l < 15) {
            world.c(i, j, k, l + 1);
            world.c(i, j, k, this.id, this.b());
        }
        if (!flag && !this.g(world, i, j, k)) {
            if (!world.d(i, j - 1, k) || l > 3) {
                world.e(i, j, k, 0);
            }
        }
        else if (!flag && !this.b((IBlockAccess)world, i, j - 1, k) && l == 15 && random.nextInt(4) == 0) {
            world.e(i, j, k, 0);
        }
        else {
            if (l % 2 == 0 && l > 2) {
                this.a(world, i + 1, j, k, 300, random);
                this.a(world, i - 1, j, k, 300, random);
                this.a(world, i, j - 1, k, 250, random);
                this.a(world, i, j + 1, k, 250, random);
                this.a(world, i, j, k - 1, 300, random);
                this.a(world, i, j, k + 1, 300, random);
                final Server server = ((WorldServer)world).getServer();
                final CraftWorld cworld = ((WorldServer)world).getWorld();
                final BlockIgniteEvent.IgniteCause igniteCause = BlockIgniteEvent.IgniteCause.SPREAD;
                final Player thePlayer = null;
                for (int i2 = i - 1; i2 <= i + 1; ++i2) {
                    for (int j2 = k - 1; j2 <= k + 1; ++j2) {
                        for (int k2 = j - 1; k2 <= j + 4; ++k2) {
                            if (i2 != i || k2 != j || j2 != k) {
                                int l2 = 100;
                                if (k2 > j + 1) {
                                    l2 += (k2 - (j + 1)) * 100;
                                }
                                final int i3 = this.h(world, i2, k2, j2);
                                if (i3 > 0 && random.nextInt(l2) <= i3) {
                                    final org.bukkit.block.Block theBlock = cworld.getBlockAt(i2, k2, j2);
                                    if (theBlock.getTypeId() != Block.FIRE.id) {
                                        final BlockIgniteEvent event = new BlockIgniteEvent(theBlock, igniteCause, thePlayer);
                                        server.getPluginManager().callEvent(event);
                                        if (event.isCancelled()) {
                                            continue;
                                        }
                                    }
                                    world.e(i2, k2, j2, this.id);
                                }
                            }
                        }
                    }
                }
            }
            if (l == 15) {
                this.a(world, i + 1, j, k, 1, random);
                this.a(world, i - 1, j, k, 1, random);
                this.a(world, i, j - 1, k, 1, random);
                this.a(world, i, j + 1, k, 1, random);
                this.a(world, i, j, k - 1, 1, random);
                this.a(world, i, j, k + 1, 1, random);
            }
        }
    }
    
    private void a(final World world, final int i, final int j, final int k, final int l, final Random random) {
        final int i2 = this.b[world.getTypeId(i, j, k)];
        if (random.nextInt(l) < i2) {
            final boolean flag = world.getTypeId(i, j, k) == Block.TNT.id;
            final Server server = ((WorldServer)world).getServer();
            final CraftWorld cworld = ((WorldServer)world).getWorld();
            final org.bukkit.block.Block theBlock = cworld.getBlockAt(i, j, k);
            final BlockBurnEvent event = new BlockBurnEvent(theBlock);
            server.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                return;
            }
            if (random.nextInt(2) == 0) {
                world.e(i, j, k, this.id);
            }
            else {
                world.e(i, j, k, 0);
            }
            if (flag) {
                Block.TNT.b(world, i, j, k, 0);
            }
        }
    }
    
    private boolean g(final World world1, final int i, final int j, final int k) {
        final IBlockAccess world2 = world1;
        return this.b(world2, i + 1, j, k) || this.b(world2, i - 1, j, k) || this.b(world2, i, j - 1, k) || this.b(world2, i, j + 1, k) || this.b(world2, i, j, k - 1) || this.b(world2, i, j, k + 1);
    }
    
    private int h(final World world, final int i, final int j, final int k) {
        final byte b0 = 0;
        if (!world.isEmpty(i, j, k)) {
            return 0;
        }
        int l = this.g(world, i + 1, j, k, b0);
        l = this.g(world, i - 1, j, k, l);
        l = this.g(world, i, j - 1, k, l);
        l = this.g(world, i, j + 1, k, l);
        l = this.g(world, i, j, k - 1, l);
        l = this.g(world, i, j, k + 1, l);
        return l;
    }
    
    @Override
    public boolean d() {
        return false;
    }
    
    public boolean b(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        return this.a[iblockaccess.getTypeId(i, j, k)] > 0;
    }
    
    public int g(final World world, final int i, final int j, final int k, final int l) {
        final int i2 = this.a[world.getTypeId(i, j, k)];
        return (i2 > l) ? i2 : l;
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k) {
        return world.d(i, j - 1, k) || this.g(world, i, j, k);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        if (!world.d(i, j - 1, k) && !this.g(world, i, j, k)) {
            world.e(i, j, k, 0);
        }
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
        if (world.getTypeId(i, j - 1, k) != Block.OBSIDIAN.id || !Block.PORTAL.a_(world, i, j, k)) {
            if (!world.d(i, j - 1, k) && !this.g(world, i, j, k)) {
                world.e(i, j, k, 0);
            }
            else {
                world.c(i, j, k, this.id, this.b());
            }
        }
    }
}
