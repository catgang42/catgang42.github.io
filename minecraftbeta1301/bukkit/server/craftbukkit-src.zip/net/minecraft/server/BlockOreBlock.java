// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockOreBlock extends Block
{
    public BlockOreBlock(final int n, final int textureId) {
        super(n, Material.ORE);
        this.textureId = textureId;
    }
    
    @Override
    public int a(final int n) {
        return this.textureId;
    }
}
