// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.block.LeavesDecayEvent;
import org.bukkit.event.Event;
import java.util.Random;

public class BlockLeaves extends BlockLeavesBase
{
    private int c;
    int[] a;
    
    protected BlockLeaves(final int i, final int j) {
        super(i, j, Material.LEAVES, false);
        this.c = j;
        this.a(true);
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k) {
        final byte b0 = 1;
        final int l = b0 + 1;
        if (world.a(i - l, j - l, k - l, i + l, j + l, k + l)) {
            for (int i2 = -b0; i2 <= b0; ++i2) {
                for (int j2 = -b0; j2 <= b0; ++j2) {
                    for (int k2 = -b0; k2 <= b0; ++k2) {
                        final int l2 = world.getTypeId(i + i2, j + j2, k + k2);
                        if (l2 == Block.LEAVES.id) {
                            final int i3 = world.getData(i + i2, j + j2, k + k2);
                            world.d(i + i2, j + j2, k + k2, i3 | 0x4);
                        }
                    }
                }
            }
        }
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (!world.isStatic) {
            final int l = world.getData(i, j, k);
            if ((l & 0x4) != 0x0) {
                final byte b0 = 4;
                final int i2 = b0 + 1;
                final byte b2 = 32;
                final int j2 = b2 * b2;
                final int k2 = b2 / 2;
                if (this.a == null) {
                    this.a = new int[b2 * b2 * b2];
                }
                if (world.a(i - i2, j - i2, k - i2, i + i2, j + i2, k + i2)) {
                    for (int l2 = -b0; l2 <= b0; ++l2) {
                        for (int i3 = -b0; i3 <= b0; ++i3) {
                            for (int j3 = -b0; j3 <= b0; ++j3) {
                                final int k3 = world.getTypeId(i + l2, j + i3, k + j3);
                                if (k3 == Block.LOG.id) {
                                    this.a[(l2 + k2) * j2 + (i3 + k2) * b2 + j3 + k2] = 0;
                                }
                                else if (k3 == Block.LEAVES.id) {
                                    this.a[(l2 + k2) * j2 + (i3 + k2) * b2 + j3 + k2] = -2;
                                }
                                else {
                                    this.a[(l2 + k2) * j2 + (i3 + k2) * b2 + j3 + k2] = -1;
                                }
                            }
                        }
                    }
                    for (int l2 = 1; l2 <= 4; ++l2) {
                        for (int i3 = -b0; i3 <= b0; ++i3) {
                            for (int j3 = -b0; j3 <= b0; ++j3) {
                                for (int k3 = -b0; k3 <= b0; ++k3) {
                                    if (this.a[(i3 + k2) * j2 + (j3 + k2) * b2 + k3 + k2] == l2 - 1) {
                                        if (this.a[(i3 + k2 - 1) * j2 + (j3 + k2) * b2 + k3 + k2] == -2) {
                                            this.a[(i3 + k2 - 1) * j2 + (j3 + k2) * b2 + k3 + k2] = l2;
                                        }
                                        if (this.a[(i3 + k2 + 1) * j2 + (j3 + k2) * b2 + k3 + k2] == -2) {
                                            this.a[(i3 + k2 + 1) * j2 + (j3 + k2) * b2 + k3 + k2] = l2;
                                        }
                                        if (this.a[(i3 + k2) * j2 + (j3 + k2 - 1) * b2 + k3 + k2] == -2) {
                                            this.a[(i3 + k2) * j2 + (j3 + k2 - 1) * b2 + k3 + k2] = l2;
                                        }
                                        if (this.a[(i3 + k2) * j2 + (j3 + k2 + 1) * b2 + k3 + k2] == -2) {
                                            this.a[(i3 + k2) * j2 + (j3 + k2 + 1) * b2 + k3 + k2] = l2;
                                        }
                                        if (this.a[(i3 + k2) * j2 + (j3 + k2) * b2 + (k3 + k2 - 1)] == -2) {
                                            this.a[(i3 + k2) * j2 + (j3 + k2) * b2 + (k3 + k2 - 1)] = l2;
                                        }
                                        if (this.a[(i3 + k2) * j2 + (j3 + k2) * b2 + k3 + k2 + 1] == -2) {
                                            this.a[(i3 + k2) * j2 + (j3 + k2) * b2 + k3 + k2 + 1] = l2;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                int l2 = this.a[k2 * j2 + k2 * b2 + k2];
                if (l2 >= 0) {
                    world.c(i, j, k, l & 0xFFFFFFFB);
                }
                else {
                    this.g(world, i, j, k);
                }
            }
        }
    }
    
    private void g(final World world, final int i, final int j, final int k) {
        final CraftServer server = ((WorldServer)world).getServer();
        final CraftWorld cworld = ((WorldServer)world).getWorld();
        final LeavesDecayEvent event = new LeavesDecayEvent(Event.Type.LEAVES_DECAY, cworld.getBlockAt(i, j, k));
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return;
        }
        this.b_(world, i, j, k, world.getData(i, j, k));
        world.e(i, j, k, 0);
    }
    
    @Override
    public int a(final Random random) {
        return (random.nextInt(16) == 0) ? 1 : 0;
    }
    
    @Override
    public int a(final int i, final Random random) {
        return Block.SAPLING.id;
    }
    
    @Override
    public boolean a() {
        return !this.b;
    }
    
    @Override
    public int a(final int i, final int j) {
        return ((j & 0x3) == 0x1) ? (this.textureId + 80) : this.textureId;
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k, final Entity entity) {
        super.b(world, i, j, k, entity);
    }
}
