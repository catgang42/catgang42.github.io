// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class MaterialLiquid extends Material
{
    @Override
    public boolean isLiquid() {
        return true;
    }
    
    @Override
    public boolean isSolid() {
        return false;
    }
    
    @Override
    public boolean isBuildable() {
        return false;
    }
}
