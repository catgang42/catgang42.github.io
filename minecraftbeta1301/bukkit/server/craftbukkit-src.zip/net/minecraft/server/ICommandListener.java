// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public interface ICommandListener
{
    void b(final String p0);
    
    String c();
}
