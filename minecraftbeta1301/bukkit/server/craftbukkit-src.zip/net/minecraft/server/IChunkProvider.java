// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public interface IChunkProvider
{
    boolean a(final int p0, final int p1);
    
    Chunk b(final int p0, final int p1);
    
    void a(final IChunkProvider p0, final int p1, final int p2);
    
    boolean a(final boolean p0, final IProgressUpdate p1);
    
    boolean a();
    
    boolean b();
}
