// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockLadder extends Block
{
    protected BlockLadder(final int n, final int n2) {
        super(n, n2, Material.ORIENTABLE);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int i, final int j, final int k) {
        final int data = world.getData(i, j, k);
        final float n = 0.125f;
        if (data == 2) {
            this.a(0.0f, 0.0f, 1.0f - n, 1.0f, 1.0f, 1.0f);
        }
        if (data == 3) {
            this.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, n);
        }
        if (data == 4) {
            this.a(1.0f - n, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        }
        if (data == 5) {
            this.a(0.0f, 0.0f, 0.0f, n, 1.0f, 1.0f);
        }
        return super.d(world, i, j, k);
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3) {
        return world.d(n - 1, n2, n3) || world.d(n + 1, n2, n3) || world.d(n, n2, n3 - 1) || world.d(n, n2, n3 + 1);
    }
    
    @Override
    public void d(final World world, final int n, final int n2, final int n3, final int n4) {
        int data = world.getData(n, n2, n3);
        if ((data == 0 || n4 == 2) && world.d(n, n2, n3 + 1)) {
            data = 2;
        }
        if ((data == 0 || n4 == 3) && world.d(n, n2, n3 - 1)) {
            data = 3;
        }
        if ((data == 0 || n4 == 4) && world.d(n + 1, n2, n3)) {
            data = 4;
        }
        if ((data == 0 || n4 == 5) && world.d(n - 1, n2, n3)) {
            data = 5;
        }
        world.c(n, n2, n3, data);
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        final int data = world.getData(n, n2, n3);
        boolean b = false;
        if (data == 2 && world.d(n, n2, n3 + 1)) {
            b = true;
        }
        if (data == 3 && world.d(n, n2, n3 - 1)) {
            b = true;
        }
        if (data == 4 && world.d(n + 1, n2, n3)) {
            b = true;
        }
        if (data == 5 && world.d(n - 1, n2, n3)) {
            b = true;
        }
        if (!b) {
            this.b_(world, n, n2, n3, data);
            world.e(n, n2, n3, 0);
        }
        super.a(world, n, n2, n3, n4);
    }
    
    @Override
    public int a(final Random random) {
        return 1;
    }
}
