// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class WorldGenCactus extends WorldGenerator
{
    @Override
    public boolean a(final World world, final Random random, final int n, final int n2, final int n3) {
        for (int i = 0; i < 10; ++i) {
            final int n4 = n + random.nextInt(8) - random.nextInt(8);
            final int j = n2 + random.nextInt(4) - random.nextInt(4);
            final int n5 = n3 + random.nextInt(8) - random.nextInt(8);
            if (world.isEmpty(n4, j, n5)) {
                for (int n6 = 1 + random.nextInt(random.nextInt(3) + 1), k = 0; k < n6; ++k) {
                    if (Block.CACTUS.f(world, n4, j + k, n5)) {
                        world.setTypeId(n4, j + k, n5, Block.CACTUS.id);
                    }
                }
            }
        }
        return true;
    }
}
