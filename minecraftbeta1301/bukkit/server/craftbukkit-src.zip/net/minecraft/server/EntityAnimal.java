// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public abstract class EntityAnimal extends EntityCreature implements IAnimal
{
    public EntityAnimal(final World world) {
        super(world);
    }
    
    @Override
    protected float a(final int n, final int j, final int n2) {
        if (this.world.getTypeId(n, j - 1, n2) == Block.GRASS.id) {
            return 10.0f;
        }
        return this.world.l(n, j, n2) - 0.5f;
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
    }
    
    @Override
    public boolean b() {
        final int b = MathHelper.b(this.locX);
        final int b2 = MathHelper.b(this.boundingBox.b);
        final int b3 = MathHelper.b(this.locZ);
        return this.world.getTypeId(b, b2 - 1, b3) == Block.GRASS.id && this.world.j(b, b2, b3) > 8 && super.b();
    }
    
    @Override
    public int c() {
        return 120;
    }
}
