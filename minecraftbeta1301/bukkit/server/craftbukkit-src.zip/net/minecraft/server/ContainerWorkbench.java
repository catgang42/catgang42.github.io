// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ContainerWorkbench extends Container
{
    public InventoryCrafting a;
    public IInventory b;
    private World c;
    private int h;
    private int i;
    private int j;
    
    public ContainerWorkbench(final InventoryPlayer inventoryPlayer, final World c, final int h, final int i, final int j) {
        this.a = new InventoryCrafting(this, 3, 3);
        this.b = new InventoryCraftResult();
        this.c = c;
        this.h = h;
        this.i = i;
        this.j = j;
        this.a(new SlotResult(this.a, this.b, 0, 124, 35));
        for (int k = 0; k < 3; ++k) {
            for (int l = 0; l < 3; ++l) {
                this.a(new Slot(this.a, l + k * 3, 30 + l * 18, 17 + k * 18));
            }
        }
        for (int n = 0; n < 3; ++n) {
            for (int n2 = 0; n2 < 9; ++n2) {
                this.a(new Slot(inventoryPlayer, n2 + n * 9 + 9, 8 + n2 * 18, 84 + n * 18));
            }
        }
        for (int m = 0; m < 9; ++m) {
            this.a(new Slot(inventoryPlayer, m, 8 + m * 18, 142));
        }
        this.a(this.a);
    }
    
    @Override
    public void a(final IInventory inventory) {
        this.b.a(0, CraftingManager.a().a(this.a));
    }
    
    @Override
    public void a(final EntityHuman entityHuman) {
        super.a(entityHuman);
        for (int i = 0; i < 9; ++i) {
            final ItemStack c_ = this.a.c_(i);
            if (c_ != null) {
                entityHuman.b(c_);
            }
        }
    }
    
    @Override
    public boolean b(final EntityHuman entityHuman) {
        return this.c.getTypeId(this.h, this.i, this.j) == Block.WORKBENCH.id && entityHuman.d(this.h + 0.5, this.i + 0.5, this.j + 0.5) <= 64.0;
    }
}
