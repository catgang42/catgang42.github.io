// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public final class ThreadServerApplication extends Thread
{
    final /* synthetic */ MinecraftServer a;
    
    public ThreadServerApplication(final String name, final MinecraftServer a) {
        this.a = a;
        super(name);
    }
    
    @Override
    public void run() {
        this.a.run();
    }
}
