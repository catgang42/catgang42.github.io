// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet12PlayerLook extends Packet10Flying
{
    public Packet12PlayerLook() {
        this.i = true;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.e = dataInputStream.readFloat();
        this.f = dataInputStream.readFloat();
        super.a(dataInputStream);
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeFloat(this.e);
        dataOutputStream.writeFloat(this.f);
        super.a(dataOutputStream);
    }
    
    @Override
    public int a() {
        return 9;
    }
}
