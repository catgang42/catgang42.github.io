// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemPainting extends Item
{
    public ItemPainting(final int n) {
        super(n);
        this.durability = 64;
    }
    
    @Override
    public boolean a(final ItemStack itemStack, final EntityHuman entityHuman, final World world, final int n, final int n2, final int n3, final int n4) {
        if (n4 == 0) {
            return false;
        }
        if (n4 == 1) {
            return false;
        }
        int n5 = 0;
        if (n4 == 4) {
            n5 = 1;
        }
        if (n4 == 3) {
            n5 = 2;
        }
        if (n4 == 5) {
            n5 = 3;
        }
        final EntityPainting entity = new EntityPainting(world, n, n2, n3, n5);
        if (entity.h()) {
            if (!world.isStatic) {
                world.a(entity);
            }
            --itemStack.count;
        }
        return true;
    }
}
