// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntityFallingSand extends Entity
{
    public int a;
    public int b;
    
    public EntityFallingSand(final World world) {
        super(world);
        this.b = 0;
    }
    
    public EntityFallingSand(final World world, final double n, final double n2, final double n3, final int a) {
        super(world);
        this.b = 0;
        this.a = a;
        this.aC = true;
        this.a(0.98f, 0.98f);
        this.height = this.width / 2.0f;
        this.a(n, n2, n3);
        this.motX = 0.0;
        this.motY = 0.0;
        this.motZ = 0.0;
        this.bg = false;
        this.lastX = n;
        this.lastY = n2;
        this.lastZ = n3;
    }
    
    @Override
    protected void a() {
    }
    
    @Override
    public boolean d_() {
        return !this.dead;
    }
    
    @Override
    public void f_() {
        if (this.a == 0) {
            this.C();
            return;
        }
        this.lastX = this.locX;
        this.lastY = this.locY;
        this.lastZ = this.locZ;
        ++this.b;
        this.motY -= 0.03999999910593033;
        this.c(this.motX, this.motY, this.motZ);
        this.motX *= 0.9800000190734863;
        this.motY *= 0.9800000190734863;
        this.motZ *= 0.9800000190734863;
        final int b = MathHelper.b(this.locX);
        final int b2 = MathHelper.b(this.locY);
        final int b3 = MathHelper.b(this.locZ);
        if (this.world.getTypeId(b, b2, b3) == this.a) {
            this.world.e(b, b2, b3, 0);
        }
        if (this.onGround) {
            this.motX *= 0.699999988079071;
            this.motZ *= 0.699999988079071;
            this.motY *= -0.5;
            this.C();
            if (!this.world.a(this.a, b, b2, b3, true) || !this.world.e(b, b2, b3, this.a)) {
                if (!this.world.isStatic) {
                    this.b(this.a, 1);
                }
            }
        }
        else if (this.b > 100 && !this.world.isStatic) {
            this.b(this.a, 1);
            this.C();
        }
    }
    
    @Override
    protected void a(final NBTTagCompound nbtTagCompound) {
        nbtTagCompound.a("Tile", (byte)this.a);
    }
    
    @Override
    protected void b(final NBTTagCompound nbtTagCompound) {
        this.a = (nbtTagCompound.c("Tile") & 0xFF);
    }
}
