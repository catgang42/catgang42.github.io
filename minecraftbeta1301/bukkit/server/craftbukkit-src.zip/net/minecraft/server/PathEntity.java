// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class PathEntity
{
    private final PathPoint[] b;
    public final int a;
    private int c;
    
    public PathEntity(final PathPoint[] b) {
        this.b = b;
        this.a = b.length;
    }
    
    public void a() {
        ++this.c;
    }
    
    public boolean b() {
        return this.c >= this.b.length;
    }
    
    public PathPoint c() {
        if (this.a > 0) {
            return this.b[this.a - 1];
        }
        return null;
    }
    
    public Vec3D a(final Entity entity) {
        return Vec3D.b(this.b[this.c].a + (int)(entity.length + 1.0f) * 0.5, this.b[this.c].b, this.b[this.c].c + (int)(entity.length + 1.0f) * 0.5);
    }
}
