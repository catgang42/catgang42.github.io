// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockInteractEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.event.Event;
import java.util.Random;

public class BlockDispenser extends BlockContainer
{
    protected BlockDispenser(final int i) {
        super(i, Material.STONE);
        this.textureId = 45;
    }
    
    @Override
    public int b() {
        return 4;
    }
    
    @Override
    public int a(final int i, final Random random) {
        return Block.DISPENSER.id;
    }
    
    @Override
    public void e(final World world, final int i, final int j, final int k) {
        super.e(world, i, j, k);
        this.g(world, i, j, k);
    }
    
    private void g(final World world, final int i, final int j, final int k) {
        final int l = world.getTypeId(i, j, k - 1);
        final int i2 = world.getTypeId(i, j, k + 1);
        final int j2 = world.getTypeId(i - 1, j, k);
        final int k2 = world.getTypeId(i + 1, j, k);
        byte b0 = 3;
        if (Block.o[l] && !Block.o[i2]) {
            b0 = 3;
        }
        if (Block.o[i2] && !Block.o[l]) {
            b0 = 2;
        }
        if (Block.o[j2] && !Block.o[k2]) {
            b0 = 5;
        }
        if (Block.o[k2] && !Block.o[j2]) {
            b0 = 4;
        }
        world.c(i, j, k, b0);
    }
    
    @Override
    public int a(final int i) {
        return (i == 1) ? (this.textureId + 17) : ((i == 0) ? (this.textureId + 17) : ((i == 3) ? (this.textureId + 1) : this.textureId));
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        if (world.isStatic) {
            return true;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer server = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.BLOCK_INTERACT;
        final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
        final LivingEntity who = (entityhuman == null) ? null : ((LivingEntity)entityhuman.getBukkitEntity());
        final BlockInteractEvent event = new BlockInteractEvent(eventType, block, who);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        final TileEntityDispenser tileentitydispenser = (TileEntityDispenser)world.getTileEntity(i, j, k);
        entityhuman.a(tileentitydispenser);
        return true;
    }
    
    public void b(final World world, final int i, final int j, final int k, final Random random) {
        final int l = world.getData(i, j, k);
        float f = 0.0f;
        float f2 = 0.0f;
        if (l == 3) {
            f2 = 1.0f;
        }
        else if (l == 2) {
            f2 = -1.0f;
        }
        else if (l == 5) {
            f = 1.0f;
        }
        else {
            f = -1.0f;
        }
        final TileEntityDispenser tileentitydispenser = (TileEntityDispenser)world.getTileEntity(i, j, k);
        final ItemStack itemstack = tileentitydispenser.b();
        final double d0 = i + f * 0.5 + 0.5;
        final double d2 = j + 0.5;
        final double d3 = k + f2 * 0.5 + 0.5;
        if (itemstack == null) {
            world.a(i, j, k, "random.click", 1.0f, 1.2f);
        }
        else {
            if (itemstack.id == Item.ARROW.id) {
                final EntityArrow entityarrow = new EntityArrow(world, d0, d2, d3);
                entityarrow.a(f, 0.10000000149011612, f2, 1.1f, 6.0f);
                world.a(entityarrow);
                world.a(i, j, k, "random.bow", 1.0f, 1.2f);
            }
            else if (itemstack.id == Item.EGG.id) {
                final EntityEgg entityegg = new EntityEgg(world, d0, d2, d3);
                entityegg.a(f, 0.10000000149011612, f2, 1.1f, 6.0f);
                world.a(entityegg);
                world.a(i, j, k, "random.bow", 1.0f, 1.2f);
            }
            else if (itemstack.id == Item.SNOW_BALL.id) {
                final EntitySnowball entitysnowball = new EntitySnowball(world, d0, d2, d3);
                entitysnowball.a(f, 0.10000000149011612, f2, 1.1f, 6.0f);
                world.a(entitysnowball);
                world.a(i, j, k, "random.bow", 1.0f, 1.2f);
            }
            else {
                final EntityItem entityitem = new EntityItem(world, d0, d2 - 0.3, d3, itemstack);
                final double d4 = random.nextDouble() * 0.1 + 0.2;
                entityitem.motX = f * d4;
                entityitem.motY = 0.20000000298023224;
                entityitem.motZ = f2 * d4;
                final EntityItem entityItem = entityitem;
                entityItem.motX += random.nextGaussian() * 0.007499999832361937 * 6.0;
                final EntityItem entityItem2 = entityitem;
                entityItem2.motY += random.nextGaussian() * 0.007499999832361937 * 6.0;
                final EntityItem entityItem3 = entityitem;
                entityItem3.motZ += random.nextGaussian() * 0.007499999832361937 * 6.0;
                world.a(entityitem);
                world.a(i, j, k, "random.click", 1.0f, 1.0f);
            }
            for (int i2 = 0; i2 < 10; ++i2) {
                final double d4 = random.nextDouble() * 0.2 + 0.01;
                final double d5 = d0 + f * 0.01 + (random.nextDouble() - 0.5) * f2 * 0.5;
                final double d6 = d2 + (random.nextDouble() - 0.5) * 0.5;
                final double d7 = d3 + f2 * 0.01 + (random.nextDouble() - 0.5) * f * 0.5;
                final double d8 = f * d4 + random.nextGaussian() * 0.01;
                final double d9 = -0.03 + random.nextGaussian() * 0.01;
                final double d10 = f2 * d4 + random.nextGaussian() * 0.01;
                world.a("smoke", d5, d6, d7, d8, d9, d10);
            }
        }
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        if (l > 0 && Block.byId[l].c()) {
            final boolean flag = world.p(i, j, k) || world.p(i, j + 1, k);
            if (flag) {
                world.c(i, j, k, this.id, this.b());
            }
        }
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (world.p(i, j, k) || world.p(i, j + 1, k)) {
            this.b(world, i, j, k, random);
        }
    }
    
    @Override
    protected TileEntity a_() {
        return new TileEntityDispenser();
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final EntityLiving entityliving) {
        final int l = MathHelper.b(entityliving.yaw * 4.0f / 360.0f + 0.5) & 0x3;
        if (l == 0) {
            world.c(i, j, k, 2);
        }
        if (l == 1) {
            world.c(i, j, k, 5);
        }
        if (l == 2) {
            world.c(i, j, k, 3);
        }
        if (l == 3) {
            world.c(i, j, k, 4);
        }
    }
}
