// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.block.BlockInteractEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.event.Event;

public class BlockLever extends Block
{
    protected BlockLever(final int i, final int j) {
        super(i, j, Material.ORIENTABLE);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k) {
        return world.d(i - 1, j, k) || world.d(i + 1, j, k) || world.d(i, j, k - 1) || world.d(i, j, k + 1) || world.d(i, j - 1, k);
    }
    
    @Override
    public void d(final World world, final int i, final int j, final int k, final int l) {
        int i2 = world.getData(i, j, k);
        final int j2 = i2 & 0x8;
        i2 &= 0x7;
        if (l == 1 && world.d(i, j - 1, k)) {
            i2 = 5 + world.k.nextInt(2);
        }
        if (l == 2 && world.d(i, j, k + 1)) {
            i2 = 4;
        }
        if (l == 3 && world.d(i, j, k - 1)) {
            i2 = 3;
        }
        if (l == 4 && world.d(i + 1, j, k)) {
            i2 = 2;
        }
        if (l == 5 && world.d(i - 1, j, k)) {
            i2 = 1;
        }
        world.c(i, j, k, i2 + j2);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        if (this.g(world, i, j, k)) {
            final int i2 = world.getData(i, j, k) & 0x7;
            boolean flag = false;
            if (!world.d(i - 1, j, k) && i2 == 1) {
                flag = true;
            }
            if (!world.d(i + 1, j, k) && i2 == 2) {
                flag = true;
            }
            if (!world.d(i, j, k - 1) && i2 == 3) {
                flag = true;
            }
            if (!world.d(i, j, k + 1) && i2 == 4) {
                flag = true;
            }
            if (!world.d(i, j - 1, k) && i2 == 5) {
                flag = true;
            }
            if (flag) {
                this.b_(world, i, j, k, world.getData(i, j, k));
                world.e(i, j, k, 0);
            }
        }
    }
    
    private boolean g(final World world, final int i, final int j, final int k) {
        if (!this.a(world, i, j, k)) {
            this.b_(world, i, j, k, world.getData(i, j, k));
            world.e(i, j, k, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public void a(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final int l = iblockaccess.getData(i, j, k) & 0x7;
        float f = 0.1875f;
        if (l == 1) {
            this.a(0.0f, 0.2f, 0.5f - f, f * 2.0f, 0.8f, 0.5f + f);
        }
        else if (l == 2) {
            this.a(1.0f - f * 2.0f, 0.2f, 0.5f - f, 1.0f, 0.8f, 0.5f + f);
        }
        else if (l == 3) {
            this.a(0.5f - f, 0.2f, 0.0f, 0.5f + f, 0.8f, f * 2.0f);
        }
        else if (l == 4) {
            this.a(0.5f - f, 0.2f, 1.0f - f * 2.0f, 0.5f + f, 0.8f, 1.0f);
        }
        else {
            f = 0.25f;
            this.a(0.5f - f, 0.0f, 0.5f - f, 0.5f + f, 0.6f, 0.5f + f);
        }
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        this.a(world, i, j, k, entityhuman);
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        if (world.isStatic) {
            return true;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer server = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.BLOCK_INTERACT;
        final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
        final LivingEntity who = (entityhuman == null) ? null : ((LivingEntity)entityhuman.getBukkitEntity());
        final BlockInteractEvent event = new BlockInteractEvent(eventType, block, who);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            ((EntityPlayer)entityhuman).a.b(new Packet53BlockChange(i, j, k, world));
            return true;
        }
        final int l = world.getData(i, j, k);
        final int i2 = l & 0x7;
        final int j2 = 8 - (l & 0x8);
        final int old = (j2 != 8) ? 1 : 0;
        final int current = (j2 == 8) ? 1 : 0;
        final BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, old, current);
        server.getPluginManager().callEvent(eventRedstone);
        if (eventRedstone.getNewCurrent() > 0 != (j2 == 8)) {
            return true;
        }
        world.c(i, j, k, i2 + j2);
        world.b(i, j, k, i, j, k);
        world.a(i + 0.5, j + 0.5, k + 0.5, "random.click", 0.3f, (j2 > 0) ? 0.6f : 0.5f);
        world.h(i, j, k, this.id);
        if (i2 == 1) {
            world.h(i - 1, j, k, this.id);
        }
        else if (i2 == 2) {
            world.h(i + 1, j, k, this.id);
        }
        else if (i2 == 3) {
            world.h(i, j, k - 1, this.id);
        }
        else if (i2 == 4) {
            world.h(i, j, k + 1, this.id);
        }
        else {
            world.h(i, j - 1, k, this.id);
        }
        return true;
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k) {
        final int l = world.getData(i, j, k);
        if ((l & 0x8) > 0) {
            world.h(i, j, k, this.id);
            final int i2 = l & 0x7;
            if (i2 == 1) {
                world.h(i - 1, j, k, this.id);
            }
            else if (i2 == 2) {
                world.h(i + 1, j, k, this.id);
            }
            else if (i2 == 3) {
                world.h(i, j, k - 1, this.id);
            }
            else if (i2 == 4) {
                world.h(i, j, k + 1, this.id);
            }
            else {
                world.h(i, j - 1, k, this.id);
            }
        }
        super.b(world, i, j, k);
    }
    
    @Override
    public boolean b(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return (iblockaccess.getData(i, j, k) & 0x8) > 0;
    }
    
    @Override
    public boolean c(final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getData(i, j, k);
        if ((i2 & 0x8) == 0x0) {
            return false;
        }
        final int j2 = i2 & 0x7;
        return (j2 == 5 && l == 1) || (j2 == 4 && l == 2) || (j2 == 3 && l == 3) || (j2 == 2 && l == 4) || (j2 == 1 && l == 5);
    }
    
    @Override
    public boolean c() {
        return true;
    }
}
