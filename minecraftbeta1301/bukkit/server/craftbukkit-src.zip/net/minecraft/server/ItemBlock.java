// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.Server;
import org.bukkit.block.BlockState;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.entity.Player;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.event.Event;
import org.bukkit.craftbukkit.block.CraftBlockState;
import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.block.CraftBlock;

public class ItemBlock extends Item
{
    private int a;
    
    public ItemBlock(final int i) {
        super(i);
        this.a = i + 256;
        this.b(Block.byId[i + 256].a(2));
    }
    
    @Override
    public boolean a(final ItemStack itemstack, final EntityHuman entityhuman, final World world, int i, int j, int k, int l) {
        if (itemstack.count == 0) {
            return false;
        }
        final CraftBlock blockClicked = (CraftBlock)((WorldServer)world).getWorld().getBlockAt(i, j, k);
        final BlockFace faceClicked = CraftBlock.notchToBlockFace(l);
        if (world.getTypeId(i, j, k) == Block.SNOW.id) {
            l = 0;
        }
        else {
            if (l == 0) {
                --j;
            }
            if (l == 1) {
                ++j;
            }
            if (l == 2) {
                --k;
            }
            if (l == 3) {
                ++k;
            }
            if (l == 4) {
                --i;
            }
            if (l == 5) {
                ++i;
            }
        }
        if (itemstack.count == 0) {
            return false;
        }
        final int typeId = blockClicked.getTypeId();
        org.bukkit.block.Block replacedBlock = blockClicked.getFace(faceClicked);
        if (typeId == Block.SNOW.id || (typeId == Block.STEP.id && itemstack.id == Block.STEP.id && faceClicked == BlockFace.UP)) {
            replacedBlock = blockClicked;
        }
        final BlockState replacedBlockState = new CraftBlockState(replacedBlock);
        if (world.a(this.a, i, j, k, false)) {
            final Block block = Block.byId[this.a];
            if (world.setTypeIdAndData(i, j, k, this.a, this.a(itemstack.h()))) {
                final Server server = ((WorldServer)world).getServer();
                final Event.Type eventType = Event.Type.BLOCK_PLACED;
                final org.bukkit.block.Block placedBlock = blockClicked.getFace(faceClicked);
                final org.bukkit.inventory.ItemStack itemInHand = new CraftItemStack(itemstack);
                final Player thePlayer = (entityhuman == null) ? null : ((Player)entityhuman.getBukkitEntity());
                final ChunkCoordinates chunkcoordinates = world.l();
                final int spawnX = chunkcoordinates.a;
                final int spawnZ = chunkcoordinates.c;
                final int distanceFromSpawn = Math.max(Math.abs(i - spawnX), Math.abs(k - spawnZ));
                final boolean canBuild = distanceFromSpawn > ((WorldServer)world).x.spawnProtection || thePlayer.isOp();
                final BlockPlaceEvent event = new BlockPlaceEvent(eventType, placedBlock, replacedBlockState, blockClicked, itemInHand, thePlayer, canBuild);
                server.getPluginManager().callEvent(event);
                if (event.isCancelled() || !event.canBuild()) {
                    if (this.a == Block.STEP.id && world.getTypeId(i, j - 1, k) == Block.DOUBLE_STEP.id && world.getTypeId(i, j, k) == 0) {
                        world.setTypeId(i, j - 1, k, 44);
                    }
                    else {
                        if (this.a == Block.ICE.id) {
                            world.setTypeId(i, j, k, 20);
                        }
                        world.setTypeIdAndData(i, j, k, replacedBlockState.getTypeId(), replacedBlockState.getRawData());
                    }
                }
                else {
                    world.f(i, j, k, this.a);
                    Block.byId[this.a].d(world, i, j, k, l);
                    Block.byId[this.a].a(world, i, j, k, (EntityLiving)entityhuman);
                    world.a(i + 0.5f, j + 0.5f, k + 0.5f, block.stepSound.c(), (block.stepSound.a() + 1.0f) / 2.0f, block.stepSound.b() * 0.8f);
                    --itemstack.count;
                }
            }
        }
        return true;
    }
    
    @Override
    public String a() {
        return Block.byId[this.a].e();
    }
}
