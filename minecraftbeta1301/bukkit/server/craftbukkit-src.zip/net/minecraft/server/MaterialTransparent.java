// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class MaterialTransparent extends Material
{
    @Override
    public boolean isBuildable() {
        return false;
    }
    
    @Override
    public boolean blocksLight() {
        return false;
    }
    
    @Override
    public boolean isSolid() {
        return false;
    }
}
