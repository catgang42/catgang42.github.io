// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet38EntityStatus extends Packet
{
    public int a;
    public byte b;
    
    public Packet38EntityStatus() {
    }
    
    public Packet38EntityStatus(final int a, final byte b) {
        this.a = a;
        this.b = b;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readByte();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeByte(this.b);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 5;
    }
}
