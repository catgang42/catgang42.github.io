// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemSpade extends ItemTool
{
    private static Block[] bi;
    
    public ItemSpade(final int n, final EnumToolMaterial enumToolMaterial) {
        super(n, 1, enumToolMaterial, ItemSpade.bi);
    }
    
    @Override
    public boolean a(final Block block) {
        return block == Block.SNOW || block == Block.SNOW_BLOCK;
    }
    
    static {
        ItemSpade.bi = new Block[] { Block.GRASS, Block.DIRT, Block.SAND, Block.GRAVEL, Block.SNOW, Block.SNOW_BLOCK, Block.CLAY };
    }
}
