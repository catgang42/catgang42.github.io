// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockTorch extends Block
{
    protected BlockTorch(final int n, final int n2) {
        super(n, n2, Material.ORIENTABLE);
        this.a(true);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int i, final int n, final int k) {
        return world.d(i - 1, n, k) || world.d(i + 1, n, k) || world.d(i, n, k - 1) || world.d(i, n, k + 1) || world.d(i, n - 1, k);
    }
    
    @Override
    public void d(final World world, final int i, final int n, final int k, final int n2) {
        int data = world.getData(i, n, k);
        if (n2 == 1 && world.d(i, n - 1, k)) {
            data = 5;
        }
        if (n2 == 2 && world.d(i, n, k + 1)) {
            data = 4;
        }
        if (n2 == 3 && world.d(i, n, k - 1)) {
            data = 3;
        }
        if (n2 == 4 && world.d(i + 1, n, k)) {
            data = 2;
        }
        if (n2 == 5 && world.d(i - 1, n, k)) {
            data = 1;
        }
        world.c(i, n, k, data);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        super.a(world, i, j, k, random);
        if (world.getData(i, j, k) == 0) {
            this.e(world, i, j, k);
        }
    }
    
    @Override
    public void e(final World world, final int n, final int j, final int n2) {
        if (world.d(n - 1, j, n2)) {
            world.c(n, j, n2, 1);
        }
        else if (world.d(n + 1, j, n2)) {
            world.c(n, j, n2, 2);
        }
        else if (world.d(n, j, n2 - 1)) {
            world.c(n, j, n2, 3);
        }
        else if (world.d(n, j, n2 + 1)) {
            world.c(n, j, n2, 4);
        }
        else if (world.d(n, j - 1, n2)) {
            world.c(n, j, n2, 5);
        }
        this.g(world, n, j, n2);
    }
    
    @Override
    public void a(final World world, final int n, final int j, final int n2, final int n3) {
        if (this.g(world, n, j, n2)) {
            final int data = world.getData(n, j, n2);
            boolean b = false;
            if (!world.d(n - 1, j, n2) && data == 1) {
                b = true;
            }
            if (!world.d(n + 1, j, n2) && data == 2) {
                b = true;
            }
            if (!world.d(n, j, n2 - 1) && data == 3) {
                b = true;
            }
            if (!world.d(n, j, n2 + 1) && data == 4) {
                b = true;
            }
            if (!world.d(n, j - 1, n2) && data == 5) {
                b = true;
            }
            if (b) {
                this.b_(world, n, j, n2, world.getData(n, j, n2));
                world.e(n, j, n2, 0);
            }
        }
    }
    
    private boolean g(final World world, final int n, final int n2, final int n3) {
        if (!this.a(world, n, n2, n3)) {
            this.b_(world, n, n2, n3, world.getData(n, n2, n3));
            world.e(n, n2, n3, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public MovingObjectPosition a(final World world, final int i, final int j, final int k, final Vec3D vec3D, final Vec3D vec3D2) {
        final int n = world.getData(i, j, k) & 0x7;
        final float n2 = 0.15f;
        if (n == 1) {
            this.a(0.0f, 0.2f, 0.5f - n2, n2 * 2.0f, 0.8f, 0.5f + n2);
        }
        else if (n == 2) {
            this.a(1.0f - n2 * 2.0f, 0.2f, 0.5f - n2, 1.0f, 0.8f, 0.5f + n2);
        }
        else if (n == 3) {
            this.a(0.5f - n2, 0.2f, 0.0f, 0.5f + n2, 0.8f, n2 * 2.0f);
        }
        else if (n == 4) {
            this.a(0.5f - n2, 0.2f, 1.0f - n2 * 2.0f, 0.5f + n2, 0.8f, 1.0f);
        }
        else {
            final float n3 = 0.1f;
            this.a(0.5f - n3, 0.0f, 0.5f - n3, 0.5f + n3, 0.6f, 0.5f + n3);
        }
        return super.a(world, i, j, k, vec3D, vec3D2);
    }
}
