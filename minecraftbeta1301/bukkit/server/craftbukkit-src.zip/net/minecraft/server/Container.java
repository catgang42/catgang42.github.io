// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.HashSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;

public abstract class Container
{
    public List d;
    public List e;
    public int f;
    private short a;
    protected List g;
    private Set b;
    
    public Container() {
        this.d = new ArrayList();
        this.e = new ArrayList();
        this.f = 0;
        this.a = 0;
        this.g = new ArrayList();
        this.b = new HashSet();
    }
    
    protected void a(final Slot slot) {
        slot.a = this.e.size();
        this.e.add(slot);
        this.d.add(null);
    }
    
    public void a(final ICrafting crafting) {
        this.g.add(crafting);
        final ArrayList<ItemStack> list = new ArrayList<ItemStack>();
        for (int i = 0; i < this.e.size(); ++i) {
            list.add(((Slot)this.e.get(i)).b());
        }
        crafting.a(this, list);
        this.a();
    }
    
    public void a() {
        for (int i = 0; i < this.e.size(); ++i) {
            final ItemStack b = this.e.get(i).b();
            if (!ItemStack.a(this.d.get(i), b)) {
                final ItemStack itemStack = (b == null) ? null : b.j();
                this.d.set(i, itemStack);
                for (int j = 0; j < this.g.size(); ++j) {
                    ((ICrafting)this.g.get(j)).a(this, i, itemStack);
                }
            }
        }
    }
    
    public Slot a(final IInventory iinventory, final int i) {
        for (int j = 0; j < this.e.size(); ++j) {
            final Slot slot = this.e.get(j);
            if (slot.a(iinventory, i)) {
                return slot;
            }
        }
        return null;
    }
    
    public Slot a(final int n) {
        return this.e.get(n);
    }
    
    public ItemStack a(final int n, final int n2, final EntityHuman entityHuman) {
        ItemStack j = null;
        if (n2 == 0 || n2 == 1) {
            final InventoryPlayer inventory = entityHuman.inventory;
            if (n == -999) {
                if (inventory.i() != null && n == -999) {
                    if (n2 == 0) {
                        entityHuman.b(inventory.i());
                        inventory.b((ItemStack)null);
                    }
                    if (n2 == 1) {
                        entityHuman.b(inventory.i().a(1));
                        if (inventory.i().count == 0) {
                            inventory.b((ItemStack)null);
                        }
                    }
                }
            }
            else {
                final Slot slot = this.e.get(n);
                if (slot != null) {
                    slot.c();
                    final ItemStack b = slot.b();
                    final ItemStack i = inventory.i();
                    if (b != null) {
                        j = b.j();
                    }
                    if (b == null) {
                        if (i != null && slot.a(i)) {
                            int d = (n2 == 0) ? i.count : 1;
                            if (d > slot.d()) {
                                d = slot.d();
                            }
                            slot.b(i.a(d));
                            if (i.count == 0) {
                                inventory.b((ItemStack)null);
                            }
                        }
                    }
                    else if (i == null) {
                        inventory.b(slot.a((n2 == 0) ? b.count : ((b.count + 1) / 2)));
                        if (b.count == 0) {
                            slot.b(null);
                        }
                        slot.a();
                    }
                    else if (slot.a(i)) {
                        if (b.id != i.id || (b.e() && b.h() != i.h())) {
                            if (i.count <= slot.d()) {
                                final ItemStack itemstack = b;
                                slot.b(i);
                                inventory.b(itemstack);
                            }
                        }
                        else {
                            int k = (n2 == 0) ? i.count : 1;
                            if (k > slot.d() - b.count) {
                                k = slot.d() - b.count;
                            }
                            if (k > i.b() - b.count) {
                                k = i.b() - b.count;
                            }
                            i.a(k);
                            if (i.count == 0) {
                                inventory.b((ItemStack)null);
                            }
                            final ItemStack itemStack = b;
                            itemStack.count += k;
                        }
                    }
                    else if (b.id == i.id && i.b() > 1 && (!b.e() || b.h() == i.h())) {
                        final int count = b.count;
                        if (count > 0 && count + i.count <= i.b()) {
                            final ItemStack itemStack2 = i;
                            itemStack2.count += count;
                            b.a(count);
                            if (b.count == 0) {
                                slot.b(null);
                            }
                            slot.a();
                        }
                    }
                }
            }
        }
        return j;
    }
    
    public void a(final EntityHuman entityHuman) {
        final InventoryPlayer inventory = entityHuman.inventory;
        if (inventory.i() != null) {
            entityHuman.b(inventory.i());
            inventory.b((ItemStack)null);
        }
    }
    
    public void a(final IInventory inventory) {
        this.a();
    }
    
    public boolean c(final EntityHuman entityHuman) {
        return !this.b.contains(entityHuman);
    }
    
    public void a(final EntityHuman entityHuman, final boolean b) {
        if (b) {
            this.b.remove(entityHuman);
        }
        else {
            this.b.add(entityHuman);
        }
    }
    
    public abstract boolean b(final EntityHuman p0);
}
