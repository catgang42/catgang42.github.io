// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public class NBTTagInt extends NBTBase
{
    public int a;
    
    public NBTTagInt() {
    }
    
    public NBTTagInt(final int a) {
        this.a = a;
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        dataOutput.writeInt(this.a);
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.a = dataInput.readInt();
    }
    
    @Override
    public byte a() {
        return 3;
    }
    
    @Override
    public String toString() {
        return "" + this.a;
    }
}
