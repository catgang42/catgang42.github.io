// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BedBlockTextures
{
    public static final int[] a;
    public static final int[] b;
    public static final int[][] c;
    
    static {
        a = new int[] { 3, 4, 2, 5 };
        b = new int[] { 2, 3, 0, 1 };
        c = new int[][] { { 1, 0, 3, 2, 5, 4 }, { 1, 0, 5, 4, 2, 3 }, { 1, 0, 2, 3, 4, 5 }, { 1, 0, 4, 5, 3, 2 } };
    }
}
