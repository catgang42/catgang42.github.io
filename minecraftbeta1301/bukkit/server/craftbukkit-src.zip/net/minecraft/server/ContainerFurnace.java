// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ContainerFurnace extends Container
{
    private TileEntityFurnace a;
    private int b;
    private int c;
    private int h;
    
    public ContainerFurnace(final IInventory inventory, final TileEntityFurnace tileEntityFurnace) {
        this.b = 0;
        this.c = 0;
        this.h = 0;
        this.a = tileEntityFurnace;
        this.a(new Slot(tileEntityFurnace, 0, 56, 17));
        this.a(new Slot(tileEntityFurnace, 1, 56, 53));
        this.a(new Slot(tileEntityFurnace, 2, 116, 35));
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.a(new Slot(inventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int k = 0; k < 9; ++k) {
            this.a(new Slot(inventory, k, 8 + k * 18, 142));
        }
    }
    
    @Override
    public void a(final ICrafting crafting) {
        super.a(crafting);
        crafting.a(this, 0, this.a.c);
        crafting.a(this, 1, this.a.a);
        crafting.a(this, 2, this.a.b);
    }
    
    @Override
    public void a() {
        super.a();
        for (int i = 0; i < this.g.size(); ++i) {
            final ICrafting crafting = this.g.get(i);
            if (this.b != this.a.c) {
                crafting.a(this, 0, this.a.c);
            }
            if (this.c != this.a.a) {
                crafting.a(this, 1, this.a.a);
            }
            if (this.h != this.a.b) {
                crafting.a(this, 2, this.a.b);
            }
        }
        this.b = this.a.c;
        this.c = this.a.a;
        this.h = this.a.b;
    }
    
    @Override
    public boolean b(final EntityHuman entityhuman) {
        return this.a.a_(entityhuman);
    }
}
