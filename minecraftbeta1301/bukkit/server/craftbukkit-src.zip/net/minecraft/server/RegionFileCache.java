// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.HashMap;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.util.Iterator;
import java.io.IOException;
import java.lang.ref.SoftReference;
import java.lang.ref.Reference;
import java.io.File;
import java.util.Map;

public class RegionFileCache
{
    private static final Map a;
    
    private RegionFileCache() {
    }
    
    public static synchronized RegionFile a(final File parent, final int n, final int n2) {
        final File parent2 = new File(parent, "region");
        final File file = new File(parent2, "r." + (n >> 5) + "." + (n2 >> 5) + ".mcr");
        final Reference<RegionFile> reference = RegionFileCache.a.get(file);
        if (reference != null) {
            final RegionFile regionFile = reference.get();
            if (regionFile != null) {
                return regionFile;
            }
        }
        if (!parent2.exists()) {
            parent2.mkdirs();
        }
        if (RegionFileCache.a.size() >= 256) {
            a();
        }
        final RegionFile referent = new RegionFile(file);
        RegionFileCache.a.put(file, new SoftReference<RegionFile>(referent));
        return referent;
    }
    
    public static synchronized void a() {
        for (final Reference<RegionFile> reference : RegionFileCache.a.values()) {
            try {
                final RegionFile regionFile = reference.get();
                if (regionFile == null) {
                    continue;
                }
                regionFile.b();
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        RegionFileCache.a.clear();
    }
    
    public static int b(final File file, final int n, final int n2) {
        return a(file, n, n2).a();
    }
    
    public static DataInputStream c(final File file, final int n, final int n2) {
        return a(file, n, n2).a(n & 0x1F, n2 & 0x1F);
    }
    
    public static DataOutputStream d(final File file, final int n, final int n2) {
        return a(file, n, n2).b(n & 0x1F, n2 & 0x1F);
    }
    
    static {
        a = new HashMap();
    }
}
