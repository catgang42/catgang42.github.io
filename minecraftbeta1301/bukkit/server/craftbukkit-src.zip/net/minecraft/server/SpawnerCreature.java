// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.HashSet;
import java.util.List;
import java.util.Iterator;
import java.util.Set;

public final class SpawnerCreature
{
    private static Set b;
    protected static final Class[] a;
    
    protected static ChunkPosition a(final World world, final int n, final int n2) {
        return new ChunkPosition(n + world.k.nextInt(16), world.k.nextInt(128), n2 + world.k.nextInt(16));
    }
    
    public static final int a(final World world, final boolean b, final boolean b2) {
        if (!b && !b2) {
            return 0;
        }
        SpawnerCreature.b.clear();
        for (int i = 0; i < world.d.size(); ++i) {
            final EntityHuman entityHuman = world.d.get(i);
            final int b3 = MathHelper.b(entityHuman.locX / 16.0);
            final int b4 = MathHelper.b(entityHuman.locZ / 16.0);
            for (int n = 8, j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    SpawnerCreature.b.add(new ChunkCoordIntPair(j + b3, k + b4));
                }
            }
        }
        int n2 = 0;
        final ChunkCoordinates l = world.l();
    Label_0253_Outer:
        for (final EnumCreatureType enumCreatureType : EnumCreatureType.values()) {
            if (!enumCreatureType.d() || b2) {
                if (enumCreatureType.d() || b) {
                    if (world.a(enumCreatureType.a()) <= enumCreatureType.b() * SpawnerCreature.b.size() / 256) {
                    Label_0253:
                        while (true) {
                            for (final ChunkCoordIntPair chunkCoordIntPair : SpawnerCreature.b) {
                                final Class[] a = world.a().a(chunkCoordIntPair).a(enumCreatureType);
                                if (a != null) {
                                    if (a.length == 0) {
                                        continue Label_0253_Outer;
                                    }
                                    final int nextInt = world.k.nextInt(a.length);
                                    final ChunkPosition a2 = a(world, chunkCoordIntPair.a * 16, chunkCoordIntPair.b * 16);
                                    final int a3 = a2.a;
                                    final int b5 = a2.b;
                                    final int c = a2.c;
                                    if (world.d(a3, b5, c)) {
                                        continue Label_0253_Outer;
                                    }
                                    if (world.getMaterial(a3, b5, c) != enumCreatureType.c()) {
                                        continue Label_0253_Outer;
                                    }
                                    int n4 = 0;
                                    for (int n5 = 0; n5 < 3; ++n5) {
                                        int n6 = a3;
                                        int n7 = b5;
                                        int n8 = c;
                                        final int n9 = 6;
                                        for (int n10 = 0; n10 < 4; ++n10) {
                                            n6 += world.k.nextInt(n9) - world.k.nextInt(n9);
                                            n7 += world.k.nextInt(1) - world.k.nextInt(1);
                                            n8 += world.k.nextInt(n9) - world.k.nextInt(n9);
                                            if (a(enumCreatureType, world, n6, n7, n8)) {
                                                final float n11 = n6 + 0.5f;
                                                final float n12 = (float)n7;
                                                final float n13 = n8 + 0.5f;
                                                if (world.a(n11, n12, n13, 24.0) == null) {
                                                    final float n14 = n11 - l.a;
                                                    final float n15 = n12 - l.b;
                                                    final float n16 = n13 - l.c;
                                                    if (n14 * n14 + n15 * n15 + n16 * n16 >= 576.0f) {
                                                        EntityLiving entity;
                                                        try {
                                                            entity = a[nextInt].getConstructor(World.class).newInstance(world);
                                                        }
                                                        catch (Exception ex) {
                                                            ex.printStackTrace();
                                                            return n2;
                                                        }
                                                        entity.c(n11, n12, n13, world.k.nextFloat() * 360.0f, 0.0f);
                                                        if (entity.b()) {
                                                            ++n4;
                                                            world.a(entity);
                                                            a(entity, world, n11, n12, n13);
                                                            if (n4 >= entity.j()) {
                                                                continue Label_0253;
                                                            }
                                                        }
                                                        n2 += n4;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }
        }
        return n2;
    }
    
    private static boolean a(final EnumCreatureType enumCreatureType, final World world, final int n, final int j, final int n2) {
        if (enumCreatureType.c() == Material.WATER) {
            return world.getMaterial(n, j, n2).isLiquid() && !world.d(n, j + 1, n2);
        }
        return world.d(n, j - 1, n2) && !world.d(n, j, n2) && !world.getMaterial(n, j, n2).isLiquid() && !world.d(n, j + 1, n2);
    }
    
    private static void a(final EntityLiving entity, final World world, final float n, final float n2, final float n3) {
        if (entity instanceof EntitySpider && world.k.nextInt(100) == 0) {
            final EntitySkeleton entity2 = new EntitySkeleton(world);
            entity2.c(n, n2, n3, entity.yaw, 0.0f);
            world.a(entity2);
            entity2.b(entity);
        }
        else if (entity instanceof EntitySheep) {
            ((EntitySheep)entity).a_(EntitySheep.a(world.k));
        }
    }
    
    public static boolean a(final World world, final List list) {
        boolean b = false;
        final Pathfinder pathfinder = new Pathfinder(world);
        for (final EntityHuman entityHuman : list) {
            final Class[] a = SpawnerCreature.a;
            if (a != null) {
                if (a.length == 0) {
                    continue;
                }
                for (int n = 0, n2 = 0; n2 < 20 && n == 0; ++n2) {
                    final int i = MathHelper.b(entityHuman.locX) + world.k.nextInt(32) - world.k.nextInt(32);
                    final int k = MathHelper.b(entityHuman.locZ) + world.k.nextInt(32) - world.k.nextInt(32);
                    int n3 = MathHelper.b(entityHuman.locY) + world.k.nextInt(16) - world.k.nextInt(16);
                    if (n3 < 1) {
                        n3 = 1;
                    }
                    else if (n3 > 128) {
                        n3 = 128;
                    }
                    final int nextInt = world.k.nextInt(a.length);
                    int n4;
                    for (n4 = n3; n4 > 2 && !world.d(i, n4 - 1, k); --n4) {}
                    while (!a(EnumCreatureType.MONSTER, world, i, n4, k) && n4 < n3 + 16 && n4 < 128) {
                        ++n4;
                    }
                    if (n4 < n3 + 16 && n4 < 128) {
                        final float n5 = i + 0.5f;
                        final float n6 = (float)n4;
                        final float n7 = k + 0.5f;
                        EntityLiving entity;
                        try {
                            entity = a[nextInt].getConstructor(World.class).newInstance(world);
                        }
                        catch (Exception ex) {
                            ex.printStackTrace();
                            return b;
                        }
                        entity.c(n5, n6, n7, world.k.nextFloat() * 360.0f, 0.0f);
                        if (entity.b()) {
                            final PathEntity a2 = pathfinder.a(entity, entityHuman, 32.0f);
                            if (a2 != null && a2.a > 1) {
                                final PathPoint c = a2.c();
                                if (Math.abs(c.a - entityHuman.locX) < 1.5 && Math.abs(c.c - entityHuman.locZ) < 1.5 && Math.abs(c.b - entityHuman.locY) < 1.5) {
                                    final ChunkCoordinates g = BlockBed.g(world, MathHelper.b(entityHuman.locX), MathHelper.b(entityHuman.locY), MathHelper.b(entityHuman.locZ), 1);
                                    entity.c(g.a + 0.5f, g.b, g.c + 0.5f, 0.0f, 0.0f);
                                    world.a(entity);
                                    a(entity, world, g.a + 0.5f, (float)g.b, g.c + 0.5f);
                                    entityHuman.a(true, false);
                                    entity.G();
                                    b = true;
                                    n = 1;
                                }
                            }
                        }
                    }
                }
            }
        }
        return b;
    }
    
    static {
        SpawnerCreature.b = new HashSet();
        a = new Class[] { EntitySpider.class, EntityZombie.class, EntitySkeleton.class };
    }
}
