// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemBed extends Item
{
    public ItemBed(final int n) {
        super(n);
    }
    
    @Override
    public boolean a(final ItemStack itemStack, final EntityHuman entityHuman, final World world, final int i, int n, final int k, final int n2) {
        if (n2 != 1) {
            return false;
        }
        ++n;
        final BlockBed blockBed = (BlockBed)Block.BED;
        final int i2 = MathHelper.b(entityHuman.yaw * 4.0f / 360.0f + 0.5) & 0x3;
        int n3 = 0;
        int n4 = 0;
        if (i2 == 0) {
            n4 = 1;
        }
        if (i2 == 1) {
            n3 = -1;
        }
        if (i2 == 2) {
            n4 = -1;
        }
        if (i2 == 3) {
            n3 = 1;
        }
        if (world.isEmpty(i, n, k) && world.isEmpty(i + n3, n, k + n4) && world.d(i, n - 1, k) && world.d(i + n3, n - 1, k + n4)) {
            world.b(i, n, k, blockBed.id, i2);
            world.b(i + n3, n, k + n4, blockBed.id, i2 + 8);
            --itemStack.count;
            return true;
        }
        return false;
    }
}
