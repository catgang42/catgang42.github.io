// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public abstract class WorldGenerator
{
    public abstract boolean a(final World p0, final Random p1, final int p2, final int p3, final int p4);
    
    public void a(final double n, final double n2, final double n3) {
    }
}
