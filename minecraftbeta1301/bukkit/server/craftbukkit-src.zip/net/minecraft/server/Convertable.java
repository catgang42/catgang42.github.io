// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public interface Convertable
{
    boolean a(final String p0);
    
    boolean a(final String p0, final IProgressUpdate p1);
}
