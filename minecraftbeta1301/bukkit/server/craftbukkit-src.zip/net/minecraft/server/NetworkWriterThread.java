// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

class NetworkWriterThread extends Thread
{
    final /* synthetic */ NetworkManager a;
    
    NetworkWriterThread(final NetworkManager a, final String name) {
        this.a = a;
        super(name);
    }
    
    @Override
    public void run() {
        synchronized (NetworkManager.a) {
            ++NetworkManager.c;
        }
        try {
            while (this.a.j) {
                this.a.e();
            }
        }
        finally {
            synchronized (NetworkManager.a) {
                --NetworkManager.c;
            }
        }
    }
}
