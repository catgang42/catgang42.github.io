// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.player.PlayerItemEvent;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class ItemFlintAndSteel extends Item
{
    public ItemFlintAndSteel(final int i) {
        super(i);
        this.maxStackSize = 1;
        this.durability = 64;
    }
    
    @Override
    public boolean a(final ItemStack itemstack, final EntityHuman entityhuman, final World world, int i, int j, int k, final int l) {
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer craftServer = ((WorldServer)world).getServer();
        final org.bukkit.block.Block blockClicked = craftWorld.getBlockAt(i, j, k);
        if (l == 0) {
            --j;
        }
        if (l == 1) {
            ++j;
        }
        if (l == 2) {
            --k;
        }
        if (l == 3) {
            ++k;
        }
        if (l == 4) {
            --i;
        }
        if (l == 5) {
            ++i;
        }
        final int i2 = world.getTypeId(i, j, k);
        if (i2 == 0) {
            final Event.Type eventType = Event.Type.PLAYER_ITEM;
            final Player thePlayer = (Player)entityhuman.getBukkitEntity();
            final CraftItemStack itemInHand = new CraftItemStack(itemstack);
            final BlockFace blockFace = CraftBlock.notchToBlockFace(l);
            final PlayerItemEvent event = new PlayerItemEvent(eventType, thePlayer, itemInHand, blockClicked, blockFace);
            craftServer.getPluginManager().callEvent(event);
            final boolean preventLighter = event.isCancelled();
            final BlockIgniteEvent.IgniteCause igniteCause = BlockIgniteEvent.IgniteCause.FLINT_AND_STEEL;
            final BlockIgniteEvent eventIgnite = new BlockIgniteEvent(blockClicked, igniteCause, thePlayer);
            craftServer.getPluginManager().callEvent(eventIgnite);
            final boolean preventFire = eventIgnite.isCancelled();
            if (preventLighter) {
                return false;
            }
            if (preventFire) {
                itemstack.b(1);
                return false;
            }
            world.a(i + 0.5, j + 0.5, k + 0.5, "fire.ignite", 1.0f, ItemFlintAndSteel.b.nextFloat() * 0.4f + 0.8f);
            world.e(i, j, k, Block.FIRE.id);
        }
        itemstack.b(1);
        return true;
    }
}
