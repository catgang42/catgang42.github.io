// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockDiode extends Block
{
    public static final double[] a;
    private static final int[] b;
    private final boolean c;
    
    protected BlockDiode(final int n, final boolean c) {
        super(n, 102, Material.ORIENTABLE);
        this.c = c;
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.125f, 1.0f);
    }
    
    @Override
    public boolean a(final World world, final int i, final int n, final int k) {
        return world.d(i, n - 1, k) && super.a(world, i, n, k);
    }
    
    @Override
    public boolean f(final World world, final int i, final int n, final int k) {
        return world.d(i, n - 1, k) && super.f(world, i, n, k);
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Random random) {
        final int data = world.getData(n, n2, n3);
        final boolean g = this.g(world, n, n2, n3, data);
        if (this.c && !g) {
            world.b(n, n2, n3, Block.DIODE_OFF.id, data);
        }
        else if (!this.c) {
            world.b(n, n2, n3, Block.DIODE_ON.id, data);
            if (!g) {
                world.c(n, n2, n3, Block.DIODE_ON.id, BlockDiode.b[(data & 0xC) >> 2] * 2);
            }
        }
    }
    
    @Override
    public int a(final int n, final int n2) {
        if (n == 0) {
            if (this.c) {
                return 99;
            }
            return 115;
        }
        else {
            if (n != 1) {
                return 5;
            }
            if (this.c) {
                return 147;
            }
            return 131;
        }
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        return n4 != 0 && n4 != 1;
    }
    
    @Override
    public int a(final int n) {
        return this.a(n, 0);
    }
    
    @Override
    public boolean c(final World world, final int n, final int n2, final int n3, final int n4) {
        return this.b((IBlockAccess)world, n, n2, n3, n4);
    }
    
    @Override
    public boolean b(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        if (!this.c) {
            return false;
        }
        final int n5 = blockAccess.getData(n, n2, n3) & 0x3;
        return (n5 == 0 && n4 == 3) || (n5 == 1 && n4 == 4) || (n5 == 2 && n4 == 2) || (n5 == 3 && n4 == 5);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int n) {
        if (!this.f(world, i, j, k)) {
            this.b_(world, i, j, k, world.getData(i, j, k));
            world.e(i, j, k, 0);
            return;
        }
        final int data = world.getData(i, j, k);
        final boolean g = this.g(world, i, j, k, data);
        final int n2 = (data & 0xC) >> 2;
        if (this.c && !g) {
            world.c(i, j, k, this.id, BlockDiode.b[n2] * 2);
        }
        else if (!this.c && g) {
            world.c(i, j, k, this.id, BlockDiode.b[n2] * 2);
        }
    }
    
    private boolean g(final World world, final int n, final int n2, final int n3, final int n4) {
        switch (n4 & 0x3) {
            case 0: {
                return world.j(n, n2, n3 + 1, 3);
            }
            case 2: {
                return world.j(n, n2, n3 - 1, 2);
            }
            case 3: {
                return world.j(n + 1, n2, n3, 5);
            }
            case 1: {
                return world.j(n - 1, n2, n3, 4);
            }
            default: {
                return false;
            }
        }
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        final int data = world.getData(n, n2, n3);
        world.c(n, n2, n3, (((data & 0xC) >> 2) + 1 << 2 & 0xC) | (data & 0x3));
        return true;
    }
    
    @Override
    public boolean c() {
        return false;
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final EntityLiving entityLiving) {
        final int l = ((MathHelper.b(entityLiving.yaw * 4.0f / 360.0f + 0.5) & 0x3) + 2) % 4;
        world.c(n, n2, n3, l);
        if (this.g(world, n, n2, n3, l)) {
            world.c(n, n2, n3, this.id, 1);
        }
    }
    
    @Override
    public void e(final World world, final int n, final int n2, final int n3) {
        world.h(n + 1, n2, n3, this.id);
        world.h(n - 1, n2, n3, this.id);
        world.h(n, n2, n3 + 1, this.id);
        world.h(n, n2, n3 - 1, this.id);
        world.h(n, n2 - 1, n3, this.id);
        world.h(n, n2 + 1, n3, this.id);
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Item.DIODE.id;
    }
    
    static {
        a = new double[] { -0.0625, 0.0625, 0.1875, 0.3125 };
        b = new int[] { 1, 2, 3, 4 };
    }
}
