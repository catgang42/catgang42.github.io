// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.HashMap;
import java.util.Map;

public class EntityTypes
{
    private static Map a;
    private static Map b;
    private static Map c;
    private static Map d;
    
    private static void a(final Class clazz, final String s, final int n) {
        EntityTypes.a.put(s, clazz);
        EntityTypes.b.put(clazz, s);
        EntityTypes.c.put(n, clazz);
        EntityTypes.d.put(clazz, n);
    }
    
    public static Entity a(final String s, final World world) {
        Entity entity = null;
        try {
            final Class<Entity> clazz = EntityTypes.a.get(s);
            if (clazz != null) {
                entity = clazz.getConstructor(World.class).newInstance(world);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        return entity;
    }
    
    public static Entity a(final NBTTagCompound nbttagcompound, final World world) {
        Entity entity = null;
        try {
            final Class<Entity> clazz = EntityTypes.a.get(nbttagcompound.i("id"));
            if (clazz != null) {
                entity = clazz.getConstructor(World.class).newInstance(world);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        if (entity != null) {
            entity.e(nbttagcompound);
        }
        else {
            System.out.println("Skipping Entity with id " + nbttagcompound.i("id"));
        }
        return entity;
    }
    
    public static int a(final Entity entity) {
        return EntityTypes.d.get(entity.getClass());
    }
    
    public static String b(final Entity entity) {
        return EntityTypes.b.get(entity.getClass());
    }
    
    static {
        EntityTypes.a = new HashMap();
        EntityTypes.b = new HashMap();
        EntityTypes.c = new HashMap();
        EntityTypes.d = new HashMap();
        a(EntityArrow.class, "Arrow", 10);
        a(EntitySnowball.class, "Snowball", 11);
        a(EntityItem.class, "Item", 1);
        a(EntityPainting.class, "Painting", 9);
        a(EntityLiving.class, "Mob", 48);
        a(EntityMonster.class, "Monster", 49);
        a(EntityCreeper.class, "Creeper", 50);
        a(EntitySkeleton.class, "Skeleton", 51);
        a(EntitySpider.class, "Spider", 52);
        a(EntityGiantZombie.class, "Giant", 53);
        a(EntityZombie.class, "Zombie", 54);
        a(EntitySlime.class, "Slime", 55);
        a(EntityGhast.class, "Ghast", 56);
        a(EntityPigZombie.class, "PigZombie", 57);
        a(EntityPig.class, "Pig", 90);
        a(EntitySheep.class, "Sheep", 91);
        a(EntityCow.class, "Cow", 92);
        a(EntityChicken.class, "Chicken", 93);
        a(EntitySquid.class, "Squid", 94);
        a(EntityTNTPrimed.class, "PrimedTnt", 20);
        a(EntityFallingSand.class, "FallingSand", 21);
        a(EntityMinecart.class, "Minecart", 40);
        a(EntityBoat.class, "Boat", 41);
    }
}
