// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class MetadataChunkBlock
{
    public final EnumSkyBlock a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    
    public MetadataChunkBlock(final EnumSkyBlock a, final int b, final int c, final int d, final int e, final int f, final int g) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
    }
    
    public void a(final World world) {
        if ((this.e - this.b + 1) * (this.f - this.c + 1) * (this.g - this.d + 1) > 32768) {
            System.out.println("Light too large, skipping!");
            return;
        }
        int n = 0;
        int n2 = 0;
        final boolean b = false;
        int n3 = 0;
        for (int i = this.b; i <= this.e; ++i) {
            for (int j = this.d; j <= this.g; ++j) {
                final int n4 = i >> 4;
                final int n5 = j >> 4;
                int a;
                if (b && n4 == n && n5 == n2) {
                    a = n3;
                }
                else {
                    a = (world.a(i, 0, j, 1) ? 1 : 0);
                    if (a != 0 && world.c(i >> 4, j >> 4).g()) {
                        a = 0;
                    }
                    n3 = a;
                    n = n4;
                    n2 = n5;
                }
                if (a != 0) {
                    if (this.c < 0) {
                        this.c = 0;
                    }
                    if (this.f >= 128) {
                        this.f = 127;
                    }
                    for (int k = this.c; k <= this.f; ++k) {
                        final int a2 = world.a(this.a, i, k, j);
                        final int typeId = world.getTypeId(i, k, j);
                        int n6 = Block.q[typeId];
                        if (n6 == 0) {
                            n6 = 1;
                        }
                        int n7 = 0;
                        if (this.a == EnumSkyBlock.SKY) {
                            if (world.k(i, k, j)) {
                                n7 = 15;
                            }
                        }
                        else if (this.a == EnumSkyBlock.BLOCK) {
                            n7 = Block.s[typeId];
                        }
                        int l;
                        if (n6 >= 15 && n7 == 0) {
                            l = 0;
                        }
                        else {
                            final int a3 = world.a(this.a, i - 1, k, j);
                            final int a4 = world.a(this.a, i + 1, k, j);
                            final int a5 = world.a(this.a, i, k - 1, j);
                            final int a6 = world.a(this.a, i, k + 1, j);
                            final int a7 = world.a(this.a, i, k, j - 1);
                            final int a8 = world.a(this.a, i, k, j + 1);
                            int n8 = a3;
                            if (a4 > n8) {
                                n8 = a4;
                            }
                            if (a5 > n8) {
                                n8 = a5;
                            }
                            if (a6 > n8) {
                                n8 = a6;
                            }
                            if (a7 > n8) {
                                n8 = a7;
                            }
                            if (a8 > n8) {
                                n8 = a8;
                            }
                            l = n8 - n6;
                            if (l < 0) {
                                l = 0;
                            }
                            if (n7 > l) {
                                l = n7;
                            }
                        }
                        if (a2 != l) {
                            world.b(this.a, i, k, j, l);
                            int n9 = l - 1;
                            if (n9 < 0) {
                                n9 = 0;
                            }
                            world.a(this.a, i - 1, k, j, n9);
                            world.a(this.a, i, k - 1, j, n9);
                            world.a(this.a, i, k, j - 1, n9);
                            if (i + 1 >= this.e) {
                                world.a(this.a, i + 1, k, j, n9);
                            }
                            if (k + 1 >= this.f) {
                                world.a(this.a, i, k + 1, j, n9);
                            }
                            if (j + 1 >= this.g) {
                                world.a(this.a, i, k, j + 1, n9);
                            }
                        }
                    }
                }
            }
        }
    }
    
    public boolean a(int b, int c, int d, int e, int f, int g) {
        if (b >= this.b && c >= this.c && d >= this.d && e <= this.e && f <= this.f && g <= this.g) {
            return true;
        }
        final int n = 1;
        if (b >= this.b - n && c >= this.c - n && d >= this.d - n && e <= this.e + n && f <= this.f + n && g <= this.g + n) {
            final int n2 = this.e - this.b;
            final int n3 = this.f - this.c;
            final int n4 = this.g - this.d;
            if (b > this.b) {
                b = this.b;
            }
            if (c > this.c) {
                c = this.c;
            }
            if (d > this.d) {
                d = this.d;
            }
            if (e < this.e) {
                e = this.e;
            }
            if (f < this.f) {
                f = this.f;
            }
            if (g < this.g) {
                g = this.g;
            }
            if ((e - b) * (f - c) * (g - d) - n2 * n3 * n4 <= 2) {
                this.b = b;
                this.c = c;
                this.d = d;
                this.e = e;
                this.f = f;
                this.g = g;
                return true;
            }
        }
        return false;
    }
}
