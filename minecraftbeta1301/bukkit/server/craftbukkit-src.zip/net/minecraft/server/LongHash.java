// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public abstract class LongHash<V>
{
    static long toLong(final int msw, final int lsw) {
        return ((long)msw << 32) + lsw + 2147483648L;
    }
    
    static int msw(final long l) {
        return (int)(l >> 32);
    }
    
    static int lsw(final long l) {
        return (int)(l & -1L) + Integer.MIN_VALUE;
    }
    
    public boolean containsKey(final int msw, final int lsw) {
        return this.containsKey(toLong(msw, lsw));
    }
    
    public void remove(final int msw, final int lsw) {
        this.remove(toLong(msw, lsw));
    }
    
    public abstract boolean containsKey(final long p0);
    
    public abstract void remove(final long p0);
}
