// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ThreadSleepForever extends Thread
{
    final /* synthetic */ MinecraftServer a;
    
    public ThreadSleepForever(final MinecraftServer a) {
        this.a = a;
        this.setDaemon(true);
        this.start();
    }
    
    @Override
    public void run() {
        while (true) {
            try {
                while (true) {
                    Thread.sleep(2147483647L);
                }
            }
            catch (InterruptedException ex) {
                continue;
            }
            break;
        }
    }
}
