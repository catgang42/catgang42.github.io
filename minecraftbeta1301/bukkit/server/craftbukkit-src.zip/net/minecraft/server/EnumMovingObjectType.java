// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public enum EnumMovingObjectType
{
    TILE("TILE", 0), 
    ENTITY("ENTITY", 1);
    
    private EnumMovingObjectType(final String name, final int ordinal) {
    }
}
