// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class SlotResult extends Slot
{
    private final IInventory d;
    
    public SlotResult(final IInventory d, final IInventory iinventory, final int i, final int j, final int k) {
        super(iinventory, i, j, k);
        this.d = d;
    }
    
    @Override
    public boolean a(final ItemStack itemStack) {
        return false;
    }
    
    @Override
    public void a() {
        for (int i = 0; i < this.d.m_(); ++i) {
            final ItemStack c_ = this.d.c_(i);
            if (c_ != null) {
                this.d.a(i, 1);
                if (c_.a().g()) {
                    this.d.a(i, new ItemStack(c_.a().f()));
                }
            }
        }
    }
}
