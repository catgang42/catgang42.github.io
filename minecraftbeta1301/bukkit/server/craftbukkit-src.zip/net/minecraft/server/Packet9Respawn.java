// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet9Respawn extends Packet
{
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
    }
    
    @Override
    public int a() {
        return 0;
    }
}
