// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

class PacketCounter
{
    private int a;
    private long b;
    
    private PacketCounter() {
    }
    
    public void a(final int n) {
        ++this.a;
        this.b += n;
    }
}
