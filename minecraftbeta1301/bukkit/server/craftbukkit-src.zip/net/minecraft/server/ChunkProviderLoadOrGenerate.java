// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.IOException;

public class ChunkProviderLoadOrGenerate implements IChunkProvider
{
    private Chunk c;
    private IChunkProvider d;
    private IChunkLoader e;
    private Chunk[] f;
    private World g;
    int a;
    int b;
    private Chunk h;
    private int i;
    private int j;
    
    public ChunkProviderLoadOrGenerate(final World g, final IChunkLoader e, final IChunkProvider d) {
        this.f = new Chunk[1024];
        this.a = -999999999;
        this.b = -999999999;
        this.c = new EmptyChunk(g, new byte[32768], 0, 0);
        this.g = g;
        this.e = e;
        this.d = d;
    }
    
    public boolean c(final int n, final int n2) {
        final int n3 = 15;
        return n >= this.i - n3 && n2 >= this.j - n3 && n <= this.i + n3 && n2 <= this.j + n3;
    }
    
    public boolean a(final int i, final int j) {
        if (!this.c(i, j)) {
            return false;
        }
        if (i == this.a && j == this.b && this.h != null) {
            return true;
        }
        final int n = (i & 0x1F) + (j & 0x1F) * 32;
        return this.f[n] != null && (this.f[n] == this.c || this.f[n].a(i, j));
    }
    
    public Chunk b(final int a, final int b) {
        if (a == this.a && b == this.b && this.h != null) {
            return this.h;
        }
        if (!this.g.r && !this.c(a, b)) {
            return this.c;
        }
        final int n = (a & 0x1F) + (b & 0x1F) * 32;
        if (!this.a(a, b)) {
            if (this.f[n] != null) {
                this.f[n].e();
                this.b(this.f[n]);
                this.a(this.f[n]);
            }
            Chunk chunk = this.d(a, b);
            if (chunk == null) {
                if (this.d == null) {
                    chunk = this.c;
                }
                else {
                    chunk = this.d.b(a, b);
                }
            }
            (this.f[n] = chunk).c();
            if (this.f[n] != null) {
                this.f[n].d();
            }
            if (!this.f[n].n && this.a(a + 1, b + 1) && this.a(a, b + 1) && this.a(a + 1, b)) {
                this.a(this, a, b);
            }
            if (this.a(a - 1, b) && !this.b(a - 1, b).n && this.a(a - 1, b + 1) && this.a(a, b + 1) && this.a(a - 1, b)) {
                this.a(this, a - 1, b);
            }
            if (this.a(a, b - 1) && !this.b(a, b - 1).n && this.a(a + 1, b - 1) && this.a(a, b - 1) && this.a(a + 1, b)) {
                this.a(this, a, b - 1);
            }
            if (this.a(a - 1, b - 1) && !this.b(a - 1, b - 1).n && this.a(a - 1, b - 1) && this.a(a, b - 1) && this.a(a - 1, b)) {
                this.a(this, a - 1, b - 1);
            }
        }
        this.a = a;
        this.b = b;
        this.h = this.f[n];
        return this.f[n];
    }
    
    private Chunk d(final int n, final int n2) {
        if (this.e == null) {
            return this.c;
        }
        try {
            final Chunk a = this.e.a(this.g, n, n2);
            if (a != null) {
                a.r = this.g.k();
            }
            return a;
        }
        catch (Exception ex) {
            ex.printStackTrace();
            return this.c;
        }
    }
    
    private void a(final Chunk chunk) {
        if (this.e == null) {
            return;
        }
        try {
            this.e.b(this.g, chunk);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private void b(final Chunk chunk) {
        if (this.e == null) {
            return;
        }
        try {
            chunk.r = this.g.k();
            this.e.a(this.g, chunk);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void a(final IChunkProvider chunkProvider, final int n, final int n2) {
        final Chunk b = this.b(n, n2);
        if (!b.n) {
            b.n = true;
            if (this.d != null) {
                this.d.a(chunkProvider, n, n2);
                b.f();
            }
        }
    }
    
    public boolean a(final boolean b, final IProgressUpdate progressUpdate) {
        int n = 0;
        int n2 = 0;
        if (progressUpdate != null) {
            for (int i = 0; i < this.f.length; ++i) {
                if (this.f[i] != null && this.f[i].a(b)) {
                    ++n2;
                }
            }
        }
        int n3 = 0;
        for (int j = 0; j < this.f.length; ++j) {
            if (this.f[j] != null) {
                if (b && !this.f[j].p) {
                    this.a(this.f[j]);
                }
                if (this.f[j].a(b)) {
                    this.b(this.f[j]);
                    this.f[j].o = false;
                    if (++n == 2 && !b) {
                        return false;
                    }
                    if (progressUpdate != null && ++n3 % 10 == 0) {
                        progressUpdate.a(n3 * 100 / n2);
                    }
                }
            }
        }
        if (b) {
            if (this.e == null) {
                return true;
            }
            this.e.b();
        }
        return true;
    }
    
    public boolean a() {
        if (this.e != null) {
            this.e.a();
        }
        return this.d.a();
    }
    
    public boolean b() {
        return true;
    }
}
