// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class PlayerList
{
    private transient PlayerListEntry[] a;
    private transient int b;
    private int c;
    private final float d;
    private transient volatile int e;
    
    public PlayerList() {
        this.d = 0.75f;
        this.c = 12;
        this.a = new PlayerListEntry[16];
    }
    
    private static int e(final long n) {
        return a((int)(n ^ n >>> 32));
    }
    
    private static int a(int n) {
        n ^= (n >>> 20 ^ n >>> 12);
        return n ^ n >>> 7 ^ n >>> 4;
    }
    
    private static int a(final int n, final int n2) {
        return n & n2 - 1;
    }
    
    public Object a(final long n) {
        for (PlayerListEntry c = this.a[a(e(n), this.a.length)]; c != null; c = c.c) {
            if (c.a == n) {
                return c.b;
            }
        }
        return null;
    }
    
    public void a(final long n, final Object b) {
        final int e = e(n);
        final int a = a(e, this.a.length);
        for (PlayerListEntry c = this.a[a]; c != null; c = c.c) {
            if (c.a == n) {
                c.b = b;
            }
        }
        ++this.e;
        this.a(e, n, b, a);
    }
    
    private void b(final int n) {
        if (this.a.length == 1073741824) {
            this.c = Integer.MAX_VALUE;
            return;
        }
        final PlayerListEntry[] a = new PlayerListEntry[n];
        this.a(a);
        this.a = a;
        this.c = (int)(n * this.d);
    }
    
    private void a(final PlayerListEntry[] array) {
        final PlayerListEntry[] a = this.a;
        final int length = array.length;
        for (int i = 0; i < a.length; ++i) {
            PlayerListEntry playerListEntry = a[i];
            if (playerListEntry != null) {
                a[i] = null;
                do {
                    final PlayerListEntry c = playerListEntry.c;
                    final int a2 = a(playerListEntry.d, length);
                    playerListEntry.c = array[a2];
                    array[a2] = playerListEntry;
                    playerListEntry = c;
                } while (playerListEntry != null);
            }
        }
    }
    
    public Object b(final long n) {
        final PlayerListEntry c = this.c(n);
        return (c == null) ? null : c.b;
    }
    
    final PlayerListEntry c(final long n) {
        final int a = a(e(n), this.a.length);
        PlayerListEntry playerListEntry2;
        PlayerListEntry c;
        for (PlayerListEntry playerListEntry = playerListEntry2 = this.a[a]; playerListEntry2 != null; playerListEntry2 = c) {
            c = playerListEntry2.c;
            if (playerListEntry2.a == n) {
                ++this.e;
                --this.b;
                if (playerListEntry == playerListEntry2) {
                    this.a[a] = c;
                }
                else {
                    playerListEntry.c = c;
                }
                return playerListEntry2;
            }
            playerListEntry = playerListEntry2;
        }
        return playerListEntry2;
    }
    
    private void a(final int n, final long n2, final Object o, final int n3) {
        this.a[n3] = new PlayerListEntry(n, n2, o, this.a[n3]);
        if (this.b++ >= this.c) {
            this.b(2 * this.a.length);
        }
    }
}
