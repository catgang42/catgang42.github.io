// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class EntityList
{
    private transient EntityListEntry[] a;
    private transient int b;
    private int c;
    private final float d;
    private transient volatile int e;
    
    public EntityList() {
        this.d = 0.75f;
        this.c = 12;
        this.a = new EntityListEntry[16];
    }
    
    private static int g(int n) {
        n ^= (n >>> 20 ^ n >>> 12);
        return n ^ n >>> 7 ^ n >>> 4;
    }
    
    private static int a(final int n, final int n2) {
        return n & n2 - 1;
    }
    
    public Object a(final int n) {
        for (EntityListEntry c = this.a[a(g(n), this.a.length)]; c != null; c = c.c) {
            if (c.a == n) {
                return c.b;
            }
        }
        return null;
    }
    
    public boolean b(final int n) {
        return this.c(n) != null;
    }
    
    final EntityListEntry c(final int n) {
        for (EntityListEntry c = this.a[a(g(n), this.a.length)]; c != null; c = c.c) {
            if (c.a == n) {
                return c;
            }
        }
        return null;
    }
    
    public void a(final int n, final Object b) {
        final int g = g(n);
        final int a = a(g, this.a.length);
        for (EntityListEntry c = this.a[a]; c != null; c = c.c) {
            if (c.a == n) {
                c.b = b;
            }
        }
        ++this.e;
        this.a(g, n, b, a);
    }
    
    private void h(final int n) {
        if (this.a.length == 1073741824) {
            this.c = Integer.MAX_VALUE;
            return;
        }
        final EntityListEntry[] a = new EntityListEntry[n];
        this.a(a);
        this.a = a;
        this.c = (int)(n * this.d);
    }
    
    private void a(final EntityListEntry[] array) {
        final EntityListEntry[] a = this.a;
        final int length = array.length;
        for (int i = 0; i < a.length; ++i) {
            EntityListEntry entityListEntry = a[i];
            if (entityListEntry != null) {
                a[i] = null;
                do {
                    final EntityListEntry c = entityListEntry.c;
                    final int a2 = a(entityListEntry.d, length);
                    entityListEntry.c = array[a2];
                    array[a2] = entityListEntry;
                    entityListEntry = c;
                } while (entityListEntry != null);
            }
        }
    }
    
    public Object d(final int n) {
        final EntityListEntry e = this.e(n);
        return (e == null) ? null : e.b;
    }
    
    final EntityListEntry e(final int n) {
        final int a = a(g(n), this.a.length);
        EntityListEntry entityListEntry2;
        EntityListEntry c;
        for (EntityListEntry entityListEntry = entityListEntry2 = this.a[a]; entityListEntry2 != null; entityListEntry2 = c) {
            c = entityListEntry2.c;
            if (entityListEntry2.a == n) {
                ++this.e;
                --this.b;
                if (entityListEntry == entityListEntry2) {
                    this.a[a] = c;
                }
                else {
                    entityListEntry.c = c;
                }
                return entityListEntry2;
            }
            entityListEntry = entityListEntry2;
        }
        return entityListEntry2;
    }
    
    public void a() {
        ++this.e;
        final EntityListEntry[] a = this.a;
        for (int i = 0; i < a.length; ++i) {
            a[i] = null;
        }
        this.b = 0;
    }
    
    private void a(final int n, final int n2, final Object o, final int n3) {
        this.a[n3] = new EntityListEntry(n, n2, o, this.a[n3]);
        if (this.b++ >= this.c) {
            this.h(2 * this.a.length);
        }
    }
}
