// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import java.util.List;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageByProjectileEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class EntityFish extends Entity
{
    private int d;
    private int e;
    private int f;
    private int g;
    private boolean h;
    public int a;
    public EntityHuman b;
    private int i;
    private int j;
    private int k;
    public Entity c;
    private int l;
    private double m;
    private double n;
    private double o;
    private double p;
    private double q;
    
    public EntityFish(final World world) {
        super(world);
        this.d = -1;
        this.e = -1;
        this.f = -1;
        this.g = 0;
        this.h = false;
        this.a = 0;
        this.j = 0;
        this.k = 0;
        this.c = null;
        this.a(0.25f, 0.25f);
    }
    
    @Override
    protected void a() {
    }
    
    public EntityFish(final World world, final EntityHuman entityhuman) {
        super(world);
        this.d = -1;
        this.e = -1;
        this.f = -1;
        this.g = 0;
        this.h = false;
        this.a = 0;
        this.j = 0;
        this.k = 0;
        this.c = null;
        this.b = entityhuman;
        (this.b.hookedFish = this).a(0.25f, 0.25f);
        this.c(entityhuman.locX, entityhuman.locY + 1.62 - entityhuman.height, entityhuman.locZ, entityhuman.yaw, entityhuman.pitch);
        this.locX -= MathHelper.b(this.yaw / 180.0f * 3.1415927f) * 0.16f;
        this.locY -= 0.10000000149011612;
        this.locZ -= MathHelper.a(this.yaw / 180.0f * 3.1415927f) * 0.16f;
        this.a(this.locX, this.locY, this.locZ);
        this.height = 0.0f;
        final float f = 0.4f;
        this.motX = -MathHelper.a(this.yaw / 180.0f * 3.1415927f) * MathHelper.b(this.pitch / 180.0f * 3.1415927f) * f;
        this.motZ = MathHelper.b(this.yaw / 180.0f * 3.1415927f) * MathHelper.b(this.pitch / 180.0f * 3.1415927f) * f;
        this.motY = -MathHelper.a(this.pitch / 180.0f * 3.1415927f) * f;
        this.a(this.motX, this.motY, this.motZ, 1.5f, 1.0f);
    }
    
    public void a(double d0, double d1, double d2, final float f, final float f1) {
        final float f2 = MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2);
        d0 /= f2;
        d1 /= f2;
        d2 /= f2;
        d0 += this.random.nextGaussian() * 0.007499999832361937 * f1;
        d1 += this.random.nextGaussian() * 0.007499999832361937 * f1;
        d2 += this.random.nextGaussian() * 0.007499999832361937 * f1;
        d0 *= f;
        d1 *= f;
        d2 *= f;
        this.motX = d0;
        this.motY = d1;
        this.motZ = d2;
        final float f3 = MathHelper.a(d0 * d0 + d2 * d2);
        final float n = (float)(Math.atan2(d0, d2) * 180.0 / 3.1415927410125732);
        this.yaw = n;
        this.lastYaw = n;
        final float n2 = (float)(Math.atan2(d1, f3) * 180.0 / 3.1415927410125732);
        this.pitch = n2;
        this.lastPitch = n2;
        this.i = 0;
    }
    
    @Override
    public void f_() {
        super.f_();
        if (this.l > 0) {
            final double d0 = this.locX + (this.m - this.locX) / this.l;
            final double d2 = this.locY + (this.n - this.locY) / this.l;
            final double d3 = this.locZ + (this.o - this.locZ) / this.l;
            double d4;
            for (d4 = this.p - this.yaw; d4 < -180.0; d4 += 360.0) {}
            while (d4 >= 180.0) {
                d4 -= 360.0;
            }
            this.yaw += (float)(d4 / this.l);
            this.pitch += (float)((this.q - this.pitch) / this.l);
            --this.l;
            this.a(d0, d2, d3);
            this.c(this.yaw, this.pitch);
        }
        else {
            if (!this.world.isStatic) {
                final ItemStack itemstack = this.b.z();
                if (this.b.dead || !this.b.J() || itemstack == null || itemstack.a() != Item.FISHING_ROD || this.g(this.b) > 1024.0) {
                    this.C();
                    this.b.hookedFish = null;
                    return;
                }
                if (this.c != null) {
                    if (!this.c.dead) {
                        this.locX = this.c.locX;
                        this.locY = this.c.boundingBox.b + this.c.width * 0.8;
                        this.locZ = this.c.locZ;
                        return;
                    }
                    this.c = null;
                }
            }
            if (this.a > 0) {
                --this.a;
            }
            if (this.h) {
                final int i = this.world.getTypeId(this.d, this.e, this.f);
                if (i == this.g) {
                    ++this.i;
                    if (this.i == 1200) {
                        this.C();
                    }
                    return;
                }
                this.h = false;
                this.motX *= this.random.nextFloat() * 0.2f;
                this.motY *= this.random.nextFloat() * 0.2f;
                this.motZ *= this.random.nextFloat() * 0.2f;
                this.i = 0;
                this.j = 0;
            }
            else {
                ++this.j;
            }
            Vec3D vec3d = Vec3D.b(this.locX, this.locY, this.locZ);
            Vec3D vec3d2 = Vec3D.b(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
            MovingObjectPosition movingobjectposition = this.world.a(vec3d, vec3d2);
            vec3d = Vec3D.b(this.locX, this.locY, this.locZ);
            vec3d2 = Vec3D.b(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
            if (movingobjectposition != null) {
                vec3d2 = Vec3D.b(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
            }
            Entity entity = null;
            final List list = this.world.b(this, this.boundingBox.a(this.motX, this.motY, this.motZ).b(1.0, 1.0, 1.0));
            double d5 = 0.0;
            for (int j = 0; j < list.size(); ++j) {
                final Entity entity2 = list.get(j);
                if (entity2.d_() && (entity2 != this.b || this.j >= 5)) {
                    final float f = 0.3f;
                    final AxisAlignedBB axisalignedbb = entity2.boundingBox.b(f, f, f);
                    final MovingObjectPosition movingobjectposition2 = axisalignedbb.a(vec3d, vec3d2);
                    if (movingobjectposition2 != null) {
                        final double d6 = vec3d.a(movingobjectposition2.f);
                        if (d6 < d5 || d5 == 0.0) {
                            entity = entity2;
                            d5 = d6;
                        }
                    }
                }
            }
            if (entity != null) {
                movingobjectposition = new MovingObjectPosition(entity);
            }
            if (movingobjectposition != null) {
                if (movingobjectposition.g != null) {
                    boolean stick;
                    if (movingobjectposition.g instanceof EntityLiving) {
                        final CraftServer server = ((WorldServer)this.world).getServer();
                        final org.bukkit.entity.Entity shooter = (this.b == null) ? null : this.b.getBukkitEntity();
                        final org.bukkit.entity.Entity damagee = movingobjectposition.g.getBukkitEntity();
                        final org.bukkit.entity.Entity projectile = this.getBukkitEntity();
                        final EntityDamageEvent.DamageCause damageCause = EntityDamageEvent.DamageCause.ENTITY_ATTACK;
                        final int damage = 0;
                        final EntityDamageByProjectileEvent event = new EntityDamageByProjectileEvent(shooter, damagee, projectile, damageCause, damage);
                        server.getPluginManager().callEvent(event);
                        if (!event.isCancelled()) {
                            stick = movingobjectposition.g.a(this.b, event.getDamage());
                        }
                        else {
                            stick = !event.getBounce();
                        }
                    }
                    else {
                        stick = movingobjectposition.g.a(this.b, 0);
                    }
                    if (!stick) {
                        this.c = movingobjectposition.g;
                    }
                }
                else {
                    this.h = true;
                }
            }
            if (!this.h) {
                this.c(this.motX, this.motY, this.motZ);
                final float f2 = MathHelper.a(this.motX * this.motX + this.motZ * this.motZ);
                this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0 / 3.1415927410125732);
                this.pitch = (float)(Math.atan2(this.motY, f2) * 180.0 / 3.1415927410125732);
                while (this.pitch - this.lastPitch < -180.0f) {
                    this.lastPitch -= 360.0f;
                }
                while (this.pitch - this.lastPitch >= 180.0f) {
                    this.lastPitch += 360.0f;
                }
                while (this.yaw - this.lastYaw < -180.0f) {
                    this.lastYaw -= 360.0f;
                }
                while (this.yaw - this.lastYaw >= 180.0f) {
                    this.lastYaw += 360.0f;
                }
                this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2f;
                this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2f;
                float f3 = 0.92f;
                if (this.onGround || this.aV) {
                    f3 = 0.5f;
                }
                final byte b0 = 5;
                double d7 = 0.0;
                for (int k = 0; k < b0; ++k) {
                    final double d8 = this.boundingBox.b + (this.boundingBox.e - this.boundingBox.b) * (k + 0) / b0 - 0.125 + 0.125;
                    final double d9 = this.boundingBox.b + (this.boundingBox.e - this.boundingBox.b) * (k + 1) / b0 - 0.125 + 0.125;
                    final AxisAlignedBB axisalignedbb2 = AxisAlignedBB.b(this.boundingBox.a, d8, this.boundingBox.c, this.boundingBox.d, d9, this.boundingBox.f);
                    if (this.world.b(axisalignedbb2, Material.WATER)) {
                        d7 += 1.0 / b0;
                    }
                }
                if (d7 > 0.0) {
                    if (this.k > 0) {
                        --this.k;
                    }
                    else if (this.random.nextInt(500) == 0) {
                        this.k = this.random.nextInt(30) + 10;
                        this.motY -= 0.20000000298023224;
                        this.world.a(this, "random.splash", 0.25f, 1.0f + (this.random.nextFloat() - this.random.nextFloat()) * 0.4f);
                        final float f4 = (float)MathHelper.b(this.boundingBox.b);
                        for (int l = 0; l < 1.0f + this.length * 20.0f; ++l) {
                            final float f5 = (this.random.nextFloat() * 2.0f - 1.0f) * this.length;
                            final float f6 = (this.random.nextFloat() * 2.0f - 1.0f) * this.length;
                            this.world.a("bubble", this.locX + f5, f4 + 1.0f, this.locZ + f6, this.motX, this.motY - this.random.nextFloat() * 0.2f, this.motZ);
                        }
                        for (int l = 0; l < 1.0f + this.length * 20.0f; ++l) {
                            final float f5 = (this.random.nextFloat() * 2.0f - 1.0f) * this.length;
                            final float f6 = (this.random.nextFloat() * 2.0f - 1.0f) * this.length;
                            this.world.a("splash", this.locX + f5, f4 + 1.0f, this.locZ + f6, this.motX, this.motY, this.motZ);
                        }
                    }
                }
                if (this.k > 0) {
                    this.motY -= this.random.nextFloat() * this.random.nextFloat() * this.random.nextFloat() * 0.2;
                }
                final double d6 = d7 * 2.0 - 1.0;
                this.motY += 0.03999999910593033 * d6;
                if (d7 > 0.0) {
                    f3 *= (float)0.9;
                    this.motY *= 0.8;
                }
                this.motX *= f3;
                this.motY *= f3;
                this.motZ *= f3;
                this.a(this.locX, this.locY, this.locZ);
            }
        }
    }
    
    public void a(final NBTTagCompound nbttagcompound) {
        nbttagcompound.a("xTile", (short)this.d);
        nbttagcompound.a("yTile", (short)this.e);
        nbttagcompound.a("zTile", (short)this.f);
        nbttagcompound.a("inTile", (byte)this.g);
        nbttagcompound.a("shake", (byte)this.a);
        nbttagcompound.a("inGround", (byte)(this.h ? 1 : 0));
    }
    
    public void b(final NBTTagCompound nbttagcompound) {
        this.d = nbttagcompound.d("xTile");
        this.e = nbttagcompound.d("yTile");
        this.f = nbttagcompound.d("zTile");
        this.g = (nbttagcompound.c("inTile") & 0xFF);
        this.a = (nbttagcompound.c("shake") & 0xFF);
        this.h = (nbttagcompound.c("inGround") == 1);
    }
    
    public int h() {
        byte b0 = 0;
        if (this.c != null) {
            final double d0 = this.b.locX - this.locX;
            final double d2 = this.b.locY - this.locY;
            final double d3 = this.b.locZ - this.locZ;
            final double d4 = MathHelper.a(d0 * d0 + d2 * d2 + d3 * d3);
            final double d5 = 0.1;
            final Entity c = this.c;
            c.motX += d0 * d5;
            final Entity c2 = this.c;
            c2.motY += d2 * d5 + MathHelper.a(d4) * 0.08;
            final Entity c3 = this.c;
            c3.motZ += d3 * d5;
            b0 = 3;
        }
        else if (this.k > 0) {
            final EntityItem entityitem = new EntityItem(this.world, this.locX, this.locY, this.locZ, new ItemStack(Item.RAW_FISH));
            final double d6 = this.b.locX - this.locX;
            final double d7 = this.b.locY - this.locY;
            final double d8 = this.b.locZ - this.locZ;
            final double d9 = MathHelper.a(d6 * d6 + d7 * d7 + d8 * d8);
            final double d10 = 0.1;
            entityitem.motX = d6 * d10;
            entityitem.motY = d7 * d10 + MathHelper.a(d9) * 0.08;
            entityitem.motZ = d8 * d10;
            this.world.a(entityitem);
            b0 = 1;
        }
        if (this.h) {
            b0 = 2;
        }
        this.C();
        this.b.hookedFish = null;
        return b0;
    }
}
