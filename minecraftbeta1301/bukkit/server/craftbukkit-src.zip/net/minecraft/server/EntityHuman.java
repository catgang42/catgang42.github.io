// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.Event;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.craftbukkit.entity.CraftItem;
import org.bukkit.entity.Player;
import java.util.List;
import org.bukkit.craftbukkit.TrigMath;

public abstract class EntityHuman extends EntityLiving
{
    public InventoryPlayer inventory;
    public Container defaultContainer;
    public Container activeContainer;
    public byte l;
    public int m;
    public float n;
    public float o;
    public boolean p;
    public int q;
    public String name;
    public int dimension;
    public double t;
    public double u;
    public double v;
    public double w;
    public double x;
    public double y;
    private boolean sleeping;
    private ChunkCoordinates b;
    private int sleepTicks;
    public float z;
    public float A;
    private int d;
    public EntityFish hookedFish;
    
    public EntityHuman(final World world) {
        super(world);
        this.inventory = new InventoryPlayer(this);
        this.l = 0;
        this.m = 0;
        this.p = false;
        this.q = 0;
        this.d = 0;
        this.hookedFish = null;
        this.defaultContainer = new ContainerPlayer(this.inventory, !world.isStatic);
        this.activeContainer = this.defaultContainer;
        this.height = 1.62f;
        final ChunkCoordinates chunkcoordinates = world.l();
        this.c(chunkcoordinates.a + 0.5, chunkcoordinates.b + 1, chunkcoordinates.c + 0.5, 0.0f, 0.0f);
        this.health = 20;
        this.P = "humanoid";
        this.O = 180.0f;
        this.maxFireTicks = 20;
        this.texture = "/mob/char.png";
    }
    
    @Override
    protected void a() {
        super.a();
        this.datawatcher.a(16, 0);
    }
    
    @Override
    public void f_() {
        if (this.E()) {
            ++this.sleepTicks;
            if (this.sleepTicks > 100) {
                this.sleepTicks = 100;
            }
            if (!this.l()) {
                this.a(true, true);
            }
            else if (!this.world.isStatic && this.world.c()) {
                this.a(false, true);
            }
        }
        else if (this.sleepTicks > 0) {
            ++this.sleepTicks;
            if (this.sleepTicks >= 110) {
                this.sleepTicks = 0;
            }
        }
        super.f_();
        if (!this.world.isStatic && this.activeContainer != null && !this.activeContainer.b(this)) {
            this.t();
            this.activeContainer = this.defaultContainer;
        }
        this.t = this.w;
        this.u = this.x;
        this.v = this.y;
        final double d0 = this.locX - this.w;
        final double d2 = this.locY - this.x;
        final double d3 = this.locZ - this.y;
        final double d4 = 10.0;
        if (d0 > d4) {
            final double locX = this.locX;
            this.w = locX;
            this.t = locX;
        }
        if (d3 > d4) {
            final double locZ = this.locZ;
            this.y = locZ;
            this.v = locZ;
        }
        if (d2 > d4) {
            final double locY = this.locY;
            this.x = locY;
            this.u = locY;
        }
        if (d0 < -d4) {
            final double locX2 = this.locX;
            this.w = locX2;
            this.t = locX2;
        }
        if (d3 < -d4) {
            final double locZ2 = this.locZ;
            this.y = locZ2;
            this.v = locZ2;
        }
        if (d2 < -d4) {
            final double locY2 = this.locY;
            this.x = locY2;
            this.u = locY2;
        }
        this.w += d0 * 0.25;
        this.y += d3 * 0.25;
        this.x += d2 * 0.25;
    }
    
    @Override
    protected boolean w() {
        return this.health <= 0 || this.E();
    }
    
    protected void t() {
        this.activeContainer = this.defaultContainer;
    }
    
    @Override
    public void x() {
        super.x();
        this.n = this.o;
        this.o = 0.0f;
    }
    
    @Override
    protected void c_() {
        if (this.p) {
            ++this.q;
            if (this.q == 8) {
                this.q = 0;
                this.p = false;
            }
        }
        else {
            this.q = 0;
        }
        this.V = this.q / 8.0f;
    }
    
    @Override
    public void q() {
        if (this.world.j == 0 && this.health < 20 && this.ticksLived % 20 * 12 == 0) {
            this.b(1);
        }
        this.inventory.e();
        this.n = this.o;
        super.q();
        float f = MathHelper.a(this.motX * this.motX + this.motZ * this.motZ);
        float f2 = (float)TrigMath.atan(-this.motY * 0.20000000298023224) * 15.0f;
        if (f > 0.1f) {
            f = 0.1f;
        }
        if (!this.onGround || this.health <= 0) {
            f = 0.0f;
        }
        if (this.onGround || this.health <= 0) {
            f2 = 0.0f;
        }
        this.o += (f - this.o) * 0.4f;
        this.ae += (f2 - this.ae) * 0.8f;
        if (this.health > 0) {
            final List list = this.world.b(this, this.boundingBox.b(1.0, 0.0, 1.0));
            if (list != null) {
                for (int i = 0; i < list.size(); ++i) {
                    final Entity entity = list.get(i);
                    if (!entity.dead) {
                        this.i(entity);
                    }
                }
            }
        }
    }
    
    private void i(final Entity entity) {
        entity.b(this);
    }
    
    @Override
    public void a(final Entity entity) {
        super.a(entity);
        this.a(0.2f, 0.2f);
        this.a(this.locX, this.locY, this.locZ);
        this.motY = 0.10000000149011612;
        if (this.name.equals("Notch")) {
            this.a(new ItemStack(Item.APPLE, 1), true);
        }
        this.inventory.g();
        if (entity != null) {
            this.motX = -MathHelper.b((this.aa + this.yaw) * 3.1415927f / 180.0f) * 0.1f;
            this.motZ = -MathHelper.a((this.aa + this.yaw) * 3.1415927f / 180.0f) * 0.1f;
        }
        else {
            final double n = 0.0;
            this.motZ = n;
            this.motX = n;
        }
        this.height = 0.1f;
    }
    
    @Override
    public void c(final Entity entity, final int i) {
        this.m += i;
    }
    
    public void y() {
        this.a(this.inventory.a(this.inventory.c, 1), false);
    }
    
    public void b(final ItemStack itemstack) {
        this.a(itemstack, false);
    }
    
    public void a(final ItemStack itemstack, final boolean flag) {
        if (itemstack != null) {
            final EntityItem entityitem = new EntityItem(this.world, this.locX, this.locY - 0.30000001192092896 + this.p(), this.locZ, itemstack);
            entityitem.c = 40;
            float f = 0.1f;
            if (flag) {
                final float f2 = this.random.nextFloat() * 0.5f;
                final float f3 = this.random.nextFloat() * 3.1415927f * 2.0f;
                entityitem.motX = -MathHelper.a(f3) * f2;
                entityitem.motZ = MathHelper.b(f3) * f2;
                entityitem.motY = 0.20000000298023224;
            }
            else {
                f = 0.3f;
                entityitem.motX = -MathHelper.a(this.yaw / 180.0f * 3.1415927f) * MathHelper.b(this.pitch / 180.0f * 3.1415927f) * f;
                entityitem.motZ = MathHelper.b(this.yaw / 180.0f * 3.1415927f) * MathHelper.b(this.pitch / 180.0f * 3.1415927f) * f;
                entityitem.motY = -MathHelper.a(this.pitch / 180.0f * 3.1415927f) * f + 0.1f;
                f = 0.02f;
                final float f2 = this.random.nextFloat() * 3.1415927f * 2.0f;
                f *= this.random.nextFloat();
                final EntityItem entityItem = entityitem;
                entityItem.motX += Math.cos(f2) * f;
                final EntityItem entityItem2 = entityitem;
                entityItem2.motY += (this.random.nextFloat() - this.random.nextFloat()) * 0.1f;
                final EntityItem entityItem3 = entityitem;
                entityItem3.motZ += Math.sin(f2) * f;
            }
            final Player player = (Player)this.getBukkitEntity();
            final CraftServer server = ((WorldServer)this.world).getServer();
            final CraftItem drop = new CraftItem(server, entityitem);
            final PlayerDropItemEvent event = new PlayerDropItemEvent(player, drop);
            server.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                final org.bukkit.inventory.ItemStack stack = drop.getItemStack();
                stack.setAmount(1);
                player.getInventory().addItem(stack);
                return;
            }
            this.a(entityitem);
        }
    }
    
    protected void a(final EntityItem entityitem) {
        this.world.a(entityitem);
    }
    
    public float a(final Block block) {
        float f = this.inventory.a(block);
        if (this.a(Material.WATER)) {
            f /= 5.0f;
        }
        if (!this.onGround) {
            f /= 5.0f;
        }
        return f;
    }
    
    public boolean b(final Block block) {
        return this.inventory.b(block);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
        final NBTTagList nbttaglist = nbttagcompound.l("Inventory");
        this.inventory.b(nbttaglist);
        this.dimension = nbttagcompound.e("Dimension");
        this.sleeping = nbttagcompound.m("Sleeping");
        this.sleepTicks = nbttagcompound.d("SleepTimer");
        if (this.sleeping) {
            this.b = new ChunkCoordinates(MathHelper.b(this.locX), MathHelper.b(this.locY), MathHelper.b(this.locZ));
            this.a(true, true);
        }
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
        nbttagcompound.a("Inventory", this.inventory.a(new NBTTagList()));
        nbttagcompound.a("Dimension", this.dimension);
        nbttagcompound.a("Sleeping", this.sleeping);
        nbttagcompound.a("SleepTimer", (short)this.sleepTicks);
    }
    
    public void a(final IInventory iinventory) {
    }
    
    public void b(final int i, final int j, final int k) {
    }
    
    public void b(final Entity entity, final int i) {
    }
    
    @Override
    public float p() {
        return 0.12f;
    }
    
    protected void l_() {
        this.height = 1.62f;
    }
    
    @Override
    public boolean a(final Entity entity, int i) {
        this.at = 0;
        if (this.health <= 0) {
            return false;
        }
        if (this.E()) {
            this.a(true, true);
        }
        if (entity instanceof EntityMonster || entity instanceof EntityArrow) {
            if (this.world.j == 0) {
                i = 0;
            }
            if (this.world.j == 1) {
                i = i / 3 + 1;
            }
            if (this.world.j == 3) {
                i = i * 3 / 2;
            }
        }
        if (entity instanceof EntityLiving) {
            final CraftServer server = ((WorldServer)this.world).getServer();
            final org.bukkit.entity.Entity damager = entity.getBukkitEntity();
            final org.bukkit.entity.Entity damagee = this.getBukkitEntity();
            final EntityDamageEvent.DamageCause damageType = EntityDamageEvent.DamageCause.ENTITY_ATTACK;
            final EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(damager, damagee, damageType, i);
            server.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                return false;
            }
        }
        return i != 0 && super.a(entity, i);
    }
    
    @Override
    protected void c(int i) {
        final int j = 25 - this.inventory.f();
        final int k = i * j + this.d;
        this.inventory.c(i);
        i = k / 25;
        this.d = k % 25;
        super.c(i);
    }
    
    public void a(final TileEntityFurnace tileentityfurnace) {
    }
    
    public void a(final TileEntityDispenser tileentitydispenser) {
    }
    
    public void a(final TileEntitySign tileentitysign) {
    }
    
    public void c(final Entity entity) {
        if (!entity.a(this)) {
            final ItemStack itemstack = this.z();
            if (itemstack != null && entity instanceof EntityLiving) {
                itemstack.b((EntityLiving)entity);
                if (itemstack.count <= 0) {
                    itemstack.a(this);
                    this.A();
                }
            }
        }
    }
    
    public ItemStack z() {
        return this.inventory.b();
    }
    
    public void A() {
        this.inventory.a(this.inventory.c, null);
    }
    
    @Override
    public double B() {
        return this.height - 0.5f;
    }
    
    public void r() {
        this.q = -1;
        this.p = true;
    }
    
    public void d(final Entity entity) {
        int i = this.inventory.a(entity);
        if (i > 0) {
            if (entity instanceof EntityLiving) {
                final CraftServer server = ((WorldServer)this.world).getServer();
                final org.bukkit.entity.Entity damager = this.getBukkitEntity();
                final org.bukkit.entity.Entity damagee = (entity == null) ? null : entity.getBukkitEntity();
                final EntityDamageEvent.DamageCause damageType = EntityDamageEvent.DamageCause.ENTITY_ATTACK;
                final EntityDamageByEntityEvent event = new EntityDamageByEntityEvent(damager, damagee, damageType, i);
                server.getPluginManager().callEvent(event);
                if (event.isCancelled()) {
                    return;
                }
                i = event.getDamage();
            }
            entity.a(this, i);
            final ItemStack itemstack = this.z();
            if (itemstack != null && entity instanceof EntityLiving) {
                itemstack.a((EntityLiving)entity);
                if (itemstack.count <= 0) {
                    itemstack.a(this);
                    this.A();
                }
            }
        }
    }
    
    public void a(final ItemStack itemstack) {
    }
    
    @Override
    public void C() {
        super.C();
        this.defaultContainer.a(this);
        if (this.activeContainer != null) {
            this.activeContainer.a(this);
        }
    }
    
    @Override
    public boolean D() {
        return !this.sleeping && super.D();
    }
    
    public boolean a(final int i, final int j, final int k) {
        if (this.E() || !this.J()) {
            return false;
        }
        if (this.world.m.c) {
            return false;
        }
        if (this.world.c()) {
            return false;
        }
        if (Math.abs(this.locX - i) <= 3.0 && Math.abs(this.locY - j) <= 2.0 && Math.abs(this.locZ - k) <= 3.0) {
            this.a(0.2f, 0.2f);
            this.height = 0.2f;
            if (this.world.f(i, j, k)) {
                final int l = this.world.getData(i, j, k);
                final int i2 = BlockBed.c(l);
                float f = 0.5f;
                float f2 = 0.5f;
                switch (i2) {
                    case 0: {
                        f2 = 0.9f;
                        break;
                    }
                    case 1: {
                        f = 0.1f;
                        break;
                    }
                    case 2: {
                        f2 = 0.1f;
                        break;
                    }
                    case 3: {
                        f = 0.9f;
                        break;
                    }
                }
                this.e(i2);
                this.a(i + f, j + 0.9375f, (double)(k + f2));
            }
            else {
                this.a(i + 0.5f, j + 0.9375f, (double)(k + 0.5f));
            }
            this.sleeping = true;
            this.sleepTicks = 0;
            this.b = new ChunkCoordinates(i, j, k);
            final double motX = 0.0;
            this.motY = motX;
            this.motZ = motX;
            this.motX = motX;
            if (!this.world.isStatic) {
                this.world.o();
            }
            return true;
        }
        return false;
    }
    
    private void e(final int i) {
        this.z = 0.0f;
        this.A = 0.0f;
        switch (i) {
            case 0: {
                this.A = -1.8f;
                break;
            }
            case 1: {
                this.z = 1.8f;
                break;
            }
            case 2: {
                this.A = 1.8f;
                break;
            }
            case 3: {
                this.z = -1.8f;
                break;
            }
        }
    }
    
    public void a(final boolean flag, final boolean flag1) {
        this.a(0.6f, 1.8f);
        this.l_();
        final ChunkCoordinates chunkcoordinates = this.b;
        if (chunkcoordinates != null && this.world.getTypeId(chunkcoordinates.a, chunkcoordinates.b, chunkcoordinates.c) == Block.BED.id) {
            BlockBed.a(this.world, chunkcoordinates.a, chunkcoordinates.b, chunkcoordinates.c, false);
            final ChunkCoordinates chunkcoordinates2 = BlockBed.g(this.world, chunkcoordinates.a, chunkcoordinates.b, chunkcoordinates.c, 0);
            this.a(chunkcoordinates2.a + 0.5f, chunkcoordinates2.b + this.height + 0.1f, (double)(chunkcoordinates2.c + 0.5f));
        }
        this.sleeping = false;
        if (!this.world.isStatic && flag1) {
            this.world.o();
        }
        if (flag) {
            this.sleepTicks = 0;
        }
        else {
            this.sleepTicks = 100;
        }
    }
    
    private boolean l() {
        return this.world.getTypeId(this.b.a, this.b.b, this.b.c) == Block.BED.id;
    }
    
    @Override
    public boolean E() {
        return this.sleeping;
    }
    
    public boolean F() {
        return this.sleeping && this.sleepTicks >= 100;
    }
    
    public void a(final String s) {
    }
}
