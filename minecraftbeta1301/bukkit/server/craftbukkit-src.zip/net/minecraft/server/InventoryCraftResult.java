// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class InventoryCraftResult implements IInventory
{
    private ItemStack[] a;
    
    public ItemStack[] getContents() {
        return this.a;
    }
    
    public InventoryCraftResult() {
        this.a = new ItemStack[1];
    }
    
    public int m_() {
        return 1;
    }
    
    public ItemStack c_(final int i) {
        return this.a[i];
    }
    
    public String c() {
        return "Result";
    }
    
    public ItemStack a(final int i, final int j) {
        if (this.a[i] != null) {
            final ItemStack itemstack = this.a[i];
            this.a[i] = null;
            return itemstack;
        }
        return null;
    }
    
    public void a(final int i, final ItemStack itemstack) {
        this.a[i] = itemstack;
    }
    
    public int n_() {
        return 64;
    }
    
    public void h() {
    }
    
    public boolean a_(final EntityHuman entityhuman) {
        return true;
    }
}
