// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemTool extends Item
{
    private Block[] bi;
    private float bj;
    private int bk;
    protected EnumToolMaterial a;
    
    protected ItemTool(final int n, final int n2, final EnumToolMaterial a, final Block[] bi) {
        super(n);
        this.bj = 4.0f;
        this.a = a;
        this.bi = bi;
        this.maxStackSize = 1;
        this.durability = a.a();
        this.bj = a.b();
        this.bk = n2 + a.c();
    }
    
    @Override
    public float a(final ItemStack itemStack, final Block block) {
        for (int i = 0; i < this.bi.length; ++i) {
            if (this.bi[i] == block) {
                return this.bj;
            }
        }
        return 1.0f;
    }
    
    @Override
    public void a(final ItemStack itemStack, final EntityLiving entityLiving) {
        itemStack.b(2);
    }
    
    @Override
    public void a(final ItemStack itemStack, final int n, final int n2, final int n3, final int n4) {
        itemStack.b(1);
    }
    
    @Override
    public int a(final Entity entity) {
        return this.bk;
    }
}
