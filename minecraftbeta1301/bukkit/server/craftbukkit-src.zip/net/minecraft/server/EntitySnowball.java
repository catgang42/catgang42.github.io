// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import java.util.List;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageByProjectileEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class EntitySnowball extends Entity
{
    private int b;
    private int c;
    private int d;
    private int e;
    private boolean f;
    public int a;
    private EntityLiving g;
    private int h;
    private int i;
    
    public EntitySnowball(final World world) {
        super(world);
        this.b = -1;
        this.c = -1;
        this.d = -1;
        this.e = 0;
        this.f = false;
        this.a = 0;
        this.i = 0;
        this.a(0.25f, 0.25f);
    }
    
    @Override
    protected void a() {
    }
    
    public EntitySnowball(final World world, final EntityLiving entityliving) {
        super(world);
        this.b = -1;
        this.c = -1;
        this.d = -1;
        this.e = 0;
        this.f = false;
        this.a = 0;
        this.i = 0;
        this.g = entityliving;
        this.a(0.25f, 0.25f);
        this.c(entityliving.locX, entityliving.locY + entityliving.p(), entityliving.locZ, entityliving.yaw, entityliving.pitch);
        this.locX -= MathHelper.b(this.yaw / 180.0f * 3.1415927f) * 0.16f;
        this.locY -= 0.10000000149011612;
        this.locZ -= MathHelper.a(this.yaw / 180.0f * 3.1415927f) * 0.16f;
        this.a(this.locX, this.locY, this.locZ);
        this.height = 0.0f;
        final float f = 0.4f;
        this.motX = -MathHelper.a(this.yaw / 180.0f * 3.1415927f) * MathHelper.b(this.pitch / 180.0f * 3.1415927f) * f;
        this.motZ = MathHelper.b(this.yaw / 180.0f * 3.1415927f) * MathHelper.b(this.pitch / 180.0f * 3.1415927f) * f;
        this.motY = -MathHelper.a(this.pitch / 180.0f * 3.1415927f) * f;
        this.a(this.motX, this.motY, this.motZ, 1.5f, 1.0f);
    }
    
    public EntitySnowball(final World world, final double d0, final double d1, final double d2) {
        super(world);
        this.b = -1;
        this.c = -1;
        this.d = -1;
        this.e = 0;
        this.f = false;
        this.a = 0;
        this.i = 0;
        this.h = 0;
        this.a(0.25f, 0.25f);
        this.a(d0, d1, d2);
        this.height = 0.0f;
    }
    
    public void a(double d0, double d1, double d2, final float f, final float f1) {
        final float f2 = MathHelper.a(d0 * d0 + d1 * d1 + d2 * d2);
        d0 /= f2;
        d1 /= f2;
        d2 /= f2;
        d0 += this.random.nextGaussian() * 0.007499999832361937 * f1;
        d1 += this.random.nextGaussian() * 0.007499999832361937 * f1;
        d2 += this.random.nextGaussian() * 0.007499999832361937 * f1;
        d0 *= f;
        d1 *= f;
        d2 *= f;
        this.motX = d0;
        this.motY = d1;
        this.motZ = d2;
        final float f3 = MathHelper.a(d0 * d0 + d2 * d2);
        final float n = (float)(Math.atan2(d0, d2) * 180.0 / 3.1415927410125732);
        this.yaw = n;
        this.lastYaw = n;
        final float n2 = (float)(Math.atan2(d1, f3) * 180.0 / 3.1415927410125732);
        this.pitch = n2;
        this.lastPitch = n2;
        this.h = 0;
    }
    
    @Override
    public void f_() {
        this.bi = this.locX;
        this.bj = this.locY;
        this.bk = this.locZ;
        super.f_();
        if (this.a > 0) {
            --this.a;
        }
        if (this.f) {
            final int i = this.world.getTypeId(this.b, this.c, this.d);
            if (i == this.e) {
                ++this.h;
                if (this.h == 1200) {
                    this.C();
                }
                return;
            }
            this.f = false;
            this.motX *= this.random.nextFloat() * 0.2f;
            this.motY *= this.random.nextFloat() * 0.2f;
            this.motZ *= this.random.nextFloat() * 0.2f;
            this.h = 0;
            this.i = 0;
        }
        else {
            ++this.i;
        }
        Vec3D vec3d = Vec3D.b(this.locX, this.locY, this.locZ);
        Vec3D vec3d2 = Vec3D.b(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
        MovingObjectPosition movingobjectposition = this.world.a(vec3d, vec3d2);
        vec3d = Vec3D.b(this.locX, this.locY, this.locZ);
        vec3d2 = Vec3D.b(this.locX + this.motX, this.locY + this.motY, this.locZ + this.motZ);
        if (movingobjectposition != null) {
            vec3d2 = Vec3D.b(movingobjectposition.f.a, movingobjectposition.f.b, movingobjectposition.f.c);
        }
        if (!this.world.isStatic) {
            Entity entity = null;
            final List list = this.world.b(this, this.boundingBox.a(this.motX, this.motY, this.motZ).b(1.0, 1.0, 1.0));
            double d0 = 0.0;
            for (int j = 0; j < list.size(); ++j) {
                final Entity entity2 = list.get(j);
                if (entity2.d_() && (entity2 != this.g || this.i >= 5)) {
                    final float f = 0.3f;
                    final AxisAlignedBB axisalignedbb = entity2.boundingBox.b(f, f, f);
                    final MovingObjectPosition movingobjectposition2 = axisalignedbb.a(vec3d, vec3d2);
                    if (movingobjectposition2 != null) {
                        final double d2 = vec3d.a(movingobjectposition2.f);
                        if (d2 < d0 || d0 == 0.0) {
                            entity = entity2;
                            d0 = d2;
                        }
                    }
                }
            }
            if (entity != null) {
                movingobjectposition = new MovingObjectPosition(entity);
            }
        }
        if (movingobjectposition != null) {
            if (movingobjectposition.g != null) {
                boolean stick;
                if (movingobjectposition.g instanceof EntityLiving) {
                    final CraftServer server = ((WorldServer)this.world).getServer();
                    final org.bukkit.entity.Entity shooter = (this.g == null) ? null : this.g.getBukkitEntity();
                    final org.bukkit.entity.Entity damagee = movingobjectposition.g.getBukkitEntity();
                    final org.bukkit.entity.Entity projectile = this.getBukkitEntity();
                    final EntityDamageEvent.DamageCause damageCause = EntityDamageEvent.DamageCause.ENTITY_ATTACK;
                    final int damage = 0;
                    final EntityDamageByProjectileEvent event = new EntityDamageByProjectileEvent(shooter, damagee, projectile, damageCause, damage);
                    server.getPluginManager().callEvent(event);
                    if (!event.isCancelled()) {
                        stick = movingobjectposition.g.a(this.g, event.getDamage());
                    }
                    else {
                        stick = !event.getBounce();
                    }
                }
                else {
                    stick = movingobjectposition.g.a(this.g, 0);
                }
                if (stick) {}
            }
            for (int k = 0; k < 8; ++k) {
                this.world.a("snowballpoof", this.locX, this.locY, this.locZ, 0.0, 0.0, 0.0);
            }
            this.C();
        }
        this.locX += this.motX;
        this.locY += this.motY;
        this.locZ += this.motZ;
        final float f2 = MathHelper.a(this.motX * this.motX + this.motZ * this.motZ);
        this.yaw = (float)(Math.atan2(this.motX, this.motZ) * 180.0 / 3.1415927410125732);
        this.pitch = (float)(Math.atan2(this.motY, f2) * 180.0 / 3.1415927410125732);
        while (this.pitch - this.lastPitch < -180.0f) {
            this.lastPitch -= 360.0f;
        }
        while (this.pitch - this.lastPitch >= 180.0f) {
            this.lastPitch += 360.0f;
        }
        while (this.yaw - this.lastYaw < -180.0f) {
            this.lastYaw -= 360.0f;
        }
        while (this.yaw - this.lastYaw >= 180.0f) {
            this.lastYaw += 360.0f;
        }
        this.pitch = this.lastPitch + (this.pitch - this.lastPitch) * 0.2f;
        this.yaw = this.lastYaw + (this.yaw - this.lastYaw) * 0.2f;
        float f3 = 0.99f;
        final float f4 = 0.03f;
        if (this.g_()) {
            for (int l = 0; l < 4; ++l) {
                final float f5 = 0.25f;
                this.world.a("bubble", this.locX - this.motX * f5, this.locY - this.motY * f5, this.locZ - this.motZ * f5, this.motX, this.motY, this.motZ);
            }
            f3 = 0.8f;
        }
        this.motX *= f3;
        this.motY *= f3;
        this.motZ *= f3;
        this.motY -= f4;
        this.a(this.locX, this.locY, this.locZ);
    }
    
    public void a(final NBTTagCompound nbttagcompound) {
        nbttagcompound.a("xTile", (short)this.b);
        nbttagcompound.a("yTile", (short)this.c);
        nbttagcompound.a("zTile", (short)this.d);
        nbttagcompound.a("inTile", (byte)this.e);
        nbttagcompound.a("shake", (byte)this.a);
        nbttagcompound.a("inGround", (byte)(this.f ? 1 : 0));
    }
    
    public void b(final NBTTagCompound nbttagcompound) {
        this.b = nbttagcompound.d("xTile");
        this.c = nbttagcompound.d("yTile");
        this.d = nbttagcompound.d("zTile");
        this.e = (nbttagcompound.c("inTile") & 0xFF);
        this.a = (nbttagcompound.c("shake") & 0xFF);
        this.f = (nbttagcompound.c("inGround") == 1);
    }
    
    @Override
    public void b(final EntityHuman entityhuman) {
        if (this.f && this.g == entityhuman && this.a <= 0 && entityhuman.inventory.a(new ItemStack(Item.ARROW, 1))) {
            this.world.a(this, "random.pop", 0.2f, ((this.random.nextFloat() - this.random.nextFloat()) * 0.7f + 1.0f) * 2.0f);
            entityhuman.b(this, 1);
            this.C();
        }
    }
}
