// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class Pathfinder
{
    private IBlockAccess a;
    private Path b;
    private EntityList c;
    private PathPoint[] d;
    
    public Pathfinder(final IBlockAccess a) {
        this.b = new Path();
        this.c = new EntityList();
        this.d = new PathPoint[32];
        this.a = a;
    }
    
    public PathEntity a(final Entity entity, final Entity entity2, final float n) {
        return this.a(entity, entity2.locX, entity2.boundingBox.b, entity2.locZ, n);
    }
    
    public PathEntity a(final Entity entity, final int n, final int n2, final int n3, final float n4) {
        return this.a(entity, n + 0.5f, n2 + 0.5f, n3 + 0.5f, n4);
    }
    
    private PathEntity a(final Entity entity, final double n, final double n2, final double n3, final float n4) {
        this.b.a();
        this.c.a();
        return this.a(entity, this.a(MathHelper.b(entity.boundingBox.a), MathHelper.b(entity.boundingBox.b), MathHelper.b(entity.boundingBox.c)), this.a(MathHelper.b(n - entity.length / 2.0f), MathHelper.b(n2), MathHelper.b(n3 - entity.length / 2.0f)), new PathPoint(MathHelper.d(entity.length + 1.0f), MathHelper.d(entity.width + 1.0f), MathHelper.d(entity.length + 1.0f)), n4);
    }
    
    private PathEntity a(final Entity entity, final PathPoint pathPoint, final PathPoint pathPoint2, final PathPoint pathPoint3, final float n) {
        pathPoint.e = 0.0f;
        pathPoint.f = pathPoint.a(pathPoint2);
        pathPoint.g = pathPoint.f;
        this.b.a();
        this.b.a(pathPoint);
        PathPoint pathPoint4 = pathPoint;
        while (!this.b.c()) {
            final PathPoint b = this.b.b();
            if (b.equals(pathPoint2)) {
                return this.a(pathPoint, pathPoint2);
            }
            if (b.a(pathPoint2) < pathPoint4.a(pathPoint2)) {
                pathPoint4 = b;
            }
            b.i = true;
            for (int b2 = this.b(entity, b, pathPoint3, pathPoint2, n), i = 0; i < b2; ++i) {
                final PathPoint pathPoint5 = this.d[i];
                final float e = b.e + b.a(pathPoint5);
                if (!pathPoint5.a() || e < pathPoint5.e) {
                    pathPoint5.h = b;
                    pathPoint5.e = e;
                    pathPoint5.f = pathPoint5.a(pathPoint2);
                    if (pathPoint5.a()) {
                        this.b.a(pathPoint5, pathPoint5.e + pathPoint5.f);
                    }
                    else {
                        pathPoint5.g = pathPoint5.e + pathPoint5.f;
                        this.b.a(pathPoint5);
                    }
                }
            }
        }
        if (pathPoint4 == pathPoint) {
            return null;
        }
        return this.a(pathPoint, pathPoint4);
    }
    
    private int b(final Entity entity, final PathPoint pathPoint, final PathPoint pathPoint2, final PathPoint pathPoint3, final float n) {
        int n2 = 0;
        int n3 = 0;
        if (this.a(entity, pathPoint.a, pathPoint.b + 1, pathPoint.c, pathPoint2) > 0) {
            n3 = 1;
        }
        final PathPoint a = this.a(entity, pathPoint.a, pathPoint.b, pathPoint.c + 1, pathPoint2, n3);
        final PathPoint a2 = this.a(entity, pathPoint.a - 1, pathPoint.b, pathPoint.c, pathPoint2, n3);
        final PathPoint a3 = this.a(entity, pathPoint.a + 1, pathPoint.b, pathPoint.c, pathPoint2, n3);
        final PathPoint a4 = this.a(entity, pathPoint.a, pathPoint.b, pathPoint.c - 1, pathPoint2, n3);
        if (a != null && !a.i && a.a(pathPoint3) < n) {
            this.d[n2++] = a;
        }
        if (a2 != null && !a2.i && a2.a(pathPoint3) < n) {
            this.d[n2++] = a2;
        }
        if (a3 != null && !a3.i && a3.a(pathPoint3) < n) {
            this.d[n2++] = a3;
        }
        if (a4 != null && !a4.i && a4.a(pathPoint3) < n) {
            this.d[n2++] = a4;
        }
        return n2;
    }
    
    private PathPoint a(final Entity entity, final int n, int n2, final int n3, final PathPoint pathPoint, final int n4) {
        PathPoint pathPoint2 = null;
        if (this.a(entity, n, n2, n3, pathPoint) > 0) {
            pathPoint2 = this.a(n, n2, n3);
        }
        if (pathPoint2 == null && n4 > 0 && this.a(entity, n, n2 + n4, n3, pathPoint) > 0) {
            pathPoint2 = this.a(n, n2 + n4, n3);
            n2 += n4;
        }
        if (pathPoint2 != null) {
            int n5 = 0;
            int a;
            while (n2 > 0 && (a = this.a(entity, n, n2 - 1, n3, pathPoint)) > 0) {
                if (a < 0) {
                    return null;
                }
                if (++n5 >= 4) {
                    return null;
                }
                --n2;
            }
            if (n2 > 0) {
                pathPoint2 = this.a(n, n2, n3);
            }
        }
        return pathPoint2;
    }
    
    private final PathPoint a(final int n, final int n2, final int n3) {
        final int a = PathPoint.a(n, n2, n3);
        PathPoint pathPoint = (PathPoint)this.c.a(a);
        if (pathPoint == null) {
            pathPoint = new PathPoint(n, n2, n3);
            this.c.a(a, pathPoint);
        }
        return pathPoint;
    }
    
    private int a(final Entity entity, final int n, final int n2, final int n3, final PathPoint pathPoint) {
        for (int i = n; i < n + pathPoint.a; ++i) {
            for (int j = n2; j < n2 + pathPoint.b; ++j) {
                for (int k = n3; k < n3 + pathPoint.c; ++k) {
                    final Material material = this.a.getMaterial(i, j, k);
                    if (material.isSolid()) {
                        return 0;
                    }
                    if (material == Material.WATER || material == Material.LAVA) {
                        return -1;
                    }
                }
            }
        }
        return 1;
    }
    
    private PathEntity a(final PathPoint pathPoint, final PathPoint pathPoint2) {
        int n = 1;
        for (PathPoint h = pathPoint2; h.h != null; h = h.h) {
            ++n;
        }
        final PathPoint[] array = new PathPoint[n];
        PathPoint h2 = pathPoint2;
        array[--n] = h2;
        while (h2.h != null) {
            h2 = h2.h;
            array[--n] = h2;
        }
        return new PathEntity(array);
    }
}
