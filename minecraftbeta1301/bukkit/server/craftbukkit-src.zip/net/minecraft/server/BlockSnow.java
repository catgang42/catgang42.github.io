// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockSnow extends Block
{
    protected BlockSnow(final int n, final int n2) {
        super(n, n2, Material.SNOW_LAYER);
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.125f, 1.0f);
        this.a(true);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3) {
        final int typeId = world.getTypeId(n, n2 - 1, n3);
        return typeId != 0 && Block.byId[typeId].a() && world.getMaterial(n, n2 - 1, n3).isSolid();
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        this.g(world, n, n2, n3);
    }
    
    private boolean g(final World world, final int n, final int n2, final int n3) {
        if (!this.a(world, n, n2, n3)) {
            this.b_(world, n, n2, n3, world.getData(n, n2, n3));
            world.e(n, n2, n3, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public void a_(final World world, final int i, final int j, final int k, final int n) {
        final int id = Item.SNOW_BALL.id;
        final float n2 = 0.7f;
        final EntityItem entity = new EntityItem(world, i + (world.k.nextFloat() * n2 + (1.0f - n2) * 0.5), j + (world.k.nextFloat() * n2 + (1.0f - n2) * 0.5), k + (world.k.nextFloat() * n2 + (1.0f - n2) * 0.5), new ItemStack(id, 1, 0));
        entity.c = 10;
        world.a(entity);
        world.e(i, j, k, 0);
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Item.SNOW_BALL.id;
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (world.a(EnumSkyBlock.BLOCK, i, j, k) > 11) {
            this.b_(world, i, j, k, world.getData(i, j, k));
            world.e(i, j, k, 0);
        }
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        final Material material = blockAccess.getMaterial(n, n2, n3);
        return n4 == 1 || (material != this.material && super.a(blockAccess, n, n2, n3, n4));
    }
}
