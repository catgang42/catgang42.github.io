// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ContainerDispenser extends Container
{
    private TileEntityDispenser a;
    
    public ContainerDispenser(final IInventory inventory, final TileEntityDispenser tileEntityDispenser) {
        this.a = tileEntityDispenser;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                this.a(new Slot(tileEntityDispenser, j + i * 3, 61 + j * 18, 17 + i * 18));
            }
        }
        for (int k = 0; k < 3; ++k) {
            for (int l = 0; l < 9; ++l) {
                this.a(new Slot(inventory, l + k * 9 + 9, 8 + l * 18, 84 + k * 18));
            }
        }
        for (int m = 0; m < 9; ++m) {
            this.a(new Slot(inventory, m, 8 + m * 18, 142));
        }
    }
    
    @Override
    public boolean b(final EntityHuman entityhuman) {
        return this.a.a_(entityhuman);
    }
}
