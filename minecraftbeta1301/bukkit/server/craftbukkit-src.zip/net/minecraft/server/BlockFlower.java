// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockFlower extends Block
{
    protected BlockFlower(final int n, final int textureId) {
        super(n, Material.PLANT);
        this.textureId = textureId;
        this.a(true);
        final float n2 = 0.2f;
        this.a(0.5f - n2, 0.0f, 0.5f - n2, 0.5f + n2, n2 * 3.0f, 0.5f + n2);
    }
    
    @Override
    public boolean a(final World world, final int i, final int n, final int k) {
        return this.c(world.getTypeId(i, n - 1, k));
    }
    
    protected boolean c(final int n) {
        return n == Block.GRASS.id || n == Block.DIRT.id || n == Block.SOIL.id;
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        super.a(world, n, n2, n3, n4);
        this.g(world, n, n2, n3);
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Random random) {
        this.g(world, n, n2, n3);
    }
    
    protected final void g(final World world, final int n, final int n2, final int n3) {
        if (!this.f(world, n, n2, n3)) {
            this.b_(world, n, n2, n3, world.getData(n, n2, n3));
            world.e(n, n2, n3, 0);
        }
    }
    
    @Override
    public boolean f(final World world, final int i, final int n, final int k) {
        return (world.j(i, n, k) >= 8 || world.i(i, n, k)) && this.c(world.getTypeId(i, n - 1, k));
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public boolean a() {
        return false;
    }
}
