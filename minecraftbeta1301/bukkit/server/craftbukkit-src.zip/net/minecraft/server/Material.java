// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class Material
{
    public static final Material AIR;
    public static final Material EARTH;
    public static final Material WOOD;
    public static final Material STONE;
    public static final Material ORE;
    public static final Material WATER;
    public static final Material LAVA;
    public static final Material LEAVES;
    public static final Material PLANT;
    public static final Material SPONGE;
    public static final Material CLOTH;
    public static final Material FIRE;
    public static final Material SAND;
    public static final Material ORIENTABLE;
    public static final Material SHATTERABLE;
    public static final Material TNT;
    public static final Material CORAL;
    public static final Material ICE;
    public static final Material SNOW_LAYER;
    public static final Material SNOW_BLOCK;
    public static final Material CACTUS;
    public static final Material CLAY;
    public static final Material PUMPKIN;
    public static final Material PORTAL;
    public static final Material CAKE;
    private boolean canBurn;
    
    public boolean isLiquid() {
        return false;
    }
    
    public boolean isBuildable() {
        return true;
    }
    
    public boolean blocksLight() {
        return true;
    }
    
    public boolean isSolid() {
        return true;
    }
    
    private Material f() {
        this.canBurn = true;
        return this;
    }
    
    public boolean isBurnable() {
        return this.canBurn;
    }
    
    static {
        AIR = new MaterialTransparent();
        EARTH = new Material();
        WOOD = new Material().f();
        STONE = new Material();
        ORE = new Material();
        WATER = new MaterialLiquid();
        LAVA = new MaterialLiquid();
        LEAVES = new Material().f();
        PLANT = new MaterialLogic();
        SPONGE = new Material();
        CLOTH = new Material().f();
        FIRE = new MaterialTransparent();
        SAND = new Material();
        ORIENTABLE = new MaterialLogic();
        SHATTERABLE = new Material();
        TNT = new Material().f();
        CORAL = new Material();
        ICE = new Material();
        SNOW_LAYER = new MaterialLogic();
        SNOW_BLOCK = new Material();
        CACTUS = new Material();
        CLAY = new Material();
        PUMPKIN = new Material();
        PORTAL = new Material();
        CAKE = new Material();
    }
}
