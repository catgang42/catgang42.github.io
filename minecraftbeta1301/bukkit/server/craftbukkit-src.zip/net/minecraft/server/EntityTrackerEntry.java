// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Iterator;
import java.util.List;
import java.util.HashSet;
import java.util.Set;

public class EntityTrackerEntry
{
    public Entity a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public int h;
    public double i;
    public double j;
    public double k;
    public int l;
    private double o;
    private double p;
    private double q;
    private boolean r;
    private boolean s;
    public boolean m;
    public Set n;
    
    public EntityTrackerEntry(final Entity entity, final int i, final int j, final boolean flag) {
        this.l = 0;
        this.r = false;
        this.m = false;
        this.n = new HashSet();
        this.a = entity;
        this.b = i;
        this.c = j;
        this.s = flag;
        this.d = MathHelper.b(entity.locX * 32.0);
        this.e = MathHelper.b(entity.locY * 32.0);
        this.f = MathHelper.b(entity.locZ * 32.0);
        this.g = MathHelper.d(entity.yaw * 256.0f / 360.0f);
        this.h = MathHelper.d(entity.pitch * 256.0f / 360.0f);
    }
    
    @Override
    public boolean equals(final Object object) {
        return object instanceof EntityTrackerEntry && ((EntityTrackerEntry)object).a.id == this.a.id;
    }
    
    @Override
    public int hashCode() {
        return this.a.id;
    }
    
    public void a(final List list) {
        this.m = false;
        if (!this.r || this.a.d(this.o, this.p, this.q) > 16.0) {
            this.o = this.a.locX;
            this.p = this.a.locY;
            this.q = this.a.locZ;
            this.r = true;
            this.m = true;
            this.b(list);
        }
        if (++this.l % this.c == 0) {
            final int i = MathHelper.b(this.a.locX * 32.0);
            final int j = MathHelper.b(this.a.locY * 32.0);
            final int k = MathHelper.b(this.a.locZ * 32.0);
            final int l = MathHelper.d(this.a.yaw * 256.0f / 360.0f);
            final int i2 = MathHelper.d(this.a.pitch * 256.0f / 360.0f);
            final int j2 = i - this.d;
            final int k2 = j - this.e;
            final int l2 = k - this.f;
            Object object = null;
            final boolean flag = Math.abs(i) >= 8 || Math.abs(j) >= 8 || Math.abs(k) >= 8;
            final boolean flag2 = Math.abs(l - this.g) >= 8 || Math.abs(i2 - this.h) >= 8;
            if (j2 >= -128 && j2 < 128 && k2 >= -128 && k2 < 128 && l2 >= -128 && l2 < 128) {
                if (flag && flag2) {
                    object = new Packet33RelEntityMoveLook(this.a.id, (byte)j2, (byte)k2, (byte)l2, (byte)l, (byte)i2);
                }
                else if (flag) {
                    object = new Packet31RelEntityMove(this.a.id, (byte)j2, (byte)k2, (byte)l2);
                }
                else if (flag2) {
                    object = new Packet32EntityLook(this.a.id, (byte)l, (byte)i2);
                }
            }
            else {
                object = new Packet34EntityTeleport(this.a.id, i, j, k, (byte)l, (byte)i2);
            }
            if (this.s) {
                final double d0 = this.a.motX - this.i;
                final double d2 = this.a.motY - this.j;
                final double d3 = this.a.motZ - this.k;
                final double d4 = 0.02;
                final double d5 = d0 * d0 + d2 * d2 + d3 * d3;
                if (d5 > d4 * d4 || (d5 > 0.0 && this.a.motX == 0.0 && this.a.motY == 0.0 && this.a.motZ == 0.0)) {
                    this.i = this.a.motX;
                    this.j = this.a.motY;
                    this.k = this.a.motZ;
                    this.a(new Packet28EntityVelocity(this.a.id, this.i, this.j, this.k));
                }
            }
            if (object != null) {
                this.a((Packet)object);
            }
            final DataWatcher datawatcher = this.a.O();
            if (datawatcher.a()) {
                this.b(new Packet40EntityMetadata(this.a.id, datawatcher));
            }
            if (flag) {
                this.d = i;
                this.e = j;
                this.f = k;
            }
            if (flag2) {
                this.g = l;
                this.h = i2;
            }
        }
        if (this.a.aY) {
            this.b(new Packet28EntityVelocity(this.a));
            this.a.aY = false;
        }
    }
    
    public void a(final Packet packet) {
        for (final EntityPlayer entityplayer : this.n) {
            entityplayer.a.b(packet);
        }
    }
    
    public void b(final Packet packet) {
        this.a(packet);
        if (this.a instanceof EntityPlayer) {
            ((EntityPlayer)this.a).a.b(packet);
        }
    }
    
    public void a() {
        this.a(new Packet29DestroyEntity(this.a.id));
    }
    
    public void a(final EntityPlayer entityplayer) {
        if (this.n.contains(entityplayer)) {
            this.n.remove(entityplayer);
        }
    }
    
    public void b(final EntityPlayer entityplayer) {
        if (entityplayer != this.a) {
            final double d0 = entityplayer.locX - this.d / 32;
            final double d2 = entityplayer.locZ - this.f / 32;
            if (d0 >= -this.b && d0 <= this.b && d2 >= -this.b && d2 <= this.b) {
                if (!this.n.contains(entityplayer) && this.a.world == entityplayer.world) {
                    this.n.add(entityplayer);
                    entityplayer.a.b(this.b());
                    if (this.s) {
                        entityplayer.a.b(new Packet28EntityVelocity(this.a.id, this.a.motX, this.a.motY, this.a.motZ));
                    }
                    final ItemStack[] aitemstack = this.a.k_();
                    if (aitemstack != null) {
                        for (int i = 0; i < aitemstack.length; ++i) {
                            entityplayer.a.b(new Packet5EntityEquipment(this.a.id, i, aitemstack[i]));
                        }
                    }
                }
            }
            else if (this.n.contains(entityplayer)) {
                this.n.remove(entityplayer);
                entityplayer.a.b(new Packet29DestroyEntity(this.a.id));
            }
        }
    }
    
    public void b(final List list) {
        for (int i = 0; i < list.size(); ++i) {
            this.b(list.get(i));
        }
    }
    
    private Packet b() {
        if (this.a instanceof EntityItem) {
            final EntityItem entityitem = (EntityItem)this.a;
            final Packet21PickupSpawn packet21pickupspawn = new Packet21PickupSpawn(entityitem);
            entityitem.locX = packet21pickupspawn.b / 32.0;
            entityitem.locY = packet21pickupspawn.c / 32.0;
            entityitem.locZ = packet21pickupspawn.d / 32.0;
            return packet21pickupspawn;
        }
        if (this.a instanceof EntityPlayer) {
            return new Packet20NamedEntitySpawn((EntityHuman)this.a);
        }
        if (this.a instanceof EntityMinecart) {
            final EntityMinecart entityminecart = (EntityMinecart)this.a;
            if (entityminecart.d == 0) {
                return new Packet23VehicleSpawn(this.a, 10);
            }
            if (entityminecart.d == 1) {
                return new Packet23VehicleSpawn(this.a, 11);
            }
            if (entityminecart.d == 2) {
                return new Packet23VehicleSpawn(this.a, 12);
            }
        }
        if (this.a instanceof EntityBoat) {
            return new Packet23VehicleSpawn(this.a, 1);
        }
        if (this.a instanceof IAnimal) {
            return new Packet24MobSpawn((EntityLiving)this.a);
        }
        if (this.a instanceof EntityFish) {
            return new Packet23VehicleSpawn(this.a, 90);
        }
        if (this.a instanceof EntityArrow) {
            return new Packet23VehicleSpawn(this.a, 60);
        }
        if (this.a instanceof EntitySnowball) {
            return new Packet23VehicleSpawn(this.a, 61);
        }
        if (this.a instanceof EntityEgg) {
            return new Packet23VehicleSpawn(this.a, 62);
        }
        if (this.a instanceof EntityTNTPrimed) {
            return new Packet23VehicleSpawn(this.a, 50);
        }
        if (this.a instanceof EntityFallingSand) {
            final EntityFallingSand entityfallingsand = (EntityFallingSand)this.a;
            if (entityfallingsand.a == Block.SAND.id) {
                return new Packet23VehicleSpawn(this.a, 70);
            }
            if (entityfallingsand.a == Block.GRAVEL.id) {
                return new Packet23VehicleSpawn(this.a, 71);
            }
        }
        if (this.a instanceof EntityPainting) {
            return new Packet25EntityPainting((EntityPainting)this.a);
        }
        throw new IllegalArgumentException("Don't know how to add " + this.a.getClass() + "!");
    }
    
    public void c(final EntityPlayer entityplayer) {
        if (this.n.contains(entityplayer)) {
            this.n.remove(entityplayer);
            entityplayer.a.b(new Packet29DestroyEntity(this.a.id));
        }
    }
}
