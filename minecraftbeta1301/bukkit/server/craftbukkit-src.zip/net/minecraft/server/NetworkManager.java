// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.io.DataOutputStream;
import java.io.DataInputStream;
import java.net.SocketAddress;
import java.net.Socket;

public class NetworkManager
{
    public static final Object a;
    public static int b;
    public static int c;
    private Object e;
    private Socket f;
    private final SocketAddress g;
    private DataInputStream h;
    private DataOutputStream i;
    private boolean j;
    private List k;
    private List l;
    private List m;
    private NetHandler n;
    private boolean o;
    private Thread p;
    private Thread q;
    private boolean r;
    private String s;
    private Object[] t;
    private int u;
    private int v;
    public int d;
    private int w;
    
    public NetworkManager(final Socket f, final String s, final NetHandler n) {
        this.e = new Object();
        this.j = true;
        this.k = Collections.synchronizedList(new ArrayList<Object>());
        this.l = Collections.synchronizedList(new ArrayList<Object>());
        this.m = Collections.synchronizedList(new ArrayList<Object>());
        this.o = false;
        this.r = false;
        this.s = "";
        this.u = 0;
        this.v = 0;
        this.d = 0;
        this.w = 50;
        this.f = f;
        this.g = f.getRemoteSocketAddress();
        this.n = n;
        f.setTrafficClass(24);
        this.h = new DataInputStream(f.getInputStream());
        this.i = new DataOutputStream(f.getOutputStream());
        this.q = new NetworkReaderThread(this, s + " read thread");
        this.p = new NetworkWriterThread(this, s + " write thread");
        this.q.start();
        this.p.start();
    }
    
    public void a(final NetHandler n) {
        this.n = n;
    }
    
    public void a(final Packet packet) {
        if (this.o) {
            return;
        }
        synchronized (this.e) {
            this.v += packet.a() + 1;
            if (packet.k) {
                this.m.add(packet);
            }
            else {
                this.l.add(packet);
            }
        }
    }
    
    private void e() {
        try {
            int n = 1;
            if (!this.l.isEmpty() && (this.d == 0 || System.currentTimeMillis() - this.l.get(0).j >= this.d)) {
                n = 0;
                final Packet packet;
                synchronized (this.e) {
                    packet = this.l.remove(0);
                    this.v -= packet.a() + 1;
                }
                Packet.a(packet, this.i);
            }
            if ((n != 0 || this.w-- <= 0) && !this.m.isEmpty() && (this.d == 0 || System.currentTimeMillis() - this.m.get(0).j >= this.d)) {
                n = 0;
                final Packet packet;
                synchronized (this.e) {
                    packet = this.m.remove(0);
                    this.v -= packet.a() + 1;
                }
                Packet.a(packet, this.i);
                this.w = 50;
            }
            if (n != 0) {
                Thread.sleep(10L);
            }
        }
        catch (InterruptedException ex2) {}
        catch (Exception ex) {
            if (!this.r) {
                this.a(ex);
            }
        }
    }
    
    private void f() {
        try {
            final Packet b = Packet.b(this.h);
            if (b != null) {
                this.k.add(b);
            }
            else {
                this.a("disconnect.endOfStream", new Object[0]);
            }
        }
        catch (Exception ex) {
            if (!this.r) {
                this.a(ex);
            }
        }
    }
    
    private void a(final Exception ex) {
        ex.printStackTrace();
        this.a("disconnect.genericReason", "Internal exception: " + ex.toString());
    }
    
    public void a(final String s, final Object... t) {
        if (!this.j) {
            return;
        }
        this.r = true;
        this.s = s;
        this.t = t;
        new NetworkMasterThread(this).start();
        this.j = false;
        try {
            this.h.close();
            this.h = null;
        }
        catch (Throwable t2) {}
        try {
            this.i.close();
            this.i = null;
        }
        catch (Throwable t3) {}
        try {
            this.f.close();
            this.f = null;
        }
        catch (Throwable t4) {}
    }
    
    public void a() {
        if (this.v > 1048576) {
            this.a("disconnect.overflow", new Object[0]);
        }
        if (this.k.isEmpty()) {
            if (this.u++ == 1200) {
                this.a("disconnect.timeout", new Object[0]);
            }
        }
        else {
            this.u = 0;
        }
        int n = 100;
        while (!this.k.isEmpty() && n-- >= 0) {
            this.k.remove(0).a(this.n);
        }
        if (this.r && this.k.isEmpty()) {
            this.n.a(this.s, this.t);
        }
    }
    
    public SocketAddress b() {
        return this.g;
    }
    
    public void c() {
        this.o = true;
        this.q.interrupt();
        new ThreadMonitorConnection(this).start();
    }
    
    public int d() {
        return this.m.size();
    }
    
    static {
        a = new Object();
    }
}
