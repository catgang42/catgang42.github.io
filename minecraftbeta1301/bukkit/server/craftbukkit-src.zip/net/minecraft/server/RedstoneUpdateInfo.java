// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

class RedstoneUpdateInfo
{
    int a;
    int b;
    int c;
    long d;
    
    public RedstoneUpdateInfo(final int a, final int b, final int c, final long d) {
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
}
