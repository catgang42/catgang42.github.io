// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashSet;
import java.util.Set;

public class EntityTracker
{
    private Set a;
    private EntityList b;
    private MinecraftServer c;
    private int d;
    
    public EntityTracker(final MinecraftServer minecraftserver) {
        this.a = new HashSet();
        this.b = new EntityList();
        this.c = minecraftserver;
        this.d = minecraftserver.f.a();
    }
    
    public void a(final Entity entity) {
        if (entity instanceof EntityPlayer) {
            this.a(entity, 512, 2);
            final EntityPlayer entityplayer = (EntityPlayer)entity;
            for (final EntityTrackerEntry entitytrackerentry : this.a) {
                if (entitytrackerentry.a != entityplayer) {
                    entitytrackerentry.b(entityplayer);
                }
            }
        }
        else if (entity instanceof EntityFish) {
            this.a(entity, 64, 5, true);
        }
        else if (entity instanceof EntityArrow) {
            this.a(entity, 64, 5, true);
        }
        else if (entity instanceof EntitySnowball) {
            this.a(entity, 64, 5, true);
        }
        else if (entity instanceof EntityEgg) {
            this.a(entity, 64, 5, true);
        }
        else if (entity instanceof EntityItem) {
            this.a(entity, 64, 20, true);
        }
        else if (entity instanceof EntityMinecart) {
            this.a(entity, 160, 5, true);
        }
        else if (entity instanceof EntityBoat) {
            this.a(entity, 160, 5, true);
        }
        else if (entity instanceof EntitySquid) {
            this.a(entity, 160, 3, true);
        }
        else if (entity instanceof IAnimal) {
            this.a(entity, 160, 3);
        }
        else if (entity instanceof EntityTNTPrimed) {
            this.a(entity, 160, 10, true);
        }
        else if (entity instanceof EntityFallingSand) {
            this.a(entity, 160, 20, true);
        }
        else if (entity instanceof EntityPainting) {
            this.a(entity, 160, Integer.MAX_VALUE, false);
        }
    }
    
    public void a(final Entity entity, final int i, final int j) {
        this.a(entity, i, j, false);
    }
    
    public void a(final Entity entity, int i, final int j, final boolean flag) {
        if (i > this.d) {
            i = this.d;
        }
        if (this.b.b(entity.id)) {
            throw new IllegalStateException("Entity is already tracked!");
        }
        final EntityTrackerEntry entitytrackerentry = new EntityTrackerEntry(entity, i, j, flag);
        this.a.add(entitytrackerentry);
        this.b.a(entity.id, entitytrackerentry);
        entitytrackerentry.b(entity.world.d);
    }
    
    public void b(final Entity entity) {
        if (entity instanceof EntityPlayer) {
            final EntityPlayer entityplayer = (EntityPlayer)entity;
            for (final EntityTrackerEntry entitytrackerentry : this.a) {
                entitytrackerentry.a(entityplayer);
            }
        }
        final EntityTrackerEntry entitytrackerentry2 = (EntityTrackerEntry)this.b.d(entity.id);
        if (entitytrackerentry2 != null) {
            this.a.remove(entitytrackerentry2);
            entitytrackerentry2.a();
        }
    }
    
    public void a() {
        final ArrayList arraylist = new ArrayList();
        for (final EntityTrackerEntry entitytrackerentry : this.a) {
            entitytrackerentry.a(entitytrackerentry.a.world.d);
            if (entitytrackerentry.m && entitytrackerentry.a instanceof EntityPlayer) {
                arraylist.add(entitytrackerentry.a);
            }
        }
        for (int i = 0; i < arraylist.size(); ++i) {
            final EntityPlayer entityplayer = arraylist.get(i);
            for (final EntityTrackerEntry entitytrackerentry2 : this.a) {
                if (entitytrackerentry2.a != entityplayer) {
                    entitytrackerentry2.b(entityplayer);
                }
            }
        }
    }
    
    public void a(final Entity entity, final Packet packet) {
        final EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry)this.b.a(entity.id);
        if (entitytrackerentry != null) {
            entitytrackerentry.a(packet);
        }
    }
    
    public void b(final Entity entity, final Packet packet) {
        final EntityTrackerEntry entitytrackerentry = (EntityTrackerEntry)this.b.a(entity.id);
        if (entitytrackerentry != null) {
            entitytrackerentry.b(packet);
        }
    }
    
    public void a(final EntityPlayer entityplayer) {
        for (final EntityTrackerEntry entitytrackerentry : this.a) {
            entitytrackerentry.c(entityplayer);
        }
    }
}
