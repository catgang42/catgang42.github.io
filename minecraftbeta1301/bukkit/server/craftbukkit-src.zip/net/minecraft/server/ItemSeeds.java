// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.player.PlayerItemEvent;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class ItemSeeds extends Item
{
    private int a;
    
    public ItemSeeds(final int i, final int j) {
        super(i);
        this.a = j;
    }
    
    @Override
    public boolean a(final ItemStack itemstack, final EntityHuman entityhuman, final World world, final int i, final int j, final int k, final int l) {
        if (l != 1) {
            return false;
        }
        final int i2 = world.getTypeId(i, j, k);
        if (i2 != Block.SOIL.id || !world.isEmpty(i, j + 1, k)) {
            return false;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer craftServer = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.PLAYER_ITEM;
        final Player who = (entityhuman == null) ? null : ((Player)entityhuman.getBukkitEntity());
        final org.bukkit.inventory.ItemStack itemInHand = new CraftItemStack(itemstack);
        final org.bukkit.block.Block blockClicked = craftWorld.getBlockAt(i, j, k);
        final BlockFace blockface = CraftBlock.notchToBlockFace(l);
        final PlayerItemEvent event = new PlayerItemEvent(eventType, who, itemInHand, blockClicked, blockface);
        craftServer.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return false;
        }
        world.e(i, j + 1, k, this.a);
        --itemstack.count;
        return true;
    }
}
