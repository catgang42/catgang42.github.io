// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public abstract class BlockFluids extends Block
{
    protected BlockFluids(final int n, final Material material) {
        super(n, ((material == Material.LAVA) ? 14 : 12) * 16 + 13, material);
        final float n2 = 0.0f;
        final float n3 = 0.0f;
        this.a(0.0f + n3, 0.0f + n2, 0.0f + n3, 1.0f + n3, 1.0f + n2, 1.0f + n3);
        this.a(true);
    }
    
    public static float c(int n) {
        if (n >= 8) {
            n = 0;
        }
        return (n + 1) / 9.0f;
    }
    
    @Override
    public int a(final int n) {
        if (n == 0 || n == 1) {
            return this.textureId;
        }
        return this.textureId + 1;
    }
    
    protected int g(final World world, final int n, final int n2, final int n3) {
        if (world.getMaterial(n, n2, n3) != this.material) {
            return -1;
        }
        return world.getData(n, n2, n3);
    }
    
    protected int b(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
        if (blockAccess.getMaterial(n, n2, n3) != this.material) {
            return -1;
        }
        int data = blockAccess.getData(n, n2, n3);
        if (data >= 8) {
            data = 0;
        }
        return data;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final int n, final boolean b) {
        return b && n == 0;
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        final Material material = blockAccess.getMaterial(n, n2, n3);
        return material != this.material && material != Material.ICE && (n4 == 1 || super.a(blockAccess, n, n2, n3, n4));
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public int a(final int n, final Random random) {
        return 0;
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
    
    private Vec3D c(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
        Vec3D vec3D = Vec3D.b(0.0, 0.0, 0.0);
        final int b = this.b(blockAccess, n, n2, n3);
        for (int i = 0; i < 4; ++i) {
            int n4 = n;
            int n5 = n3;
            if (i == 0) {
                --n4;
            }
            if (i == 1) {
                --n5;
            }
            if (i == 2) {
                ++n4;
            }
            if (i == 3) {
                ++n5;
            }
            final int b2 = this.b(blockAccess, n4, n2, n5);
            if (b2 < 0) {
                if (!blockAccess.getMaterial(n4, n2, n5).isSolid()) {
                    final int b3 = this.b(blockAccess, n4, n2 - 1, n5);
                    if (b3 >= 0) {
                        final int n6 = b3 - (b - 8);
                        vec3D = vec3D.c((n4 - n) * n6, (n2 - n2) * n6, (n5 - n3) * n6);
                    }
                }
            }
            else if (b2 >= 0) {
                final int n7 = b2 - b;
                vec3D = vec3D.c((n4 - n) * n7, (n2 - n2) * n7, (n5 - n3) * n7);
            }
        }
        if (blockAccess.getData(n, n2, n3) >= 8) {
            int n8 = 0;
            if (n8 != 0 || this.a(blockAccess, n, n2, n3 - 1, 2)) {
                n8 = 1;
            }
            if (n8 != 0 || this.a(blockAccess, n, n2, n3 + 1, 3)) {
                n8 = 1;
            }
            if (n8 != 0 || this.a(blockAccess, n - 1, n2, n3, 4)) {
                n8 = 1;
            }
            if (n8 != 0 || this.a(blockAccess, n + 1, n2, n3, 5)) {
                n8 = 1;
            }
            if (n8 != 0 || this.a(blockAccess, n, n2 + 1, n3 - 1, 2)) {
                n8 = 1;
            }
            if (n8 != 0 || this.a(blockAccess, n, n2 + 1, n3 + 1, 3)) {
                n8 = 1;
            }
            if (n8 != 0 || this.a(blockAccess, n - 1, n2 + 1, n3, 4)) {
                n8 = 1;
            }
            if (n8 != 0 || this.a(blockAccess, n + 1, n2 + 1, n3, 5)) {
                n8 = 1;
            }
            if (n8 != 0) {
                vec3D = vec3D.b().c(0.0, -6.0, 0.0);
            }
        }
        return vec3D.b();
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Entity entity, final Vec3D vec3D) {
        final Vec3D c = this.c((IBlockAccess)world, n, n2, n3);
        vec3D.a += c.a;
        vec3D.b += c.b;
        vec3D.c += c.c;
    }
    
    @Override
    public int b() {
        if (this.material == Material.WATER) {
            return 5;
        }
        if (this.material == Material.LAVA) {
            return 30;
        }
        return 0;
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Random random) {
        super.a(world, n, n2, n3, random);
    }
    
    @Override
    public void e(final World world, final int n, final int n2, final int n3) {
        this.i(world, n, n2, n3);
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        this.i(world, n, n2, n3);
    }
    
    private void i(final World world, final int i, final int n, final int k) {
        if (world.getTypeId(i, n, k) != this.id) {
            return;
        }
        if (this.material == Material.LAVA) {
            int n2 = 0;
            if (n2 != 0 || world.getMaterial(i, n, k - 1) == Material.WATER) {
                n2 = 1;
            }
            if (n2 != 0 || world.getMaterial(i, n, k + 1) == Material.WATER) {
                n2 = 1;
            }
            if (n2 != 0 || world.getMaterial(i - 1, n, k) == Material.WATER) {
                n2 = 1;
            }
            if (n2 != 0 || world.getMaterial(i + 1, n, k) == Material.WATER) {
                n2 = 1;
            }
            if (n2 != 0 || world.getMaterial(i, n + 1, k) == Material.WATER) {
                n2 = 1;
            }
            if (n2 != 0) {
                final int data = world.getData(i, n, k);
                if (data == 0) {
                    world.e(i, n, k, Block.OBSIDIAN.id);
                }
                else if (data <= 4) {
                    world.e(i, n, k, Block.COBBLESTONE.id);
                }
                this.h(world, i, n, k);
            }
        }
    }
    
    protected void h(final World world, final int n, final int n2, final int n3) {
        world.a(n + 0.5f, n2 + 0.5f, n3 + 0.5f, "random.fizz", 0.5f, 2.6f + (world.k.nextFloat() - world.k.nextFloat()) * 0.8f);
        for (int i = 0; i < 8; ++i) {
            world.a("largesmoke", n + Math.random(), n2 + 1.2, n3 + Math.random(), 0.0, 0.0, 0.0);
        }
    }
}
