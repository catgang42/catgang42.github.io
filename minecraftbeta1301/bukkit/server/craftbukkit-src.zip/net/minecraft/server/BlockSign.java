// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockSign extends BlockContainer
{
    private Class a;
    private boolean b;
    
    protected BlockSign(final int n, final Class a, final boolean b) {
        super(n, Material.WOOD);
        this.b = b;
        this.textureId = 4;
        this.a = a;
        final float n2 = 0.25f;
        this.a(0.5f - n2, 0.0f, 0.5f - n2, 0.5f + n2, 1.0f, 0.5f + n2);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public void a(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
        if (this.b) {
            return;
        }
        final int data = blockAccess.getData(n, n2, n3);
        final float n4 = 0.28125f;
        final float n5 = 0.78125f;
        final float n6 = 0.0f;
        final float n7 = 1.0f;
        final float n8 = 0.125f;
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        if (data == 2) {
            this.a(n6, n4, 1.0f - n8, n7, n5, 1.0f);
        }
        if (data == 3) {
            this.a(n6, n4, 0.0f, n7, n5, n8);
        }
        if (data == 4) {
            this.a(1.0f - n8, n4, n6, 1.0f, n5, n7);
        }
        if (data == 5) {
            this.a(0.0f, n4, n6, n8, n5, n7);
        }
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    protected TileEntity a_() {
        try {
            return this.a.newInstance();
        }
        catch (Exception cause) {
            throw new RuntimeException(cause);
        }
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Item.SIGN.id;
    }
    
    @Override
    public void a(final World world, final int n, final int j, final int n2, final int n3) {
        boolean b = false;
        if (this.b) {
            if (!world.getMaterial(n, j - 1, n2).isBuildable()) {
                b = true;
            }
        }
        else {
            final int data = world.getData(n, j, n2);
            b = true;
            if (data == 2 && world.getMaterial(n, j, n2 + 1).isBuildable()) {
                b = false;
            }
            if (data == 3 && world.getMaterial(n, j, n2 - 1).isBuildable()) {
                b = false;
            }
            if (data == 4 && world.getMaterial(n + 1, j, n2).isBuildable()) {
                b = false;
            }
            if (data == 5 && world.getMaterial(n - 1, j, n2).isBuildable()) {
                b = false;
            }
        }
        if (b) {
            this.b_(world, n, j, n2, world.getData(n, j, n2));
            world.e(n, j, n2, 0);
        }
        super.a(world, n, j, n2, n3);
    }
}
