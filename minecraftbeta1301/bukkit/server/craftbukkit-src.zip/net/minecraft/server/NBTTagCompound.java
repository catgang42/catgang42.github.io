// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.util.Iterator;
import java.io.DataOutput;
import java.util.HashMap;
import java.util.Map;

public class NBTTagCompound extends NBTBase
{
    private Map a;
    
    public NBTTagCompound() {
        this.a = new HashMap();
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        final Iterator<NBTBase> iterator = this.a.values().iterator();
        while (iterator.hasNext()) {
            NBTBase.a(iterator.next(), dataOutput);
        }
        dataOutput.writeByte(0);
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.a.clear();
        NBTBase b;
        while ((b = NBTBase.b(dataInput)).a() != 0) {
            this.a.put(b.b(), b);
        }
    }
    
    @Override
    public byte a() {
        return 10;
    }
    
    public void a(final String s, final NBTBase nbtBase) {
        this.a.put(s, nbtBase.a(s));
    }
    
    public void a(final String s, final byte b) {
        this.a.put(s, new NBTTagByte(b).a(s));
    }
    
    public void a(final String s, final short n) {
        this.a.put(s, new NBTTagShort(n).a(s));
    }
    
    public void a(final String s, final int n) {
        this.a.put(s, new NBTTagInt(n).a(s));
    }
    
    public void a(final String s, final long n) {
        this.a.put(s, new NBTTagLong(n).a(s));
    }
    
    public void a(final String s, final float n) {
        this.a.put(s, new NBTTagFloat(n).a(s));
    }
    
    public void a(final String s, final double n) {
        this.a.put(s, new NBTTagDouble(n).a(s));
    }
    
    public void a(final String s, final String s2) {
        this.a.put(s, new NBTTagString(s2).a(s));
    }
    
    public void a(final String s, final byte[] array) {
        this.a.put(s, new NBTTagByteArray(array).a(s));
    }
    
    public void a(final String s, final NBTTagCompound nbtTagCompound) {
        this.a.put(s, nbtTagCompound.a(s));
    }
    
    public void a(final String s, final boolean b) {
        this.a(s, (byte)(b ? 1 : 0));
    }
    
    public boolean b(final String s) {
        return this.a.containsKey(s);
    }
    
    public byte c(final String s) {
        if (!this.a.containsKey(s)) {
            return 0;
        }
        return this.a.get(s).a;
    }
    
    public short d(final String s) {
        if (!this.a.containsKey(s)) {
            return 0;
        }
        return this.a.get(s).a;
    }
    
    public int e(final String s) {
        if (!this.a.containsKey(s)) {
            return 0;
        }
        return this.a.get(s).a;
    }
    
    public long f(final String s) {
        if (!this.a.containsKey(s)) {
            return 0L;
        }
        return this.a.get(s).a;
    }
    
    public float g(final String s) {
        if (!this.a.containsKey(s)) {
            return 0.0f;
        }
        return this.a.get(s).a;
    }
    
    public double h(final String s) {
        if (!this.a.containsKey(s)) {
            return 0.0;
        }
        return this.a.get(s).a;
    }
    
    public String i(final String s) {
        if (!this.a.containsKey(s)) {
            return "";
        }
        return this.a.get(s).a;
    }
    
    public byte[] j(final String s) {
        if (!this.a.containsKey(s)) {
            return new byte[0];
        }
        return this.a.get(s).a;
    }
    
    public NBTTagCompound k(final String s) {
        if (!this.a.containsKey(s)) {
            return new NBTTagCompound();
        }
        return this.a.get(s);
    }
    
    public NBTTagList l(final String s) {
        if (!this.a.containsKey(s)) {
            return new NBTTagList();
        }
        return this.a.get(s);
    }
    
    public boolean m(final String s) {
        return this.c(s) != 0;
    }
    
    @Override
    public String toString() {
        return "" + this.a.size() + " entries";
    }
}
