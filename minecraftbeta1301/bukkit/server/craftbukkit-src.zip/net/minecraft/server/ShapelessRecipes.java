// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

public class ShapelessRecipes implements CraftingRecipe
{
    private final ItemStack a;
    private final List b;
    
    public ShapelessRecipes(final ItemStack a, final List b) {
        this.a = a;
        this.b = b;
    }
    
    public boolean a(final InventoryCrafting inventoryCrafting) {
        final ArrayList<ItemStack> list = new ArrayList<ItemStack>(this.b);
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j) {
                final ItemStack b = inventoryCrafting.b(j, i);
                if (b != null) {
                    boolean b2 = false;
                    for (final ItemStack itemStack : list) {
                        if (b.id == itemStack.id && (itemStack.h() == -1 || b.h() == itemStack.h())) {
                            b2 = true;
                            list.remove(itemStack);
                            break;
                        }
                    }
                    if (!b2) {
                        return false;
                    }
                }
            }
        }
        return list.isEmpty();
    }
    
    public ItemStack b(final InventoryCrafting inventoryCrafting) {
        return this.a.j();
    }
    
    public int a() {
        return this.b.size();
    }
}
