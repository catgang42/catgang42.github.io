// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;
import java.util.Arrays;
import java.util.List;

public class EmptyChunk extends Chunk
{
    public EmptyChunk(final World world, final int i, final int j) {
        super(world, i, j);
        this.p = true;
    }
    
    public EmptyChunk(final World world, final byte[] abyte, final int i, final int j) {
        super(world, abyte, i, j);
        this.p = true;
    }
    
    @Override
    public boolean a(final int n, final int n2) {
        return n == this.j && n2 == this.k;
    }
    
    @Override
    public int b(final int n, final int n2) {
        return 0;
    }
    
    @Override
    public void a() {
    }
    
    @Override
    public void b() {
    }
    
    @Override
    public void c() {
    }
    
    @Override
    public int a(final int n, final int n2, final int n3) {
        return 0;
    }
    
    @Override
    public boolean a(final int n, final int n2, final int n3, final int n4, final int n5) {
        return true;
    }
    
    @Override
    public boolean a(final int n, final int n2, final int n3, final int n4) {
        return true;
    }
    
    @Override
    public int b(final int n, final int n2, final int n3) {
        return 0;
    }
    
    @Override
    public void b(final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public int a(final EnumSkyBlock enumSkyBlock, final int n, final int n2, final int n3) {
        return 0;
    }
    
    @Override
    public void a(final EnumSkyBlock enumSkyBlock, final int n, final int n2, final int n3, final int n4) {
    }
    
    @Override
    public int c(final int n, final int n2, final int n3, final int n4) {
        return 0;
    }
    
    @Override
    public void a(final Entity entity) {
    }
    
    @Override
    public void b(final Entity entity) {
    }
    
    @Override
    public void a(final Entity entity, final int n) {
    }
    
    @Override
    public boolean c(final int n, final int n2, final int n3) {
        return false;
    }
    
    @Override
    public TileEntity d(final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public void a(final TileEntity tileEntity) {
    }
    
    @Override
    public void a(final int n, final int n2, final int n3, final TileEntity tileEntity) {
    }
    
    @Override
    public void e(final int n, final int n2, final int n3) {
    }
    
    @Override
    public void d() {
    }
    
    @Override
    public void e() {
    }
    
    @Override
    public void f() {
    }
    
    @Override
    public void a(final Entity entity, final AxisAlignedBB axisAlignedBB, final List list) {
    }
    
    @Override
    public void a(final Class clazz, final AxisAlignedBB axisAlignedBB, final List list) {
    }
    
    @Override
    public boolean a(final boolean b) {
        return false;
    }
    
    @Override
    public int a(final byte[] a, final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final int fromIndex) {
        final int n7 = (n4 - n) * (n5 - n2) * (n6 - n3);
        final int n8 = n7 + n7 / 2 * 3;
        Arrays.fill(a, fromIndex, fromIndex + n8, (byte)0);
        return n8;
    }
    
    @Override
    public Random a(final long n) {
        return new Random(this.d.j() + this.j * this.j * 4987142 + this.j * 5947611 + this.k * this.k * 4392871L + this.k * 389711 ^ n);
    }
    
    @Override
    public boolean g() {
        return true;
    }
}
