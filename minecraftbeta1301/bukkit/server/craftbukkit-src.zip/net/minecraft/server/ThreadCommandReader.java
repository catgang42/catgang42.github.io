// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import jline.ConsoleReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ThreadCommandReader extends Thread
{
    final MinecraftServer a;
    
    public ThreadCommandReader(final MinecraftServer minecraftserver) {
        this.a = minecraftserver;
    }
    
    @Override
    public void run() {
        try {
            final ConsoleReader reader = this.a.reader;
            String line = null;
            while (!this.a.g && MinecraftServer.a(this.a) && (line = reader.readLine(">", null)) != null) {
                this.a.a(line, this.a);
            }
        }
        catch (IOException ex) {
            Logger.getLogger(ThreadCommandReader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
