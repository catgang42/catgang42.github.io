// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.List;

public class WorldData
{
    private long a;
    private int b;
    private int c;
    private int d;
    private long e;
    private long f;
    private long g;
    private NBTTagCompound h;
    private int i;
    public String j;
    private int k;
    
    public WorldData(final NBTTagCompound nbttagcompound) {
        this.a = nbttagcompound.f("RandomSeed");
        this.b = nbttagcompound.e("SpawnX");
        this.c = nbttagcompound.e("SpawnY");
        this.d = nbttagcompound.e("SpawnZ");
        this.e = nbttagcompound.f("Time");
        this.f = nbttagcompound.f("LastPlayed");
        this.g = nbttagcompound.f("SizeOnDisk");
        this.j = nbttagcompound.i("LevelName");
        this.k = nbttagcompound.e("version");
        if (nbttagcompound.b("Player")) {
            this.h = nbttagcompound.k("Player");
            this.i = this.h.e("Dimension");
        }
    }
    
    public WorldData(final long i, final String s) {
        this.a = i;
        this.j = s;
    }
    
    public WorldData(final WorldData worlddata) {
        this.a = worlddata.a;
        this.b = worlddata.b;
        this.c = worlddata.c;
        this.d = worlddata.d;
        this.e = worlddata.e;
        this.f = worlddata.f;
        this.g = worlddata.g;
        this.h = worlddata.h;
        this.i = worlddata.i;
        this.j = worlddata.j;
        this.k = worlddata.k;
    }
    
    public NBTTagCompound a() {
        final NBTTagCompound nbttagcompound = new NBTTagCompound();
        this.a(nbttagcompound, this.h);
        return nbttagcompound;
    }
    
    public NBTTagCompound a(final List list) {
        final NBTTagCompound nbttagcompound = new NBTTagCompound();
        EntityHuman entityhuman = null;
        NBTTagCompound nbttagcompound2 = null;
        if (list.size() > 0) {
            entityhuman = list.get(0);
        }
        if (entityhuman != null) {
            nbttagcompound2 = new NBTTagCompound();
            entityhuman.d(nbttagcompound2);
        }
        this.a(nbttagcompound, nbttagcompound2);
        return nbttagcompound;
    }
    
    private void a(final NBTTagCompound nbttagcompound, final NBTTagCompound nbttagcompound1) {
        nbttagcompound.a("RandomSeed", this.a);
        nbttagcompound.a("SpawnX", this.b);
        nbttagcompound.a("SpawnY", this.c);
        nbttagcompound.a("SpawnZ", this.d);
        nbttagcompound.a("Time", this.e);
        nbttagcompound.a("SizeOnDisk", this.g);
        nbttagcompound.a("LastPlayed", System.currentTimeMillis());
        nbttagcompound.a("LevelName", this.j);
        nbttagcompound.a("version", this.k);
        if (nbttagcompound1 != null) {
            nbttagcompound.a("Player", nbttagcompound1);
        }
    }
    
    public long b() {
        return this.a;
    }
    
    public int c() {
        return this.b;
    }
    
    public int d() {
        return this.c;
    }
    
    public int e() {
        return this.d;
    }
    
    public long f() {
        return this.e;
    }
    
    public long g() {
        return this.g;
    }
    
    public int h() {
        return this.i;
    }
    
    public void a(final long i) {
        this.e = i;
    }
    
    public void b(final long i) {
        this.g = i;
    }
    
    public void a(final int i, final int j, final int k) {
        this.b = i;
        this.c = j;
        this.d = k;
    }
    
    public void a(final String s) {
        this.j = s;
    }
    
    public int i() {
        return this.k;
    }
    
    public void a(final int i) {
        this.k = i;
    }
}
