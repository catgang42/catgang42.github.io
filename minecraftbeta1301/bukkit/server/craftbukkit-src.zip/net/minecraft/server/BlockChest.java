// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.block.Block;
import org.bukkit.event.block.BlockInteractEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.event.Event;
import java.util.Random;

public class BlockChest extends BlockContainer
{
    private Random a;
    
    protected BlockChest(final int i) {
        super(i, Material.WOOD);
        this.a = new Random();
        this.textureId = 26;
    }
    
    @Override
    public int a(final int i) {
        return (i == 1) ? (this.textureId - 1) : ((i == 0) ? (this.textureId - 1) : ((i == 3) ? (this.textureId + 1) : this.textureId));
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k) {
        int l = 0;
        if (world.getTypeId(i - 1, j, k) == this.id) {
            ++l;
        }
        if (world.getTypeId(i + 1, j, k) == this.id) {
            ++l;
        }
        if (world.getTypeId(i, j, k - 1) == this.id) {
            ++l;
        }
        if (world.getTypeId(i, j, k + 1) == this.id) {
            ++l;
        }
        return l <= 1 && !this.g(world, i - 1, j, k) && !this.g(world, i + 1, j, k) && !this.g(world, i, j, k - 1) && !this.g(world, i, j, k + 1);
    }
    
    private boolean g(final World world, final int i, final int j, final int k) {
        return world.getTypeId(i, j, k) == this.id && (world.getTypeId(i - 1, j, k) == this.id || world.getTypeId(i + 1, j, k) == this.id || world.getTypeId(i, j, k - 1) == this.id || world.getTypeId(i, j, k + 1) == this.id);
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k) {
        final TileEntityChest tileentitychest = (TileEntityChest)world.getTileEntity(i, j, k);
        for (int l = 0; l < tileentitychest.m_(); ++l) {
            final ItemStack itemstack = tileentitychest.c_(l);
            if (itemstack != null) {
                final float f = this.a.nextFloat() * 0.8f + 0.1f;
                final float f2 = this.a.nextFloat() * 0.8f + 0.1f;
                final float f3 = this.a.nextFloat() * 0.8f + 0.1f;
                while (itemstack.count > 0) {
                    int i2 = this.a.nextInt(21) + 10;
                    if (i2 > itemstack.count) {
                        i2 = itemstack.count;
                    }
                    final ItemStack itemStack = itemstack;
                    itemStack.count -= i2;
                    final EntityItem entityitem = new EntityItem(world, i + f, j + f2, k + f3, new ItemStack(itemstack.id, i2, itemstack.h()));
                    final float f4 = 0.05f;
                    entityitem.motX = (float)this.a.nextGaussian() * f4;
                    entityitem.motY = (float)this.a.nextGaussian() * f4 + 0.2f;
                    entityitem.motZ = (float)this.a.nextGaussian() * f4;
                    world.a(entityitem);
                }
            }
        }
        super.b(world, i, j, k);
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        Object object = world.getTileEntity(i, j, k);
        if (world.d(i, j + 1, k)) {
            return true;
        }
        if (world.getTypeId(i - 1, j, k) == this.id && world.d(i - 1, j + 1, k)) {
            return true;
        }
        if (world.getTypeId(i + 1, j, k) == this.id && world.d(i + 1, j + 1, k)) {
            return true;
        }
        if (world.getTypeId(i, j, k - 1) == this.id && world.d(i, j + 1, k - 1)) {
            return true;
        }
        if (world.getTypeId(i, j, k + 1) == this.id && world.d(i, j + 1, k + 1)) {
            return true;
        }
        if (world.getTypeId(i - 1, j, k) == this.id) {
            object = new InventoryLargeChest("Large chest", (IInventory)world.getTileEntity(i - 1, j, k), (IInventory)object);
        }
        if (world.getTypeId(i + 1, j, k) == this.id) {
            object = new InventoryLargeChest("Large chest", (IInventory)object, (IInventory)world.getTileEntity(i + 1, j, k));
        }
        if (world.getTypeId(i, j, k - 1) == this.id) {
            object = new InventoryLargeChest("Large chest", (IInventory)world.getTileEntity(i, j, k - 1), (IInventory)object);
        }
        if (world.getTypeId(i, j, k + 1) == this.id) {
            object = new InventoryLargeChest("Large chest", (IInventory)object, (IInventory)world.getTileEntity(i, j, k + 1));
        }
        if (world.isStatic) {
            return true;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer server = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.BLOCK_INTERACT;
        final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
        final LivingEntity who = (entityhuman == null) ? null : ((LivingEntity)entityhuman.getBukkitEntity());
        final BlockInteractEvent event = new BlockInteractEvent(eventType, block, who);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        entityhuman.a((IInventory)object);
        return true;
    }
    
    @Override
    protected TileEntity a_() {
        return new TileEntityChest();
    }
}
