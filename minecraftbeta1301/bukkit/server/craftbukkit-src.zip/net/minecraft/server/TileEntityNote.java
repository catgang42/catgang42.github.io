// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class TileEntityNote extends TileEntity
{
    public byte a;
    public boolean b;
    
    public TileEntityNote() {
        this.a = 0;
        this.b = false;
    }
    
    @Override
    public void b(final NBTTagCompound nbtTagCompound) {
        super.b(nbtTagCompound);
        nbtTagCompound.a("note", this.a);
    }
    
    @Override
    public void a(final NBTTagCompound nbtTagCompound) {
        super.a(nbtTagCompound);
        this.a = nbtTagCompound.c("note");
        if (this.a < 0) {
            this.a = 0;
        }
        if (this.a > 24) {
            this.a = 24;
        }
    }
    
    public void a() {
        this.a = (byte)((this.a + 1) % 25);
        this.h();
    }
    
    public void a(final World world, final int i, final int j, final int k) {
        if (world.getMaterial(i, j + 1, k) != Material.AIR) {
            return;
        }
        final Material material = world.getMaterial(i, j - 1, k);
        int l = 0;
        if (material == Material.STONE) {
            l = 1;
        }
        if (material == Material.SAND) {
            l = 2;
        }
        if (material == Material.SHATTERABLE) {
            l = 3;
        }
        if (material == Material.WOOD) {
            l = 4;
        }
        world.d(i, j, k, l, this.a);
    }
}
