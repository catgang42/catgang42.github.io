// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class GuiStatsListener implements ActionListener
{
    final /* synthetic */ GuiStatsComponent a;
    
    GuiStatsListener(final GuiStatsComponent a) {
        this.a = a;
    }
    
    public void actionPerformed(final ActionEvent actionEvent) {
        this.a.a();
    }
}
