// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.block.BlockRedstoneEvent;
import org.bukkit.event.block.BlockInteractEvent;
import org.bukkit.entity.LivingEntity;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.event.Event;

public class BlockButton extends Block
{
    protected BlockButton(final int i, final int j) {
        super(i, j, Material.ORIENTABLE);
        this.a(true);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int i, final int j, final int k) {
        return null;
    }
    
    @Override
    public int b() {
        return 20;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k) {
        return world.d(i - 1, j, k) || world.d(i + 1, j, k) || world.d(i, j, k - 1) || world.d(i, j, k + 1);
    }
    
    @Override
    public void d(final World world, final int i, final int j, final int k, final int l) {
        int i2 = world.getData(i, j, k);
        final int j2 = i2 & 0x8;
        i2 &= 0x7;
        if (l == 2 && world.d(i, j, k + 1)) {
            i2 = 4;
        }
        else if (l == 3 && world.d(i, j, k - 1)) {
            i2 = 3;
        }
        else if (l == 4 && world.d(i + 1, j, k)) {
            i2 = 2;
        }
        else if (l == 5 && world.d(i - 1, j, k)) {
            i2 = 1;
        }
        else {
            i2 = this.g(world, i, j, k);
        }
        world.c(i, j, k, i2 + j2);
    }
    
    private int g(final World world, final int i, final int j, final int k) {
        return world.d(i - 1, j, k) ? 1 : (world.d(i + 1, j, k) ? 2 : (world.d(i, j, k - 1) ? 3 : (world.d(i, j, k + 1) ? 4 : 1)));
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        if (this.h(world, i, j, k)) {
            final int i2 = world.getData(i, j, k) & 0x7;
            boolean flag = false;
            if (!world.d(i - 1, j, k) && i2 == 1) {
                flag = true;
            }
            if (!world.d(i + 1, j, k) && i2 == 2) {
                flag = true;
            }
            if (!world.d(i, j, k - 1) && i2 == 3) {
                flag = true;
            }
            if (!world.d(i, j, k + 1) && i2 == 4) {
                flag = true;
            }
            if (flag) {
                this.b_(world, i, j, k, world.getData(i, j, k));
                world.e(i, j, k, 0);
            }
        }
    }
    
    private boolean h(final World world, final int i, final int j, final int k) {
        if (!this.a(world, i, j, k)) {
            this.b_(world, i, j, k, world.getData(i, j, k));
            world.e(i, j, k, 0);
            return false;
        }
        return true;
    }
    
    @Override
    public void a(final IBlockAccess iblockaccess, final int i, final int j, final int k) {
        final int l = iblockaccess.getData(i, j, k);
        final int i2 = l & 0x7;
        final boolean flag = (l & 0x8) > 0;
        final float f = 0.375f;
        final float f2 = 0.625f;
        final float f3 = 0.1875f;
        float f4 = 0.125f;
        if (flag) {
            f4 = 0.0625f;
        }
        if (i2 == 1) {
            this.a(0.0f, f, 0.5f - f3, f4, f2, 0.5f + f3);
        }
        else if (i2 == 2) {
            this.a(1.0f - f4, f, 0.5f - f3, 1.0f, f2, 0.5f + f3);
        }
        else if (i2 == 3) {
            this.a(0.5f - f3, f, 0.0f, 0.5f + f3, f2, f4);
        }
        else if (i2 == 4) {
            this.a(0.5f - f3, f, 1.0f - f4, 0.5f + f3, f2, 1.0f);
        }
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        this.a(world, i, j, k, entityhuman);
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k, final EntityHuman entityhuman) {
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer server = ((WorldServer)world).getServer();
        final Event.Type eventType = Event.Type.BLOCK_INTERACT;
        final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
        final LivingEntity who = (entityhuman == null) ? null : ((LivingEntity)entityhuman.getBukkitEntity());
        final BlockInteractEvent event = new BlockInteractEvent(eventType, block, who);
        server.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return true;
        }
        final int l = world.getData(i, j, k);
        final int i2 = l & 0x7;
        final int j2 = 8 - (l & 0x8);
        if (j2 == 0) {
            return true;
        }
        final int old = (j2 != 8) ? 1 : 0;
        final int current = (j2 == 8) ? 1 : 0;
        final BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, old, current);
        server.getPluginManager().callEvent(eventRedstone);
        if (eventRedstone.getNewCurrent() > 0 != (j2 == 8)) {
            return true;
        }
        world.c(i, j, k, i2 + j2);
        world.b(i, j, k, i, j, k);
        world.a(i + 0.5, j + 0.5, k + 0.5, "random.click", 0.3f, 0.6f);
        world.h(i, j, k, this.id);
        if (i2 == 1) {
            world.h(i - 1, j, k, this.id);
        }
        else if (i2 == 2) {
            world.h(i + 1, j, k, this.id);
        }
        else if (i2 == 3) {
            world.h(i, j, k - 1, this.id);
        }
        else if (i2 == 4) {
            world.h(i, j, k + 1, this.id);
        }
        else {
            world.h(i, j - 1, k, this.id);
        }
        world.c(i, j, k, this.id, this.b());
        return true;
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k) {
        final int l = world.getData(i, j, k);
        if ((l & 0x8) > 0) {
            world.h(i, j, k, this.id);
            final int i2 = l & 0x7;
            if (i2 == 1) {
                world.h(i - 1, j, k, this.id);
            }
            else if (i2 == 2) {
                world.h(i + 1, j, k, this.id);
            }
            else if (i2 == 3) {
                world.h(i, j, k - 1, this.id);
            }
            else if (i2 == 4) {
                world.h(i, j, k + 1, this.id);
            }
            else {
                world.h(i, j - 1, k, this.id);
            }
        }
        super.b(world, i, j, k);
    }
    
    @Override
    public boolean b(final IBlockAccess iblockaccess, final int i, final int j, final int k, final int l) {
        return (iblockaccess.getData(i, j, k) & 0x8) > 0;
    }
    
    @Override
    public boolean c(final World world, final int i, final int j, final int k, final int l) {
        final int i2 = world.getData(i, j, k);
        if ((i2 & 0x8) == 0x0) {
            return false;
        }
        final int j2 = i2 & 0x7;
        return (j2 == 5 && l == 1) || (j2 == 4 && l == 2) || (j2 == 3 && l == 3) || (j2 == 2 && l == 4) || (j2 == 1 && l == 5);
    }
    
    @Override
    public boolean c() {
        return true;
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (!world.isStatic) {
            final int l = world.getData(i, j, k);
            if ((l & 0x8) != 0x0) {
                final CraftWorld craftWorld = ((WorldServer)world).getWorld();
                final CraftServer server = ((WorldServer)world).getServer();
                final CraftBlock block = (CraftBlock)craftWorld.getBlockAt(i, j, k);
                final BlockRedstoneEvent eventRedstone = new BlockRedstoneEvent(block, 1, 0);
                server.getPluginManager().callEvent(eventRedstone);
                if (eventRedstone.getNewCurrent() > 0) {
                    return;
                }
                world.c(i, j, k, l & 0x7);
                world.h(i, j, k, this.id);
                final int i2 = l & 0x7;
                if (i2 == 1) {
                    world.h(i - 1, j, k, this.id);
                }
                else if (i2 == 2) {
                    world.h(i + 1, j, k, this.id);
                }
                else if (i2 == 3) {
                    world.h(i, j, k - 1, this.id);
                }
                else if (i2 == 4) {
                    world.h(i, j, k + 1, this.id);
                }
                else {
                    world.h(i, j - 1, k, this.id);
                }
                world.a(i + 0.5, j + 0.5, k + 0.5, "random.click", 0.3f, 0.5f);
                world.b(i, j, k, i, j, k);
            }
        }
    }
}
