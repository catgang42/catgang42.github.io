// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;
import java.util.ArrayList;
import java.util.List;

public class NBTTagList extends NBTBase
{
    private List a;
    private byte b;
    
    public NBTTagList() {
        this.a = new ArrayList();
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        if (this.a.size() > 0) {
            this.b = this.a.get(0).a();
        }
        else {
            this.b = 1;
        }
        dataOutput.writeByte(this.b);
        dataOutput.writeInt(this.a.size());
        for (int i = 0; i < this.a.size(); ++i) {
            ((NBTBase)this.a.get(i)).a(dataOutput);
        }
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.b = dataInput.readByte();
        final int int1 = dataInput.readInt();
        this.a = new ArrayList();
        for (int i = 0; i < int1; ++i) {
            final NBTBase a = NBTBase.a(this.b);
            a.a(dataInput);
            this.a.add(a);
        }
    }
    
    @Override
    public byte a() {
        return 9;
    }
    
    @Override
    public String toString() {
        return "" + this.a.size() + " entries of type " + NBTBase.b(this.b);
    }
    
    public void a(final NBTBase nbtBase) {
        this.b = nbtBase.a();
        this.a.add(nbtBase);
    }
    
    public NBTBase a(final int n) {
        return this.a.get(n);
    }
    
    public int c() {
        return this.a.size();
    }
}
