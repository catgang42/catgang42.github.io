// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class RecipesFood
{
    public void a(final CraftingManager craftingManager) {
        craftingManager.a(new ItemStack(Item.MUSHROOM_SOUP), "Y", "X", "#", 'X', Block.BROWN_MUSHROOM, 'Y', Block.RED_MUSHROOM, '#', Item.BOWL);
        craftingManager.a(new ItemStack(Item.MUSHROOM_SOUP), "Y", "X", "#", 'X', Block.RED_MUSHROOM, 'Y', Block.BROWN_MUSHROOM, '#', Item.BOWL);
    }
}
