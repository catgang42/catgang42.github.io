// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;

class MinecartTrackLogic
{
    private World b;
    private int c;
    private int d;
    private int e;
    private int f;
    private List g;
    final /* synthetic */ BlockMinecartTrack a;
    
    public MinecartTrackLogic(final BlockMinecartTrack a, final World b, final int n, final int n2, final int n3) {
        this.a = a;
        this.g = new ArrayList();
        this.b = b;
        this.c = n;
        this.d = n2;
        this.e = n3;
        this.f = b.getData(n, n2, n3);
        this.a();
    }
    
    private void a() {
        this.g.clear();
        if (this.f == 0) {
            this.g.add(new ChunkPosition(this.c, this.d, this.e - 1));
            this.g.add(new ChunkPosition(this.c, this.d, this.e + 1));
        }
        else if (this.f == 1) {
            this.g.add(new ChunkPosition(this.c - 1, this.d, this.e));
            this.g.add(new ChunkPosition(this.c + 1, this.d, this.e));
        }
        else if (this.f == 2) {
            this.g.add(new ChunkPosition(this.c - 1, this.d, this.e));
            this.g.add(new ChunkPosition(this.c + 1, this.d + 1, this.e));
        }
        else if (this.f == 3) {
            this.g.add(new ChunkPosition(this.c - 1, this.d + 1, this.e));
            this.g.add(new ChunkPosition(this.c + 1, this.d, this.e));
        }
        else if (this.f == 4) {
            this.g.add(new ChunkPosition(this.c, this.d + 1, this.e - 1));
            this.g.add(new ChunkPosition(this.c, this.d, this.e + 1));
        }
        else if (this.f == 5) {
            this.g.add(new ChunkPosition(this.c, this.d, this.e - 1));
            this.g.add(new ChunkPosition(this.c, this.d + 1, this.e + 1));
        }
        else if (this.f == 6) {
            this.g.add(new ChunkPosition(this.c + 1, this.d, this.e));
            this.g.add(new ChunkPosition(this.c, this.d, this.e + 1));
        }
        else if (this.f == 7) {
            this.g.add(new ChunkPosition(this.c - 1, this.d, this.e));
            this.g.add(new ChunkPosition(this.c, this.d, this.e + 1));
        }
        else if (this.f == 8) {
            this.g.add(new ChunkPosition(this.c - 1, this.d, this.e));
            this.g.add(new ChunkPosition(this.c, this.d, this.e - 1));
        }
        else if (this.f == 9) {
            this.g.add(new ChunkPosition(this.c + 1, this.d, this.e));
            this.g.add(new ChunkPosition(this.c, this.d, this.e - 1));
        }
    }
    
    private void b() {
        for (int i = 0; i < this.g.size(); ++i) {
            final MinecartTrackLogic a = this.a(this.g.get(i));
            if (a == null || !a.b(this)) {
                this.g.remove(i--);
            }
            else {
                this.g.set(i, new ChunkPosition(a.c, a.d, a.e));
            }
        }
    }
    
    private boolean a(final int i, final int j, final int k) {
        return this.b.getTypeId(i, j, k) == this.a.id || this.b.getTypeId(i, j + 1, k) == this.a.id || this.b.getTypeId(i, j - 1, k) == this.a.id;
    }
    
    private MinecartTrackLogic a(final ChunkPosition chunkPosition) {
        if (this.b.getTypeId(chunkPosition.a, chunkPosition.b, chunkPosition.c) == this.a.id) {
            return new MinecartTrackLogic(this.a, this.b, chunkPosition.a, chunkPosition.b, chunkPosition.c);
        }
        if (this.b.getTypeId(chunkPosition.a, chunkPosition.b + 1, chunkPosition.c) == this.a.id) {
            return new MinecartTrackLogic(this.a, this.b, chunkPosition.a, chunkPosition.b + 1, chunkPosition.c);
        }
        if (this.b.getTypeId(chunkPosition.a, chunkPosition.b - 1, chunkPosition.c) == this.a.id) {
            return new MinecartTrackLogic(this.a, this.b, chunkPosition.a, chunkPosition.b - 1, chunkPosition.c);
        }
        return null;
    }
    
    private boolean b(final MinecartTrackLogic minecartTrackLogic) {
        for (int i = 0; i < this.g.size(); ++i) {
            final ChunkPosition chunkPosition = this.g.get(i);
            if (chunkPosition.a == minecartTrackLogic.c && chunkPosition.c == minecartTrackLogic.e) {
                return true;
            }
        }
        return false;
    }
    
    private boolean b(final int n, final int n2, final int n3) {
        for (int i = 0; i < this.g.size(); ++i) {
            final ChunkPosition chunkPosition = this.g.get(i);
            if (chunkPosition.a == n && chunkPosition.c == n3) {
                return true;
            }
        }
        return false;
    }
    
    private int c() {
        int n = 0;
        if (this.a(this.c, this.d, this.e - 1)) {
            ++n;
        }
        if (this.a(this.c, this.d, this.e + 1)) {
            ++n;
        }
        if (this.a(this.c - 1, this.d, this.e)) {
            ++n;
        }
        if (this.a(this.c + 1, this.d, this.e)) {
            ++n;
        }
        return n;
    }
    
    private boolean c(final MinecartTrackLogic minecartTrackLogic) {
        if (this.b(minecartTrackLogic)) {
            return true;
        }
        if (this.g.size() == 2) {
            return false;
        }
        if (this.g.size() == 0) {
            return true;
        }
        final ChunkPosition chunkPosition = this.g.get(0);
        return minecartTrackLogic.d != this.d || chunkPosition.b != this.d || true;
    }
    
    private void d(final MinecartTrackLogic minecartTrackLogic) {
        this.g.add(new ChunkPosition(minecartTrackLogic.c, minecartTrackLogic.d, minecartTrackLogic.e));
        final boolean b = this.b(this.c, this.d, this.e - 1);
        final boolean b2 = this.b(this.c, this.d, this.e + 1);
        final boolean b3 = this.b(this.c - 1, this.d, this.e);
        final boolean b4 = this.b(this.c + 1, this.d, this.e);
        int l = -1;
        if (b || b2) {
            l = 0;
        }
        if (b3 || b4) {
            l = 1;
        }
        if (b2 && b4 && !b && !b3) {
            l = 6;
        }
        if (b2 && b3 && !b && !b4) {
            l = 7;
        }
        if (b && b3 && !b2 && !b4) {
            l = 8;
        }
        if (b && b4 && !b2 && !b3) {
            l = 9;
        }
        if (l == 0) {
            if (this.b.getTypeId(this.c, this.d + 1, this.e - 1) == this.a.id) {
                l = 4;
            }
            if (this.b.getTypeId(this.c, this.d + 1, this.e + 1) == this.a.id) {
                l = 5;
            }
        }
        if (l == 1) {
            if (this.b.getTypeId(this.c + 1, this.d + 1, this.e) == this.a.id) {
                l = 2;
            }
            if (this.b.getTypeId(this.c - 1, this.d + 1, this.e) == this.a.id) {
                l = 3;
            }
        }
        if (l < 0) {
            l = 0;
        }
        this.b.c(this.c, this.d, this.e, l);
    }
    
    private boolean c(final int n, final int n2, final int n3) {
        final MinecartTrackLogic a = this.a(new ChunkPosition(n, n2, n3));
        if (a == null) {
            return false;
        }
        a.b();
        return a.c(this);
    }
    
    public void a(final boolean b) {
        final boolean c = this.c(this.c, this.d, this.e - 1);
        final boolean c2 = this.c(this.c, this.d, this.e + 1);
        final boolean c3 = this.c(this.c - 1, this.d, this.e);
        final boolean c4 = this.c(this.c + 1, this.d, this.e);
        int n = -1;
        if ((c || c2) && !c3 && !c4) {
            n = 0;
        }
        if ((c3 || c4) && !c && !c2) {
            n = 1;
        }
        if (c2 && c4 && !c && !c3) {
            n = 6;
        }
        if (c2 && c3 && !c && !c4) {
            n = 7;
        }
        if (c && c3 && !c2 && !c4) {
            n = 8;
        }
        if (c && c4 && !c2 && !c3) {
            n = 9;
        }
        if (n == -1) {
            if (c || c2) {
                n = 0;
            }
            if (c3 || c4) {
                n = 1;
            }
            if (b) {
                if (c2 && c4) {
                    n = 6;
                }
                if (c3 && c2) {
                    n = 7;
                }
                if (c4 && c) {
                    n = 9;
                }
                if (c && c3) {
                    n = 8;
                }
            }
            else {
                if (c && c3) {
                    n = 8;
                }
                if (c4 && c) {
                    n = 9;
                }
                if (c3 && c2) {
                    n = 7;
                }
                if (c2 && c4) {
                    n = 6;
                }
            }
        }
        if (n == 0) {
            if (this.b.getTypeId(this.c, this.d + 1, this.e - 1) == this.a.id) {
                n = 4;
            }
            if (this.b.getTypeId(this.c, this.d + 1, this.e + 1) == this.a.id) {
                n = 5;
            }
        }
        if (n == 1) {
            if (this.b.getTypeId(this.c + 1, this.d + 1, this.e) == this.a.id) {
                n = 2;
            }
            if (this.b.getTypeId(this.c - 1, this.d + 1, this.e) == this.a.id) {
                n = 3;
            }
        }
        if (n < 0) {
            n = 0;
        }
        this.f = n;
        this.a();
        this.b.c(this.c, this.d, this.e, n);
        for (int i = 0; i < this.g.size(); ++i) {
            final MinecartTrackLogic a = this.a(this.g.get(i));
            if (a != null) {
                a.b();
                if (a.c(this)) {
                    a.d(this);
                }
            }
        }
    }
}
