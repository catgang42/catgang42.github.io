// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class MovingObjectPosition
{
    public EnumMovingObjectType a;
    public int b;
    public int c;
    public int d;
    public int e;
    public Vec3D f;
    public Entity g;
    
    public MovingObjectPosition(final int b, final int c, final int d, final int e, final Vec3D vec3D) {
        this.a = EnumMovingObjectType.TILE;
        this.b = b;
        this.c = c;
        this.d = d;
        this.e = e;
        this.f = Vec3D.b(vec3D.a, vec3D.b, vec3D.c);
    }
    
    public MovingObjectPosition(final Entity g) {
        this.a = EnumMovingObjectType.ENTITY;
        this.g = g;
        this.f = Vec3D.b(g.locX, g.locY, g.locZ);
    }
}
