// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.ExplosionPrimedEvent;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.Event;

public class EntityTNTPrimed extends Entity
{
    public int a;
    
    public EntityTNTPrimed(final World world) {
        super(world);
        this.a = 0;
        this.aC = true;
        this.a(0.98f, 0.98f);
        this.height = this.width / 2.0f;
    }
    
    public EntityTNTPrimed(final World world, final double d0, final double d1, final double d2) {
        this(world);
        this.a(d0, d1, d2);
        final float f = (float)(Math.random() * 3.1415927410125732 * 2.0);
        this.motX = -MathHelper.a(f * 3.1415927f / 180.0f) * 0.02f;
        this.motY = 0.20000000298023224;
        this.motZ = -MathHelper.b(f * 3.1415927f / 180.0f) * 0.02f;
        this.bg = false;
        this.a = 80;
        this.lastX = d0;
        this.lastY = d1;
        this.lastZ = d2;
    }
    
    @Override
    protected void a() {
    }
    
    @Override
    public boolean d_() {
        return !this.dead;
    }
    
    @Override
    public void f_() {
        this.lastX = this.locX;
        this.lastY = this.locY;
        this.lastZ = this.locZ;
        this.motY -= 0.03999999910593033;
        this.c(this.motX, this.motY, this.motZ);
        this.motX *= 0.9800000190734863;
        this.motY *= 0.9800000190734863;
        this.motZ *= 0.9800000190734863;
        if (this.onGround) {
            this.motX *= 0.699999988079071;
            this.motZ *= 0.699999988079071;
            this.motY *= -0.5;
        }
        if (this.a-- <= 0) {
            this.h();
            this.C();
        }
        else {
            this.world.a("smoke", this.locX, this.locY + 0.5, this.locZ, 0.0, 0.0, 0.0);
        }
    }
    
    private void h() {
        final float f = 4.0f;
        final CraftServer server = ((WorldServer)this.world).getServer();
        final Event.Type eventType = Event.Type.EXPLOSION_PRIMED;
        final ExplosionPrimedEvent event = new ExplosionPrimedEvent(eventType, CraftEntity.getEntity(server, this), f, false);
        server.getPluginManager().callEvent(event);
        if (!event.isCancelled()) {
            this.world.a(null, this.locX, this.locY, this.locZ, event.getRadius(), event.getFire());
        }
    }
    
    @Override
    protected void a(final NBTTagCompound nbttagcompound) {
        nbttagcompound.a("Fuse", (byte)this.a);
    }
    
    @Override
    protected void b(final NBTTagCompound nbttagcompound) {
        this.a = nbttagcompound.c("Fuse");
    }
}
