// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.block.BlockFace;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.player.PlayerItemEvent;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class ItemBoat extends Item
{
    public ItemBoat(final int i) {
        super(i);
        this.maxStackSize = 1;
    }
    
    @Override
    public ItemStack a(final ItemStack itemstack, final World world, final EntityHuman entityhuman) {
        final float f = 1.0f;
        final float f2 = entityhuman.lastPitch + (entityhuman.pitch - entityhuman.lastPitch) * f;
        final float f3 = entityhuman.lastYaw + (entityhuman.yaw - entityhuman.lastYaw) * f;
        final double d0 = entityhuman.lastX + (entityhuman.locX - entityhuman.lastX) * f;
        final double d2 = entityhuman.lastY + (entityhuman.locY - entityhuman.lastY) * f + 1.62 - entityhuman.height;
        final double d3 = entityhuman.lastZ + (entityhuman.locZ - entityhuman.lastZ) * f;
        final Vec3D vec3d = Vec3D.b(d0, d2, d3);
        final float f4 = MathHelper.b(-f3 * 0.017453292f - 3.1415927f);
        final float f5 = MathHelper.a(-f3 * 0.017453292f - 3.1415927f);
        final float f6 = -MathHelper.b(-f2 * 0.017453292f);
        final float f7 = MathHelper.a(-f2 * 0.017453292f);
        final float f8 = f5 * f6;
        final float f9 = f4 * f6;
        final double d4 = 5.0;
        final Vec3D vec3d2 = vec3d.c(f8 * d4, f7 * d4, f9 * d4);
        final MovingObjectPosition movingobjectposition = world.a(vec3d, vec3d2, true);
        if (movingobjectposition == null) {
            return itemstack;
        }
        if (movingobjectposition.a == EnumMovingObjectType.TILE) {
            final int i = movingobjectposition.b;
            final int j = movingobjectposition.c;
            final int k = movingobjectposition.d;
            if (!world.isStatic) {
                final CraftWorld craftWorld = ((WorldServer)world).getWorld();
                final CraftServer craftServer = ((WorldServer)world).getServer();
                final Event.Type eventType = Event.Type.PLAYER_ITEM;
                final Player who = (entityhuman == null) ? null : ((Player)entityhuman.getBukkitEntity());
                final org.bukkit.inventory.ItemStack itemInHand = new CraftItemStack(itemstack);
                final Block blockClicked = craftWorld.getBlockAt(i, j, k);
                final BlockFace blockFace = CraftBlock.notchToBlockFace(movingobjectposition.e);
                final PlayerItemEvent event = new PlayerItemEvent(eventType, who, itemInHand, blockClicked, blockFace);
                craftServer.getPluginManager().callEvent(event);
                if (event.isCancelled()) {
                    return itemstack;
                }
                world.a(new EntityBoat(world, i + 0.5f, j + 1.5f, k + 0.5f));
            }
            --itemstack.count;
        }
        return itemstack;
    }
}
