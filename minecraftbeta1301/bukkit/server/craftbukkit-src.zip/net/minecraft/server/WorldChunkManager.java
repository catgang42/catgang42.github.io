// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class WorldChunkManager
{
    private NoiseGeneratorOctaves2 e;
    private NoiseGeneratorOctaves2 f;
    private NoiseGeneratorOctaves2 g;
    public double[] a;
    public double[] b;
    public double[] c;
    public BiomeBase[] d;
    
    protected WorldChunkManager() {
    }
    
    public WorldChunkManager(final World world) {
        this.e = new NoiseGeneratorOctaves2(new Random(world.j() * 9871L), 4);
        this.f = new NoiseGeneratorOctaves2(new Random(world.j() * 39811L), 4);
        this.g = new NoiseGeneratorOctaves2(new Random(world.j() * 543321L), 2);
    }
    
    public BiomeBase a(final ChunkCoordIntPair chunkCoordIntPair) {
        return this.a(chunkCoordIntPair.a >> 4, chunkCoordIntPair.b >> 4);
    }
    
    public BiomeBase a(final int n, final int n2) {
        return this.a(n, n2, 1, 1)[0];
    }
    
    public BiomeBase[] a(final int n, final int n2, final int n3, final int n4) {
        return this.d = this.a(this.d, n, n2, n3, n4);
    }
    
    public double[] a(double[] a, final int n, final int n2, final int n3, final int n4) {
        if (a == null || a.length < n3 * n4) {
            a = new double[n3 * n4];
        }
        a = this.e.a(a, n, n2, n3, n4, 0.02500000037252903, 0.02500000037252903, 0.25);
        this.c = this.g.a(this.c, n, n2, n3, n4, 0.25, 0.25, 0.5882352941176471);
        int n5 = 0;
        for (int i = 0; i < n3; ++i) {
            for (int j = 0; j < n4; ++j) {
                final double n6 = this.c[n5] * 1.1 + 0.5;
                final double n7 = 0.01;
                final double n8 = (a[n5] * 0.15 + 0.7) * (1.0 - n7) + n6 * n7;
                double n9 = 1.0 - (1.0 - n8) * (1.0 - n8);
                if (n9 < 0.0) {
                    n9 = 0.0;
                }
                if (n9 > 1.0) {
                    n9 = 1.0;
                }
                a[n5] = n9;
                ++n5;
            }
        }
        return a;
    }
    
    public BiomeBase[] a(BiomeBase[] array, final int n, final int n2, final int n3, final int n4) {
        if (array == null || array.length < n3 * n4) {
            array = new BiomeBase[n3 * n4];
        }
        this.a = this.e.a(this.a, n, n2, n3, n3, 0.02500000037252903, 0.02500000037252903, 0.25);
        this.b = this.f.a(this.b, n, n2, n3, n3, 0.05000000074505806, 0.05000000074505806, 0.3333333333333333);
        this.c = this.g.a(this.c, n, n2, n3, n3, 0.25, 0.25, 0.5882352941176471);
        int n5 = 0;
        for (int i = 0; i < n3; ++i) {
            for (int j = 0; j < n4; ++j) {
                final double n6 = this.c[n5] * 1.1 + 0.5;
                final double n7 = 0.01;
                final double n8 = (this.a[n5] * 0.15 + 0.7) * (1.0 - n7) + n6 * n7;
                final double n9 = 0.002;
                double n10 = (this.b[n5] * 0.15 + 0.5) * (1.0 - n9) + n6 * n9;
                double n11 = 1.0 - (1.0 - n8) * (1.0 - n8);
                if (n11 < 0.0) {
                    n11 = 0.0;
                }
                if (n10 < 0.0) {
                    n10 = 0.0;
                }
                if (n11 > 1.0) {
                    n11 = 1.0;
                }
                if (n10 > 1.0) {
                    n10 = 1.0;
                }
                this.a[n5] = n11;
                this.b[n5] = n10;
                array[n5++] = BiomeBase.a(n11, n10);
            }
        }
        return array;
    }
}
