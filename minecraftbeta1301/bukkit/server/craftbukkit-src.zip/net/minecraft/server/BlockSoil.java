// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockSoil extends Block
{
    protected BlockSoil(final int n) {
        super(n, Material.EARTH);
        this.textureId = 87;
        this.a(true);
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 0.9375f, 1.0f);
        this.e(255);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return AxisAlignedBB.b(n + 0, n2 + 0, n3 + 0, n + 1, n2 + 1, n3 + 1);
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public int a(final int n, final int n2) {
        if (n == 1 && n2 > 0) {
            return this.textureId - 1;
        }
        if (n == 1) {
            return this.textureId;
        }
        return 2;
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Random random) {
        if (random.nextInt(5) == 0) {
            if (this.h(world, n, n2, n3)) {
                world.c(n, n2, n3, 7);
            }
            else {
                final int data = world.getData(n, n2, n3);
                if (data > 0) {
                    world.c(n, n2, n3, data - 1);
                }
                else if (!this.g(world, n, n2, n3)) {
                    world.e(n, n2, n3, Block.DIRT.id);
                }
            }
        }
    }
    
    @Override
    public void b(final World world, final int i, final int j, final int k, final Entity entity) {
        if (world.k.nextInt(4) == 0) {
            world.e(i, j, k, Block.DIRT.id);
        }
    }
    
    private boolean g(final World world, final int n, final int n2, final int n3) {
        for (int n4 = 0, i = n - n4; i <= n + n4; ++i) {
            for (int j = n3 - n4; j <= n3 + n4; ++j) {
                if (world.getTypeId(i, n2 + 1, j) == Block.CROPS.id) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean h(final World world, final int n, final int n2, final int n3) {
        for (int i = n - 4; i <= n + 4; ++i) {
            for (int j = n2; j <= n2 + 1; ++j) {
                for (int k = n3 - 4; k <= n3 + 4; ++k) {
                    if (world.getMaterial(i, j, k) == Material.WATER) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    @Override
    public void a(final World world, final int n, final int j, final int n2, final int n3) {
        super.a(world, n, j, n2, n3);
        if (world.getMaterial(n, j + 1, n2).isBuildable()) {
            world.e(n, j, n2, Block.DIRT.id);
        }
    }
    
    @Override
    public int a(final int n, final Random random) {
        return Block.DIRT.a(0, random);
    }
}
