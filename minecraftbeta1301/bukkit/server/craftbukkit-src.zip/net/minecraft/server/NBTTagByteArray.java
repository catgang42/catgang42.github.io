// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public class NBTTagByteArray extends NBTBase
{
    public byte[] a;
    
    public NBTTagByteArray() {
    }
    
    public NBTTagByteArray(final byte[] a) {
        this.a = a;
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        dataOutput.writeInt(this.a.length);
        dataOutput.write(this.a);
    }
    
    @Override
    void a(final DataInput dataInput) {
        dataInput.readFully(this.a = new byte[dataInput.readInt()]);
    }
    
    @Override
    public byte a() {
        return 7;
    }
    
    @Override
    public String toString() {
        return "[" + this.a.length + " bytes]";
    }
}
