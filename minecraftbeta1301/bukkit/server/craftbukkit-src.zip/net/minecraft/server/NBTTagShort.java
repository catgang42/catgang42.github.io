// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public class NBTTagShort extends NBTBase
{
    public short a;
    
    public NBTTagShort() {
    }
    
    public NBTTagShort(final short a) {
        this.a = a;
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        dataOutput.writeShort(this.a);
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.a = dataInput.readShort();
    }
    
    @Override
    public byte a() {
        return 2;
    }
    
    @Override
    public String toString() {
        return "" + this.a;
    }
}
