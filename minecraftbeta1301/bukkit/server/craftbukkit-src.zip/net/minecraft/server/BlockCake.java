// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockCake extends Block
{
    protected BlockCake(final int n, final int n2) {
        super(n, n2, Material.CAKE);
        this.a(true);
    }
    
    @Override
    public void a(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
        final int data = blockAccess.getData(n, n2, n3);
        final float n4 = 0.0625f;
        this.a((1 + data * 2) / 16.0f, 0.0f, n4, 1.0f - n4, 0.5f, 1.0f - n4);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int i, final int j, final int k) {
        final int data = world.getData(i, j, k);
        final float n = 0.0625f;
        return AxisAlignedBB.b(i + (1 + data * 2) / 16.0f, j, k + n, i + 1 - n, j + 0.5f - n, k + 1 - n);
    }
    
    @Override
    public int a(final int n, final int n2) {
        if (n == 1) {
            return this.textureId;
        }
        if (n == 0) {
            return this.textureId + 3;
        }
        if (n2 > 0 && n == 4) {
            return this.textureId + 2;
        }
        return this.textureId + 1;
    }
    
    @Override
    public int a(final int n) {
        if (n == 1) {
            return this.textureId;
        }
        if (n == 0) {
            return this.textureId + 3;
        }
        return this.textureId + 1;
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        this.c(world, n, n2, n3, entityHuman);
        return true;
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        this.c(world, n, n2, n3, entityHuman);
    }
    
    private void c(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        if (entityHuman.health < 20) {
            entityHuman.b(3);
            final int l = world.getData(n, n2, n3) + 1;
            if (l >= 6) {
                world.e(n, n2, n3, 0);
            }
            else {
                world.c(n, n2, n3, l);
                world.h(n, n2, n3);
            }
        }
    }
    
    @Override
    public boolean a(final World world, final int n, final int n2, final int n3) {
        return super.a(world, n, n2, n3) && this.f(world, n, n2, n3);
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        if (!this.f(world, n, n2, n3)) {
            this.b_(world, n, n2, n3, world.getData(n, n2, n3));
            world.e(n, n2, n3, 0);
        }
    }
    
    @Override
    public boolean f(final World world, final int i, final int n, final int k) {
        return world.getMaterial(i, n - 1, k).isBuildable();
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
    
    @Override
    public int a(final int n, final Random random) {
        return 0;
    }
}
