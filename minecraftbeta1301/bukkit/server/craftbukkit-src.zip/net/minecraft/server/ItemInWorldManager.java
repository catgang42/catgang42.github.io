// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.Event;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.entity.Player;

public class ItemInWorldManager
{
    private World b;
    public EntityHuman a;
    public float c;
    private int d;
    private int e;
    private float f;
    private int g;
    private int h;
    private int i;
    private int j;
    private boolean k;
    private int l;
    private int m;
    private int n;
    private int o;
    
    public ItemInWorldManager(final World world) {
        this.c = 0.0f;
        this.e = 0;
        this.f = 0.0f;
        this.b = world;
    }
    
    public void a() {
        ++this.j;
        if (this.k) {
            final int i = this.j - this.o;
            final int j = this.b.getTypeId(this.l, this.m, this.n);
            if (j != 0) {
                final Block block = Block.byId[j];
                final float f = block.a(this.a) * (i + 1);
                if (f >= 1.0f) {
                    this.k = false;
                    this.d(this.l, this.m, this.n);
                }
            }
            else {
                this.k = false;
            }
        }
    }
    
    public void a(final int i, final int j, final int k) {
        this.d = this.j;
        final int l = this.b.getTypeId(i, j, k);
        if (l > 0) {
            Block.byId[l].b(this.b, i, j, k, this.a);
        }
        if (l > 0 && Block.byId[l].a(this.a) >= 1.0f) {
            this.d(i, j, k);
        }
        else {
            this.g = i;
            this.h = j;
            this.i = k;
        }
    }
    
    public void b(final int i, final int j, final int k) {
        if (i == this.g && j == this.h && k == this.i) {
            final int l = this.j - this.d;
            final int i2 = this.b.getTypeId(i, j, k);
            if (i2 != 0) {
                final Block block = Block.byId[i2];
                final float f = block.a(this.a) * (l + 1);
                if (f >= 1.0f) {
                    this.d(i, j, k);
                }
                else if (!this.k) {
                    this.k = true;
                    this.l = i;
                    this.m = j;
                    this.n = k;
                    this.o = this.d;
                }
            }
        }
        this.c = 0.0f;
        this.e = 0;
    }
    
    public boolean c(final int i, final int j, final int k) {
        final Block block = Block.byId[this.b.getTypeId(i, j, k)];
        final int l = this.b.getData(i, j, k);
        final boolean flag = this.b.e(i, j, k, 0);
        if (block != null && flag) {
            block.b(this.b, i, j, k, l);
        }
        return flag;
    }
    
    public boolean d(final int i, final int j, final int k) {
        if (this.a instanceof EntityPlayer) {
            final CraftServer server = ((WorldServer)this.b).getServer();
            final org.bukkit.block.Block block = ((WorldServer)this.b).getWorld().getBlockAt(i, j, k);
            final Player player = (Player)this.a.getBukkitEntity();
            final BlockBreakEvent event = new BlockBreakEvent(block, player);
            server.getPluginManager().callEvent(event);
            if (event.isCancelled()) {
                MinecraftServer.a.info("A plugin cancelled the block break event");
                return false;
            }
        }
        final int l = this.b.getTypeId(i, j, k);
        final int i2 = this.b.getData(i, j, k);
        final boolean flag = this.c(i, j, k);
        final ItemStack itemstack = this.a.z();
        if (itemstack != null) {
            itemstack.a(l, i, j, k);
            if (itemstack.count == 0) {
                itemstack.a(this.a);
                this.a.A();
            }
        }
        if (flag && this.a.b(Block.byId[l])) {
            Block.byId[l].a_(this.b, i, j, k, i2);
            ((EntityPlayer)this.a).a.b(new Packet53BlockChange(i, j, k, this.b));
        }
        return flag;
    }
    
    public boolean a(final EntityHuman entityhuman, final World world, final ItemStack itemstack) {
        final int i = itemstack.count;
        final ItemStack itemstack2 = itemstack.a(world, entityhuman);
        if (itemstack2 == itemstack && (itemstack2 == null || itemstack2.count == i)) {
            return false;
        }
        entityhuman.inventory.a[entityhuman.inventory.c] = itemstack2;
        if (itemstack2.count == 0) {
            entityhuman.inventory.a[entityhuman.inventory.c] = null;
        }
        return true;
    }
    
    public boolean a(final EntityHuman entityhuman, final World world, final ItemStack itemstack, final int i, final int j, final int k, final int l) {
        final int i2 = world.getTypeId(i, j, k);
        return (i2 > 0 && Block.byId[i2].a(world, i, j, k, entityhuman)) || (itemstack != null && itemstack.a(entityhuman, world, i, j, k, l));
    }
}
