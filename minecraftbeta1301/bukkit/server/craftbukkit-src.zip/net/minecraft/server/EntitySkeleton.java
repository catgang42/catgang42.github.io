// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Iterator;
import org.bukkit.Server;
import org.bukkit.craftbukkit.CraftWorld;
import java.util.List;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.Material;
import java.util.ArrayList;
import org.bukkit.entity.Entity;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.entity.EntityCombustEvent;
import org.bukkit.event.Event;

public class EntitySkeleton extends EntityMonster
{
    private static final ItemStack a;
    
    public EntitySkeleton(final World world) {
        super(world);
        this.texture = "/mob/skeleton.png";
    }
    
    @Override
    protected String e() {
        return "mob.skeleton";
    }
    
    @Override
    protected String f() {
        return "mob.skeletonhurt";
    }
    
    @Override
    protected String g() {
        return "mob.skeletonhurt";
    }
    
    @Override
    public void q() {
        if (this.world.c()) {
            final float f = this.c(1.0f);
            if (f > 0.5f && this.world.i(MathHelper.b(this.locX), MathHelper.b(this.locY), MathHelper.b(this.locZ)) && this.random.nextFloat() * 30.0f < (f - 0.4f) * 2.0f) {
                final CraftServer server = ((WorldServer)this.world).getServer();
                final Event.Type eventType = Event.Type.ENTITY_COMBUST;
                final org.bukkit.entity.Entity entity = this.getBukkitEntity();
                final EntityCombustEvent event = new EntityCombustEvent(eventType, entity);
                server.getPluginManager().callEvent(event);
                if (!event.isCancelled()) {
                    this.fireTicks = 300;
                }
            }
        }
        super.q();
    }
    
    @Override
    protected void a(final Entity entity, final float f) {
        if (f < 10.0f) {
            final double d0 = entity.locX - this.locX;
            final double d2 = entity.locZ - this.locZ;
            if (this.attackTicks == 0) {
                final EntityArrow entityArrow;
                final EntityArrow entityarrow = entityArrow = new EntityArrow(this.world, this);
                ++entityArrow.locY;
                final double d3 = entity.locY - 0.20000000298023224 - entityarrow.locY;
                final float f2 = MathHelper.a(d0 * d0 + d2 * d2) * 0.2f;
                this.world.a(this, "random.bow", 1.0f, 1.0f / (this.random.nextFloat() * 0.4f + 0.8f));
                this.world.a(entityarrow);
                entityarrow.a(d0, d3 + f2, d2, 0.6f, 12.0f);
                this.attackTicks = 30;
            }
            this.yaw = (float)(Math.atan2(d2, d0) * 180.0 / 3.1415927410125732) - 90.0f;
            this.e = true;
        }
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
    }
    
    @Override
    protected int h() {
        return Item.ARROW.id;
    }
    
    @Override
    protected void o() {
        final List<org.bukkit.inventory.ItemStack> loot = new ArrayList<org.bukkit.inventory.ItemStack>();
        int count = this.random.nextInt(3);
        if (count > 0) {
            loot.add(new org.bukkit.inventory.ItemStack(Material.ARROW, count));
        }
        count = this.random.nextInt(3);
        if (count > 0) {
            loot.add(new org.bukkit.inventory.ItemStack(Material.BONE, count));
        }
        final CraftWorld cworld = ((WorldServer)this.world).getWorld();
        final Server server = ((WorldServer)this.world).getServer();
        final CraftEntity entity = (CraftEntity)this.getBukkitEntity();
        final EntityDeathEvent event = new EntityDeathEvent(Event.Type.ENTITY_DEATH, entity, loot);
        server.getPluginManager().callEvent(event);
        for (final org.bukkit.inventory.ItemStack stack : event.getDrops()) {
            cworld.dropItemNaturally(entity.getLocation(), stack);
        }
    }
    
    static {
        a = new ItemStack(Item.BOW, 1);
    }
}
