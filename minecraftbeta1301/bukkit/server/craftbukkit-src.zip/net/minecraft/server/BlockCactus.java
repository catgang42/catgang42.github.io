// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityDamageByBlockEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import java.util.Random;

public class BlockCactus extends Block
{
    protected BlockCactus(final int i, final int j) {
        super(i, j, Material.CACTUS);
        this.a(true);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (world.isEmpty(i, j + 1, k)) {
            int l;
            for (l = 1; world.getTypeId(i, j - l, k) == this.id; ++l) {}
            if (l < 3) {
                final int i2 = world.getData(i, j, k);
                if (i2 == 15) {
                    world.e(i, j + 1, k, this.id);
                    world.c(i, j, k, 0);
                }
                else {
                    world.c(i, j, k, i2 + 1);
                }
            }
        }
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int i, final int j, final int k) {
        final float f = 0.0625f;
        return AxisAlignedBB.b(i + f, j, k + f, i + 1 - f, j + 1 - f, k + 1 - f);
    }
    
    @Override
    public int a(final int i) {
        return (i == 1) ? (this.textureId - 1) : ((i == 0) ? (this.textureId + 1) : this.textureId);
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    @Override
    public boolean a(final World world, final int i, final int j, final int k) {
        return super.a(world, i, j, k) && this.f(world, i, j, k);
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final int l) {
        if (!this.f(world, i, j, k)) {
            this.b_(world, i, j, k, world.getData(i, j, k));
            world.e(i, j, k, 0);
        }
    }
    
    @Override
    public boolean f(final World world, final int i, final int j, final int k) {
        if (world.getMaterial(i - 1, j, k).isBuildable()) {
            return false;
        }
        if (world.getMaterial(i + 1, j, k).isBuildable()) {
            return false;
        }
        if (world.getMaterial(i, j, k - 1).isBuildable()) {
            return false;
        }
        if (world.getMaterial(i, j, k + 1).isBuildable()) {
            return false;
        }
        final int l = world.getTypeId(i, j - 1, k);
        return l == Block.CACTUS.id || l == Block.SAND.id;
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Entity entity) {
        if (entity instanceof EntityLiving) {
            final CraftServer server = ((WorldServer)world).getServer();
            final org.bukkit.block.Block damager = ((WorldServer)world).getWorld().getBlockAt(i, j, k);
            final org.bukkit.entity.Entity damagee = (entity == null) ? null : entity.getBukkitEntity();
            final EntityDamageEvent.DamageCause damageType = EntityDamageEvent.DamageCause.CONTACT;
            final int damageDone = 1;
            final EntityDamageByBlockEvent event = new EntityDamageByBlockEvent(damager, damagee, damageType, damageDone);
            server.getPluginManager().callEvent(event);
            if (!event.isCancelled()) {
                entity.a(null, event.getDamage());
            }
            return;
        }
        entity.a(null, 1);
    }
}
