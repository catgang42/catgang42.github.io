// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.ArrayList;
import java.util.List;

public class PlayerManager
{
    private List a;
    private PlayerList b;
    private List c;
    private MinecraftServer d;
    private final int[][] e;
    public WorldServer world;
    
    public PlayerManager(final MinecraftServer minecraftserver, final WorldServer world) {
        this.a = new ArrayList();
        this.b = new PlayerList();
        this.c = new ArrayList();
        this.e = new int[][] { { 1, 0 }, { 0, 1 }, { -1, 0 }, { 0, -1 } };
        this.d = minecraftserver;
        this.world = world;
    }
    
    public void a() {
        for (int i = 0; i < this.c.size(); ++i) {
            this.c.get(i).a();
        }
        this.c.clear();
    }
    
    private PlayerInstance a(final int i, final int j, final boolean flag) {
        final long k = i + 2147483647L | j + 2147483647L << 32;
        PlayerInstance playerinstance = (PlayerInstance)this.b.a(k);
        if (playerinstance == null && flag) {
            playerinstance = new PlayerInstance(this, i, j);
            this.b.a(k, playerinstance);
        }
        return playerinstance;
    }
    
    public void a(final int i, final int j, final int k) {
        final int l = i >> 4;
        final int i2 = k >> 4;
        final PlayerInstance playerinstance = this.a(l, i2, false);
        if (playerinstance != null) {
            playerinstance.a(i & 0xF, j, k & 0xF);
        }
    }
    
    public void a(final EntityPlayer entityplayer) {
        final int i = (int)entityplayer.locX >> 4;
        final int j = (int)entityplayer.locZ >> 4;
        entityplayer.d = entityplayer.locX;
        entityplayer.e = entityplayer.locZ;
        int k = 0;
        final byte b0 = 10;
        int l = 0;
        int i2 = 0;
        this.a(i, j, true).a(entityplayer);
        for (int j2 = 1; j2 <= b0 * 2; ++j2) {
            for (int k2 = 0; k2 < 2; ++k2) {
                final int[] aint = this.e[k++ % 4];
                for (int l2 = 0; l2 < j2; ++l2) {
                    l += aint[0];
                    i2 += aint[1];
                    this.a(i + l, j + i2, true).a(entityplayer);
                }
            }
        }
        k %= 4;
        for (int j2 = 0; j2 < b0 * 2; ++j2) {
            l += this.e[k][0];
            i2 += this.e[k][1];
            this.a(i + l, j + i2, true).a(entityplayer);
        }
        this.a.add(entityplayer);
    }
    
    public void b(final EntityPlayer entityplayer) {
        final int i = (int)entityplayer.d >> 4;
        final int j = (int)entityplayer.e >> 4;
        for (int k = i - 10; k <= i + 10; ++k) {
            for (int l = j - 10; l <= j + 10; ++l) {
                final PlayerInstance playerinstance = this.a(k, l, false);
                if (playerinstance != null) {
                    playerinstance.b(entityplayer);
                }
            }
        }
        this.a.remove(entityplayer);
    }
    
    private boolean a(final int i, final int j, final int k, final int l) {
        final int i2 = i - k;
        final int j2 = j - l;
        return i2 >= -10 && i2 <= 10 && (j2 >= -10 && j2 <= 10);
    }
    
    public void c(final EntityPlayer entityplayer) {
        final int i = (int)entityplayer.locX >> 4;
        final int j = (int)entityplayer.locZ >> 4;
        final double d0 = entityplayer.d - entityplayer.locX;
        final double d2 = entityplayer.e - entityplayer.locZ;
        final double d3 = d0 * d0 + d2 * d2;
        if (d3 >= 64.0) {
            final int k = (int)entityplayer.d >> 4;
            final int l = (int)entityplayer.e >> 4;
            final int i2 = i - k;
            final int j2 = j - l;
            if (!this.a(i, j, k, l)) {
                this.a(i, j, true).a(entityplayer);
            }
            if (!this.a(i - i2, j - j2, i, j)) {
                final PlayerInstance playerinstance = this.a(i - i2, j - j2, false);
                if (playerinstance != null) {
                    playerinstance.b(entityplayer);
                }
            }
            if (i2 != 0 || j2 != 0) {
                for (int k2 = i - 10; k2 <= i + 10; ++k2) {
                    for (int l2 = j - 10; l2 <= j + 10; ++l2) {
                        if (k2 != i || l2 != j) {
                            if (!this.a(k2, l2, k, l)) {
                                this.a(k2, l2, true).a(entityplayer);
                            }
                            if (!this.a(k2 - i2, l2 - j2, i, j)) {
                                final PlayerInstance playerinstance2 = this.a(k2 - i2, l2 - j2, false);
                                if (playerinstance2 != null) {
                                    playerinstance2.b(entityplayer);
                                }
                            }
                        }
                    }
                }
                entityplayer.d = entityplayer.locX;
                entityplayer.e = entityplayer.locZ;
            }
        }
    }
    
    public int b() {
        return 144;
    }
    
    static MinecraftServer a(final PlayerManager playermanager) {
        return playermanager.d;
    }
    
    static PlayerList b(final PlayerManager playermanager) {
        return playermanager.b;
    }
    
    static List c(final PlayerManager playermanager) {
        return playermanager.c;
    }
}
