// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockPortal extends BlockBreakable
{
    public BlockPortal(final int n, final int n2) {
        super(n, n2, Material.PORTAL, false);
    }
    
    @Override
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return null;
    }
    
    @Override
    public void a(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
        if (blockAccess.getTypeId(n - 1, n2, n3) == this.id || blockAccess.getTypeId(n + 1, n2, n3) == this.id) {
            final float n4 = 0.5f;
            final float n5 = 0.125f;
            this.a(0.5f - n4, 0.0f, 0.5f - n5, 0.5f + n4, 1.0f, 0.5f + n5);
        }
        else {
            final float n6 = 0.125f;
            final float n7 = 0.5f;
            this.a(0.5f - n6, 0.0f, 0.5f - n7, 0.5f + n6, 1.0f, 0.5f + n7);
        }
    }
    
    @Override
    public boolean a() {
        return false;
    }
    
    public boolean a_(final World world, int n, final int j, int n2) {
        int i = 0;
        int k = 0;
        if (world.getTypeId(n - 1, j, n2) == Block.OBSIDIAN.id || world.getTypeId(n + 1, j, n2) == Block.OBSIDIAN.id) {
            i = 1;
        }
        if (world.getTypeId(n, j, n2 - 1) == Block.OBSIDIAN.id || world.getTypeId(n, j, n2 + 1) == Block.OBSIDIAN.id) {
            k = 1;
        }
        System.out.println(i + ", " + k);
        if (i == k) {
            return false;
        }
        if (world.getTypeId(n - i, j, n2 - k) == 0) {
            n -= i;
            n2 -= k;
        }
        for (int l = -1; l <= 2; ++l) {
            for (int n3 = -1; n3 <= 3; ++n3) {
                final boolean b = l == -1 || l == 2 || n3 == -1 || n3 == 3;
                if (l == -1 || l == 2) {
                    if (n3 == -1) {
                        continue;
                    }
                    if (n3 == 3) {
                        continue;
                    }
                }
                final int typeId = world.getTypeId(n + i * l, j + n3, n2 + k * l);
                if (b) {
                    if (typeId != Block.OBSIDIAN.id) {
                        return false;
                    }
                }
                else if (typeId != 0 && typeId != Block.FIRE.id) {
                    return false;
                }
            }
        }
        world.h = true;
        for (int n4 = 0; n4 < 2; ++n4) {
            for (int n5 = 0; n5 < 3; ++n5) {
                world.e(n + i * n4, j + n5, n2 + k * n4, Block.PORTAL.id);
            }
        }
        world.h = false;
        return true;
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
        int n5 = 0;
        int n6 = 1;
        if (world.getTypeId(n - 1, n2, n3) == this.id || world.getTypeId(n + 1, n2, n3) == this.id) {
            n5 = 1;
            n6 = 0;
        }
        int n7;
        for (n7 = n2; world.getTypeId(n, n7 - 1, n3) == this.id; --n7) {}
        if (world.getTypeId(n, n7 - 1, n3) != Block.OBSIDIAN.id) {
            world.e(n, n2, n3, 0);
            return;
        }
        int n8;
        for (n8 = 1; n8 < 4 && world.getTypeId(n, n7 + n8, n3) == this.id; ++n8) {}
        if (n8 != 3 || world.getTypeId(n, n7 + n8, n3) != Block.OBSIDIAN.id) {
            world.e(n, n2, n3, 0);
            return;
        }
        final boolean b = world.getTypeId(n - 1, n2, n3) == this.id || world.getTypeId(n + 1, n2, n3) == this.id;
        final boolean b2 = world.getTypeId(n, n2, n3 - 1) == this.id || world.getTypeId(n, n2, n3 + 1) == this.id;
        if (b && b2) {
            world.e(n, n2, n3, 0);
            return;
        }
        if ((world.getTypeId(n + n5, n2, n3 + n6) != Block.OBSIDIAN.id || world.getTypeId(n - n5, n2, n3 - n6) != this.id) && (world.getTypeId(n - n5, n2, n3 - n6) != Block.OBSIDIAN.id || world.getTypeId(n + n5, n2, n3 + n6) != this.id)) {
            world.e(n, n2, n3, 0);
        }
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        return true;
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
    
    @Override
    public void a(final World world, final int n, final int n2, final int n3, final Entity entity) {
        if (world.isStatic) {
            return;
        }
        entity.T();
    }
}
