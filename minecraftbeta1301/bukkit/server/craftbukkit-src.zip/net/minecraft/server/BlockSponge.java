// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BlockSponge extends Block
{
    protected BlockSponge(final int n) {
        super(n, Material.SPONGE);
        this.textureId = 48;
    }
    
    @Override
    public void e(final World world, final int n, final int n2, final int n3) {
        for (int n4 = 2, i = n - n4; i <= n + n4; ++i) {
            for (int j = n2 - n4; j <= n2 + n4; ++j) {
                for (int k = n3 - n4; k <= n3 + n4; ++k) {
                    if (world.getMaterial(i, j, k) == Material.WATER) {}
                }
            }
        }
    }
    
    @Override
    public void b(final World world, final int n, final int n2, final int n3) {
        for (int n4 = 2, i = n - n4; i <= n + n4; ++i) {
            for (int j = n2 - n4; j <= n2 + n4; ++j) {
                for (int k = n3 - n4; k <= n3 + n4; ++k) {
                    world.h(i, j, k, world.getTypeId(i, j, k));
                }
            }
        }
    }
}
