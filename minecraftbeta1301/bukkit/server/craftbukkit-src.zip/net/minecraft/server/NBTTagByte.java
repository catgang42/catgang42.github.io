// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public class NBTTagByte extends NBTBase
{
    public byte a;
    
    public NBTTagByte() {
    }
    
    public NBTTagByte(final byte a) {
        this.a = a;
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        dataOutput.writeByte(this.a);
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.a = dataInput.readByte();
    }
    
    @Override
    public byte a() {
        return 1;
    }
    
    @Override
    public String toString() {
        return "" + this.a;
    }
}
