// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.util.zip.DataFormatException;
import java.io.IOException;
import java.util.zip.Inflater;
import java.io.DataInputStream;
import java.util.zip.Deflater;

public class Packet51MapChunk extends Packet
{
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public byte[] g;
    private int h;
    
    public Packet51MapChunk() {
        this.k = true;
    }
    
    public Packet51MapChunk(final int n, final int n2, final int n3, final int n4, final int n5, final int n6, final World world) {
        this.k = true;
        this.a = n;
        this.b = n2;
        this.c = n3;
        this.d = n4;
        this.e = n5;
        this.f = n6;
        final byte[] c = world.c(n, n2, n3, n4, n5, n6);
        final Deflater deflater = new Deflater(1);
        try {
            deflater.setInput(c);
            deflater.finish();
            this.g = new byte[n4 * n5 * n6 * 5 / 2];
            this.h = deflater.deflate(this.g);
        }
        finally {
            deflater.end();
        }
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readShort();
        this.c = dataInputStream.readInt();
        this.d = dataInputStream.read() + 1;
        this.e = dataInputStream.read() + 1;
        this.f = dataInputStream.read() + 1;
        this.h = dataInputStream.readInt();
        final byte[] array = new byte[this.h];
        dataInputStream.readFully(array);
        this.g = new byte[this.d * this.e * this.f * 5 / 2];
        final Inflater inflater = new Inflater();
        inflater.setInput(array);
        try {
            inflater.inflate(this.g);
        }
        catch (DataFormatException ex) {
            throw new IOException("Bad compressed data format");
        }
        finally {
            inflater.end();
        }
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeShort(this.b);
        dataOutputStream.writeInt(this.c);
        dataOutputStream.write(this.d - 1);
        dataOutputStream.write(this.e - 1);
        dataOutputStream.write(this.f - 1);
        dataOutputStream.writeInt(this.h);
        dataOutputStream.write(this.g, 0, this.h);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 17 + this.h;
    }
}
