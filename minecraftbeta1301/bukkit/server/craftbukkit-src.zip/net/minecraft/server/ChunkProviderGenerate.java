// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class ChunkProviderGenerate implements IChunkProvider
{
    private Random j;
    private NoiseGeneratorOctaves k;
    private NoiseGeneratorOctaves l;
    private NoiseGeneratorOctaves m;
    private NoiseGeneratorOctaves n;
    private NoiseGeneratorOctaves o;
    public NoiseGeneratorOctaves a;
    public NoiseGeneratorOctaves b;
    public NoiseGeneratorOctaves c;
    private World p;
    private double[] q;
    private double[] r;
    private double[] s;
    private double[] t;
    private MapGenBase u;
    private BiomeBase[] v;
    double[] d;
    double[] e;
    double[] f;
    double[] g;
    double[] h;
    int[][] i;
    private double[] w;
    
    public ChunkProviderGenerate(final World p2, final long seed) {
        this.r = new double[256];
        this.s = new double[256];
        this.t = new double[256];
        this.u = new MapGenCaves();
        this.i = new int[32][32];
        this.p = p2;
        this.j = new Random(seed);
        this.k = new NoiseGeneratorOctaves(this.j, 16);
        this.l = new NoiseGeneratorOctaves(this.j, 16);
        this.m = new NoiseGeneratorOctaves(this.j, 8);
        this.n = new NoiseGeneratorOctaves(this.j, 4);
        this.o = new NoiseGeneratorOctaves(this.j, 4);
        this.a = new NoiseGeneratorOctaves(this.j, 10);
        this.b = new NoiseGeneratorOctaves(this.j, 16);
        this.c = new NoiseGeneratorOctaves(this.j, 8);
    }
    
    public void a(final int n, final int n2, final byte[] array, final BiomeBase[] array2, final double[] array3) {
        final int n3 = 4;
        final int n4 = 64;
        final int n5 = n3 + 1;
        final int n6 = 17;
        final int n7 = n3 + 1;
        this.q = this.a(this.q, n * n3, 0, n2 * n3, n5, n6, n7);
        for (int i = 0; i < n3; ++i) {
            for (int j = 0; j < n3; ++j) {
                for (int k = 0; k < 16; ++k) {
                    final double n8 = 0.125;
                    double n9 = this.q[((i + 0) * n7 + (j + 0)) * n6 + (k + 0)];
                    double n10 = this.q[((i + 0) * n7 + (j + 1)) * n6 + (k + 0)];
                    double n11 = this.q[((i + 1) * n7 + (j + 0)) * n6 + (k + 0)];
                    double n12 = this.q[((i + 1) * n7 + (j + 1)) * n6 + (k + 0)];
                    final double n13 = (this.q[((i + 0) * n7 + (j + 0)) * n6 + (k + 1)] - n9) * n8;
                    final double n14 = (this.q[((i + 0) * n7 + (j + 1)) * n6 + (k + 1)] - n10) * n8;
                    final double n15 = (this.q[((i + 1) * n7 + (j + 0)) * n6 + (k + 1)] - n11) * n8;
                    final double n16 = (this.q[((i + 1) * n7 + (j + 1)) * n6 + (k + 1)] - n12) * n8;
                    for (int l = 0; l < 8; ++l) {
                        final double n17 = 0.25;
                        double n18 = n9;
                        double n19 = n10;
                        final double n20 = (n11 - n9) * n17;
                        final double n21 = (n12 - n10) * n17;
                        for (int n22 = 0; n22 < 4; ++n22) {
                            int n23 = n22 + i * 4 << 11 | 0 + j * 4 << 7 | k * 8 + l;
                            final int n24 = 128;
                            final double n25 = 0.25;
                            double n26 = n18;
                            final double n27 = (n19 - n18) * n25;
                            for (int n28 = 0; n28 < 4; ++n28) {
                                final double n29 = array3[(i * 4 + n22) * 16 + (j * 4 + n28)];
                                int n30 = 0;
                                if (k * 8 + l < n4) {
                                    if (n29 < 0.5 && k * 8 + l >= n4 - 1) {
                                        n30 = Block.ICE.id;
                                    }
                                    else {
                                        n30 = Block.STATIONARY_WATER.id;
                                    }
                                }
                                if (n26 > 0.0) {
                                    n30 = Block.STONE.id;
                                }
                                array[n23] = (byte)n30;
                                n23 += n24;
                                n26 += n27;
                            }
                            n18 += n20;
                            n19 += n21;
                        }
                        n9 += n13;
                        n10 += n14;
                        n11 += n15;
                        n12 += n16;
                    }
                }
            }
        }
    }
    
    public void a(final int n, final int n2, final byte[] array, final BiomeBase[] array2) {
        final int n3 = 64;
        final double n4 = 0.03125;
        this.r = this.n.a(this.r, n * 16, n2 * 16, 0.0, 16, 16, 1, n4, n4, 1.0);
        this.s = this.n.a(this.s, n * 16, 109.0134, n2 * 16, 16, 1, 16, n4, 1.0, n4);
        this.t = this.o.a(this.t, n * 16, n2 * 16, 0.0, 16, 16, 1, n4 * 2.0, n4 * 2.0, n4 * 2.0);
        for (int i = 0; i < 16; ++i) {
            for (int j = 0; j < 16; ++j) {
                final BiomeBase biomeBase = array2[i + j * 16];
                final boolean b = this.r[i + j * 16] + this.j.nextDouble() * 0.2 > 0.0;
                final boolean b2 = this.s[i + j * 16] + this.j.nextDouble() * 0.2 > 3.0;
                final int n5 = (int)(this.t[i + j * 16] / 3.0 + 3.0 + this.j.nextDouble() * 0.25);
                int nextInt = -1;
                byte b3 = biomeBase.o;
                byte b4 = biomeBase.p;
                for (int k = 127; k >= 0; --k) {
                    final int n6 = (j * 16 + i) * 128 + k;
                    if (k <= 0 + this.j.nextInt(5)) {
                        array[n6] = (byte)Block.BEDROCK.id;
                    }
                    else {
                        final byte b5 = array[n6];
                        if (b5 == 0) {
                            nextInt = -1;
                        }
                        else if (b5 == Block.STONE.id) {
                            if (nextInt == -1) {
                                if (n5 <= 0) {
                                    b3 = 0;
                                    b4 = (byte)Block.STONE.id;
                                }
                                else if (k >= n3 - 4 && k <= n3 + 1) {
                                    b3 = biomeBase.o;
                                    b4 = biomeBase.p;
                                    if (b2) {
                                        b3 = 0;
                                    }
                                    if (b2) {
                                        b4 = (byte)Block.GRAVEL.id;
                                    }
                                    if (b) {
                                        b3 = (byte)Block.SAND.id;
                                    }
                                    if (b) {
                                        b4 = (byte)Block.SAND.id;
                                    }
                                }
                                if (k < n3 && b3 == 0) {
                                    b3 = (byte)Block.STATIONARY_WATER.id;
                                }
                                nextInt = n5;
                                if (k >= n3 - 1) {
                                    array[n6] = b3;
                                }
                                else {
                                    array[n6] = b4;
                                }
                            }
                            else if (nextInt > 0) {
                                --nextInt;
                                array[n6] = b4;
                                if (nextInt == 0 && b4 == Block.SAND.id) {
                                    nextInt = this.j.nextInt(4);
                                    b4 = (byte)Block.SANDSTONE.id;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    public Chunk b(final int i, final int j) {
        this.j.setSeed(i * 341873128712L + j * 132897987541L);
        final byte[] abyte = new byte[32768];
        final Chunk chunk = new Chunk(this.p, abyte, i, j);
        this.a(i, j, abyte, this.v = this.p.a().a(this.v, i * 16, j * 16, 16, 16), this.p.a().a);
        this.a(i, j, abyte, this.v);
        this.u.a(this, this.p, i, j, abyte);
        chunk.b();
        return chunk;
    }
    
    private double[] a(double[] array, final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        if (array == null) {
            array = new double[n4 * n5 * n6];
        }
        final double n7 = 684.412;
        final double n8 = 684.412;
        final double[] a = this.p.a().a;
        final double[] b = this.p.a().b;
        this.g = this.a.a(this.g, n, n3, n4, n6, 1.121, 1.121, 0.5);
        this.h = this.b.a(this.h, n, n3, n4, n6, 200.0, 200.0, 0.5);
        this.d = this.m.a(this.d, n, n2, n3, n4, n5, n6, n7 / 80.0, n8 / 160.0, n7 / 80.0);
        this.e = this.k.a(this.e, n, n2, n3, n4, n5, n6, n7, n8, n7);
        this.f = this.l.a(this.f, n, n2, n3, n4, n5, n6, n7, n8, n7);
        int n9 = 0;
        int n10 = 0;
        final int n11 = 16 / n4;
        for (int i = 0; i < n4; ++i) {
            final int n12 = i * n11 + n11 / 2;
            for (int j = 0; j < n6; ++j) {
                final int n13 = j * n11 + n11 / 2;
                final double n14 = 1.0 - b[n12 * 16 + n13] * a[n12 * 16 + n13];
                final double n15 = n14 * n14;
                double n16 = (this.g[n10] + 256.0) / 512.0 * (1.0 - n15 * n15);
                if (n16 > 1.0) {
                    n16 = 1.0;
                }
                double n17 = this.h[n10] / 8000.0;
                if (n17 < 0.0) {
                    n17 = -n17 * 0.3;
                }
                double n18 = n17 * 3.0 - 2.0;
                double n20;
                if (n18 < 0.0) {
                    double n19 = n18 / 2.0;
                    if (n19 < -1.0) {
                        n19 = -1.0;
                    }
                    n20 = n19 / 1.4 / 2.0;
                    n16 = 0.0;
                }
                else {
                    if (n18 > 1.0) {
                        n18 = 1.0;
                    }
                    n20 = n18 / 8.0;
                }
                if (n16 < 0.0) {
                    n16 = 0.0;
                }
                final double n21 = n16 + 0.5;
                final double n22 = n5 / 2.0 + n20 * n5 / 16.0 * 4.0;
                ++n10;
                for (int k = 0; k < n5; ++k) {
                    double n23 = (k - n22) * 12.0 / n21;
                    if (n23 < 0.0) {
                        n23 *= 4.0;
                    }
                    final double n24 = this.e[n9] / 512.0;
                    final double n25 = this.f[n9] / 512.0;
                    final double n26 = (this.d[n9] / 10.0 + 1.0) / 2.0;
                    double n27;
                    if (n26 < 0.0) {
                        n27 = n24;
                    }
                    else if (n26 > 1.0) {
                        n27 = n25;
                    }
                    else {
                        n27 = n24 + (n25 - n24) * n26;
                    }
                    double n28 = n27 - n23;
                    if (k > n5 - 4) {
                        final double n29 = (k - (n5 - 4)) / 3.0f;
                        n28 = n28 * (1.0 - n29) + -10.0 * n29;
                    }
                    array[n9] = n28;
                    ++n9;
                }
            }
        }
        return array;
    }
    
    public boolean a(final int n, final int n2) {
        return true;
    }
    
    public void a(final IChunkProvider chunkProvider, final int n, final int n2) {
        BlockSand.a = true;
        final int n3 = n * 16;
        final int n4 = n2 * 16;
        final BiomeBase a = this.p.a().a(n3 + 16, n4 + 16);
        this.j.setSeed(this.p.j());
        this.j.setSeed(n * (this.j.nextLong() / 2L * 2L + 1L) + n2 * (this.j.nextLong() / 2L * 2L + 1L) ^ this.p.j());
        if (this.j.nextInt(4) == 0) {
            new WorldGenLakes(Block.STATIONARY_WATER.id).a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        if (this.j.nextInt(8) == 0) {
            final int n5 = n3 + this.j.nextInt(16) + 8;
            final int nextInt = this.j.nextInt(this.j.nextInt(120) + 8);
            final int n6 = n4 + this.j.nextInt(16) + 8;
            if (nextInt < 64 || this.j.nextInt(10) == 0) {
                new WorldGenLakes(Block.STATIONARY_LAVA.id).a(this.p, this.j, n5, nextInt, n6);
            }
        }
        for (int i = 0; i < 8; ++i) {
            new WorldGenDungeons().a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        for (int j = 0; j < 10; ++j) {
            new WorldGenClay(32).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(128), n4 + this.j.nextInt(16));
        }
        for (int k = 0; k < 20; ++k) {
            new WorldGenMinable(Block.DIRT.id, 32).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(128), n4 + this.j.nextInt(16));
        }
        for (int l = 0; l < 10; ++l) {
            new WorldGenMinable(Block.GRAVEL.id, 32).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(128), n4 + this.j.nextInt(16));
        }
        for (int n7 = 0; n7 < 20; ++n7) {
            new WorldGenMinable(Block.COAL_ORE.id, 16).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(128), n4 + this.j.nextInt(16));
        }
        for (int n8 = 0; n8 < 20; ++n8) {
            new WorldGenMinable(Block.IRON_ORE.id, 8).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(64), n4 + this.j.nextInt(16));
        }
        for (int n9 = 0; n9 < 2; ++n9) {
            new WorldGenMinable(Block.GOLD_ORE.id, 8).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(32), n4 + this.j.nextInt(16));
        }
        for (int n10 = 0; n10 < 8; ++n10) {
            new WorldGenMinable(Block.REDSTONE_ORE.id, 7).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(16), n4 + this.j.nextInt(16));
        }
        for (int n11 = 0; n11 < 1; ++n11) {
            new WorldGenMinable(Block.DIAMOND_ORE.id, 7).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(16), n4 + this.j.nextInt(16));
        }
        for (int n12 = 0; n12 < 1; ++n12) {
            new WorldGenMinable(Block.LAPIS_ORE.id, 6).a(this.p, this.j, n3 + this.j.nextInt(16), this.j.nextInt(16) + this.j.nextInt(16), n4 + this.j.nextInt(16));
        }
        final double n13 = 0.5;
        final int n14 = (int)((this.c.a(n3 * n13, n4 * n13) / 8.0 + this.j.nextDouble() * 4.0 + 4.0) / 3.0);
        int n15 = 0;
        if (this.j.nextInt(10) == 0) {
            ++n15;
        }
        if (a == BiomeBase.FOREST) {
            n15 += n14 + 5;
        }
        if (a == BiomeBase.RAINFOREST) {
            n15 += n14 + 5;
        }
        if (a == BiomeBase.SEASONAL_FOREST) {
            n15 += n14 + 2;
        }
        if (a == BiomeBase.TAIGA) {
            n15 += n14 + 5;
        }
        if (a == BiomeBase.DESERT) {
            n15 -= 20;
        }
        if (a == BiomeBase.TUNDRA) {
            n15 -= 20;
        }
        if (a == BiomeBase.PLAINS) {
            n15 -= 20;
        }
        for (int n16 = 0; n16 < n15; ++n16) {
            final int m = n3 + this.j.nextInt(16) + 8;
            final int j2 = n4 + this.j.nextInt(16) + 8;
            final WorldGenerator a2 = a.a(this.j);
            a2.a(1.0, 1.0, 1.0);
            a2.a(this.p, this.j, m, this.p.d(m, j2), j2);
        }
        for (int n17 = 0; n17 < 2; ++n17) {
            new WorldGenFlowers(Block.YELLOW_FLOWER.id).a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        if (this.j.nextInt(2) == 0) {
            new WorldGenFlowers(Block.RED_ROSE.id).a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        if (this.j.nextInt(4) == 0) {
            new WorldGenFlowers(Block.BROWN_MUSHROOM.id).a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        if (this.j.nextInt(8) == 0) {
            new WorldGenFlowers(Block.RED_MUSHROOM.id).a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        for (int n18 = 0; n18 < 10; ++n18) {
            new WorldGenReed().a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        if (this.j.nextInt(32) == 0) {
            new WorldGenPumpkin().a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        int n19 = 0;
        if (a == BiomeBase.DESERT) {
            n19 += 10;
        }
        for (int n20 = 0; n20 < n19; ++n20) {
            new WorldGenCactus().a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(128), n4 + this.j.nextInt(16) + 8);
        }
        for (int n21 = 0; n21 < 50; ++n21) {
            new WorldGenLiquids(Block.WATER.id).a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(this.j.nextInt(120) + 8), n4 + this.j.nextInt(16) + 8);
        }
        for (int n22 = 0; n22 < 20; ++n22) {
            new WorldGenLiquids(Block.LAVA.id).a(this.p, this.j, n3 + this.j.nextInt(16) + 8, this.j.nextInt(this.j.nextInt(this.j.nextInt(112) + 8) + 8), n4 + this.j.nextInt(16) + 8);
        }
        this.w = this.p.a().a(this.w, n3 + 8, n4 + 8, 16, 16);
        for (int i2 = n3 + 8; i2 < n3 + 8 + 16; ++i2) {
            for (int k2 = n4 + 8; k2 < n4 + 8 + 16; ++k2) {
                final int n23 = i2 - (n3 + 8);
                final int n24 = k2 - (n4 + 8);
                final int e = this.p.e(i2, k2);
                if (this.w[n23 * 16 + n24] - (e - 64) / 64.0 * 0.3 < 0.5 && e > 0 && e < 128 && this.p.isEmpty(i2, e, k2) && this.p.getMaterial(i2, e - 1, k2).isSolid() && this.p.getMaterial(i2, e - 1, k2) != Material.ICE) {
                    this.p.e(i2, e, k2, Block.SNOW.id);
                }
            }
        }
        BlockSand.a = false;
    }
    
    public boolean a(final boolean b, final IProgressUpdate progressUpdate) {
        return true;
    }
    
    public boolean a() {
        return false;
    }
    
    public boolean b() {
        return true;
    }
}
