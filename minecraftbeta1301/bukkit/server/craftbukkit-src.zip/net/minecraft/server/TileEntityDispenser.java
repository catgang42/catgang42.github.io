// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class TileEntityDispenser extends TileEntity implements IInventory
{
    private ItemStack[] a;
    private Random b;
    
    public ItemStack[] getContents() {
        return this.a;
    }
    
    public TileEntityDispenser() {
        this.a = new ItemStack[9];
        this.b = new Random();
    }
    
    public int m_() {
        return 9;
    }
    
    public ItemStack c_(final int i) {
        return this.a[i];
    }
    
    public ItemStack a(final int i, final int j) {
        if (this.a[i] == null) {
            return null;
        }
        if (this.a[i].count <= j) {
            final ItemStack itemstack = this.a[i];
            this.a[i] = null;
            this.h();
            return itemstack;
        }
        final ItemStack itemstack = this.a[i].a(j);
        if (this.a[i].count == 0) {
            this.a[i] = null;
        }
        this.h();
        return itemstack;
    }
    
    public ItemStack b() {
        int i = -1;
        int j = 1;
        for (int k = 0; k < this.a.length; ++k) {
            if (this.a[k] != null && this.b.nextInt(j) == 0) {
                i = k;
                ++j;
            }
        }
        if (i >= 0) {
            return this.a(i, 1);
        }
        return null;
    }
    
    public void a(final int i, final ItemStack itemstack) {
        this.a[i] = itemstack;
        if (itemstack != null && itemstack.count > this.n_()) {
            itemstack.count = this.n_();
        }
        this.h();
    }
    
    public String c() {
        return "Trap";
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
        final NBTTagList nbttaglist = nbttagcompound.l("Items");
        this.a = new ItemStack[this.m_()];
        for (int i = 0; i < nbttaglist.c(); ++i) {
            final NBTTagCompound nbttagcompound2 = (NBTTagCompound)nbttaglist.a(i);
            final int j = nbttagcompound2.c("Slot") & 0xFF;
            if (j >= 0 && j < this.a.length) {
                this.a[j] = new ItemStack(nbttagcompound2);
            }
        }
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
        final NBTTagList nbttaglist = new NBTTagList();
        for (int i = 0; i < this.a.length; ++i) {
            if (this.a[i] != null) {
                final NBTTagCompound nbttagcompound2 = new NBTTagCompound();
                nbttagcompound2.a("Slot", (byte)i);
                this.a[i].a(nbttagcompound2);
                nbttaglist.a(nbttagcompound2);
            }
        }
        nbttagcompound.a("Items", nbttaglist);
    }
    
    public int n_() {
        return 64;
    }
    
    public boolean a_(final EntityHuman entityhuman) {
        return this.d.getTileEntity(this.e, this.f, this.g) == this && entityhuman.d(this.e + 0.5, this.f + 0.5, this.g + 0.5) <= 64.0;
    }
}
