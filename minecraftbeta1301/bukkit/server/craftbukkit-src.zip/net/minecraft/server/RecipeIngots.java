// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class RecipeIngots
{
    private Object[][] a;
    
    public RecipeIngots() {
        this.a = new Object[][] { { Block.GOLD_BLOCK, new ItemStack(Item.GOLD_INGOT, 9) }, { Block.IRON_BLOCK, new ItemStack(Item.IRON_INGOT, 9) }, { Block.DIAMOND_BLOCK, new ItemStack(Item.DIAMOND, 9) }, { Block.LAPIS_BLOCK, new ItemStack(Item.INK_SACK, 9, 4) } };
    }
    
    public void a(final CraftingManager craftingManager) {
        for (int i = 0; i < this.a.length; ++i) {
            final Block block = (Block)this.a[i][0];
            final ItemStack itemStack = (ItemStack)this.a[i][1];
            craftingManager.a(new ItemStack(block), "###", "###", "###", '#', itemStack);
            craftingManager.a(itemStack, "#", '#', block);
        }
    }
}
