// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemReed extends Item
{
    private int a;
    
    public ItemReed(final int n, final Block block) {
        super(n);
        this.a = block.id;
    }
    
    @Override
    public boolean a(final ItemStack itemStack, final EntityHuman entityHuman, final World world, int i, int j, int k, int n) {
        if (world.getTypeId(i, j, k) == Block.SNOW.id) {
            n = 0;
        }
        else {
            if (n == 0) {
                --j;
            }
            if (n == 1) {
                ++j;
            }
            if (n == 2) {
                --k;
            }
            if (n == 3) {
                ++k;
            }
            if (n == 4) {
                --i;
            }
            if (n == 5) {
                ++i;
            }
        }
        if (itemStack.count == 0) {
            return false;
        }
        if (world.a(this.a, i, j, k, false)) {
            final Block block = Block.byId[this.a];
            if (world.e(i, j, k, this.a)) {
                Block.byId[this.a].d(world, i, j, k, n);
                Block.byId[this.a].a(world, i, j, k, (EntityLiving)entityHuman);
                world.a(i + 0.5f, j + 0.5f, k + 0.5f, block.stepSound.c(), (block.stepSound.a() + 1.0f) / 2.0f, block.stepSound.b() * 0.8f);
                --itemStack.count;
            }
        }
        return true;
    }
}
