// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.command.CommandSender;
import org.bukkit.craftbukkit.scheduler.CraftScheduler;
import org.bukkit.World;
import org.bukkit.event.world.WorldEvent;
import org.bukkit.event.Event;
import java.util.Iterator;
import java.net.UnknownHostException;
import java.io.File;
import java.net.InetAddress;
import java.io.OutputStream;
import java.io.PrintStream;
import org.bukkit.craftbukkit.LoggerOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.Collections;
import java.util.ArrayList;
import jline.ConsoleReader;
import org.bukkit.craftbukkit.command.ColouredConsoleSender;
import joptsimple.OptionSet;
import org.bukkit.craftbukkit.CraftServer;
import java.util.List;
import java.util.HashMap;
import java.util.logging.Logger;

public class MinecraftServer implements Runnable, ICommandListener
{
    public static Logger a;
    public static HashMap b;
    public NetworkListenThread c;
    public PropertyManager d;
    public ServerConfigurationManager f;
    private ConsoleCommandHandler o;
    private boolean p;
    public boolean g;
    int h;
    public String i;
    public int j;
    private List q;
    private List r;
    public EntityTracker k;
    public boolean l;
    public boolean m;
    public boolean n;
    public int spawnProtection;
    public List<WorldServer> worlds;
    public CraftServer server;
    public OptionSet options;
    public ColouredConsoleSender console;
    public ConsoleReader reader;
    
    public MinecraftServer(final OptionSet options) {
        this.p = true;
        this.g = false;
        this.h = 0;
        this.q = new ArrayList();
        this.r = Collections.synchronizedList(new ArrayList<Object>());
        this.worlds = new ArrayList<WorldServer>();
        new ThreadSleepForever(this);
        this.options = options;
        try {
            this.reader = new ConsoleReader();
        }
        catch (IOException ex) {
            Logger.getLogger(MinecraftServer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private boolean d() throws UnknownHostException {
        this.o = new ConsoleCommandHandler(this);
        final ThreadCommandReader threadcommandreader = new ThreadCommandReader(this);
        threadcommandreader.setDaemon(true);
        threadcommandreader.start();
        ConsoleLogManager.a(this);
        System.setOut(new PrintStream(new LoggerOutputStream(MinecraftServer.a, Level.INFO), true));
        System.setErr(new PrintStream(new LoggerOutputStream(MinecraftServer.a, Level.SEVERE), true));
        MinecraftServer.a.info("Starting minecraft server version Beta 1.3");
        if (Runtime.getRuntime().maxMemory() / 1024L / 1024L < 512L) {
            MinecraftServer.a.warning("**** NOT ENOUGH RAM!");
            MinecraftServer.a.warning("To start the server with more ram, launch it as \"java -Xmx1024M -Xms1024M -jar minecraft_server.jar\"");
        }
        MinecraftServer.a.info("Loading properties");
        this.d = new PropertyManager(this.options);
        final String s = this.d.a("server-ip", "");
        this.l = this.d.a("online-mode", true);
        this.m = this.d.a("spawn-animals", true);
        this.n = this.d.a("pvp", true);
        this.spawnProtection = this.d.a("spawn-protection", 16);
        InetAddress inetaddress = null;
        if (s.length() > 0) {
            inetaddress = InetAddress.getByName(s);
        }
        final int i = this.d.a("server-port", 25565);
        MinecraftServer.a.info("Starting Minecraft server on " + ((s.length() == 0) ? "*" : s) + ":" + i);
        try {
            this.c = new NetworkListenThread(this, inetaddress, i);
        }
        catch (Throwable ioexception) {
            MinecraftServer.a.warning("**** FAILED TO BIND TO PORT!");
            MinecraftServer.a.log(Level.WARNING, "The exception was: " + ioexception.toString());
            MinecraftServer.a.warning("Perhaps a server is already running on that port?");
            return false;
        }
        if (!this.l) {
            MinecraftServer.a.warning("**** SERVER IS RUNNING IN OFFLINE/INSECURE MODE!");
            MinecraftServer.a.warning("The server will make no attempt to authenticate usernames. Beware.");
            MinecraftServer.a.warning("While this makes the game possible to play without internet access, it also opens up the ability for hackers to connect with any username they choose.");
            MinecraftServer.a.warning("To change this, set \"online-mode\" to \"true\" in the server.settings file.");
        }
        this.f = new ServerConfigurationManager(this);
        this.k = new EntityTracker(this);
        final long j = System.nanoTime();
        final String s2 = this.d.a("level-name", "world");
        MinecraftServer.a.info("Preparing level \"" + s2 + "\"");
        this.a(new WorldLoaderServer(new File(".")), s2);
        final long elapsed = System.nanoTime() - j;
        final String time = String.format("%.3fs", elapsed / 1.0E10);
        MinecraftServer.a.info("Done (" + time + ")! For help, type \"help\" or \"?\"");
        return true;
    }
    
    private void a(final Convertable convertable, final String s) {
        if (convertable.a(s)) {
            MinecraftServer.a.info("Converting map!");
            convertable.a(s, new ConvertProgressUpdater(this));
        }
        MinecraftServer.a.info("Preparing start region");
        final WorldServer world = new WorldServer(this, new ServerNBTManager(new File("."), s, true), s, this.d.a("hellworld", false) ? -1 : 0);
        world.a(new WorldManager(this, world));
        world.j = (this.d.a("spawn-monsters", true) ? 1 : 0);
        world.a(this.d.a("spawn-monsters", true), this.m);
        this.f.a(world);
        this.worlds.add(world);
        final short short1 = 196;
        long i = System.currentTimeMillis();
        final ChunkCoordinates chunkcoordinates = this.worlds.get(0).l();
        for (int j = -short1; j <= short1 && this.p; j += 16) {
            for (int k = -short1; k <= short1 && this.p; k += 16) {
                final long l = System.currentTimeMillis();
                if (l < i) {
                    i = l;
                }
                if (l > i + 1000L) {
                    final int i2 = (short1 * 2 + 1) * (short1 * 2 + 1);
                    final int j2 = (j + short1) * (short1 * 2 + 1) + k + 1;
                    this.a("Preparing spawn area", j2 * 100 / i2);
                    i = l;
                }
                for (final WorldServer worldserver : this.worlds) {
                    world.u.d(chunkcoordinates.a + j >> 4, chunkcoordinates.c + k >> 4);
                    while (world.e() && this.p) {}
                }
            }
        }
        this.e();
    }
    
    private void a(final String s, final int i) {
        this.i = s;
        this.j = i;
        MinecraftServer.a.info(s + ": " + i + "%");
    }
    
    private void e() {
        this.i = null;
        this.j = 0;
        this.server.loadPlugins();
    }
    
    void f() {
        MinecraftServer.a.info("Saving chunks");
        for (final WorldServer world : this.worlds) {
            world.a(true, null);
            world.r();
            final WorldEvent event = new WorldEvent(Event.Type.WORLD_SAVED, world.getWorld());
            this.server.getPluginManager().callEvent(event);
        }
        this.f.d();
    }
    
    private void g() {
        MinecraftServer.a.info("Stopping server");
        if (this.server != null) {
            this.server.disablePlugins();
        }
        if (this.f != null) {
            this.f.d();
        }
        if (this.worlds.size() > 0) {
            this.f();
        }
    }
    
    public void a() {
        this.p = false;
    }
    
    public void run() {
        try {
            if (this.d()) {
                long i = System.currentTimeMillis();
                long j = 0L;
                while (this.p) {
                    final long k = System.currentTimeMillis();
                    long l = k - i;
                    if (l > 2000L) {
                        MinecraftServer.a.warning("Can't keep up! Did the system time change, or is the server overloaded?");
                        l = 2000L;
                    }
                    if (l < 0L) {
                        MinecraftServer.a.warning("Time ran backwards! Did the system time change?");
                        l = 0L;
                    }
                    j += l;
                    i = k;
                    if (this.worlds.size() > 0 && this.worlds.get(0).q()) {
                        this.h();
                        j = 0L;
                    }
                    else {
                        while (j > 50L) {
                            j -= 50L;
                            this.h();
                        }
                    }
                    Thread.sleep(1L);
                }
            }
            else {
                while (this.p) {
                    this.b();
                    try {
                        Thread.sleep(10L);
                    }
                    catch (InterruptedException interruptedexception) {
                        interruptedexception.printStackTrace();
                    }
                }
            }
        }
        catch (Throwable throwable) {
            throwable.printStackTrace();
            MinecraftServer.a.log(Level.SEVERE, "Unexpected exception", throwable);
            while (this.p) {
                this.b();
                try {
                    Thread.sleep(10L);
                }
                catch (InterruptedException interruptedexception2) {
                    interruptedexception2.printStackTrace();
                }
            }
            try {
                this.g();
                this.g = true;
            }
            catch (Throwable throwable2) {
                throwable2.printStackTrace();
            }
            finally {
                System.exit(0);
            }
        }
        finally {
            try {
                this.g();
                this.g = true;
            }
            catch (Throwable throwable3) {
                throwable3.printStackTrace();
                System.exit(0);
            }
            finally {
                System.exit(0);
            }
        }
    }
    
    private void h() {
        final ArrayList arraylist = new ArrayList();
        for (final String s : MinecraftServer.b.keySet()) {
            final int i = MinecraftServer.b.get(s);
            if (i > 0) {
                MinecraftServer.b.put(s, i - 1);
            }
            else {
                arraylist.add(s);
            }
        }
        for (int j = 0; j < arraylist.size(); ++j) {
            MinecraftServer.b.remove(arraylist.get(j));
        }
        AxisAlignedBB.a();
        Vec3D.a();
        ++this.h;
        if (this.h % 20 == 0) {
            for (int i = 0; i < this.f.b.size(); ++i) {
                final EntityPlayer entityplayer = this.f.b.get(i);
                entityplayer.a.b(new Packet4UpdateTime(entityplayer.world.k()));
            }
        }
        ((CraftScheduler)this.server.getScheduler()).mainThreadHeartbeat(this.h);
        for (final WorldServer world : this.worlds) {
            world.g();
            while (world.e()) {}
            world.d();
        }
        this.c.a();
        this.f.b();
        this.k.a();
        for (int j = 0; j < this.q.size(); ++j) {
            this.q.get(j).a();
        }
        try {
            this.b();
        }
        catch (Exception exception) {
            MinecraftServer.a.log(Level.WARNING, "Unexpected exception while parsing console command", exception);
        }
    }
    
    public void a(final String s, final ICommandListener icommandlistener) {
        this.r.add(new ServerCommand(s, icommandlistener));
    }
    
    public void b() {
        while (this.r.size() > 0) {
            final ServerCommand servercommand = this.r.remove(0);
            if (this.server.dispatchCommand(this.console, servercommand.a)) {
                continue;
            }
            this.o.a(servercommand);
        }
    }
    
    public void a(final IUpdatePlayerListBox iupdateplayerlistbox) {
        this.q.add(iupdateplayerlistbox);
    }
    
    public static void main(final OptionSet options) {
        try {
            final MinecraftServer minecraftserver = new MinecraftServer(options);
            new ThreadServerApplication("Server thread", minecraftserver).start();
        }
        catch (Exception exception) {
            MinecraftServer.a.log(Level.SEVERE, "Failed to start the minecraft server", exception);
        }
    }
    
    public File a(final String s) {
        return new File(s);
    }
    
    public void b(final String s) {
        MinecraftServer.a.info(s);
    }
    
    public String c() {
        return "CONSOLE";
    }
    
    public static boolean a(final MinecraftServer minecraftserver) {
        return minecraftserver.p;
    }
    
    static {
        MinecraftServer.a = Logger.getLogger("Minecraft");
        MinecraftServer.b = new HashMap();
    }
}
