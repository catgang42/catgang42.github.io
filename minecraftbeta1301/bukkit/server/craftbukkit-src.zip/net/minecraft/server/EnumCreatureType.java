// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public enum EnumCreatureType
{
    MONSTER("monster", 0, (Class)IMonster.class, 70, Material.AIR, false), 
    CREATURE("creature", 1, (Class)EntityAnimal.class, 15, Material.AIR, true), 
    WATER_CREATURE("waterCreature", 2, (Class)EntityWaterAnimal.class, 5, Material.WATER, true);
    
    private final Class d;
    private final int e;
    private final Material f;
    private final boolean g;
    
    private EnumCreatureType(final String name, final int ordinal, final Class d, final int e, final Material f, final boolean g) {
        this.d = d;
        this.e = e;
        this.f = f;
        this.g = g;
    }
    
    public Class a() {
        return this.d;
    }
    
    public int b() {
        return this.e;
    }
    
    public Material c() {
        return this.f;
    }
    
    public boolean d() {
        return this.g;
    }
}
