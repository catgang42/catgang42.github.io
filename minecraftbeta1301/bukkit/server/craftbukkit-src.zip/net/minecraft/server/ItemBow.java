// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemBow extends Item
{
    public ItemBow(final int n) {
        super(n);
        this.maxStackSize = 1;
    }
    
    @Override
    public ItemStack a(final ItemStack itemStack, final World world, final EntityHuman entityHuman) {
        if (entityHuman.inventory.b(Item.ARROW.id)) {
            world.a(entityHuman, "random.bow", 1.0f, 1.0f / (ItemBow.b.nextFloat() * 0.4f + 0.8f));
            if (!world.isStatic) {
                world.a(new EntityArrow(world, entityHuman));
            }
        }
        return itemStack;
    }
}
