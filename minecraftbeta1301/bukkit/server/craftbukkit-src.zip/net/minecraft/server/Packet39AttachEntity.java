// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet39AttachEntity extends Packet
{
    public int a;
    public int b;
    
    public Packet39AttachEntity() {
    }
    
    public Packet39AttachEntity(final Entity entity, final Entity entity2) {
        this.a = entity.id;
        this.b = ((entity2 != null) ? entity2.id : -1);
    }
    
    @Override
    public int a() {
        return 8;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readInt();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeInt(this.b);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
}
