// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

final class StepSoundSand extends StepSound
{
    StepSoundSand(final String s, final float n, final float n2) {
        super(s, n, n2);
    }
}
