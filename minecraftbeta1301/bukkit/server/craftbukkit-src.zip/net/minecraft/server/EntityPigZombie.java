// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.entity.CraftEntity;
import org.bukkit.event.Event;
import org.bukkit.event.entity.EntityTargetEvent;
import java.util.List;

public class EntityPigZombie extends EntityZombie
{
    private int a;
    private int b;
    private static final ItemStack f;
    
    public EntityPigZombie(final World world) {
        super(world);
        this.a = 0;
        this.b = 0;
        this.texture = "/mob/pigzombie.png";
        this.az = 0.5f;
        this.c = 5;
        this.by = true;
    }
    
    @Override
    public void f_() {
        this.az = ((this.d != null) ? 0.95f : 0.5f);
        if (this.b > 0 && --this.b == 0) {
            this.world.a(this, "mob.zombiepig.zpigangry", this.i() * 2.0f, ((this.random.nextFloat() - this.random.nextFloat()) * 0.2f + 1.0f) * 1.8f);
        }
        super.f_();
    }
    
    @Override
    public boolean b() {
        return this.world.j > 0 && this.world.a(this.boundingBox) && this.world.a(this, this.boundingBox).size() == 0 && !this.world.b(this.boundingBox);
    }
    
    @Override
    public void a(final NBTTagCompound nbttagcompound) {
        super.a(nbttagcompound);
        nbttagcompound.a("Anger", (short)this.a);
    }
    
    @Override
    public void b(final NBTTagCompound nbttagcompound) {
        super.b(nbttagcompound);
        this.a = nbttagcompound.d("Anger");
    }
    
    @Override
    protected Entity l() {
        return (this.a == 0) ? null : super.l();
    }
    
    @Override
    public void q() {
        super.q();
    }
    
    @Override
    public boolean a(final Entity entity, final int i) {
        if (entity instanceof EntityHuman) {
            final List list = this.world.b(this, this.boundingBox.b(32.0, 32.0, 32.0));
            for (int j = 0; j < list.size(); ++j) {
                final Entity entity2 = list.get(j);
                if (entity2 instanceof EntityPigZombie) {
                    final EntityPigZombie entitypigzombie = (EntityPigZombie)entity2;
                    entitypigzombie.c(entity);
                }
            }
            this.c(entity);
        }
        return super.a(entity, i);
    }
    
    private void c(final Entity entity) {
        final CraftServer server = ((WorldServer)this.world).getServer();
        org.bukkit.entity.Entity bukkitTarget = null;
        if (entity != null) {
            bukkitTarget = entity.getBukkitEntity();
        }
        final EntityTargetEvent event = new EntityTargetEvent(this.getBukkitEntity(), bukkitTarget, EntityTargetEvent.TargetReason.PIG_ZOMBIE_TARGET);
        server.getPluginManager().callEvent(event);
        if (!event.isCancelled()) {
            if (event.getTarget() == null) {
                this.d = null;
            }
            else {
                this.d = ((CraftEntity)event.getTarget()).getHandle();
                this.a = 400 + this.random.nextInt(400);
                this.b = this.random.nextInt(40);
            }
        }
    }
    
    @Override
    protected String e() {
        return "mob.zombiepig.zpig";
    }
    
    @Override
    protected String f() {
        return "mob.zombiepig.zpighurt";
    }
    
    @Override
    protected String g() {
        return "mob.zombiepig.zpigdeath";
    }
    
    @Override
    protected int h() {
        return Item.GRILLED_PORK.id;
    }
    
    static {
        f = new ItemStack(Item.GOLD_SWORD, 1);
    }
}
