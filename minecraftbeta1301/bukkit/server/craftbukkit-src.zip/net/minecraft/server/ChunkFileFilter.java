// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.File;
import java.util.regex.Pattern;
import java.io.FileFilter;

class ChunkFileFilter implements FileFilter
{
    public static final Pattern a;
    
    private ChunkFileFilter() {
    }
    
    public boolean accept(final File file) {
        return file.isDirectory() && ChunkFileFilter.a.matcher(file.getName()).matches();
    }
    
    static {
        a = Pattern.compile("[0-9a-z]|([0-9a-z][0-9a-z])");
    }
}
