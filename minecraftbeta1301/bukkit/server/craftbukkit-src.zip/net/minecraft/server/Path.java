// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class Path
{
    private PathPoint[] a;
    private int b;
    
    public Path() {
        this.a = new PathPoint[1024];
        this.b = 0;
    }
    
    public PathPoint a(final PathPoint pathPoint) {
        if (pathPoint.d >= 0) {
            throw new IllegalStateException("OW KNOWS!");
        }
        if (this.b == this.a.length) {
            final PathPoint[] a = new PathPoint[this.b << 1];
            System.arraycopy(this.a, 0, a, 0, this.b);
            this.a = a;
        }
        this.a[this.b] = pathPoint;
        pathPoint.d = this.b;
        this.a(this.b++);
        return pathPoint;
    }
    
    public void a() {
        this.b = 0;
    }
    
    public PathPoint b() {
        final PathPoint pathPoint = this.a[0];
        final PathPoint[] a = this.a;
        final int n = 0;
        final PathPoint[] a2 = this.a;
        final int b = this.b - 1;
        this.b = b;
        a[n] = a2[b];
        this.a[this.b] = null;
        if (this.b > 0) {
            this.b(0);
        }
        pathPoint.d = -1;
        return pathPoint;
    }
    
    public void a(final PathPoint pathPoint, final float g) {
        final float g2 = pathPoint.g;
        pathPoint.g = g;
        if (g < g2) {
            this.a(pathPoint.d);
        }
        else {
            this.b(pathPoint.d);
        }
    }
    
    private void a(int i) {
        final PathPoint pathPoint = this.a[i];
        final float g = pathPoint.g;
        while (i > 0) {
            final int n = i - 1 >> 1;
            final PathPoint pathPoint2 = this.a[n];
            if (g >= pathPoint2.g) {
                break;
            }
            this.a[i] = pathPoint2;
            pathPoint2.d = i;
            i = n;
        }
        this.a[i] = pathPoint;
        pathPoint.d = i;
    }
    
    private void b(int d) {
        final PathPoint pathPoint = this.a[d];
        final float g = pathPoint.g;
        while (true) {
            final int n = 1 + (d << 1);
            final int n2 = n + 1;
            if (n >= this.b) {
                break;
            }
            final PathPoint pathPoint2 = this.a[n];
            final float g2 = pathPoint2.g;
            PathPoint pathPoint3;
            float g3;
            if (n2 >= this.b) {
                pathPoint3 = null;
                g3 = Float.POSITIVE_INFINITY;
            }
            else {
                pathPoint3 = this.a[n2];
                g3 = pathPoint3.g;
            }
            if (g2 < g3) {
                if (g2 >= g) {
                    break;
                }
                this.a[d] = pathPoint2;
                pathPoint2.d = d;
                d = n;
            }
            else {
                if (g3 >= g) {
                    break;
                }
                this.a[d] = pathPoint3;
                pathPoint3.d = d;
                d = n2;
            }
        }
        this.a[d] = pathPoint;
        pathPoint.d = d;
    }
    
    public boolean c() {
        return this.b == 0;
    }
}
