// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import org.bukkit.block.BlockFace;
import org.bukkit.craftbukkit.CraftServer;
import org.bukkit.craftbukkit.CraftWorld;
import org.bukkit.event.player.PlayerItemEvent;
import org.bukkit.craftbukkit.block.CraftBlock;
import org.bukkit.craftbukkit.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;

public class ItemSign extends Item
{
    public ItemSign(final int i) {
        super(i);
        this.durability = 64;
        this.maxStackSize = 1;
    }
    
    @Override
    public boolean a(final ItemStack itemstack, final EntityHuman entityhuman, final World world, int i, int j, int k, final int l) {
        if (l == 0) {
            return false;
        }
        if (!world.getMaterial(i, j, k).isBuildable()) {
            return false;
        }
        final CraftWorld craftWorld = ((WorldServer)world).getWorld();
        final CraftServer craftServer = ((WorldServer)world).getServer();
        final org.bukkit.block.Block blockClicked = craftWorld.getBlockAt(i, j, k);
        if (l == 1) {
            ++j;
        }
        if (l == 2) {
            --k;
        }
        if (l == 3) {
            ++k;
        }
        if (l == 4) {
            --i;
        }
        if (l == 5) {
            ++i;
        }
        if (!Block.SIGN_POST.a(world, i, j, k)) {
            return false;
        }
        final Event.Type eventType = Event.Type.PLAYER_ITEM;
        final Player who = (entityhuman == null) ? null : ((Player)entityhuman.getBukkitEntity());
        final org.bukkit.inventory.ItemStack itemInHand = new CraftItemStack(itemstack);
        final BlockFace blockface = CraftBlock.notchToBlockFace(l);
        final PlayerItemEvent event = new PlayerItemEvent(eventType, who, itemInHand, blockClicked, blockface);
        craftServer.getPluginManager().callEvent(event);
        if (event.isCancelled()) {
            return false;
        }
        if (l == 1) {
            world.b(i, j, k, Block.SIGN_POST.id, MathHelper.b((entityhuman.yaw + 180.0f) * 16.0f / 360.0f + 0.5) & 0xF);
        }
        else {
            world.b(i, j, k, Block.WALL_SIGN.id, l);
        }
        --itemstack.count;
        final TileEntitySign tileentitysign = (TileEntitySign)world.getTileEntity(i, j, k);
        if (tileentitysign != null) {
            entityhuman.a(tileentitysign);
        }
        return true;
    }
}
