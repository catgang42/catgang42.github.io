// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.ArrayList;
import java.util.Arrays;

public class LongHashtable<V> extends LongHash
{
    Object[][][] values;
    Entry cache;
    
    public LongHashtable() {
        this.values = new Object[256][][];
        this.cache = null;
    }
    
    public void put(final int msw, final int lsw, final V value) {
        this.put(LongHash.toLong(msw, lsw), value);
        if (value instanceof Chunk) {
            final Chunk c = (Chunk)value;
            if (msw != c.j || lsw != c.k) {
                MinecraftServer.a.info("Chunk (" + c.j + ", " + c.k + ") stored at  (" + msw + ", " + lsw + ")");
                final Throwable x = new Throwable();
                x.fillInStackTrace();
                x.printStackTrace();
            }
        }
    }
    
    public V get(final int msw, final int lsw) {
        final V value = this.get(LongHash.toLong(msw, lsw));
        if (value instanceof Chunk) {
            final Chunk c = (Chunk)value;
            if (msw != c.j || lsw != c.k) {
                MinecraftServer.a.info("Chunk (" + c.j + ", " + c.k + ") stored at  (" + msw + ", " + lsw + ")");
                final Throwable x = new Throwable();
                x.fillInStackTrace();
                x.printStackTrace();
            }
        }
        return value;
    }
    
    public void put(final long key, final V value) {
        final int mainIdx = (int)(key & 0xFFL);
        final int outerIdx = (int)(key >> 32 & 0xFFL);
        Object[][] outer = this.values[mainIdx];
        if (outer == null) {
            outer = (this.values[mainIdx] = new Object[256][]);
        }
        Object[] inner = outer[outerIdx];
        if (inner == null) {
            inner = (outer[outerIdx] = new Object[5]);
            inner[0] = (this.cache = new Entry(key, value));
        }
        else {
            int i;
            for (i = 0; i < inner.length; ++i) {
                if (inner[i] == null || ((Entry)inner[i]).key == key) {
                    inner[i] = (this.cache = new Entry(key, value));
                    return;
                }
            }
            inner = (outer[outerIdx] = Arrays.copyOf(inner, i + i));
            inner[i] = new Entry(key, value);
        }
    }
    
    public V get(final long key) {
        synchronized (this) {
            return (V)(this.containsKey(key) ? this.cache.value : null);
        }
    }
    
    @Override
    public boolean containsKey(final long key) {
        if (this.cache != null && this.cache.key == key) {
            return true;
        }
        final int mainIdx = (int)(key & 0xFFL);
        final int outerIdx = (int)(key >> 32 & 0xFFL);
        final Object[][] outer = this.values[mainIdx];
        if (outer == null) {
            return false;
        }
        final Object[] inner = outer[outerIdx];
        if (inner == null) {
            return false;
        }
        for (int i = 0; i < inner.length; ++i) {
            final Entry e = (Entry)inner[i];
            if (e == null) {
                return false;
            }
            if (e.key == key) {
                this.cache = e;
                return true;
            }
        }
        return false;
    }
    
    @Override
    public void remove(final long key) {
        final Object[][] outer = this.values[(int)(key & 0xFFL)];
        if (outer == null) {
            return;
        }
        final Object[] inner = outer[(int)(key >> 32 & 0xFFL)];
        if (inner == null) {
            return;
        }
        for (int i = 0; i < inner.length; ++i) {
            if (inner[i] != null) {
                if (((Entry)inner[i]).key == key) {
                    ++i;
                    while (i < inner.length && inner[i] != null) {
                        inner[i - 1] = inner[i];
                        ++i;
                    }
                    inner[i - 1] = null;
                    this.cache = null;
                    return;
                }
            }
        }
    }
    
    public ArrayList<V> values() {
        final ArrayList<V> ret = new ArrayList<V>();
        for (final Object[][] outer : this.values) {
            if (outer != null) {
                for (final Object[] inner : outer) {
                    if (inner != null) {
                        for (final Object entry : inner) {
                            if (entry == null) {
                                break;
                            }
                            ret.add((V)((Entry)entry).value);
                        }
                    }
                }
            }
        }
        return ret;
    }
    
    private class Entry
    {
        long key;
        Object value;
        
        Entry(final long k, final Object v) {
            this.key = k;
            this.value = v;
        }
    }
}
