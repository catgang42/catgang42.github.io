// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemCoal extends Item
{
    public ItemCoal(final int n) {
        super(n);
        this.a(true);
        this.d(0);
    }
}
