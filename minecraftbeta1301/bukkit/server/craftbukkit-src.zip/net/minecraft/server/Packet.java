// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.DataInputStream;
import java.util.HashMap;
import java.util.Map;

public abstract class Packet
{
    private static Map a;
    private static Map b;
    public final long j;
    public boolean k;
    private static HashMap c;
    private static int d;
    
    public Packet() {
        this.j = System.currentTimeMillis();
        this.k = false;
    }
    
    static void a(final int n, final Class obj) {
        if (Packet.a.containsKey(n)) {
            throw new IllegalArgumentException("Duplicate packet id:" + n);
        }
        if (Packet.b.containsKey(obj)) {
            throw new IllegalArgumentException("Duplicate packet class:" + obj);
        }
        Packet.a.put(n, obj);
        Packet.b.put(obj, n);
    }
    
    public static Packet a(final int n) {
        try {
            final Class<Packet> clazz = Packet.a.get(n);
            if (clazz == null) {
                return null;
            }
            return clazz.newInstance();
        }
        catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Skipping packet with id " + n);
            return null;
        }
    }
    
    public final int b() {
        return Packet.b.get(this.getClass());
    }
    
    public static Packet b(final DataInputStream dataInputStream) {
        dataInputStream.mark(16384);
        int read;
        Packet a;
        try {
            read = dataInputStream.read();
            if (read == -1) {
                return null;
            }
            a = a(read);
            if (a == null) {
                throw new IOException("Bad packet id " + read);
            }
            a.a(dataInputStream);
        }
        catch (EOFException ex) {
            System.out.println("Reached end of stream");
            dataInputStream.reset();
            return null;
        }
        PacketCounter value = Packet.c.get(read);
        if (value == null) {
            value = new PacketCounter(null);
            Packet.c.put(read, value);
        }
        value.a(a.a());
        ++Packet.d;
        if (Packet.d % 1000 == 0) {}
        return a;
    }
    
    public static void a(final Packet packet, final DataOutputStream dataOutputStream) {
        dataOutputStream.write(packet.b());
        packet.a(dataOutputStream);
    }
    
    public abstract void a(final DataInputStream p0);
    
    public abstract void a(final DataOutputStream p0);
    
    public abstract void a(final NetHandler p0);
    
    public abstract int a();
    
    static {
        Packet.a = new HashMap();
        Packet.b = new HashMap();
        a(0, Packet0KeepAlive.class);
        a(1, Packet1Login.class);
        a(2, Packet2Handshake.class);
        a(3, Packet3Chat.class);
        a(4, Packet4UpdateTime.class);
        a(5, Packet5EntityEquipment.class);
        a(6, Packet6SpawnPosition.class);
        a(7, Packet7UseEntity.class);
        a(8, Packet8UpdateHealth.class);
        a(9, Packet9Respawn.class);
        a(10, Packet10Flying.class);
        a(11, Packet11PlayerPosition.class);
        a(12, Packet12PlayerLook.class);
        a(13, Packet13PlayerLookMove.class);
        a(14, Packet14BlockDig.class);
        a(15, Packet15Place.class);
        a(16, Packet16BlockItemSwitch.class);
        a(17, Packet17.class);
        a(18, Packet18ArmAnimation.class);
        a(19, Packet19EntityAction.class);
        a(20, Packet20NamedEntitySpawn.class);
        a(21, Packet21PickupSpawn.class);
        a(22, Packet22Collect.class);
        a(23, Packet23VehicleSpawn.class);
        a(24, Packet24MobSpawn.class);
        a(25, Packet25EntityPainting.class);
        a(27, Packet27.class);
        a(28, Packet28EntityVelocity.class);
        a(29, Packet29DestroyEntity.class);
        a(30, Packet30Entity.class);
        a(31, Packet31RelEntityMove.class);
        a(32, Packet32EntityLook.class);
        a(33, Packet33RelEntityMoveLook.class);
        a(34, Packet34EntityTeleport.class);
        a(38, Packet38EntityStatus.class);
        a(39, Packet39AttachEntity.class);
        a(40, Packet40EntityMetadata.class);
        a(50, Packet50PreChunk.class);
        a(51, Packet51MapChunk.class);
        a(52, Packet52MultiBlockChange.class);
        a(53, Packet53BlockChange.class);
        a(54, Packet54PlayNoteBlock.class);
        a(60, Packet60Explosion.class);
        a(100, Packet100OpenWindow.class);
        a(101, Packet101CloseWindow.class);
        a(102, Packet102WindowClick.class);
        a(103, Packet103SetSlot.class);
        a(104, Packet104WindowItems.class);
        a(105, Packet105CraftProgressBar.class);
        a(106, Packet106Transaction.class);
        a(130, Packet130UpdateSign.class);
        a(255, Packet255KickDisconnect.class);
        Packet.c = new HashMap();
        Packet.d = 0;
    }
}
