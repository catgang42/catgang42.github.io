// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataInput;
import java.io.DataOutput;

public class NBTTagDouble extends NBTBase
{
    public double a;
    
    public NBTTagDouble() {
    }
    
    public NBTTagDouble(final double a) {
        this.a = a;
    }
    
    @Override
    void a(final DataOutput dataOutput) {
        dataOutput.writeDouble(this.a);
    }
    
    @Override
    void a(final DataInput dataInput) {
        this.a = dataInput.readDouble();
    }
    
    @Override
    public byte a() {
        return 6;
    }
    
    @Override
    public String toString() {
        return "" + this.a;
    }
}
