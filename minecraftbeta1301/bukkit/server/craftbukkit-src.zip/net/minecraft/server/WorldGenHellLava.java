// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class WorldGenHellLava extends WorldGenerator
{
    private int a;
    
    public WorldGenHellLava(final int a) {
        this.a = a;
    }
    
    @Override
    public boolean a(final World world, final Random random, final int n, final int j, final int n2) {
        if (world.getTypeId(n, j + 1, n2) != Block.NETHERRACK.id) {
            return false;
        }
        if (world.getTypeId(n, j, n2) != 0 && world.getTypeId(n, j, n2) != Block.NETHERRACK.id) {
            return false;
        }
        int n3 = 0;
        if (world.getTypeId(n - 1, j, n2) == Block.NETHERRACK.id) {
            ++n3;
        }
        if (world.getTypeId(n + 1, j, n2) == Block.NETHERRACK.id) {
            ++n3;
        }
        if (world.getTypeId(n, j, n2 - 1) == Block.NETHERRACK.id) {
            ++n3;
        }
        if (world.getTypeId(n, j, n2 + 1) == Block.NETHERRACK.id) {
            ++n3;
        }
        if (world.getTypeId(n, j - 1, n2) == Block.NETHERRACK.id) {
            ++n3;
        }
        int n4 = 0;
        if (world.isEmpty(n - 1, j, n2)) {
            ++n4;
        }
        if (world.isEmpty(n + 1, j, n2)) {
            ++n4;
        }
        if (world.isEmpty(n, j, n2 - 1)) {
            ++n4;
        }
        if (world.isEmpty(n, j, n2 + 1)) {
            ++n4;
        }
        if (world.isEmpty(n, j - 1, n2)) {
            ++n4;
        }
        if (n3 == 4 && n4 == 1) {
            world.e(n, j, n2, this.a);
            world.a = true;
            Block.byId[this.a].a(world, n, j, n2, random);
            world.a = false;
        }
        return true;
    }
}
