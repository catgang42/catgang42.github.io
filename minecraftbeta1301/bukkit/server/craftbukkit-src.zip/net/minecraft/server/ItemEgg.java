// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class ItemEgg extends Item
{
    public ItemEgg(final int n) {
        super(n);
        this.maxStackSize = 16;
    }
    
    @Override
    public ItemStack a(final ItemStack itemStack, final World world, final EntityHuman entityHuman) {
        --itemStack.count;
        world.a(entityHuman, "random.bow", 0.5f, 0.4f / (ItemEgg.b.nextFloat() * 0.4f + 0.8f));
        if (!world.isStatic) {
            world.a(new EntityEgg(world, entityHuman));
        }
        return itemStack;
    }
}
