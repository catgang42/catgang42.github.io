// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

class EntityListEntry
{
    final int a;
    Object b;
    EntityListEntry c;
    final int d;
    
    EntityListEntry(final int d, final int a, final Object b, final EntityListEntry c) {
        this.b = b;
        this.c = c;
        this.a = a;
        this.d = d;
    }
    
    public final int a() {
        return this.a;
    }
    
    public final Object b() {
        return this.b;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (!(o instanceof EntityListEntry)) {
            return false;
        }
        final EntityListEntry entityListEntry = (EntityListEntry)o;
        final Integer value = this.a();
        final Integer value2 = entityListEntry.a();
        if (value == value2 || (value != null && value.equals(value2))) {
            final Object b = this.b();
            final Object b2 = entityListEntry.b();
            if (b == b2 || (b != null && b.equals(b2))) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public final int hashCode() {
        return g(this.a);
    }
    
    @Override
    public final String toString() {
        return this.a() + "=" + this.b();
    }
}
