// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class BlockIce extends BlockBreakable
{
    public BlockIce(final int n, final int n2) {
        super(n, n2, Material.ICE, false);
        this.frictionFactor = 0.98f;
        this.a(true);
    }
    
    @Override
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        return super.a(blockAccess, n, n2, n3, 1 - n4);
    }
    
    @Override
    public void b(final World world, final int n, final int j, final int n2) {
        final Material material = world.getMaterial(n, j - 1, n2);
        if (material.isSolid() || material.isLiquid()) {
            world.e(n, j, n2, Block.WATER.id);
        }
    }
    
    @Override
    public int a(final Random random) {
        return 0;
    }
    
    @Override
    public void a(final World world, final int i, final int j, final int k, final Random random) {
        if (world.a(EnumSkyBlock.BLOCK, i, j, k) > 11 - Block.q[this.id]) {
            this.b_(world, i, j, k, world.getData(i, j, k));
            world.e(i, j, k, Block.STATIONARY_WATER.id);
        }
    }
}
