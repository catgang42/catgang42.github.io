// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;

public class NoiseGenerator2
{
    private static int[][] d;
    private int[] e;
    public double a;
    public double b;
    public double c;
    private static final double f;
    private static final double g;
    
    public NoiseGenerator2() {
        this(new Random());
    }
    
    public NoiseGenerator2(final Random random) {
        this.e = new int[512];
        this.a = random.nextDouble() * 256.0;
        this.b = random.nextDouble() * 256.0;
        this.c = random.nextDouble() * 256.0;
        for (int i = 0; i < 256; ++i) {
            this.e[i] = i;
        }
        for (int j = 0; j < 256; ++j) {
            final int n = random.nextInt(256 - j) + j;
            final int n2 = this.e[j];
            this.e[j] = this.e[n];
            this.e[n] = n2;
            this.e[j + 256] = this.e[j];
        }
    }
    
    private static int a(final double n) {
        return (n > 0.0) ? ((int)n) : ((int)n - 1);
    }
    
    private static double a(final int[] array, final double n, final double n2) {
        return array[0] * n + array[1] * n2;
    }
    
    public void a(final double[] array, final double n, final double n2, final int n3, final int n4, final double n5, final double n6, final double n7) {
        int n8 = 0;
        for (int i = 0; i < n3; ++i) {
            final double n9 = (n + i) * n5 + this.a;
            for (int j = 0; j < n4; ++j) {
                final double n10 = (n2 + j) * n6 + this.b;
                final double n11 = (n9 + n10) * NoiseGenerator2.f;
                final int a = a(n9 + n11);
                final int a2 = a(n10 + n11);
                final double n12 = (a + a2) * NoiseGenerator2.g;
                final double n13 = a - n12;
                final double n14 = a2 - n12;
                final double n15 = n9 - n13;
                final double n16 = n10 - n14;
                int n17;
                int n18;
                if (n15 > n16) {
                    n17 = 1;
                    n18 = 0;
                }
                else {
                    n17 = 0;
                    n18 = 1;
                }
                final double n19 = n15 - n17 + NoiseGenerator2.g;
                final double n20 = n16 - n18 + NoiseGenerator2.g;
                final double n21 = n15 - 1.0 + 2.0 * NoiseGenerator2.g;
                final double n22 = n16 - 1.0 + 2.0 * NoiseGenerator2.g;
                final int n23 = a & 0xFF;
                final int n24 = a2 & 0xFF;
                final int n25 = this.e[n23 + this.e[n24]] % 12;
                final int n26 = this.e[n23 + n17 + this.e[n24 + n18]] % 12;
                final int n27 = this.e[n23 + 1 + this.e[n24 + 1]] % 12;
                final double n28 = 0.5 - n15 * n15 - n16 * n16;
                double n29;
                if (n28 < 0.0) {
                    n29 = 0.0;
                }
                else {
                    final double n30 = n28 * n28;
                    n29 = n30 * n30 * a(NoiseGenerator2.d[n25], n15, n16);
                }
                final double n31 = 0.5 - n19 * n19 - n20 * n20;
                double n32;
                if (n31 < 0.0) {
                    n32 = 0.0;
                }
                else {
                    final double n33 = n31 * n31;
                    n32 = n33 * n33 * a(NoiseGenerator2.d[n26], n19, n20);
                }
                final double n34 = 0.5 - n21 * n21 - n22 * n22;
                double n35;
                if (n34 < 0.0) {
                    n35 = 0.0;
                }
                else {
                    final double n36 = n34 * n34;
                    n35 = n36 * n36 * a(NoiseGenerator2.d[n27], n21, n22);
                }
                final int n37 = n8++;
                array[n37] += 70.0 * (n29 + n32 + n35) * n7;
            }
        }
    }
    
    static {
        NoiseGenerator2.d = new int[][] { { 1, 1, 0 }, { -1, 1, 0 }, { 1, -1, 0 }, { -1, -1, 0 }, { 1, 0, 1 }, { -1, 0, 1 }, { 1, 0, -1 }, { -1, 0, -1 }, { 0, 1, 1 }, { 0, -1, 1 }, { 0, 1, -1 }, { 0, -1, -1 } };
        f = 0.5 * (Math.sqrt(3.0) - 1.0);
        g = (3.0 - Math.sqrt(3.0)) / 6.0;
    }
}
