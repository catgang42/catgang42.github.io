// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet50PreChunk extends Packet
{
    public int a;
    public int b;
    public boolean c;
    
    public Packet50PreChunk() {
        this.k = false;
    }
    
    public Packet50PreChunk(final int a, final int b, final boolean c) {
        this.k = false;
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readInt();
        this.c = (dataInputStream.read() != 0);
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeInt(this.b);
        dataOutputStream.write(this.c ? 1 : 0);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 9;
    }
}
