// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet23VehicleSpawn extends Packet
{
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    
    public Packet23VehicleSpawn() {
    }
    
    public Packet23VehicleSpawn(final Entity entity, final int e) {
        this.a = entity.id;
        this.b = MathHelper.b(entity.locX * 32.0);
        this.c = MathHelper.b(entity.locY * 32.0);
        this.d = MathHelper.b(entity.locZ * 32.0);
        this.e = e;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.e = dataInputStream.readByte();
        this.b = dataInputStream.readInt();
        this.c = dataInputStream.readInt();
        this.d = dataInputStream.readInt();
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeByte(this.e);
        dataOutputStream.writeInt(this.b);
        dataOutputStream.writeInt(this.c);
        dataOutputStream.writeInt(this.d);
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        return 17;
    }
}
