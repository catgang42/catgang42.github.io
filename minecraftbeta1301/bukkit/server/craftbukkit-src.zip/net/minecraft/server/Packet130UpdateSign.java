// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.io.DataOutputStream;
import java.io.DataInputStream;

public class Packet130UpdateSign extends Packet
{
    public int a;
    public int b;
    public int c;
    public String[] d;
    
    public Packet130UpdateSign() {
        this.k = true;
    }
    
    public Packet130UpdateSign(final int a, final int b, final int c, final String[] d) {
        this.k = true;
        this.a = a;
        this.b = b;
        this.c = c;
        this.d = d;
    }
    
    @Override
    public void a(final DataInputStream dataInputStream) {
        this.a = dataInputStream.readInt();
        this.b = dataInputStream.readShort();
        this.c = dataInputStream.readInt();
        this.d = new String[4];
        for (int i = 0; i < 4; ++i) {
            this.d[i] = dataInputStream.readUTF();
        }
    }
    
    @Override
    public void a(final DataOutputStream dataOutputStream) {
        dataOutputStream.writeInt(this.a);
        dataOutputStream.writeShort(this.b);
        dataOutputStream.writeInt(this.c);
        for (int i = 0; i < 4; ++i) {
            dataOutputStream.writeUTF(this.d[i]);
        }
    }
    
    @Override
    public void a(final NetHandler netHandler) {
        netHandler.a(this);
    }
    
    @Override
    public int a() {
        int n = 0;
        for (int i = 0; i < 4; ++i) {
            n += this.d[i].length();
        }
        return n;
    }
}
