// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

import java.util.Random;
import java.util.ArrayList;

public class Block
{
    public static final StepSound d;
    public static final StepSound e;
    public static final StepSound f;
    public static final StepSound g;
    public static final StepSound h;
    public static final StepSound i;
    public static final StepSound j;
    public static final StepSound k;
    public static final StepSound l;
    public static final Block[] byId;
    public static final boolean[] n;
    public static final boolean[] o;
    public static final boolean[] p;
    public static final int[] q;
    public static final boolean[] r;
    public static final int[] s;
    public static final Block STONE;
    public static final BlockGrass GRASS;
    public static final Block DIRT;
    public static final Block COBBLESTONE;
    public static final Block WOOD;
    public static final Block SAPLING;
    public static final Block BEDROCK;
    public static final Block WATER;
    public static final Block STATIONARY_WATER;
    public static final Block LAVA;
    public static final Block STATIONARY_LAVA;
    public static final Block SAND;
    public static final Block GRAVEL;
    public static final Block GOLD_ORE;
    public static final Block IRON_ORE;
    public static final Block COAL_ORE;
    public static final Block LOG;
    public static final BlockLeaves LEAVES;
    public static final Block SPONGE;
    public static final Block GLASS;
    public static final Block LAPIS_ORE;
    public static final Block LAPIS_BLOCK;
    public static final Block DISPENSER;
    public static final Block SANDSTONE;
    public static final Block NOTE_BLOCK;
    public static final Block BED;
    public static final Block T;
    public static final Block U;
    public static final Block V;
    public static final Block W;
    public static final Block X;
    public static final Block Y;
    public static final Block Z;
    public static final Block aa;
    public static final Block WOOL;
    public static final Block ac;
    public static final BlockFlower YELLOW_FLOWER;
    public static final BlockFlower RED_ROSE;
    public static final BlockFlower BROWN_MUSHROOM;
    public static final BlockFlower RED_MUSHROOM;
    public static final Block GOLD_BLOCK;
    public static final Block IRON_BLOCK;
    public static final Block DOUBLE_STEP;
    public static final Block STEP;
    public static final Block BRICK;
    public static final Block TNT;
    public static final Block BOOKSHELF;
    public static final Block MOSSY_COBBLESTONE;
    public static final Block OBSIDIAN;
    public static final Block TORCH;
    public static final BlockFire FIRE;
    public static final Block MOB_SPAWNER;
    public static final Block WOOD_STAIRS;
    public static final Block CHEST;
    public static final Block REDSTONE_WIRE;
    public static final Block DIAMOND_ORE;
    public static final Block DIAMOND_BLOCK;
    public static final Block WORKBENCH;
    public static final Block CROPS;
    public static final Block SOIL;
    public static final Block FURNACE;
    public static final Block BURNING_FURNACE;
    public static final Block SIGN_POST;
    public static final Block WOODEN_DOOR;
    public static final Block LADDER;
    public static final Block RAILS;
    public static final Block COBBLESTONE_STAIRS;
    public static final Block WALL_SIGN;
    public static final Block LEVER;
    public static final Block STONE_PLATE;
    public static final Block IRON_DOOR_BLOCK;
    public static final Block WOOD_PLATE;
    public static final Block REDSTONE_ORE;
    public static final Block GLOWING_REDSTONE_ORE;
    public static final Block REDSTONE_TORCH_OFF;
    public static final Block REDSTONE_TORCH_ON;
    public static final Block STONE_BUTTON;
    public static final Block SNOW;
    public static final Block ICE;
    public static final Block SNOW_BLOCK;
    public static final Block CACTUS;
    public static final Block CLAY;
    public static final Block SUGAR_CANE_BLOCK;
    public static final Block JUKEBOX;
    public static final Block FENCE;
    public static final Block PUMPKIN;
    public static final Block NETHERRACK;
    public static final Block SOUL_SAND;
    public static final Block GLOWSTONE;
    public static final BlockPortal PORTAL;
    public static final Block JACK_O_LANTERN;
    public static final Block CAKE_BLOCK;
    public static final Block DIODE_OFF;
    public static final Block DIODE_ON;
    public int textureId;
    public final int id;
    protected float strength;
    protected float durability;
    public double minX;
    public double minY;
    public double minZ;
    public double maxX;
    public double maxY;
    public double maxZ;
    public StepSound stepSound;
    public float bu;
    public final Material material;
    public float frictionFactor;
    private String name;
    
    protected Block(final int n, final Material material) {
        this.stepSound = Block.d;
        this.bu = 1.0f;
        this.frictionFactor = 0.6f;
        if (Block.byId[n] != null) {
            throw new IllegalArgumentException("Slot " + n + " is already occupied by " + Block.byId[n] + " when adding " + this);
        }
        this.material = material;
        Block.byId[n] = this;
        this.id = n;
        this.a(0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f);
        Block.o[n] = this.a();
        Block.q[n] = (this.a() ? 255 : 0);
        Block.r[n] = !material.blocksLight();
        Block.p[n] = false;
    }
    
    protected Block(final int n, final int textureId, final Material material) {
        this(n, material);
        this.textureId = textureId;
    }
    
    protected Block a(final StepSound stepSound) {
        this.stepSound = stepSound;
        return this;
    }
    
    protected Block e(final int n) {
        Block.q[this.id] = n;
        return this;
    }
    
    protected Block a(final float n) {
        Block.s[this.id] = (int)(15.0f * n);
        return this;
    }
    
    protected Block b(final float n) {
        this.durability = n * 3.0f;
        return this;
    }
    
    protected Block c(final float strength) {
        this.strength = strength;
        if (this.durability < strength * 5.0f) {
            this.durability = strength * 5.0f;
        }
        return this;
    }
    
    protected void a(final boolean b) {
        Block.n[this.id] = b;
    }
    
    public void a(final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.minX = n;
        this.minY = n2;
        this.minZ = n3;
        this.maxX = n4;
        this.maxY = n5;
        this.maxZ = n6;
    }
    
    public boolean a(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        return (n4 == 0 && this.minY > 0.0) || (n4 == 1 && this.maxY < 1.0) || (n4 == 2 && this.minZ > 0.0) || (n4 == 3 && this.maxZ < 1.0) || (n4 == 4 && this.minX > 0.0) || (n4 == 5 && this.maxX < 1.0) || !blockAccess.d(n, n2, n3);
    }
    
    public int a(final int n, final int n2) {
        return this.a(n);
    }
    
    public int a(final int n) {
        return this.textureId;
    }
    
    public void a(final World world, final int n, final int n2, final int n3, final AxisAlignedBB axisAlignedBB, final ArrayList list) {
        final AxisAlignedBB d = this.d(world, n, n2, n3);
        if (d != null && axisAlignedBB.a(d)) {
            list.add(d);
        }
    }
    
    public AxisAlignedBB d(final World world, final int n, final int n2, final int n3) {
        return AxisAlignedBB.b(n + this.minX, n2 + this.minY, n3 + this.minZ, n + this.maxX, n2 + this.maxY, n3 + this.maxZ);
    }
    
    public boolean a() {
        return true;
    }
    
    public boolean a(final int n, final boolean b) {
        return this.d();
    }
    
    public boolean d() {
        return true;
    }
    
    public void a(final World world, final int n, final int n2, final int n3, final Random random) {
    }
    
    public void b(final World world, final int n, final int n2, final int n3, final int n4) {
    }
    
    public void a(final World world, final int n, final int n2, final int n3, final int n4) {
    }
    
    public int b() {
        return 10;
    }
    
    public void e(final World world, final int n, final int n2, final int n3) {
    }
    
    public void b(final World world, final int n, final int n2, final int n3) {
    }
    
    public int a(final Random random) {
        return 1;
    }
    
    public int a(final int n, final Random random) {
        return this.id;
    }
    
    public float a(final EntityHuman entityHuman) {
        if (this.strength < 0.0f) {
            return 0.0f;
        }
        if (!entityHuman.b(this)) {
            return 1.0f / this.strength / 100.0f;
        }
        return entityHuman.a(this) / this.strength / 30.0f;
    }
    
    public void b_(final World world, final int n, final int n2, final int n3, final int n4) {
        this.a(world, n, n2, n3, n4, 1.0f);
    }
    
    public void a(final World world, final int n, final int n2, final int n3, final int n4, final float n5) {
        if (world.isStatic) {
            return;
        }
        for (int a = this.a(world.k), i = 0; i < a; ++i) {
            if (world.k.nextFloat() <= n5) {
                final int a2 = this.a(n4, world.k);
                if (a2 > 0) {
                    final float n6 = 0.7f;
                    final EntityItem entity = new EntityItem(world, n + (world.k.nextFloat() * n6 + (1.0f - n6) * 0.5), n2 + (world.k.nextFloat() * n6 + (1.0f - n6) * 0.5), n3 + (world.k.nextFloat() * n6 + (1.0f - n6) * 0.5), new ItemStack(a2, 1, this.b(n4)));
                    entity.c = 10;
                    world.a(entity);
                }
            }
        }
    }
    
    protected int b(final int n) {
        return 0;
    }
    
    public float a(final Entity entity) {
        return this.durability / 5.0f;
    }
    
    public MovingObjectPosition a(final World world, final int n, final int n2, final int n3, Vec3D c, Vec3D c2) {
        this.a((IBlockAccess)world, n, n2, n3);
        c = c.c(-n, -n2, -n3);
        c2 = c2.c(-n, -n2, -n3);
        Vec3D a = c.a(c2, this.minX);
        Vec3D a2 = c.a(c2, this.maxX);
        Vec3D b = c.b(c2, this.minY);
        Vec3D b2 = c.b(c2, this.maxY);
        Vec3D c3 = c.c(c2, this.minZ);
        Vec3D c4 = c.c(c2, this.maxZ);
        if (!this.a(a)) {
            a = null;
        }
        if (!this.a(a2)) {
            a2 = null;
        }
        if (!this.b(b)) {
            b = null;
        }
        if (!this.b(b2)) {
            b2 = null;
        }
        if (!this.c(c3)) {
            c3 = null;
        }
        if (!this.c(c4)) {
            c4 = null;
        }
        Vec3D vec3D = null;
        if (a != null && (vec3D == null || c.a(a) < c.a(vec3D))) {
            vec3D = a;
        }
        if (a2 != null && (vec3D == null || c.a(a2) < c.a(vec3D))) {
            vec3D = a2;
        }
        if (b != null && (vec3D == null || c.a(b) < c.a(vec3D))) {
            vec3D = b;
        }
        if (b2 != null && (vec3D == null || c.a(b2) < c.a(vec3D))) {
            vec3D = b2;
        }
        if (c3 != null && (vec3D == null || c.a(c3) < c.a(vec3D))) {
            vec3D = c3;
        }
        if (c4 != null && (vec3D == null || c.a(c4) < c.a(vec3D))) {
            vec3D = c4;
        }
        if (vec3D == null) {
            return null;
        }
        int n4 = -1;
        if (vec3D == a) {
            n4 = 4;
        }
        if (vec3D == a2) {
            n4 = 5;
        }
        if (vec3D == b) {
            n4 = 0;
        }
        if (vec3D == b2) {
            n4 = 1;
        }
        if (vec3D == c3) {
            n4 = 2;
        }
        if (vec3D == c4) {
            n4 = 3;
        }
        return new MovingObjectPosition(n, n2, n3, n4, vec3D.c(n, n2, n3));
    }
    
    private boolean a(final Vec3D vec3D) {
        return vec3D != null && vec3D.b >= this.minY && vec3D.b <= this.maxY && vec3D.c >= this.minZ && vec3D.c <= this.maxZ;
    }
    
    private boolean b(final Vec3D vec3D) {
        return vec3D != null && vec3D.a >= this.minX && vec3D.a <= this.maxX && vec3D.c >= this.minZ && vec3D.c <= this.maxZ;
    }
    
    private boolean c(final Vec3D vec3D) {
        return vec3D != null && vec3D.a >= this.minX && vec3D.a <= this.maxX && vec3D.b >= this.minY && vec3D.b <= this.maxY;
    }
    
    public void c(final World world, final int n, final int n2, final int n3) {
    }
    
    public boolean a(final World world, final int i, final int j, final int k) {
        final int typeId = world.getTypeId(i, j, k);
        return typeId == 0 || Block.byId[typeId].material.isLiquid();
    }
    
    public boolean a(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
        return false;
    }
    
    public void b(final World world, final int n, final int n2, final int n3, final Entity entity) {
    }
    
    public void d(final World world, final int n, final int n2, final int n3, final int n4) {
    }
    
    public void b(final World world, final int n, final int n2, final int n3, final EntityHuman entityHuman) {
    }
    
    public void a(final World world, final int n, final int n2, final int n3, final Entity entity, final Vec3D vec3D) {
    }
    
    public void a(final IBlockAccess blockAccess, final int n, final int n2, final int n3) {
    }
    
    public boolean b(final IBlockAccess blockAccess, final int n, final int n2, final int n3, final int n4) {
        return false;
    }
    
    public boolean c() {
        return false;
    }
    
    public void a(final World world, final int n, final int n2, final int n3, final Entity entity) {
    }
    
    public boolean c(final World world, final int n, final int n2, final int n3, final int n4) {
        return false;
    }
    
    public void a_(final World world, final int n, final int n2, final int n3, final int n4) {
        this.b_(world, n, n2, n3, n4);
    }
    
    public boolean f(final World world, final int n, final int n2, final int n3) {
        return true;
    }
    
    public void a(final World world, final int n, final int n2, final int n3, final EntityLiving entityLiving) {
    }
    
    public Block a(final String str) {
        this.name = "tile." + str;
        return this;
    }
    
    public String e() {
        return this.name;
    }
    
    public void a(final World world, final int n, final int n2, final int n3, final int n4, final int n5) {
    }
    
    static {
        d = new StepSound("stone", 1.0f, 1.0f);
        e = new StepSound("wood", 1.0f, 1.0f);
        f = new StepSound("gravel", 1.0f, 1.0f);
        g = new StepSound("grass", 1.0f, 1.0f);
        h = new StepSound("stone", 1.0f, 1.0f);
        i = new StepSound("stone", 1.0f, 1.5f);
        j = new StepSoundStone("stone", 1.0f, 1.0f);
        k = new StepSound("cloth", 1.0f, 1.0f);
        l = new StepSoundSand("sand", 1.0f, 1.0f);
        byId = new Block[256];
        n = new boolean[256];
        o = new boolean[256];
        p = new boolean[256];
        q = new int[256];
        r = new boolean[256];
        s = new int[256];
        STONE = new BlockStone(1, 1).c(1.5f).b(10.0f).a(Block.h).a("stone");
        GRASS = (BlockGrass)new BlockGrass(2).c(0.6f).a(Block.g).a("grass");
        DIRT = new BlockDirt(3, 2).c(0.5f).a(Block.f).a("dirt");
        COBBLESTONE = new Block(4, 16, Material.STONE).c(2.0f).b(10.0f).a(Block.h).a("stonebrick");
        WOOD = new Block(5, 4, Material.WOOD).c(2.0f).b(5.0f).a(Block.e).a("wood");
        SAPLING = new BlockSapling(6, 15).c(0.0f).a(Block.g).a("sapling");
        BEDROCK = new Block(7, 17, Material.STONE).c(-1.0f).b(6000000.0f).a(Block.h).a("bedrock");
        WATER = new BlockFlowing(8, Material.WATER).c(100.0f).e(3).a("water");
        STATIONARY_WATER = new BlockStationary(9, Material.WATER).c(100.0f).e(3).a("water");
        LAVA = new BlockFlowing(10, Material.LAVA).c(0.0f).a(1.0f).e(255).a("lava");
        STATIONARY_LAVA = new BlockStationary(11, Material.LAVA).c(100.0f).a(1.0f).e(255).a("lava");
        SAND = new BlockSand(12, 18).c(0.5f).a(Block.l).a("sand");
        GRAVEL = new BlockGravel(13, 19).c(0.6f).a(Block.f).a("gravel");
        GOLD_ORE = new BlockOre(14, 32).c(3.0f).b(5.0f).a(Block.h).a("oreGold");
        IRON_ORE = new BlockOre(15, 33).c(3.0f).b(5.0f).a(Block.h).a("oreIron");
        COAL_ORE = new BlockOre(16, 34).c(3.0f).b(5.0f).a(Block.h).a("oreCoal");
        LOG = new BlockLog(17).c(2.0f).a(Block.e).a("log");
        LEAVES = (BlockLeaves)new BlockLeaves(18, 52).c(0.2f).e(1).a(Block.g).a("leaves");
        SPONGE = new BlockSponge(19).c(0.6f).a(Block.g).a("sponge");
        GLASS = new BlockGlass(20, 49, Material.SHATTERABLE, false).c(0.3f).a(Block.j).a("glass");
        LAPIS_ORE = new BlockOre(21, 160).c(3.0f).b(5.0f).a(Block.h).a("oreLapis");
        LAPIS_BLOCK = new Block(22, 144, Material.STONE).c(3.0f).b(5.0f).a(Block.h).a("blockLapis");
        DISPENSER = new BlockDispenser(23).c(3.5f).a(Block.h).a("dispenser");
        SANDSTONE = new BlockSandStone(24).a(Block.h).c(0.8f).a("sandStone");
        NOTE_BLOCK = new BlockNote(25).c(0.8f).a("musicBlock");
        BED = new BlockBed(26).c(0.2f).a("bed");
        T = null;
        U = null;
        V = null;
        W = null;
        X = null;
        Y = null;
        Z = null;
        aa = null;
        WOOL = new BlockCloth().c(0.8f).a(Block.k).a("cloth");
        ac = null;
        YELLOW_FLOWER = (BlockFlower)new BlockFlower(37, 13).c(0.0f).a(Block.g).a("flower");
        RED_ROSE = (BlockFlower)new BlockFlower(38, 12).c(0.0f).a(Block.g).a("rose");
        BROWN_MUSHROOM = (BlockFlower)new BlockMushroom(39, 29).c(0.0f).a(Block.g).a(0.125f).a("mushroom");
        RED_MUSHROOM = (BlockFlower)new BlockMushroom(40, 28).c(0.0f).a(Block.g).a("mushroom");
        GOLD_BLOCK = new BlockOreBlock(41, 23).c(3.0f).b(10.0f).a(Block.i).a("blockGold");
        IRON_BLOCK = new BlockOreBlock(42, 22).c(5.0f).b(10.0f).a(Block.i).a("blockIron");
        DOUBLE_STEP = new BlockStep(43, true).c(2.0f).b(10.0f).a(Block.h).a("stoneSlab");
        STEP = new BlockStep(44, false).c(2.0f).b(10.0f).a(Block.h).a("stoneSlab");
        BRICK = new Block(45, 7, Material.STONE).c(2.0f).b(10.0f).a(Block.h).a("brick");
        TNT = new BlockTNT(46, 8).c(0.0f).a(Block.g).a("tnt");
        BOOKSHELF = new BlockBookshelf(47, 35).c(1.5f).a(Block.e).a("bookshelf");
        MOSSY_COBBLESTONE = new Block(48, 36, Material.STONE).c(2.0f).b(10.0f).a(Block.h).a("stoneMoss");
        OBSIDIAN = new BlockObsidian(49, 37).c(10.0f).b(2000.0f).a(Block.h).a("obsidian");
        TORCH = new BlockTorch(50, 80).c(0.0f).a(0.9375f).a(Block.e).a("torch");
        FIRE = (BlockFire)new BlockFire(51, 31).c(0.0f).a(1.0f).a(Block.e).a("fire");
        MOB_SPAWNER = new BlockMobSpawner(52, 65).c(5.0f).a(Block.i).a("mobSpawner");
        WOOD_STAIRS = new BlockStairs(53, Block.WOOD).a("stairsWood");
        CHEST = new BlockChest(54).c(2.5f).a(Block.e).a("chest");
        REDSTONE_WIRE = new BlockRedstoneWire(55, 164).c(0.0f).a(Block.d).a("redstoneDust");
        DIAMOND_ORE = new BlockOre(56, 50).c(3.0f).b(5.0f).a(Block.h).a("oreDiamond");
        DIAMOND_BLOCK = new BlockOreBlock(57, 24).c(5.0f).b(10.0f).a(Block.i).a("blockDiamond");
        WORKBENCH = new BlockWorkbench(58).c(2.5f).a(Block.e).a("workbench");
        CROPS = new BlockCrops(59, 88).c(0.0f).a(Block.g).a("crops");
        SOIL = new BlockSoil(60).c(0.6f).a(Block.f).a("farmland");
        FURNACE = new BlockFurnace(61, false).c(3.5f).a(Block.h).a("furnace");
        BURNING_FURNACE = new BlockFurnace(62, true).c(3.5f).a(Block.h).a(0.875f).a("furnace");
        SIGN_POST = new BlockSign(63, TileEntitySign.class, true).c(1.0f).a(Block.e).a("sign");
        WOODEN_DOOR = new BlockDoor(64, Material.WOOD).c(3.0f).a(Block.e).a("doorWood");
        LADDER = new BlockLadder(65, 83).c(0.4f).a(Block.e).a("ladder");
        RAILS = new BlockMinecartTrack(66, 128).c(0.7f).a(Block.i).a("rail");
        COBBLESTONE_STAIRS = new BlockStairs(67, Block.COBBLESTONE).a("stairsStone");
        WALL_SIGN = new BlockSign(68, TileEntitySign.class, false).c(1.0f).a(Block.e).a("sign");
        LEVER = new BlockLever(69, 96).c(0.5f).a(Block.e).a("lever");
        STONE_PLATE = new BlockPressurePlate(70, Block.STONE.textureId, EnumMobType.MOBS).c(0.5f).a(Block.h).a("pressurePlate");
        IRON_DOOR_BLOCK = new BlockDoor(71, Material.ORE).c(5.0f).a(Block.i).a("doorIron");
        WOOD_PLATE = new BlockPressurePlate(72, Block.WOOD.textureId, EnumMobType.EVERYTHING).c(0.5f).a(Block.e).a("pressurePlate");
        REDSTONE_ORE = new BlockRedstoneOre(73, 51, false).c(3.0f).b(5.0f).a(Block.h).a("oreRedstone");
        GLOWING_REDSTONE_ORE = new BlockRedstoneOre(74, 51, true).a(0.625f).c(3.0f).b(5.0f).a(Block.h).a("oreRedstone");
        REDSTONE_TORCH_OFF = new BlockRedstoneTorch(75, 115, false).c(0.0f).a(Block.e).a("notGate");
        REDSTONE_TORCH_ON = new BlockRedstoneTorch(76, 99, true).c(0.0f).a(0.5f).a(Block.e).a("notGate");
        STONE_BUTTON = new BlockButton(77, Block.STONE.textureId).c(0.5f).a(Block.h).a("button");
        SNOW = new BlockSnow(78, 66).c(0.1f).a(Block.k).a("snow");
        ICE = new BlockIce(79, 67).c(0.5f).e(3).a(Block.j).a("ice");
        SNOW_BLOCK = new BlockSnowBlock(80, 66).c(0.2f).a(Block.k).a("snow");
        CACTUS = new BlockCactus(81, 70).c(0.4f).a(Block.k).a("cactus");
        CLAY = new BlockClay(82, 72).c(0.6f).a(Block.f).a("clay");
        SUGAR_CANE_BLOCK = new BlockReed(83, 73).c(0.0f).a(Block.g).a("reeds");
        JUKEBOX = new BlockJukeBox(84, 74).c(2.0f).b(10.0f).a(Block.h).a("jukebox");
        FENCE = new BlockFence(85, 4).c(2.0f).b(5.0f).a(Block.e).a("fence");
        PUMPKIN = new BlockPumpkin(86, 102, false).c(1.0f).a(Block.e).a("pumpkin");
        NETHERRACK = new BlockBloodStone(87, 103).c(0.4f).a(Block.h).a("hellrock");
        SOUL_SAND = new BlockSlowSand(88, 104).c(0.5f).a(Block.l).a("hellsand");
        GLOWSTONE = new BlockLightStone(89, 105, Material.SHATTERABLE).c(0.3f).a(Block.j).a(1.0f).a("lightgem");
        PORTAL = (BlockPortal)new BlockPortal(90, 14).c(-1.0f).a(Block.j).a(0.75f).a("portal");
        JACK_O_LANTERN = new BlockPumpkin(91, 102, true).c(1.0f).a(Block.e).a(1.0f).a("litpumpkin");
        CAKE_BLOCK = new BlockCake(92, 121).c(0.5f).a(Block.k).a("cake");
        DIODE_OFF = new BlockDiode(93, false).c(0.0f).a(Block.e).a("diode");
        DIODE_ON = new BlockDiode(94, true).c(0.0f).a(0.625f).a(Block.e).a("diode");
        Item.byId[Block.WOOL.id] = new ItemCloth(Block.WOOL.id - 256).a("cloth");
        Item.byId[Block.LOG.id] = new ItemLog(Block.LOG.id - 256).a("log");
        Item.byId[Block.STEP.id] = new ItemStep(Block.STEP.id - 256).a("stoneSlab");
        for (int n2 = 0; n2 < 256; ++n2) {
            if (Block.byId[n2] != null && Item.byId[n2] == null) {
                Item.byId[n2] = new ItemBlock(n2 - 256);
            }
        }
        Block.r[0] = true;
    }
}
