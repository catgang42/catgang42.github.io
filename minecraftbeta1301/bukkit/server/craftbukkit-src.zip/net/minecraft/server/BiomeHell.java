// 
// Decompiled by Procyon v0.5.36
// 

package net.minecraft.server;

public class BiomeHell extends BiomeBase
{
    public BiomeHell() {
        this.r = new Class[] { EntityGhast.class, EntityPigZombie.class };
        this.s = new Class[0];
    }
}
