// 
// Decompiled by Procyon v0.5.36
// 

package joptsimple.internal;

public class ReflectionException extends RuntimeException
{
    private static final long serialVersionUID = -2L;
    
    ReflectionException(final Throwable cause) {
        super(cause.toString());
    }
}
