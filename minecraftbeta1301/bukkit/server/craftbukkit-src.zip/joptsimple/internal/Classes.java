// 
// Decompiled by Procyon v0.5.36
// 

package joptsimple.internal;

public final class Classes
{
    private Classes() {
    }
    
    public static String shortNameOf(final String className) {
        return className.substring(className.lastIndexOf(46) + 1);
    }
    
    static {
        new Classes();
    }
}
