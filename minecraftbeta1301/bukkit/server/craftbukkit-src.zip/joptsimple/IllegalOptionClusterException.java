// 
// Decompiled by Procyon v0.5.36
// 

package joptsimple;

import java.util.Collection;
import java.util.Collections;

class IllegalOptionClusterException extends OptionException
{
    private static final long serialVersionUID = -1L;
    
    IllegalOptionClusterException(final String option) {
        super(Collections.singletonList(option));
    }
    
    @Override
    public String getMessage() {
        return "Option cluster containing " + this.singleOptionMessage() + " is illegal";
    }
}
