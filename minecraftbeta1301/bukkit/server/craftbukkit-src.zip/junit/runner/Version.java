// 
// Decompiled by Procyon v0.5.36
// 

package junit.runner;

public class Version
{
    private Version() {
    }
    
    public static String id() {
        return "3.8.1";
    }
}
