// 
// Decompiled by Procyon v0.5.36
// 

package junit.runner;

import java.util.Enumeration;

public interface TestCollector
{
    Enumeration collectTests();
}
