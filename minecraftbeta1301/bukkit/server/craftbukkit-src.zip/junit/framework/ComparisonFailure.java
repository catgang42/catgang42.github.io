// 
// Decompiled by Procyon v0.5.36
// 

package junit.framework;

public class ComparisonFailure extends AssertionFailedError
{
    private String fExpected;
    private String fActual;
    
    public ComparisonFailure(final String message, final String expected, final String actual) {
        super(message);
        this.fExpected = expected;
        this.fActual = actual;
    }
    
    public String getMessage() {
        if (this.fExpected == null || this.fActual == null) {
            return Assert.format(super.getMessage(), this.fExpected, this.fActual);
        }
        int end;
        int i;
        for (end = Math.min(this.fExpected.length(), this.fActual.length()), i = 0; i < end && this.fExpected.charAt(i) == this.fActual.charAt(i); ++i) {}
        int j;
        int k;
        for (j = this.fExpected.length() - 1, k = this.fActual.length() - 1; k >= i && j >= i && this.fExpected.charAt(j) == this.fActual.charAt(k); --k, --j) {}
        String expected;
        String actual;
        if (j < i && k < i) {
            expected = this.fExpected;
            actual = this.fActual;
        }
        else {
            expected = this.fExpected.substring(i, j + 1);
            actual = this.fActual.substring(i, k + 1);
            if (i <= end && i > 0) {
                expected = "..." + expected;
                actual = "..." + actual;
            }
            if (j < this.fExpected.length() - 1) {
                expected = String.valueOf(expected) + "...";
            }
            if (k < this.fActual.length() - 1) {
                actual = String.valueOf(actual) + "...";
            }
        }
        return Assert.format(super.getMessage(), expected, actual);
    }
}
