// 
// Decompiled by Procyon v0.5.36
// 

package junit.framework;

public class AssertionFailedError extends Error
{
    public AssertionFailedError() {
    }
    
    public AssertionFailedError(final String message) {
        super(message);
    }
}
