// 
// Decompiled by Procyon v0.5.36
// 

package junit.framework;

import java.util.Enumeration;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Vector;

public class TestSuite implements Test
{
    private Vector fTests;
    private String fName;
    static /* synthetic */ Class class$0;
    static /* synthetic */ Class class$1;
    
    public TestSuite() {
        this.fTests = new Vector(10);
    }
    
    public TestSuite(final Class theClass, final String name) {
        this(theClass);
        this.setName(name);
    }
    
    public TestSuite(final Class theClass) {
        this.fTests = new Vector(10);
        this.fName = theClass.getName();
        try {
            getTestConstructor(theClass);
        }
        catch (NoSuchMethodException e) {
            this.addTest(warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()"));
            return;
        }
        if (!Modifier.isPublic(theClass.getModifiers())) {
            this.addTest(warning("Class " + theClass.getName() + " is not public"));
            return;
        }
        Class superClass = theClass;
        final Vector names = new Vector();
        Label_0160: {
            break Label_0160;
            Class class$0;
            do {
                final Method[] methods = superClass.getDeclaredMethods();
                for (int i = 0; i < methods.length; ++i) {
                    this.addTestMethod(methods[i], names, theClass);
                }
                superClass = superClass.getSuperclass();
                if ((class$0 = TestSuite.class$0) == null) {
                    try {
                        class$0 = (TestSuite.class$0 = Class.forName("junit.framework.Test"));
                    }
                    catch (ClassNotFoundException ex) {
                        throw new NoClassDefFoundError(ex.getMessage());
                    }
                }
            } while (class$0.isAssignableFrom(superClass));
        }
        if (this.fTests.size() == 0) {
            this.addTest(warning("No tests found in " + theClass.getName()));
        }
    }
    
    public TestSuite(final String name) {
        this.fTests = new Vector(10);
        this.setName(name);
    }
    
    public void addTest(final Test test) {
        this.fTests.addElement(test);
    }
    
    public void addTestSuite(final Class testClass) {
        this.addTest(new TestSuite(testClass));
    }
    
    private void addTestMethod(final Method m, final Vector names, final Class theClass) {
        final String name = m.getName();
        if (names.contains(name)) {
            return;
        }
        if (!this.isPublicTestMethod(m)) {
            if (this.isTestMethod(m)) {
                this.addTest(warning("Test method isn't public: " + m.getName()));
            }
            return;
        }
        names.addElement(name);
        this.addTest(createTest(theClass, name));
    }
    
    public static Test createTest(final Class theClass, final String name) {
        Constructor constructor;
        try {
            constructor = getTestConstructor(theClass);
        }
        catch (NoSuchMethodException e4) {
            return warning("Class " + theClass.getName() + " has no public constructor TestCase(String name) or TestCase()");
        }
        Object test;
        try {
            if (constructor.getParameterTypes().length == 0) {
                test = constructor.newInstance(new Object[0]);
                if (test instanceof TestCase) {
                    ((TestCase)test).setName(name);
                }
            }
            else {
                test = constructor.newInstance(name);
            }
        }
        catch (InstantiationException e) {
            return warning("Cannot instantiate test case: " + name + " (" + exceptionToString(e) + ")");
        }
        catch (InvocationTargetException e2) {
            return warning("Exception in constructor: " + name + " (" + exceptionToString(e2.getTargetException()) + ")");
        }
        catch (IllegalAccessException e3) {
            return warning("Cannot access test case: " + name + " (" + exceptionToString(e3) + ")");
        }
        return (Test)test;
    }
    
    private static String exceptionToString(final Throwable t) {
        final StringWriter stringWriter = new StringWriter();
        final PrintWriter writer = new PrintWriter(stringWriter);
        t.printStackTrace(writer);
        return stringWriter.toString();
    }
    
    public int countTestCases() {
        int count = 0;
        final Enumeration e = this.tests();
        while (e.hasMoreElements()) {
            final Test test = e.nextElement();
            count += test.countTestCases();
        }
        return count;
    }
    
    public static Constructor getTestConstructor(final Class theClass) throws NoSuchMethodException {
        final Class[] array = { null };
        final int n = 0;
        Class class$1;
        if ((class$1 = TestSuite.class$1) == null) {
            try {
                class$1 = (TestSuite.class$1 = Class.forName("java.lang.String"));
            }
            catch (ClassNotFoundException ex) {
                throw new NoClassDefFoundError(ex.getMessage());
            }
        }
        array[n] = class$1;
        final Class[] args = array;
        try {
            return theClass.getConstructor((Class[])args);
        }
        catch (NoSuchMethodException ex2) {
            return theClass.getConstructor((Class[])new Class[0]);
        }
    }
    
    private boolean isPublicTestMethod(final Method m) {
        return this.isTestMethod(m) && Modifier.isPublic(m.getModifiers());
    }
    
    private boolean isTestMethod(final Method m) {
        final String name = m.getName();
        final Class[] parameters = m.getParameterTypes();
        final Class returnType = m.getReturnType();
        return parameters.length == 0 && name.startsWith("test") && returnType.equals(Void.TYPE);
    }
    
    public void run(final TestResult result) {
        final Enumeration e = this.tests();
        while (e.hasMoreElements() && !result.shouldStop()) {
            final Test test = e.nextElement();
            this.runTest(test, result);
        }
    }
    
    public void runTest(final Test test, final TestResult result) {
        test.run(result);
    }
    
    public Test testAt(final int index) {
        return this.fTests.elementAt(index);
    }
    
    public int testCount() {
        return this.fTests.size();
    }
    
    public Enumeration tests() {
        return this.fTests.elements();
    }
    
    public String toString() {
        if (this.getName() != null) {
            return this.getName();
        }
        return super.toString();
    }
    
    public void setName(final String name) {
        this.fName = name;
    }
    
    public String getName() {
        return this.fName;
    }
    
    private static Test warning(final String message) {
        return new TestCase("warning") {
            private final /* synthetic */ String val$message = val$message;
            
            protected void runTest() {
                Assert.fail(this.val$message);
            }
        };
    }
}
